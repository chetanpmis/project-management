
'use client';

import { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronUp, ChevronDown, Eye, Trash2, Edit2, Users2, Search, ListTodo } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

import taskService from '@/services/task.service';
import { cn } from '@/lib/utils';
import { hasPermission } from '@/lib/permissions';
import useAuthStore from '@/store/auth-store';
import { TaskStatusBadge, PriorityBadge } from '@/components/common/StatusBadges';
import { TableSkeleton } from '@/components/common/Skeletons';
import EmptyState from '@/components/feedback/EmptyState';
import { ConfirmDialog, SuccessDialog, ErrorDialog, useMutationFeedback } from '@/components/common/AppDialogs';
import Pagination, { usePagedList } from '@/components/common/Pagination';

import {
  TASK_STATUS_CONFIG,
  PRIORITY_CONFIG,
} from '@/lib/statusConfig';

export default function TasksTable({
  tasks = [],
  isLoading = false,
  onTaskDeleted,
  onEdit,
  projectId,
  canEdit = false,
  canDelete = false,
}) {
  const router = useRouter();
  const { user } = useAuthStore();
  const feedback = useMutationFeedback();

  const [sortField, setSortField] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const toggleSort = (field) => {
    if (sortField === field) {
      setSortOrder((o) => (o === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const filteredTasks = useMemo(() => {
    let result = [...tasks];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter((t) => t.title?.toLowerCase().includes(q) || t.tags?.some((tag) => tag.toLowerCase().includes(q)));
    }
    if (statusFilter) result = result.filter((t) => t.status === statusFilter);
    if (priorityFilter) result = result.filter((t) => t.priority === priorityFilter);

    result.sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];
      if (sortField === 'title') {
        aVal = a.title?.toLowerCase() || '';
        bVal = b.title?.toLowerCase() || '';
      } else if (['startDate', 'dueDate', 'createdAt'].includes(sortField)) {
        aVal = aVal ? new Date(aVal) : new Date(0);
        bVal = bVal ? new Date(bVal) : new Date(0);
      } else if (sortField === 'assigneeCount') {
        aVal = a.assignees?.length || 0;
        bVal = b.assignees?.length || 0;
      }
      if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [tasks, searchQuery, statusFilter, priorityFilter, sortField, sortOrder]);

  const { paged, total, safePage } = usePagedList(filteredTasks, page, pageSize);

  const canEditTask = (task) => canEdit || hasPermission(task, user?.id, 'task.edit');
  const canDeleteTask = (task) => canDelete || hasPermission(task, user?.id, 'task.delete');

  const isOverdue = (task) => task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed';
  const isDone = (task) => task.status === 'completed';

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await feedback.run(taskService.deleteTask(deleteTarget._id), `"${deleteTarget.title}" was deleted.`);
      onTaskDeleted?.(deleteTarget._id);
    } catch {
    } finally {
      setIsDeleting(false);
      setDeleteTarget(null);
    }
  };

  const getStatusBadge = (status) => {
    const config = TASK_STATUS_CONFIG[status] || { badge: '', dot: '', hex: '' };
    return {
      badge: config.badge,
      dot: config.dot,
      hex: config.hex,
    };
  };

  const getPriorityBadge = (priority) => {
    const config = PRIORITY_CONFIG[priority] || { badge: '', hex: '' };
    return {
      badge: config.badge,
      hex: config.hex,
    };
  };

  const getAssignedTooltip = (task) => {
    if (task.assignees?.length <= 3) return null;
    const more = task.assignees.slice(3);
    return more.map((a, i) => (
      <div key={i} className="bg-popover text-popover-foreground p-2 rounded shadow-sm">
        <p className="font-medium">{a.name}</p>
        <p className="text-xs text-muted-foreground">{a.email}</p>
      </div>
    ));
  };

  const handleAssigneeClick = (assignee) => {
    router.push(`/users/${assignee._id}`);
  };

  const SortHead = ({ field, children, className }) => (
    <TableHead className={className}>
      <button type="button" onClick={() => toggleSort(field)} className="flex items-center gap-1 hover:text-foreground">
        {children}
        {sortField === field && (sortOrder === 'asc' ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />)}
      </button>
    </TableHead>
  );

  const hasActiveFilters = !!(searchQuery || statusFilter || priorityFilter);

  return (
    <>
      <div className="space-y-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tasks by title or tags…"
              className="pl-9 h-10"
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
            />
          </div>
          <div className="flex gap-2">
            <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
              <SelectTrigger className="w-[140px] h-10">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All status</SelectItem>
                <SelectItem value="todo">To do</SelectItem>
                <SelectItem value="in-progress">In progress</SelectItem>
                <SelectItem value="review">In review</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>

            <Select value={priorityFilter} onValueChange={(v) => { setPriorityFilter(v); setPage(1); }}>
              <SelectTrigger className="w-[140px] h-10">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All priority</SelectItem>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setStatusFilter(''); setPriorityFilter(''); setSearchQuery(''); setPage(1); }}
            >
              Clear filters
            </Button>
          )}
        </div>
      </div>

      {isLoading ? (
        <TableSkeleton rows={8} columns={8} />
      ) : filteredTasks.length === 0 ? (
        <EmptyState
          compact={tasks.length > 0}
          icon={<ListTodo className="h-8 w-8" />}
          title={tasks.length === 0 ? 'No tasks yet' : 'No matching tasks'}
          description={tasks.length === 0 ? 'Add the first task to get moving.' : 'Try adjusting your search or filters.'}
        />
      ) : (
        <div className="rounded-2xl border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <SortHead field="title">Title</SortHead>
                <SortHead field="status" className="w-[110px]">Status</SortHead>
                <SortHead field="priority" className="w-[100px]">Priority</SortHead>
                <SortHead field="startDate" className="w-[130px]">Start date</SortHead>
                <SortHead field="dueDate" className="w-[130px]">Due date</SortHead>
                <TableHead className="w-[110px]">Assigned</TableHead>
                <TableHead className="w-[100px]">Watchers</TableHead>
                <TableHead className="w-[100px] text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paged.map((task) => (
                <TableRow key={task._id} className="group hover:bg-muted/50">
                  <TableCell>
                    <button
                      onClick={() => router.push(`/tasks/${task._id}`)}
                      className={cn(
                        'font-medium text-left hover:underline',
                        isDone(task) && 'line-through text-muted-foreground',
                        isOverdue(task) && 'text-red-600 font-semibold'
                      )}
                    >
                      {task.title}
                    </button>
                  </TableCell>
                  <TableCell>
                    <TaskStatusBadge
                      status={isOverdue(task) ? 'overdue' : task.status}
                      badgeClassName={getStatusBadge(task.status).badge}
                      dotClassName={getStatusBadge(task.status).dot}
                      hex={getStatusBadge(task.status).hex}
                    />
                  </TableCell>
                  <TableCell>
                    <PriorityBadge
                      priority={task.priority}
                      badgeClassName={getPriorityBadge(task.priority).badge}
                      hex={getPriorityBadge(task.priority).hex}
                    />
                  </TableCell>
                  <TableCell className="text-sm">
                    {task.startDate ? new Date(task.startDate).toLocaleDateString() : <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell>
                    {task.dueDate ? (
                      <span className={cn('text-sm', isOverdue(task) && 'text-red-600 font-semibold', isDone(task) && 'line-through text-muted-foreground')}>
                        {new Date(task.dueDate).toLocaleDateString()}
                      </span>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {task.assignees?.length > 0 ? (
                      <div className="flex -space-x-2">
                        {task.assignees.slice(0, 3).map((a) => (
                          <Avatar
                            key={a._id}
                            className="h-7 w-7 border-2 border-background cursor-pointer"
                            onClick={() => handleAssigneeClick(a)}
                          >
                            <AvatarFallback className="text-xs">{a.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                          </Avatar>
                        ))}
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">Unassigned</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {task.watchers?.length > 0 ? (
                      <div className="flex items-center gap-1">
                        <Users2 className="h-3.5 w-3.5 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">{task.watchers.length}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      <Button variant="ghost" size="icon" onClick={() => router.push(`/tasks/${task._id}`)} title="View task">
                        <Eye className="h-4 w-4 text-blue-600" />
                      </Button>
                      {canEditTask(task) && (
                        <Button variant="ghost" size="icon" onClick={() => onEdit?.(task)} title="Edit task">
                          <Edit2 className="h-4 w-4 text-amber-600" />
                        </Button>
                      )}
                      {canDeleteTask(task) && (
                        <Button variant="ghost" size="icon" onClick={() => setDeleteTarget(task)} title="Delete task">
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <Pagination page={safePage} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={(n) => { setPageSize(n); setPage(1); }} />
        </div>
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        title="Delete task?"
        description={`"${deleteTarget?.title}" will be permanently removed. This can't be undone.`}
        confirmLabel="Delete"
        loading={isDeleting}
        onConfirm={handleConfirmDelete}
      />

      <SuccessDialog {...feedback.successProps} title="Task deleted" />
      <ErrorDialog {...feedback.errorProps} title="Couldn't delete task" />
    </>
  );
}
