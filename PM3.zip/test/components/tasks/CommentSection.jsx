'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Loader2, Send, Trash2, CornerDownRight, MessageSquare } from 'lucide-react';
import commentService from '@/services/comment.service';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const initials = (name = '') => name.slice(0, 2).toUpperCase();
const formatTime = (value) => new Date(value).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });

function ReplyBox({ commentId, taskId, onDone }) {
  const [text, setText] = useState('');
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: () => commentService.addReply(commentId, text.trim()),
    onSuccess: () => {
      setText('');
      queryClient.invalidateQueries({ queryKey: ['comments', taskId] });
      onDone?.();
    },
  });

  return (
    <div className="flex gap-2 mt-2">
      <Textarea
        rows={1}
        placeholder="Write a reply..."
        className="text-sm min-h-[36px]"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            if (text.trim()) mutation.mutate();
          }
        }}
      />
      <Button size="sm" variant="outline" disabled={!text.trim() || mutation.isPending} onClick={() => mutation.mutate()}>
        {mutation.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
      </Button>
    </div>
  );
}

function CommentItem({ comment, taskId, currentUserId }) {
  const [showReplyBox, setShowReplyBox] = useState(false);
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: () => commentService.deleteComment(comment._id),
    onMutate: async () => {
      await queryClient.cancelQueries({ queryKey: ['comments', taskId] });
      const previous = queryClient.getQueryData(['comments', taskId]);
      queryClient.setQueryData(['comments', taskId], (old) => {
        if (!old) return old;
        return { ...old, data: old.data.filter((c) => c._id !== comment._id) };
      });
      return { previous };
    },
    onError: (err, vars, context) => {
      if (context?.previous) queryClient.setQueryData(['comments', taskId], context.previous);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['comments', taskId] }),
  });

  const canDelete = comment.author?._id === currentUserId;
  const isOptimistic = comment._optimistic;

  return (
    <div className={`flex gap-3 ${isOptimistic ? 'opacity-60' : ''}`}>
      <Avatar className="h-8 w-8 shrink-0">
        <AvatarFallback className="text-xs">{initials(comment.author?.name)}</AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="rounded-lg bg-muted/50 px-3 py-2">
          <div className="flex items-center justify-between gap-2">
            <span className="font-medium text-sm capitalize">{comment.author?.name}</span>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {isOptimistic ? <Loader2 className="h-3 w-3 animate-spin" /> : <span>{formatTime(comment.createdAt)}</span>}
              {comment.edited && <span className="italic">(edited)</span>}
            </div>
          </div>
          <p className="text-sm mt-1 whitespace-pre-wrap">{comment.content}</p>
        </div>

        {!isOptimistic && (
          <div className="flex items-center gap-3 mt-1 pl-1 text-xs text-muted-foreground">
            <button onClick={() => setShowReplyBox((v) => !v)} className="flex items-center gap-1 hover:text-foreground">
              <CornerDownRight className="h-3 w-3" /> Reply
            </button>
            {canDelete && (
              <button onClick={() => deleteMutation.mutate()} disabled={deleteMutation.isPending} className="flex items-center gap-1 hover:text-red-500">
                <Trash2 className="h-3 w-3" /> Delete
              </button>
            )}
          </div>
        )}

        {showReplyBox && <ReplyBox commentId={comment._id} taskId={taskId} onDone={() => setShowReplyBox(false)} />}

        {comment.replies?.length > 0 && (
          <div className="mt-2.5 space-y-2.5 pl-4 border-l-2 border-muted">
            {comment.replies.map((reply, i) => (
              <div key={reply._id || i} className="flex gap-2.5">
                <Avatar className="h-6 w-6 shrink-0">
                  <AvatarFallback className="text-[10px]">{initials(reply.author?.name)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="rounded-lg bg-muted/30 px-2.5 py-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-medium text-xs capitalize">{reply.author?.name}</span>
                      <span className="text-[11px] text-muted-foreground">{formatTime(reply.createdAt)}</span>
                    </div>
                    <p className="text-xs mt-0.5 whitespace-pre-wrap">{reply.content}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function CommentSection({ taskId, currentUserId }) {
  const [newComment, setNewComment] = useState('');
  const queryClient = useQueryClient();

  // Debounced background refresh: keeps comments in sync with anyone else
  // commenting on the task, without the person having to reload the page.
  const { data, isLoading } = useQuery({
    queryKey: ['comments', taskId],
    queryFn: () => commentService.getComments(taskId),
    enabled: !!taskId,
    refetchInterval: 8000,
    refetchIntervalInBackground: false,
  });

  const comments = data?.data || [];

  const postMutation = useMutation({
    mutationFn: (content) => commentService.addComment(taskId, content),
    onMutate: async (content) => {
      await queryClient.cancelQueries({ queryKey: ['comments', taskId] });
      const previous = queryClient.getQueryData(['comments', taskId]);
      const optimisticComment = {
        _id: `optimistic-${Date.now()}`,
        content,
        author: { _id: currentUserId, name: 'You' },
        createdAt: new Date().toISOString(),
        replies: [],
        _optimistic: true,
      };
      queryClient.setQueryData(['comments', taskId], (old) => ({
        ...(old || { data: [] }),
        data: [...(old?.data || []), optimisticComment],
      }));
      setNewComment('');
      return { previous };
    },
    onError: (err, vars, context) => {
      if (context?.previous) queryClient.setQueryData(['comments', taskId], context.previous);
    },
    onSettled: () => queryClient.invalidateQueries({ queryKey: ['comments', taskId] }),
  });

  return (
    <div className="border rounded-xl p-6 space-y-4">
      <h2 className="text-lg font-semibold flex items-center gap-2 capitalize">
        <MessageSquare className="h-4 w-4 text-muted-foreground" />
        Comments {comments.length > 0 && <span className="text-muted-foreground text-sm">({comments.length})</span>}
      </h2>

      {isLoading ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading Comments...
        </div>
      ) : (
        <div className="space-y-4">
          {comments.map((c) => (
            <CommentItem key={c._id} comment={c} taskId={taskId} currentUserId={currentUserId} />
          ))}
          {!comments.length && <p className="text-sm text-muted-foreground">No Comments Yet — Be The First To Say Something.</p>}
        </div>
      )}

      <div className="flex gap-2 pt-2 border-t">
        <Textarea
          rows={2}
          placeholder="Write a comment..."
          className="text-base"
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              if (newComment.trim()) postMutation.mutate(newComment.trim());
            }
          }}
        />
        <Button
          size="default"
          className="h-fit self-end"
          disabled={!newComment.trim() || postMutation.isPending}
          onClick={() => newComment.trim() && postMutation.mutate(newComment.trim())}
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}