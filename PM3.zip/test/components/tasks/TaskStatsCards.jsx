'use client';

import { useQuery } from '@tanstack/react-query';
import {
  CheckCircle2,
  AlertCircle,
  Eye,
  ClipboardList,
  Clock,
} from 'lucide-react';
import taskService from '@/services/task.service';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

export default function TaskStatsCards({ projectId = null }) {
  const { data: statsData, isLoading, error } = useQuery({
    queryKey: ['task-stats', projectId],
    queryFn: () => taskService.getMyTaskStats({ projectId }),
    staleTime: 2 * 60 * 1000,
    retry: 1,
  });

  const stats = statsData?.data || {};

  const statCards = [
    {
      id: 'total',
      title: 'Total Tasks',
      value: stats.total || 0,
      icon: ClipboardList,
      color: 'bg-blue-50 text-blue-600',
    },
    {
      id: 'pending',
      title: 'Pending',
      value: stats.pending || 0,
      icon: Clock,
      color: 'bg-amber-50 text-amber-600',
    },
    {
      id: 'completed',
      title: 'Completed',
      value: stats.completed || 0,
      icon: CheckCircle2,
      color: 'bg-green-50 text-green-600',
    },
    {
      id: 'overdue',
      title: 'Overdue',
      value: stats.overdue || 0,
      icon: AlertCircle,
      color: 'bg-red-50 text-red-600',
    },
    {
      id: 'watching',
      title: 'Watching',
      value: stats.watching || 0,
      icon: Eye,
      color: 'bg-purple-50 text-purple-600',
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        {[1, 2, 3, 4, 5].map((i) => (
          <Skeleton key={i} className="h-32 rounded-lg" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-red-600 text-center py-8">
        Could not load statistics
      </div>
    );
  }

  const completionRate = stats.total > 0
    ? Math.round((stats.completed / stats.total) * 100)
    : 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
      {statCards.map((card) => {
        const Icon = card.icon;

        return (
          <Card
            key={card.id}
            className={cn(
              'relative overflow-hidden transition-all hover:shadow-lg',
              card.id === 'overdue' && stats.overdue > 0 && 'border-red-200'
            )}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {card.title}
                </CardTitle>
                <div className={cn('p-2 rounded-lg', card.color)}>
                  <Icon className="h-5 w-5" />
                </div>
              </div>
            </CardHeader>

            <CardContent className="pt-0">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold tracking-tight">
                  {card.value}
                </span>
                {card.id === 'completed' && stats.total > 0 && (
                  <span className="text-sm text-muted-foreground">
                    {completionRate}%
                  </span>
                )}
              </div>

              {/* Overdue Alert */}
              {card.id === 'overdue' && stats.overdue > 0 && (
                <div className="mt-3 flex items-center gap-2 text-xs text-red-700 bg-red-50 p-2 rounded">
                  <AlertCircle className="h-3.5 w-3.5" />
                  Action required
                </div>
              )}
            </CardContent>

            {/* Decorative background icon */}
            <div className={cn('absolute -right-6 -bottom-6 opacity-5', card.color)}>
              <Icon className="h-20 w-20" />
            </div>
          </Card>
        );
      })}
    </div>
  );
}