'use client';

import { motion } from 'framer-motion';
import { Users, Clock, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const StatCard = ({ title, value, icon: Icon, color }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -8 }}
    transition={{ duration: 0.2 }}
  >
    <Card className="h-full overflow-hidden relative">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={cn('p-2.5 rounded-xl bg-white shadow-sm', color)}>
          <Icon className="h-5 w-5" />
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="flex items-baseline gap-2">
          <span className="text-4xl font-bold tracking-tight">{value}</span>
        </div>
      </CardContent>

      {/* Decorative background icon - EXACT same as TaskStatsCards */}
      <div className={cn('absolute -right-6 -bottom-6 opacity-5', color)}>
        <Icon className="h-20 w-20" />
      </div>
    </Card>
  </motion.div>
);

export default function ProjectStatsCards({ stats }) {
  const cards = [
    { title: 'Total Projects', value: stats.total || 0, icon: Users, color: 'text-blue-600' },
    { title: 'Planning', value: stats.planning || 0, icon: Clock, color: 'text-blue-600' },
    { title: 'Active', value: stats.active || 0, icon: CheckCircle2, color: 'text-emerald-600' },
    { title: 'Completed', value: stats.completed || 0, icon: CheckCircle2, color: 'text-emerald-600' },
    { title: 'Cancelled', value: stats.cancelled || 0, icon: XCircle, color: 'text-red-600' },
    {
      title: 'Completion',
      value: `${stats.completionRate || 0}%`,
      icon: AlertTriangle,
      color: 'text-purple-600',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {cards.map((card, i) => (
        <StatCard key={i} {...card} />
      ))}
    </div>
  );
}