"use client";
import { useState, useCallback, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Gantt, ViewMode } from "gantt-task-react";
import "gantt-task-react/dist/index.css";
import { Eye, User, ExternalLink, ArrowUpDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import reportsService from "@/services/report.service";

const priorityRank = { low: 0, medium: 1, high: 2, critical: 3 };
const statusColor = {
  todo: { backgroundColor: "#9ca3af", backgroundSelectedColor: "#6b7280" },
  "in-progress": { backgroundColor: "#3b82f6", backgroundSelectedColor: "#1e40af" },
  review: { backgroundColor: "#f59e0b", backgroundSelectedColor: "#b45309" },
  completed: { backgroundColor: "#10b981", backgroundSelectedColor: "#047857" },
  overdue: { backgroundColor: "#ef4444", backgroundSelectedColor: "#dc2626" },
};
const milestoneStyle = {
  backgroundColor: "#8b5cf6",
  backgroundSelectedColor: "#7c3aed",
};
const SCOPE_OPTIONS = [
  { value: "all", label: "All tasks" },
  { value: "mine", label: "Assigned to me", icon: User },
  { value: "watching", label: "Watching", icon: Eye },
];
const SORT_OPTIONS = [
  { value: "startDate", label: "Start date" },
  { value: "dueDate", label: "Due date" },
  { value: "priority", label: "Priority" },
  { value: "progress", label: "Progress" },
  { value: "title", label: "Title" },
];
const VIEW_MODES = [
  { value: ViewMode.Day, label: "Day" },
  { value: ViewMode.Week, label: "Week" },
  { value: ViewMode.Month, label: "Month" },
  { value: ViewMode.Year, label: "Year" },
];

function CustomTaskListTable({
  rowHeight,
  rowWidth,
  tasks,
  fontFamily,
  fontSize,
  taskMeta,
  onViewTask,
}) {
  return (
    <div style={{ fontFamily, fontSize }}>
      {tasks.map((task) => {
        const meta = taskMeta[task.id] || {};
        const isMilestoneRow = task.type === "project";
        return (
          <div
            key={task.id}
            style={{ height: rowHeight, width: rowWidth }}
            className={cn(
              "flex items-center gap-1.5 px-2 border-b border-r truncate",
              isMilestoneRow ? "bg-muted/40 font-medium" : "bg-white pl-6",
            )}
          >
            <span className="text-sm truncate">{task.name}</span>
            {!isMilestoneRow && meta.isAssignedToMe && (
              <Badge
                variant="outline"
                className="h-5 gap-1 px-1 text-[9px] border-blue-200 text-blue-700 bg-blue-50 shrink-0"
              >
                <User className="h-2.5 w-2.5" />
              </Badge>
            )}
            {!isMilestoneRow && meta.isWatcher && (
              <Badge
                variant="outline"
                className="h-5 gap-1 px-1 text-[9px] border-purple-200 text-purple-700 bg-purple-50 shrink-0"
              >
                <Eye className="h-2.5 w-2.5" />
              </Badge>
            )}
            {isMilestoneRow && (
              <span className="ml-auto text-[10px] text-muted-foreground shrink-0">
                {task.taskCount ?? 0} tasks · {Math.round(task.progress ?? 0)}%
              </span>
            )}
            {!isMilestoneRow && (
              <button
                type="button"
                title="Open task"
                className="ml-auto shrink-0 text-muted-foreground hover:text-foreground"
                onClick={(e) => {
                  e.stopPropagation();
                  onViewTask?.(meta.taskId);
                }}
              >
                <ExternalLink className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}

function CustomTaskListHeader({
  headerHeight,
  rowWidth,
  fontFamily,
  fontSize,
}) {
  return (
    <div
      style={{ height: headerHeight, width: rowWidth, fontFamily, fontSize }}
      className="flex items-center px-2 font-medium text-muted-foreground border-b border-r bg-muted/30"
    >
      Task
    </div>
  );
}

export default function ProjectGanttChart({ projectId }) {
  const router = useRouter();

  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [scopeFilter, setScopeFilter] = useState("all"); // all | mine | watching
  const [sortBy, setSortBy] = useState("startDate");
  const [sortDir, setSortDir] = useState("asc");
  const [viewMode, setViewMode] = useState(ViewMode.Week);
  const [collapsed, setCollapsed] = useState({}); // { [milestoneId]: true }

  // Data state – fetched once via useEffect (no useMemo for async)
  const [projectState, setProjectState] = useState(null);
  const [milestonesState, setMilestonesState] = useState([]);
  const [unassignedTasksState, setUnassignedTasksState] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const handleViewTask = useCallback(
    (taskId) => {
      if (!taskId) return;
      router.push(`/tasks/${taskId}`);
    },
    [router],
  );

  // Fetch data on mount + projectId change (useEffect only – async allowed)
  useEffect(() => {
    if (!projectId) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    let mounted = true;

    const fetchData = async () => {
      try {
        const response = await reportsService.getProjectGantt(projectId);
        const ganttData = response.data;

        if (mounted) {
          setProjectState(ganttData.project || null);
          setMilestonesState(ganttData.milestones || []);
          setUnassignedTasksState(ganttData.unassignedTasks || []);
        }
      } catch (err) {
        console.error("Failed to load gantt data", err);
        if (mounted) {
          setProjectState(null);
          setMilestonesState([]);
          setUnassignedTasksState([]);
        }
      } finally {
        if (mounted) setIsLoading(false);
      }
    };

    fetchData();

    return () => {
      mounted = false;
    };
  }, [projectId]);

  // flatten all tasks (milestone + unassigned) so filters/sorting run once
  const allTasks = useMemo(() => {
    const fromMilestones = milestonesState.flatMap((m) => m.tasks || []);
    return [...fromMilestones, ...unassignedTasksState];
  }, [milestonesState, unassignedTasksState]);

  const filterTask = useCallback(
    (t) => {
      if (statusFilter !== "all" && t.status !== statusFilter) return false;
      if (priorityFilter !== "all" && t.priority !== priorityFilter)
        return false;
      if (scopeFilter === "mine" && !t.isAssignedToMe) return false;
      if (scopeFilter === "watching" && !t.isWatcher) return false;
      if (!t.startDate || !t.dueDate) return false;
      return true;
    },
    [statusFilter, priorityFilter, scopeFilter],
  );

  const sortTasks = useCallback(
    (list) => {
      return [...list].sort((a, b) => {
        let res = 0;
        if (sortBy === "priority")
          res =
            (priorityRank[a.priority] ?? 0) - (priorityRank[b.priority] ?? 0);
        else if (sortBy === "progress")
          res = (a.progress ?? 0) - (b.progress ?? 0);
        else if (sortBy === "title")
          res = (a.title || "").localeCompare(b.title || "");
        else res = new Date(a[sortBy] || 0) - new Date(b[sortBy] || 0);
        return sortDir === "asc" ? res : -res;
      });
    },
    [sortBy, sortDir],
  );

  const taskMeta = useMemo(() => {
    const map = {};
    allTasks.forEach((t) => {
      map[t._id] = {
        isAssignedToMe: t.isAssignedToMe,
        isWatcher: t.isWatcher,
        taskId: t._id,
      };
    });
    return map;
  }, [allTasks]);

  const { ganttTasks, visibleMilestoneCount } = useMemo(() => {
    const items = [];
    let visibleMilestones = 0;
    if (projectState?.startDate && projectState?.endDate) {
      items.push({
        id: `project-${projectState._id}`,
        type: "project",
        name: projectState.name,
        start: new Date(projectState.startDate),
        end: new Date(projectState.endDate),
        progress: projectState.progress ?? 0,
        hideChildren: false,
        styles: {
          backgroundColor: "#6366f1",
          backgroundSelectedColor: "#4f46e5",
        },
      });
    }
    const addMilestoneGroup = (
      milestoneId,
      name,
      startDate,
      dueDate,
      progress,
      taskCount,
      tasks,
    ) => {
      const filtered = sortTasks(tasks.filter(filterTask));
      if (filtered.length === 0 && taskCount > 0) return; // filtered out entirely, skip empty group
      if (!startDate || !dueDate) return;
      visibleMilestones += 1;
      const isCollapsed = !!collapsed[milestoneId];
      items.push({
        id: `milestone-${milestoneId}`,
        type: "project",
        name: `\u25C6 ${name}`,
        start: new Date(startDate),
        end: new Date(dueDate),
        progress,
        taskCount,
        hideChildren: isCollapsed,
        styles: milestoneStyle,
      });
      if (isCollapsed) return;
      filtered.forEach((t) => {
        items.push({
          id: t._id,
          type: "task",
          name: t.title,
          start: new Date(t.startDate),
          end: new Date(t.dueDate),
          progress: t.progress ?? 0,
          project: `milestone-${milestoneId}`,
          dependencies: t.dependencies || [],
          styles: statusColor[t.status] || statusColor.todo,
        });
      });
    };
    milestonesState.forEach((m) =>
      addMilestoneGroup(
        m._id,
        m.name,
        m.startDate,
        m.dueDate,
        m.progress,
        m.taskCount,
        m.tasks || [],
      ),
    );
    const filteredUnassigned = sortTasks(
      unassignedTasksState.filter(filterTask),
    );
    if (filteredUnassigned.length > 0) {
      filteredUnassigned.forEach((t) => {
        items.push({
          id: t._id,
          type: "task",
          name: t.title,
          start: new Date(t.startDate),
          end: new Date(t.dueDate),
          progress: t.progress ?? 0,
          dependencies: t.dependencies || [],
          styles: statusColor[t.status] || statusColor.todo,
        });
      });
    }
    return { ganttTasks: items, visibleMilestoneCount: visibleMilestones };
  }, [
    projectState,
    milestonesState,
    unassignedTasksState,
    collapsed,
    filterTask,
    sortTasks,
  ]);

  const toggleSortDir = useCallback(() => {
    setSortDir((d) => (d === "asc" ? "desc" : "asc"));
  }, []);

  const handleExpanderClick = useCallback((task) => {
    if (task.type !== "project" || !task.id.startsWith("milestone-")) return;
    const milestoneId = task.id.replace("milestone-", "");
    setCollapsed((prev) => ({ ...prev, [milestoneId]: !prev[milestoneId] }));
  }, []);

  const handleClick = useCallback(
    (task) => {
      if (task.type !== "task") return;
      const original = allTasks.find((t) => t._id === task.id);
      if (original) {
        // onTaskClick is not defined in original code – removed
      }
    },
    [allTasks],
  );

  const hasVisibleRows =
    ganttTasks.some((t) => t.type === "task") || visibleMilestoneCount > 0;

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Filter / sort bar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center rounded-md border p-0.5">
          {SCOPE_OPTIONS.map((opt) => {
            const Icon = opt.icon;
            return (
              <Button
                key={opt.value}
                variant={scopeFilter === opt.value ? "default" : "ghost"}
                size="sm"
                className="h-8 gap-1.5"
                onClick={() => setScopeFilter(opt.value)}
              >
                {Icon && <Icon className="h-3.5 w-3.5" />}
                {opt.label}
              </Button>
            );
          })}
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="h-9 rounded-md border bg-background px-2 text-sm capitalize"
        >
          <option value="all">All statuses</option>
          {Object.keys(statusColor).map((s) => (
            <option key={s} value={s} className="capitalize">
              {s.replace("-", " ")}
            </option>
          ))}
        </select>
        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
          className="h-9 rounded-md border bg-background px-2 text-sm capitalize"
        >
          <option value="all">All priorities</option>
          {Object.keys(priorityRank).map((p) => (
            <option key={p} value={p} className="capitalize">
              {p}
            </option>
          ))}
        </select>
        <div className="flex items-center gap-1">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="h-9 rounded-md border bg-background px-2 text-sm"
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                Sort: {o.label}
              </option>
            ))}
          </select>
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={toggleSortDir}
            title="Toggle sort direction"
          >
            <ArrowUpDown
              className={cn(
                "h-4 w-4 transition-transform",
                sortDir === "desc" && "rotate-180",
              )}
            />
          </Button>
        </div>
        <div className="ml-auto flex items-center rounded-md border p-0.5">
          {VIEW_MODES.map((v) => (
            <Button
              key={v.value}
              variant={viewMode === v.value ? "default" : "ghost"}
              size="sm"
              className="h-8"
              onClick={() => setViewMode(v.value)}
            >
              {v.label}
            </Button>
          ))}
        </div>
      </div>

      {!hasVisibleRows ? (
        <div className="py-16 text-center text-muted-foreground border rounded-xl">
          No tasks match these filters.
        </div>
      ) : (
        <div className="border rounded-xl overflow-hidden [&_.gantt-task-react]:!font-sans">
          <Gantt
            tasks={ganttTasks}
            viewMode={viewMode}
            listCellWidth="280px"
            columnWidth={
              viewMode === ViewMode.Month
                ? 300
                : viewMode === ViewMode.Year
                  ? 350
                  : viewMode === ViewMode.Day
                    ? 60
                    : 150
            }
            rowHeight={44}
            onClick={handleClick}
            onDoubleClick={handleClick}
            onExpanderClick={handleExpanderClick}
            TaskListHeader={CustomTaskListHeader}
            TaskListTable={(props) => (
              <CustomTaskListTable
                {...props}
                taskMeta={taskMeta}
                onViewTask={handleViewTask}
              />
            )}
            columnWidth={viewMode === ViewMode.Day ? 60 : 150}
            today={true}
            todayColor="#faf8b6"
            todayBackground="#e6e8ff"
            todaySelectedBackground="#e5e7eb"
          />
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
        {Object.entries(statusColor).map(([status, style]) => (
          <span key={status} className="flex items-center gap-1.5 capitalize">
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{ backgroundColor: style.backgroundColor }}
            />
            {status.replace("-", " ")}
          </span>
        ))}
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-violet-500" /> Milestone
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-full bg-indigo-500" /> Project
        </span>
      </div>
    </div>
  );
}