'use client';

import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Gauge,
  Loader2,
  Pencil,
  Check,
  X,
  TriangleAlert,
  CalendarRange,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import workloadService from '@/services/workload.service';
import PermissionGate from '@/lib/permissionGate';
import { usePermission } from '@/hooks/usePermission';
import { PROJECT_PERMISSIONS } from '@/constants/projectPermissions';
import { utilizationTone } from '@/lib/statusConfig';
import { CardListSkeleton } from '@/components/common/Skeletons';
import EmptyState from '@/components/feedback/EmptyState';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { SuccessDialog, ErrorDialog, useMutationFeedback } from '@/components/common/AppDialogs';
import StatCard, { StatCardGrid } from '@/components/common/StatCard';

const formatDate = (d) => {
  if (!d) return '';
  return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

function CapacityEditor({ projectId, userId, currentCapacity, canEdit, applyToWholeProject, onSaved }) {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(currentCapacity ?? 8);

  const mutation = useMutation({
    mutationFn: (dailyCapacity) =>
      workloadService.updateDailyCapacity(projectId, {
        userId,
        dailyCapacity,
        applyToWholeProject: true, // update capacity across the whole project period
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workload', projectId] });
      setEditing(false);
      onSaved?.();
    },
  });

  if (!canEdit) {
    return <span className="font-medium">{currentCapacity ?? 8}h / day</span>;
  }

  if (!editing) {
    return (
      <button
        type="button"
        onClick={() => {
          setValue(currentCapacity ?? 8);
          setEditing(true);
        }}
        className="inline-flex items-center gap-1.5 font-medium hover:text-primary group"
      >
        {currentCapacity ?? 8}h / day
        <Pencil className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </button>
    );
  }

  return (
    <div className="flex items-center gap-1.5">
      <Input
        type="number"
        min="1"
        max="24"
        step="0.5"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="h-8 w-20 text-sm"
        autoFocus
      />
      <Button
        size="icon"
        className="h-8 w-8"
        disabled={mutation.isPending}
        onClick={() => mutation.mutate(Number(value) || 8)}
      >
        {mutation.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
      </Button>
      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setEditing(false)}>
        <X className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

function MemberSummaryRow({ projectId, summary, canEdit, feedback }) {
  const queryClient = useQueryClient();
  const userId = summary.user?._id;
  const name = summary.user?.name || 'Unknown';
  const email = summary.user?.email || '';

  const avgPct = Math.round(summary.avgUtilization ?? 0);
  const tone = utilizationTone(avgPct);

  const recalcMutation = useMutation({
    mutationFn: () => workloadService.recalculateUserWorkload(projectId, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workload', projectId] });
      feedback.success(`Recalculated workload for ${name} from current tasks.`);
    },
    onError: (err) => feedback.error(err?.message || 'Could not recalculate workload.'),
  });

  // per-day capacity shown here is derived from totalCapacity / totalDays
  const perDayCapacity = summary.totalDays > 0 ? Math.round((summary.totalCapacity / summary.totalDays) * 100) / 100 : 8;

  return (
    <div className="rounded-lg border px-4 py-4 space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <Avatar className="h-9 w-9 shrink-0">
            <AvatarFallback className="text-xs">{name.slice(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="font-medium truncate">{name}</p>
            <p className="text-xs text-muted-foreground truncate">{email}</p>
          </div>
        </div>

        {summary.overloadedDays > 0 && (
          <Badge variant="outline" className={tone.badge}>
            <TriangleAlert className="h-3 w-3 mr-1" />
            {summary.overloadedDays} overloaded day{summary.overloadedDays !== 1 ? 's' : ''}
          </Badge>
        )}

        <Button
          size="sm"
          variant="ghost"
          className="gap-1.5 text-xs shrink-0"
          disabled={recalcMutation.isPending}
          onClick={() => recalcMutation.mutate()}
          title="Recalculate this person's workload from their current tasks"
        >
          {recalcMutation.isPending ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <RefreshCw className="h-3.5 w-3.5" />
          )}
          Resync from tasks
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-1">
        <div>
          <p className="text-[11px] text-muted-foreground mb-0.5 flex items-center gap-1">
            <CalendarRange className="h-3 w-3" /> Project days
          </p>
          <p className="font-medium">{summary.totalDays}d</p>
          <p className="text-[11px] text-muted-foreground">
            {formatDate(summary.firstDate)} → {formatDate(summary.lastDate)}
          </p>
        </div>

        <div>
          <p className="text-[11px] text-muted-foreground mb-0.5 flex items-center gap-1">
            <Sparkles className="h-3 w-3" /> Assigned (from tasks)
          </p>
          <p className="font-medium">{summary.totalAssigned}h total</p>
          <p className="text-[11px] text-muted-foreground">auto-calculated, not editable</p>
        </div>

        <div>
          <p className="text-[11px] text-muted-foreground mb-0.5">Daily capacity</p>
          <CapacityEditor
            projectId={projectId}
            userId={userId}
            currentCapacity={perDayCapacity}
            canEdit={canEdit}
          />
          <p className="text-[11px] text-muted-foreground">applies to whole project period</p>
        </div>

        <div>
          <p className="text-[11px] text-muted-foreground mb-1">Avg utilization</p>
          <div className="flex items-center gap-2">
            <div className="h-2 flex-1 bg-muted rounded-full overflow-hidden">
              <div className={`h-full ${tone.bar}`} style={{ width: `${Math.min(100, avgPct)}%` }} />
            </div>
            <span className="text-xs font-semibold w-9 text-right">{avgPct}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ProjectWorkloadTab({ project }) {
  const canManageWorkload = usePermission(project, PROJECT_PERMISSIONS.WORKLOAD_MANAGE);
  const feedback = useMutationFeedback();

  const { data, isLoading, error } = useQuery({
    queryKey: ['workload', project?._id],
    queryFn: () => workloadService.getWorkload(project._id),
    enabled: !!project?._id,
  });

  const userSummaries = Array.isArray(data?.data?.userSummaries) ? data.data.userSummaries : [];
  const projectPeriod = data?.data?.projectPeriod;

  const overloaded = userSummaries.filter((s) => s.overloadedDays > 0).length;
  const atRisk = userSummaries.filter(
    (s) => s.overloadedDays === 0 && (s.avgUtilization ?? 0) >= 80
  ).length;
  const healthy = userSummaries.length - overloaded - atRisk;

  return (
    <PermissionGate
      project={project}
      permission={PROJECT_PERMISSIONS.WORKLOAD_MANAGE}
      title="Workload isn't available to you"
      description="Ask a project owner or manager for workload access."
    >
      <div className="space-y-6">
        <StatCardGrid columns={3}>
          <StatCard title="Healthy" value={healthy} icon={Gauge} color="text-emerald-600" loading={isLoading} />
          <StatCard
            title="At risk"
            value={atRisk}
            icon={TriangleAlert}
            color="text-amber-600"
            loading={isLoading}
            highlight={atRisk > 0}
          />
          <StatCard
            title="Overloaded"
            value={overloaded}
            icon={TriangleAlert}
            color="text-red-600"
            loading={isLoading}
            highlight={overloaded > 0}
          />
        </StatCardGrid>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Gauge className="h-4.5 w-4.5 text-primary" />
                Capacity & Utilization
              </CardTitle>
              {projectPeriod?.startDate && projectPeriod?.endDate && (
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <CalendarRange className="h-3.5 w-3.5" />
                  Project period: {formatDate(projectPeriod.startDate)} → {formatDate(projectPeriod.endDate)}
                </span>
              )}
            </div>
          </CardHeader>

          <CardContent>
            {isLoading ? (
              <CardListSkeleton count={4} height="h-24" />
            ) : error ? (
              <p className="text-sm text-red-500">Couldn't load workload data. {error.message}</p>
            ) : userSummaries.length === 0 ? (
              <EmptyState
                compact
                title="No workload data yet"
                description="Assign team members to tasks with estimated hours to see capacity here."
              />
            ) : (
              <div className="space-y-3">
                {userSummaries.map((summary) => (
                  <MemberSummaryRow
                    key={summary.user?._id}
                    projectId={project._id}
                    summary={summary}
                    canEdit={canManageWorkload}
                    feedback={feedback}
                  />
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <SuccessDialog {...feedback.successProps} />
      <ErrorDialog {...feedback.errorProps} />
    </PermissionGate>
  );
}