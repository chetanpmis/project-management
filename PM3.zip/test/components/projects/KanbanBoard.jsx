'use client';

import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import {
  Plus,
  Loader2,
  Calendar,
  AlertTriangle,
  MessageSquare,
  Paperclip,
  CheckSquare,
  FolderKanban,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import useAuthStore from '@/store/auth-store';
import { SuccessDialog, ErrorDialog, useMutationFeedback } from '@/components/common/AppDialogs';
import taskService from '@/services/task.service';
import EmptyState from '@/components/feedback/EmptyState';
import { PRIORITY_CONFIG, TASK_STATUS_CONFIG } from '@/lib/statusConfig';

export default function KanbanBoard({ projectId }) {
  const { user } = useAuthStore();
  const router = useRouter();
  const queryClient = useQueryClient();
  const feedback = useMutationFeedback();

  const [columns, setColumns] = useState([]);
  const [tasksByStatus, setTasksByStatus] = useState({});
  // taskId currently being moved -> shows skeleton + blocks further drags
  const [movingTaskId, setMovingTaskId] = useState(null);
  // keep last-known-good state to roll back to on error
  const prevStateRef = useRef(null);

  const { data: kanbanData, isLoading } = useQuery({
    queryKey: ['kanban', projectId],
    queryFn: () => taskService.getKanbanBoards(projectId),
    enabled: !!projectId,
  });

  const moveMutation = useMutation({
    mutationFn: ({ taskId, targetColumn, beforeTaskId }) =>
      taskService.moveTask(taskId, { targetColumn, beforeTaskId }),
    onSuccess: () => {
      setMovingTaskId(null);
      // sync with server truth in the background, no visible flicker
      // since local state already reflects the move
      queryClient.invalidateQueries({ queryKey: ['kanban', projectId] });
      feedback.success('Task moved successfully');
    },
    onError: (err) => {
      // rollback to state before the optimistic move
      if (prevStateRef.current) {
        setTasksByStatus(prevStateRef.current);
      }
      setMovingTaskId(null);
      feedback.error(err?.message || 'Failed to move task');
    },
  });

  useEffect(() => {
    if (kanbanData?.data) {
      setColumns(kanbanData.data.columns || []);
      // don't clobber local state with a stale server response
      // while a move is still in flight
      if (!movingTaskId) {
        setTasksByStatus(kanbanData.data.tasks || {});
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kanbanData]);

  const onDragEnd = (result) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;
    if (
      destination.droppableId === source.droppableId &&
      destination.index === source.index
    ) return;

    // block a new drag while one is already saving
    if (movingTaskId) return;

    const taskId = draggableId;
    const sourceColumn = source.droppableId;
    const targetColumn = destination.droppableId;

    // save current state for rollback
    prevStateRef.current = tasksByStatus;

    // --- optimistic local update ---
    const sourceTasks = Array.from(tasksByStatus[sourceColumn] || []);
    const [movedTask] = sourceTasks.splice(source.index, 1);
    if (!movedTask) return;

    const updatedTask = { ...movedTask, status: targetColumn };

    const destTasks =
      sourceColumn === targetColumn
        ? sourceTasks
        : Array.from(tasksByStatus[targetColumn] || []);

    destTasks.splice(destination.index, 0, updatedTask);

    const nextState = {
      ...tasksByStatus,
      [sourceColumn]: sourceTasks,
      [targetColumn]: destTasks,
    };

    setTasksByStatus(nextState);
    setMovingTaskId(taskId);

    let beforeTaskId = undefined;
    if (destination.index > 0) {
      beforeTaskId = destTasks[destination.index - 1]?._id;
    }

    moveMutation.mutate({ taskId, targetColumn, beforeTaskId });
  };

  const handleTaskClick = (taskId) => {
    if (movingTaskId) return; // avoid navigating away mid-save
    router.push(`/tasks/${taskId}`);
  };

  const handleCreateTask = () => {
    alert('Create Task Modal will open here. You can replace this with your modal.');
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return '';
    return new Date(dateStr).toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    });
  };

  const getDaysLate = (dueDate) => {
    if (!dueDate) return 0;
    const due = new Date(dueDate);
    const today = new Date();
    due.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);
    const diffMs = today - due;
    return Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!kanbanData?.success || columns.length === 0) {
    return (
      <EmptyState
        icon={<FolderKanban className="h-12 w-12" />}
        title="No Kanban Board"
        description="Something went wrong loading the board."
      />
    );
  }

  const getColumnColor = (status) => {
    switch (status) {
      case 'todo': return 'border-slate-300 bg-slate-50 dark:bg-slate-900';
      case 'in-progress': return 'border-blue-300 bg-blue-50/60 dark:bg-blue-950';
      case 'review': return 'border-purple-300 bg-purple-50/60 dark:bg-purple-950';
      case 'completed': return 'border-emerald-300 bg-emerald-50/60 dark:bg-emerald-950';
      default: return 'border-slate-300';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">Kanban Board</h2>
          <p className="text-muted-foreground">Drag and drop tasks • Double-click card to view details</p>
        </div>
        <Button onClick={handleCreateTask} className="gap-2">
          <Plus className="h-4 w-4" />
          New Task
        </Button>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {columns.map((column) => {
            const columnTasks = tasksByStatus[column.status] || [];
            const statusCfg = TASK_STATUS_CONFIG[column.status];

            return (
              <div
                key={column._id}
                className={`rounded-xl border-2 ${getColumnColor(column.status)} p-4`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: statusCfg?.hex || column.color }}
                    />
                    <h3 className="font-semibold text-lg">{column.name}</h3>
                  </div>
                  <Badge variant="secondary" className="font-mono text-xs">
                    {columnTasks.length}
                  </Badge>
                </div>

                <Droppable droppableId={column.status} isDropDisabled={!!movingTaskId}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`min-h-[500px] space-y-3 transition-all rounded-lg p-2 ${
                        snapshot.isDraggingOver ? 'bg-muted/50' : ''
                      }`}
                    >
                      {columnTasks.map((task, index) => {
                        const isSaving = movingTaskId === task._id;

                        // While this exact card is saving, show a skeleton instead of the card
                        if (isSaving) {
                          return (
                            <Draggable
                              key={task._id}
                              draggableId={task._id}
                              index={index}
                              isDragDisabled
                            >
                              {(provided) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  className="rounded-2xl border p-4 space-y-3 bg-card animate-pulse"
                                >
                                  <div className="flex justify-between">
                                    <Skeleton className="h-5 w-20 rounded-full" />
                                    <Skeleton className="h-5 w-16 rounded-full" />
                                  </div>
                                  <Skeleton className="h-4 w-3/4" />
                                  <Skeleton className="h-2 w-full rounded-full" />
                                  <div className="flex justify-between items-center pt-2">
                                    <Skeleton className="h-6 w-6 rounded-full" />
                                    <Skeleton className="h-4 w-10" />
                                  </div>
                                </div>
                              )}
                            </Draggable>
                          );
                        }

                        const startDateFormatted = formatDate(task.startDate);
                        const dueDateFormatted = formatDate(task.dueDate);
                        const dateRange =
                          startDateFormatted && dueDateFormatted
                            ? `${startDateFormatted} - ${dueDateFormatted}`
                            : dueDateFormatted || startDateFormatted;

                        const priorityCfg = PRIORITY_CONFIG[task.priority] || PRIORITY_CONFIG.medium;
                        const daysLate = task.isOverdue ? getDaysLate(task.dueDate) : 0;

                        const checklistDone = task.checklistCompleted || 0;
                        const checklistTotal = task.checklistTotal || 0;
                        const pct = task.checklistPct || 0;

                        return (
                          <Draggable
                            key={task._id}
                            draggableId={task._id}
                            index={index}
                            isDragDisabled={!!movingTaskId}
                          >
                            {(provided, snapshot) => (
                              <Card
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                className={`transition-all hover:shadow-md cursor-pointer rounded-2xl ${
                                  snapshot.isDragging ? 'shadow-lg scale-[1.02]' : ''
                                } ${task.isOverdue ? 'ring-1 ring-red-200' : ''} ${
                                  movingTaskId ? 'opacity-70 pointer-events-none' : ''
                                }`}
                                onDoubleClick={() => handleTaskClick(task._id)}
                              >
                                <CardContent className="p-4">
                                  {/* Priority + Overdue row */}
                                  <div className="flex justify-between items-center mb-3">
                                    <Badge
                                      variant="outline"
                                      className={`gap-1.5 font-medium ${priorityCfg.badge}`}
                                    >
                                      <span
                                        className="w-2 h-2 rounded-full"
                                        style={{ backgroundColor: priorityCfg.hex }}
                                      />
                                      {priorityCfg.label}
                                    </Badge>

                                    {task.isOverdue && (
                                      <Badge className="bg-red-600 hover:bg-red-600 text-white text-xs font-semibold tracking-wide">
                                        OVERDUE
                                      </Badge>
                                    )}
                                  </div>

                                  {/* Title + description */}
                                  <h4 className="font-bold text-base leading-snug mb-1 line-clamp-2">
                                    {task.title}
                                  </h4>
                                  {task.description && (
                                    <p className="text-sm text-muted-foreground line-clamp-1 mb-3">
                                      {task.description}
                                    </p>
                                  )}

                                  {/* Progress bar (checklist-based, from backend) */}
                                  {checklistTotal > 0 && (
                                    <div className="flex items-center gap-3 mb-3">
                                      <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                                        <div
                                          className="h-full rounded-full bg-emerald-500 transition-all"
                                          style={{ width: `${pct}%` }}
                                        />
                                      </div>
                                      <span className="text-sm font-semibold text-muted-foreground w-10 text-right">
                                        {pct}%
                                      </span>
                                    </div>
                                  )}

                                  <div className="border-t my-3" />

                                  {/* Date range + late-by */}
                                  {(dateRange || daysLate > 0) && (
                                    <div className="mb-3 space-y-1">
                                      {dateRange && (
                                        <div className="flex items-center gap-2 text-sm text-foreground/80">
                                          <Calendar className="h-3.5 w-3.5 shrink-0" />
                                          <span>{dateRange}</span>
                                        </div>
                                      )}
                                      {daysLate > 0 && (
                                        <div className="flex items-center gap-1 text-sm font-medium text-red-600 pl-5">
                                          <AlertTriangle className="h-3.5 w-3.5" />
                                          Late by {daysLate} day{daysLate !== 1 ? 's' : ''}
                                        </div>
                                      )}
                                    </div>
                                  )}

                                  <div className="border-t my-3" />

                                  {/* Bottom row: assignee + meta counts */}
                                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                                    <div className="flex items-center gap-2 min-w-0">
                                      {task.assignees?.[0] && (
                                        <Avatar className="h-6 w-6 border">
                                          <AvatarImage src={task.assignees[0].avatar} />
                                          <AvatarFallback className="text-[10px]">
                                            {task.assignees[0].name?.slice(0, 2).toUpperCase()}
                                          </AvatarFallback>
                                        </Avatar>
                                      )}
                                      <span className="truncate font-medium text-foreground/80">
                                        {task.assignees?.[0]?.name || 'Unassigned'}
                                      </span>
                                      {task.assignees?.length > 1 && (
                                        <span className="text-xs">+{task.assignees.length - 1}</span>
                                      )}
                                    </div>

                                    <div className="flex items-center gap-3 shrink-0">
                                      {task.comments?.length > 0 && (
                                        <span className="flex items-center gap-1">
                                          <MessageSquare className="h-3.5 w-3.5" />
                                          {task.comments.length}
                                        </span>
                                      )}
                                      {task.attachments?.length > 0 && (
                                        <span className="flex items-center gap-1">
                                          <Paperclip className="h-3.5 w-3.5" />
                                          {task.attachments.length}
                                        </span>
                                      )}
                                      {checklistTotal > 0 && (
                                        <span className="flex items-center gap-1">
                                          <CheckSquare className="h-3.5 w-3.5" />
                                          {checklistDone}/{checklistTotal}
                                        </span>
                                      )}
                                    </div>
                                  </div>

                                  {/* Labels */}
                                  {task.labels?.length > 0 && (
                                    <div className="flex flex-wrap gap-1 mt-3">
                                      {task.labels.map((label) => (
                                        <Badge key={label} variant="outline" className="text-xs">
                                          {label}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                </CardContent>
                              </Card>
                            )}
                          </Draggable>
                        );
                      })}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </div>
            );
          })}
        </div>
      </DragDropContext>

      <SuccessDialog {...feedback.successProps} />
      <ErrorDialog {...feedback.errorProps} />
    </div>
  );
}