'use client';

import { useState } from 'react';
import { UserPlus, Search, AlertCircle, ArrowLeft, Gauge, Loader2, Check } from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import userService from '@/services/user.service';
import projectService from '@/services/project.service';
import workloadService from '@/services/workload.service';
import { useDebounce } from '@/hooks/useDebounce';
import { ROLE_OPTIONS, ROLE_META } from '@/constants/projectPermissions';
import { SuccessDialog, ErrorDialog } from '@/components/common/AppDialogs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const CAPACITY_PRESETS = [4, 6, 8, 10];

/**
 * Two-step add-member flow:
 *  1. search + pick a person + role
 *  2. optional — set their daily capacity for this project before they can
 *     be assigned tasks (only shown when `canManageWorkload` is true;
 *     everyone else's flow ends after step 1)
 *
 * <AddMemberDialog
 *   open={open} onOpenChange={setOpen} projectId={project._id}
 *   existingMemberIds={existingIds} onAdded={invalidateProject}
 *   canManageWorkload={canManageWorkload}
 * />
 */
export default function AddMemberDialog({
  open,
  onOpenChange,
  projectId,
  existingMemberIds = [],
  onAdded,
  canManageWorkload = false,
}) {
  const [step, setStep] = useState('search');
  const [query, setQuery] = useState('');
  const [role, setRole] = useState('member');
  const [addedUser, setAddedUser] = useState(null);
  const [dailyCapacity, setDailyCapacity] = useState('8');
  const [feedback, setFeedback] = useState({ type: null, message: '' });
  const debouncedQuery = useDebounce(query, 400);

  const { data: results, isFetching } = useQuery({
    queryKey: ['userSearch', debouncedQuery],
    queryFn: async () => {
      const res = await userService.getUsers({ search: debouncedQuery, limit: 8 });
      return res.data || [];
    },
    enabled: open && debouncedQuery.trim().length > 1,
  });

  const addMemberMutation = useMutation({
    mutationFn: (user) => projectService.addTeamMember(projectId, { userId: user._id, role }),
    onSuccess: (_res, user) => {
      setAddedUser(user);
      onAdded?.();
      if (canManageWorkload) {
        setStep('workload');
      } else {
        setFeedback({ type: 'success', message: `${user.name} was added to the project as ${ROLE_META[role].label.toLowerCase()}.` });
        resetAndClose(false);
      }
    },
    onError: (err) => setFeedback({ type: 'error', message: err?.message || 'Could not add this member.' }),
  });

  const workloadMutation = useMutation({
    mutationFn: () =>
      workloadService.updateDailyCapacity(projectId, { userId: addedUser._id, dailyCapacity: Number(dailyCapacity) || 8 }),
    onSuccess: () => {
      setFeedback({ type: 'success', message: `${addedUser.name} was added with a ${dailyCapacity}h/day capacity.` });
      resetAndClose(false);
    },
    onError: (err) =>
      setFeedback({
        type: 'error',
        message: err?.message || 'Member was added, but capacity could not be set. You can set it later from the Workload tab.',
      }),
  });

  const resetAndClose = (next) => {
    if (!next) {
      setQuery('');
      setRole('member');
      setStep('search');
      setAddedUser(null);
      setDailyCapacity('8');
    }
    onOpenChange(next);
  };

  const capacityNum = Number(dailyCapacity) || 0;
  const capacityInvalid = capacityNum <= 0 || capacityNum > 24;

  return (
    <>
      <Dialog open={open} onOpenChange={resetAndClose}>
        <DialogContent className="sm:max-w-md">
          {step === 'search' ? (
            <>
              <DialogHeader>
                <DialogTitle>Add team member</DialogTitle>
                <DialogDescription>Search for a person and give them a role on this project.</DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Role for new member</Label>
                  <Select value={role} onValueChange={setRole}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ROLE_OPTIONS.map((r) => (
                        <SelectItem key={r} value={r} className="capitalize">
                          {ROLE_META[r].label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">{ROLE_META[role].description}</p>
                </div>

                <div className="space-y-2">
                  <Label>Search people</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by name or email…"
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>

                <div className="rounded-lg border border-border divide-y divide-border max-h-64 overflow-y-auto">
                  {debouncedQuery.trim().length <= 1 ? (
                    <p className="px-4 py-3 text-sm text-muted-foreground">Type at least 2 characters to search.</p>
                  ) : isFetching ? (
                    <p className="px-4 py-3 text-sm text-muted-foreground flex items-center gap-2">
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Searching…
                    </p>
                  ) : results && results.length > 0 ? (
                    results.map((user) => {
                      const alreadyMember = existingMemberIds.includes(user._id);
                      const isAddingThis = addMemberMutation.isPending && addMemberMutation.variables?._id === user._id;
                      return (
                        <button
                          type="button"
                          key={user._id}
                          disabled={alreadyMember || addMemberMutation.isPending}
                          onClick={() => addMemberMutation.mutate(user)}
                          className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-muted/50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <Avatar className="h-8 w-8 shrink-0">
                              <AvatarFallback className="text-xs">{user.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div className="min-w-0">
                              <p className="text-sm font-medium truncate">{user.name}</p>
                              <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                            </div>
                          </div>
                          {alreadyMember ? (
                            <Badge variant="outline" className="shrink-0 text-xs">Already added</Badge>
                          ) : isAddingThis ? (
                            <Loader2 className="h-4 w-4 text-muted-foreground animate-spin shrink-0" />
                          ) : (
                            <UserPlus className="h-4 w-4 text-muted-foreground shrink-0" />
                          )}
                        </button>
                      );
                    })
                  ) : (
                    <p className="px-4 py-3 text-sm text-muted-foreground">No matching people</p>
                  )}
                </div>

                {addMemberMutation.isError && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3.5 w-3.5" />
                    {addMemberMutation.error?.message || 'Could not add member'}
                  </p>
                )}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => resetAndClose(false)}>
                  Done
                </Button>
              </DialogFooter>
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Gauge className="h-4.5 w-4.5 text-primary" />
                  Set workload capacity
                </DialogTitle>
                <DialogDescription>
                  {`${addedUser?.name} was added as ${ROLE_META[role].label.toLowerCase()}. Set how many hours a day
                  they're available before assigning them tasks — you can change this any time from the Workload tab.`}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                <div className="flex items-center gap-3 rounded-lg border bg-muted/30 px-4 py-3">
                  <Avatar className="h-9 w-9 shrink-0">
                    <AvatarFallback className="text-xs">{addedUser?.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{addedUser?.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{addedUser?.email}</p>
                  </div>
                  <Badge variant="outline" className={cn('capitalize ml-auto shrink-0', ROLE_META[role]?.badgeClass)}>
                    {ROLE_META[role].label}
                  </Badge>
                </div>

                <div className="space-y-2">
                  <Label>Daily capacity (hours)</Label>
                  <Input
                    type="number"
                    min="1"
                    max="24"
                    step="0.5"
                    value={dailyCapacity}
                    onChange={(e) => setDailyCapacity(e.target.value)}
                  />
                  <div className="flex items-center gap-1.5">
                    {CAPACITY_PRESETS.map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setDailyCapacity(String(preset))}
                        className={cn(
                          'rounded-full border px-2.5 py-1 text-xs font-medium transition-colors',
                          Number(dailyCapacity) === preset
                            ? 'border-primary bg-primary text-primary-foreground'
                            : 'border-border text-muted-foreground hover:bg-muted'
                        )}
                      >
                        {preset}h
                      </button>
                    ))}
                  </div>
                  {capacityInvalid && (
                    <p className="text-red-500 text-xs flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      Enter a value between 1 and 24 hours.
                    </p>
                  )}
                </div>

                {workloadMutation.isError && (
                  <p className="text-red-500 text-sm flex items-center gap-1">
                    <AlertCircle className="h-3.5 w-3.5" />
                    {workloadMutation.error?.message || 'Could not set capacity'}
                  </p>
                )}
              </div>

              <DialogFooter className="flex items-center justify-between sm:justify-between w-full">
                <Button
                  type="button"
                  variant="ghost"
                  className="gap-1.5"
                  disabled={workloadMutation.isPending}
                  onClick={() => {
                    setFeedback({ type: 'success', message: `${addedUser.name} was added to the project.` });
                    resetAndClose(false);
                  }}
                >
                  <ArrowLeft className="h-4 w-4" />
                  Skip for now
                </Button>
                <Button
                  onClick={() => workloadMutation.mutate()}
                  disabled={workloadMutation.isPending || capacityInvalid}
                >
                  {workloadMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
                  ) : (
                    <Check className="h-4 w-4 mr-1.5" />
                  )}
                  Save capacity
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <SuccessDialog
        open={feedback.type === 'success'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        title="Member added"
        description={feedback.message}
      />
      <ErrorDialog
        open={feedback.type === 'error'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        description={feedback.message}
      />
    </>
  );
}