export function NotificationRowSkeleton({ count = 5 }) {
  return (
    <div className="divide-y">
      {[...Array(count)].map((_, i) => (
        <div key={i} className="flex items-start gap-3 p-3 animate-pulse">
          <div className="h-8 w-8 rounded-full bg-muted shrink-0" />
          <div className="flex-1 space-y-2">
            <div className="h-3.5 w-2/3 bg-muted rounded" />
            <div className="h-3 w-full bg-muted rounded" />
            <div className="h-2.5 w-24 bg-muted rounded" />
          </div>
        </div>
      ))}
    </div>
  );
}