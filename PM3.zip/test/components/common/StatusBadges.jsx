'use client';

import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  TASK_STATUS_CONFIG,
  PRIORITY_CONFIG,
  PROJECT_STATUS_CONFIG,
  HEALTH_CONFIG,
  MILESTONE_STATUS_CONFIG,
  WORKLOAD_STATUS_CONFIG,
} from '@/lib/statusConfig';

function ConfigBadge({ config, value, fallbackLabel, className, withDot = false }) {
  const entry = config[value] || { label: fallbackLabel || value || 'Unknown', badge: 'bg-slate-100 text-slate-700 border-slate-200' };
  return (
    <Badge variant="outline" className={cn('capitalize font-medium', entry.badge, className)}>
      {withDot && entry.dot && <span className={cn('h-1.5 w-1.5 rounded-full mr-1.5', entry.dot)} />}
      {entry.label}
    </Badge>
  );
}

export function TaskStatusBadge({ status, className, withDot = true }) {
  return <ConfigBadge config={TASK_STATUS_CONFIG} value={status} className={className} withDot={withDot} />;
}

export function PriorityBadge({ priority, className }) {
  return <ConfigBadge config={PRIORITY_CONFIG} value={priority} className={className} />;
}

export function ProjectStatusBadge({ status, className }) {
  return <ConfigBadge config={PROJECT_STATUS_CONFIG} value={status} className={className} />;
}

export function HealthBadge({ health, className }) {
  return <ConfigBadge config={HEALTH_CONFIG} value={health} className={className} />;
}

export function MilestoneStatusBadge({ status, className }) {
  return <ConfigBadge config={MILESTONE_STATUS_CONFIG} value={status} className={className} />;
}

export function WorkloadStatusBadge({ status, className }) {
  return <ConfigBadge config={WORKLOAD_STATUS_CONFIG} value={status} className={className} />;
}

/** Small colored dot for a priority — handy in compact contexts (selector
 * buttons, dense lists) where a full badge is too heavy. */
export function PriorityDot({ priority, className }) {
  const entry = PRIORITY_CONFIG[priority];
  return <span className={cn('inline-block h-2 w-2 rounded-full shrink-0', className)} style={{ backgroundColor: entry?.hex || '#94a3b8' }} />;
}