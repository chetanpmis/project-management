'use client';

import { useState } from 'react';
import { CheckCircle2, XCircle, AlertTriangle, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

/**
 * The three dialogs every mutation in the app needs, built once so "task
 * updated" and "member removed" and "project created" all look identical
 * instead of each form rolling its own <Dialog> + emerald checkmark.
 */

export function SuccessDialog({ open, onOpenChange, title = 'Success', description, actionLabel = 'Done', onAction }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-emerald-600">
            <CheckCircle2 className="h-5 w-5" />
            {title}
          </DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <DialogFooter>
          <Button
            onClick={() => {
              onAction ? onAction() : onOpenChange(false);
            }}
          >
            {actionLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function ErrorDialog({ open, onOpenChange, title = 'Something went wrong', description, actionLabel = 'Try again' }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <XCircle className="h-5 w-5" />
            {title}
          </DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {actionLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Replaces every `confirm('Delete this?')` browser prompt in the app.
 * Controlled: parent owns `open`, passes `onConfirm` (may be async — the
 * dialog shows a spinner and stays open until it resolves) and `loading`.
 */
export function ConfirmDialog({
  open,
  onOpenChange,
  title = 'Are you sure?',
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  destructive = true,
  loading = false,
  onConfirm,
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className={destructive ? 'h-5 w-5 text-red-600' : 'h-5 w-5 text-amber-600'} />
            {title}
          </DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
            {cancelLabel}
          </Button>
          <Button variant={destructive ? 'destructive' : 'default'} onClick={onConfirm} disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}
            {confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Small hook to cut the boilerplate of wiring a mutation to a
 * Success/Error dialog pair. Returns state + handlers you spread onto the
 * two dialogs, and a `run(promise)` helper to wrap any mutation call.
 *
 * const feedback = useMutationFeedback();
 * <Button onClick={() => feedback.run(projectService.deleteProject(id), 'Project deleted')}>
 * <SuccessDialog {...feedback.successProps} />
 * <ErrorDialog {...feedback.errorProps} />
 */
export function useMutationFeedback() {
  const [state, setState] = useState({ open: null, message: '' });

  const run = async (promise, successMessage = 'Done', errorMessage) => {
    try {
      const result = await promise;
      setState({ open: 'success', message: successMessage });
      return result;
    } catch (err) {
      setState({ open: 'error', message: errorMessage || err?.message || 'Please try again.' });
      throw err;
    }
  };

  const close = () => setState({ open: null, message: '' });

  return {
    run,
    successProps: { open: state.open === 'success', onOpenChange: (v) => !v && close(), description: state.message },
    errorProps: { open: state.open === 'error', onOpenChange: (v) => !v && close(), description: state.message },
  };
}