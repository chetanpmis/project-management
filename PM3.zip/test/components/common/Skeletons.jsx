'use client';

import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { StatCardGrid } from './StatCard';

/** Use anywhere a `<Table>` is about to render rows. Matches column count so
 * the skeleton doesn't jump around once real data lands. */
export function TableSkeleton({ rows = 6, columns = 5 }) {
  return (
    <div className="rounded-2xl border overflow-hidden">
      <div className="border-b bg-muted/40 px-4 py-3">
        <div className="flex gap-6">
          {Array.from({ length: columns }).map((_, i) => (
            <Skeleton key={i} className="h-4 flex-1" />
          ))}
        </div>
      </div>
      <div className="divide-y">
        {Array.from({ length: rows }).map((_, r) => (
          <div key={r} className="flex gap-6 px-4 py-4">
            {Array.from({ length: columns }).map((_, c) => (
              <Skeleton key={c} className="h-5 flex-1" />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

/** Stat card row while KPIs load — pass the same `columns` you'll use for the real grid. */
export function StatGridSkeleton({ count = 4, columns = 4 }) {
  return (
    <StatCardGrid columns={columns}>
      {Array.from({ length: count }).map((_, i) => (
        <Card key={i} className="h-full">
          <CardHeader className="pb-3">
            <Skeleton className="h-4 w-24" />
          </CardHeader>
          <CardContent className="pt-0 space-y-2">
            <Skeleton className="h-9 w-16" />
            <Skeleton className="h-3 w-20" />
          </CardContent>
        </Card>
      ))}
    </StatCardGrid>
  );
}

/** Vertical list of card-shaped rows — team members, milestones, comments, etc. */
export function CardListSkeleton({ count = 3, height = 'h-20' }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton key={i} className={`${height} w-full rounded-xl`} />
      ))}
    </div>
  );
}

export function PageHeaderSkeleton() {
  return (
    <div className="flex items-center justify-between">
      <div className="space-y-2">
        <Skeleton className="h-8 w-56" />
        <Skeleton className="h-4 w-72" />
      </div>
      <Skeleton className="h-10 w-32 rounded-md" />
    </div>
  );
}