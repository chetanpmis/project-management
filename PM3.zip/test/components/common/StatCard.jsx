'use client';

import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

/**
 * The one stat card component the whole app should use — dashboard, project
 * list, task list, reports. Matches the look already established in
 * ProjectStatsCards / TaskStatsCards / report KpiCard, so every page's
 * "number in a card" looks identical instead of three slightly different
 * hand-rolled versions.
 */
export default function StatCard({ title, value, sub, icon: Icon, color = 'text-blue-600', loading = false, index = 0, highlight = false }) {
  if (loading) {
    return (
      <Card className="h-full">
        <CardHeader className="pb-3">
          <Skeleton className="h-4 w-24" />
        </CardHeader>
        <CardContent className="pt-0 space-y-2">
          <Skeleton className="h-9 w-16" />
          <Skeleton className="h-3 w-20" />
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, delay: index * 0.03 }}
      whileHover={{ y: -6 }}
    >
      <Card className={cn('h-full overflow-hidden relative', highlight && 'border-red-200')}>
        <CardHeader className="flex flex-row items-center justify-between pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
          {Icon && (
            <div className={cn('p-2.5 rounded-xl bg-white shadow-sm', color)}>
              <Icon className="h-5 w-5" />
            </div>
          )}
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-bold tracking-tight">{value}</span>
          </div>
          {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
        </CardContent>
        {Icon && (
          <div className={cn('absolute -right-6 -bottom-6 opacity-5 pointer-events-none', color)}>
            <Icon className="h-20 w-20" />
          </div>
        )}
      </Card>
    </motion.div>
  );
}

/** Grid wrapper so pages don't hand-roll grid-cols classes differently each time. */
export function StatCardGrid({ children, columns = 4 }) {
  const colClass =
    columns === 6
      ? 'grid-cols-2 md:grid-cols-3 lg:grid-cols-6'
      : columns === 5
      ? 'grid-cols-2 md:grid-cols-3 lg:grid-cols-5'
      : columns === 3
      ? 'grid-cols-1 md:grid-cols-3'
      : 'grid-cols-2 md:grid-cols-4';
  return <div className={cn('grid gap-4', colClass)}>{children}</div>;
}