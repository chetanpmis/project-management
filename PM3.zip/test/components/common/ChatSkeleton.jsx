export function ChatMessageSkeleton({ count = 5 }) {
  return (
    <div className="space-y-4 p-4">
      {[...Array(count)].map((_, i) => (
        <div key={i} className={`flex gap-3 animate-pulse ${i % 2 === 1 ? 'flex-row-reverse' : ''}`}>
          <div className="h-8 w-8 rounded-full bg-muted shrink-0" />
          <div className={`space-y-1.5 ${i % 2 === 1 ? 'items-end flex flex-col' : ''}`}>
            <div className="h-2.5 w-16 bg-muted rounded" />
            <div className="h-9 w-52 bg-muted rounded-2xl" />
          </div>
        </div>
      ))}
    </div>
  );
}