"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  FolderKanban,
  CheckSquare,
  Users,
  Bell,
  Settings,
  Building2,
  BarChart3,
  ChevronDown,
  ChevronRight,
} from "lucide-react";

import useAuthStore from "@/store/auth-store";

import Logo from "@/components/Layout/Logo";
import { getInitials } from "../../lib/helpers/avatar";
import useSidebarStore from "../../store/sidebar.store";

const menus = [
  { title: "Dashboard", icon: LayoutDashboard, href: "/dashboard" },
  // {
  //   title: "Workspace",
  //   icon: Building2,
  //   children: [{ title: "Overview", href: "/workspace" }],
  // },
  {
    title: "Projects",
    icon: FolderKanban,
    children: [
      { title: "All Projects", href: "/projects" },
      { title: "Create Project", href: "/projects/create" },
    ],
  },
  {
    title: "Tasks",
    icon: CheckSquare,
    children: [
      { title: "My Tasks", href: "/tasks" },
      { title: "Calendar", href: "/tasks/calendar" },
    ],
  },
  {
    title: "Reports",
    icon: BarChart3,
    children: [
      { title: "Analytics", href: "/reports" },
      { title: "Budget", href: "/reports/budget" },
      { title: "Workload", href: "/reports/workload" },
    ],
  },
  // { title: "Users", icon: Users, href: "/users" },
  { title: "Notifications", icon: Bell, href: "/notifications" },
  { title: "Settings", icon: Settings, href: "/settings" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const [openMenu, setOpenMenu] = useState("Projects");
  const { collapsed } = useSidebarStore();
  const user = useAuthStore((state) => state.user);

  return (
    <aside
      className={`hidden flex-col border-r border-zinc-200 bg-white transition-all duration-300 lg:flex ${
        collapsed ? "w-20" : "w-72"
      }`}
    >
      {/* Logo */}
      <div className="flex h-20 items-center border-b border-zinc-200 px-6">
        <Logo collapsed={collapsed} />
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto p-4 space-y-1">
        {menus.map((menu) => {
          const Icon = menu.icon;
          const isActive = pathname === menu.href;

          if (!menu.children) {
            return (
              <Link
                key={menu.title}
                href={menu.href}
                className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition-all ${
                  isActive
                    ? "bg-zinc-100 text-black font-semibold"
                    : "text-zinc-700 hover:bg-zinc-100 hover:text-black"
                } ${collapsed ? "justify-center" : ""}`}
                title={collapsed ? menu.title : undefined}
              >
                <Icon size={20} />
                {!collapsed && <span>{menu.title}</span>}
              </Link>
            );
          }

          const isOpen = openMenu === menu.title && !collapsed;

          return (
            <div key={menu.title}>
              <button
                onClick={() => setOpenMenu(isOpen ? "" : menu.title)}
                className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium text-zinc-700 transition hover:bg-zinc-100 hover:text-black ${
                  collapsed ? "justify-center" : "justify-between"
                }`}
                title={collapsed ? menu.title : undefined}
              >
                <div className="flex items-center gap-3">
                  <Icon size={20} />
                  {!collapsed && <span>{menu.title}</span>}
                </div>
                {!collapsed && (isOpen ? <ChevronDown size={18} /> : <ChevronRight size={18} />)}
              </button>

              <AnimatePresence>
                {isOpen && !collapsed && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="ml-9 mt-1 space-y-1 border-l border-zinc-200 pl-5">
                      {menu.children.map((item) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className={`block rounded-xl px-4 py-2.5 text-sm transition ${
                            pathname === item.href
                              ? "bg-zinc-100 text-black font-medium"
                              : "text-zinc-600 hover:bg-zinc-100 hover:text-black"
                          }`}
                        >
                          {item.title}
                        </Link>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* User Footer */}
      <div className="border-t border-zinc-200 p-4">
        <div className={`rounded-3xl bg-zinc-100 p-4 ${collapsed ? "text-center" : ""}`}>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-semibold text-lg flex-shrink-0">
              {user?.name ? getInitials(user.name) : "U"}
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <p className="font-semibold text-black truncate">{user?.name || "User"}</p>
                <p className="text-xs text-zinc-500 capitalize">{user?.role || "Member"}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}

