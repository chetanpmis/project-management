'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Search, Menu, LogOut, User, Settings, ChevronDown } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import NotificationBell from '@/components/notifications/NotificationBell';

import useAuthStore from '@/store/auth-store';
import useSidebarStore from '../../store/sidebar.store';

const getInitials = (name) => {
  if (!name) return 'U';
  return name
    .split(' ')
    .map((word) => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
};

function UserMenu({ user, onLogout }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const router = useRouter();

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    const handleEscape = (e) => {
      if (e.key === 'Escape') setOpen(false);
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, []);

  const go = (path) => {
    setOpen(false);
    router.push(path);
  };

  return (
    <div className="relative" ref={menuRef}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-3 rounded-3xl bg-white border border-zinc-200 px-3 py-1.5 hover:border-zinc-300 transition"
      >
        <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-semibold text-sm shrink-0">
          {user?.name ? getInitials(user.name) : 'U'}
        </div>
        <div className="hidden md:block text-left">
          <p className="text-sm font-semibold text-black leading-tight">{user?.name || 'User'}</p>
          <p className="text-xs text-zinc-500 capitalize leading-tight">{user?.role || 'member'}</p>
        </div>
        <ChevronDown className={`hidden md:block h-4 w-4 text-zinc-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-56 rounded-xl border border-zinc-200 bg-white shadow-lg overflow-hidden z-50">
          <div className="px-3 py-2.5 border-b border-zinc-100">
            <p className="text-xs font-medium text-zinc-400 uppercase tracking-wide">Account</p>
            <p className="text-sm font-semibold text-black truncate mt-0.5">{user?.email}</p>
          </div>

          <div className="py-1">
            <button
              onClick={() => go('/profile')}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-zinc-700 hover:bg-zinc-50 transition"
            >
              <User className="h-4 w-4 text-zinc-500" />
              Profile
            </button>
            <button
              onClick={() => go('/settings')}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-zinc-700 hover:bg-zinc-50 transition"
            >
              <Settings className="h-4 w-4 text-zinc-500" />
              Settings
            </button>
          </div>

          <div className="border-t border-zinc-100 py-1">
            <button
              onClick={() => { setOpen(false); onLogout(); }}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-red-600 hover:bg-red-50 transition"
            >
              <LogOut className="h-4 w-4" />
              Logout
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Header() {
  const router = useRouter();
  const pathname = usePathname();
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const { collapsed, toggleSidebar } = useSidebarStore();

  const pageName = pathname.split('/').filter(Boolean).pop()?.replace('-', ' ') || 'Dashboard';

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  return (
    <header className="sticky top-0 z-50 border-b bg-white/95 backdrop-blur-md">
      <div className="flex h-16 items-center justify-between px-6">
        {/* Left side */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="text-zinc-700 hover:text-black"
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>

        {/* Search */}
        <div className="hidden w-full max-w-md mx-8 lg:block">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search projects, tasks, users..."
              className="border-gray-200 bg-white pl-11 focus-visible:ring-black"
            />
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-4">
          <NotificationBell />
          <UserMenu user={user} onLogout={handleLogout} />
        </div>
      </div>
    </header>
  );
}