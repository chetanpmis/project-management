'use client';

import { motion } from 'framer-motion';
import { ShieldAlert } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * Shown instead of a feature when the current user lacks the permission
 * for it — deliberately distinct from EmptyState (nothing to do here, this
 * isn't "add your first X") and ErrorState (nothing is broken). Amber, not
 * red: this isn't a failure, it's a boundary.
 */
export default function NoPermissionState({
  title = "You don't have permission for this",
  description = 'Ask a project owner or manager to grant you access.',
  compact = false,
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className={cn(
        'flex flex-col items-center justify-center rounded-xl border border-dashed border-amber-200 bg-amber-50/40 text-center',
        compact ? 'min-h-[160px] p-6' : 'min-h-[320px] p-8'
      )}
    >
      <div className={cn('mb-4 rounded-full bg-amber-100 text-amber-700', compact ? 'p-3' : 'p-5')}>
        <ShieldAlert className={compact ? 'h-5 w-5' : 'h-7 w-7'} />
      </div>
      <h2 className={compact ? 'text-base font-semibold text-amber-900' : 'text-xl font-semibold text-amber-900'}>{title}</h2>
      <p className={cn('mt-2 max-w-sm text-amber-700/80', compact ? 'text-xs' : 'text-sm')}>{description}</p>
    </motion.div>
  );
}