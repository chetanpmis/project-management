'use client';

import { motion } from 'framer-motion';
import { Inbox } from 'lucide-react';
import { cn } from '@/lib/utils';


export default function EmptyState({ icon, title, description, action, compact = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn(
        'flex flex-col items-center justify-center rounded-xl border border-dashed bg-muted/20 text-center',
        compact ? 'min-h-[220px] p-6' : 'min-h-[420px] p-8'
      )}
    >
      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 3, repeat: Infinity }}
        className={cn('mb-5 rounded-full bg-primary/10 p-5 text-primary', compact && 'mb-4 p-4')}
      >
        {icon || <Inbox className={compact ? 'h-6 w-6' : 'h-8 w-8'} />}
      </motion.div>

      <h2 className={compact ? 'text-lg font-semibold' : 'text-2xl font-semibold'}>{title}</h2>

      <p className={cn('mt-2 max-w-md text-muted-foreground', compact ? 'text-sm' : '')}>{description}</p>

      {action && <div className={compact ? 'mt-5' : 'mt-8'}>{action}</div>}
    </motion.div>
  );
}