'use client';

import { motion } from 'framer-motion';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export default function ErrorState({ icon, title = 'Something went wrong', description, action, onRetry, compact = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        'flex flex-col items-center justify-center rounded-xl border bg-destructive/5 text-center',
        compact ? 'min-h-[220px] p-6' : 'min-h-[420px] p-8'
      )}
    >
      <div className={cn('mb-5 rounded-full bg-destructive/10 text-destructive', compact ? 'p-4' : 'p-5')}>
        {icon || <AlertTriangle className={compact ? 'h-6 w-6' : 'h-8 w-8'} />}
      </div>

      <h2 className={compact ? 'text-lg font-semibold' : 'text-2xl font-semibold'}>{title}</h2>

      {description && <p className={cn('mt-2 max-w-md text-muted-foreground', compact ? 'text-sm' : '')}>{description}</p>}

      {(action || onRetry) && (
        <div className={compact ? 'mt-5' : 'mt-8'}>
          {action || (
            <Button variant="outline" onClick={onRetry} className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Try again
            </Button>
          )}
        </div>
      )}
    </motion.div>
  );
}