


export const PROJECT_PERMISSIONS = {
  PROJECT_VIEW: 'project.view',
  PROJECT_EDIT: 'project.edit',
  PROJECT_DELETE: 'project.delete',
  PROJECT_SETTINGS: 'project.settings',

  TASK_VIEW: 'task.view',
  TASK_CREATE: 'task.create',
  TASK_EDIT: 'task.edit',
  TASK_DELETE: 'task.delete',
  TASK_ASSIGN: 'task.assign',

  TEAM_VIEW: 'team.view',
  TEAM_INVITE: 'team.invite',
  TEAM_EDIT: 'team.edit',
  TEAM_REMOVE: 'team.remove',

  BUDGET_VIEW: 'budget.view',
  BUDGET_MANAGE: 'budget.manage',

  REPORT_VIEW: 'report.view',

  FILE_VIEW: 'file.view',
  FILE_UPLOAD: 'file.upload',
  FILE_DELETE: 'file.delete',

  TIME_VIEW: 'time.view',
  TIME_MANAGE: 'time.manage',

  ACTIVITY_VIEW: 'activity.view',

  WORKLOAD_MANAGE: 'workload.manage',
};

const P = PROJECT_PERMISSIONS;

export const DEFAULT_ROLE_PERMISSIONS = {
  owner: Object.values(P),

  manager: [
    P.PROJECT_VIEW, P.PROJECT_EDIT,
    P.TASK_VIEW, P.TASK_CREATE, P.TASK_EDIT, P.TASK_DELETE, P.TASK_ASSIGN,
    P.TEAM_VIEW, P.TEAM_INVITE, P.TEAM_EDIT, P.TEAM_REMOVE,
    P.BUDGET_VIEW,
    P.REPORT_VIEW,
    P.FILE_VIEW, P.FILE_UPLOAD, P.FILE_DELETE,
    P.TIME_VIEW, P.TIME_MANAGE,
    P.ACTIVITY_VIEW,
    P.WORKLOAD_MANAGE,
  ],

  member: [
    P.PROJECT_VIEW,
    P.TASK_VIEW, P.TASK_CREATE, P.TASK_EDIT,
    P.FILE_VIEW, P.FILE_UPLOAD,
    P.TIME_VIEW,
    P.ACTIVITY_VIEW,
  ],

  viewer: [
    P.PROJECT_VIEW,
    P.TASK_VIEW,
    P.REPORT_VIEW,
    P.FILE_VIEW,
    P.ACTIVITY_VIEW,
  ],
};

// ---- UI-only metadata below: labels, grouping, role descriptions ----

export const ROLE_OPTIONS = ['manager', 'member', 'viewer'];

export const ROLE_META = {
  owner: {
    label: 'Owner',
    description: 'Full control over the project. Cannot be changed or removed.',
    badgeClass: 'bg-violet-100 text-violet-700 border-violet-200',
  },
  manager: {
    label: 'Manager',
    description: 'Can manage tasks, team, budget visibility, and workload.',
    badgeClass: 'bg-blue-100 text-blue-700 border-blue-200',
  },
  member: {
    label: 'Member',
    description: 'Can view and work on tasks assigned to them.',
    badgeClass: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  },
  viewer: {
    label: 'Viewer',
    description: 'Read-only access to the project.',
    badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
  },
};

// Permissions grouped for a clean checkbox UI in the permissions editor.
// Owner-only permissions are intentionally excluded (delete/settings) so a
// manager can never grant them to someone else.
export const PERMISSION_GROUPS = [
  {
    id: 'tasks',
    label: 'Tasks',
    permissions: [
      { key: P.TASK_VIEW, label: 'View tasks' },
      { key: P.TASK_CREATE, label: 'Create tasks' },
      { key: P.TASK_EDIT, label: 'Edit tasks' },
      { key: P.TASK_DELETE, label: 'Delete tasks' },
      { key: P.TASK_ASSIGN, label: 'Assign tasks' },
    ],
  },
  {
    id: 'team',
    label: 'Team',
    permissions: [
      { key: P.TEAM_VIEW, label: 'View team' },
      { key: P.TEAM_INVITE, label: 'Invite members' },
      { key: P.TEAM_EDIT, label: 'Edit member roles' },
      { key: P.TEAM_REMOVE, label: 'Remove members' },
    ],
  },
  {
    id: 'workload',
    label: 'Workload & time',
    permissions: [
      { key: P.WORKLOAD_MANAGE, label: 'Manage workload & capacity' },
      { key: P.TIME_VIEW, label: 'View time logs' },
      { key: P.TIME_MANAGE, label: 'Manage time logs' },
    ],
  },
  {
    id: 'budget',
    label: 'Budget & reports',
    permissions: [
      { key: P.BUDGET_VIEW, label: 'View budget' },
      { key: P.BUDGET_MANAGE, label: 'Manage budget' },
      { key: P.REPORT_VIEW, label: 'View reports' },
    ],
  },
  {
    id: 'files',
    label: 'Files',
    permissions: [
      { key: P.FILE_VIEW, label: 'View files' },
      { key: P.FILE_UPLOAD, label: 'Upload files' },
      { key: P.FILE_DELETE, label: 'Delete files' },
    ],
  },
];

export const ALL_ASSIGNABLE_PERMISSIONS = PERMISSION_GROUPS.flatMap((g) => g.permissions.map((p) => p.key));