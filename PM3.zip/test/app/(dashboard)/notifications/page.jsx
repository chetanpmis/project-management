'use client';

import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { CheckCheck, Trash2, Bell, FolderKanban, ListChecks, BellOffIcon } from 'lucide-react';
import notificationService from '@/services/notification.service';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/feedback/EmptyState';
import StatCard, { StatCardGrid } from '@/components/common/StatCard';
import { NotificationRowSkeleton } from '@/components/common/NotificationSkeleton';
import { ConfirmDialog, useMutationFeedback, SuccessDialog, ErrorDialog } from '@/components/common/AppDialogs';
import { useNotificationSocket } from '@/hooks/useNotificationSocket';
import { formatDistanceToNow } from 'date-fns';

export default function NotificationsPage() {
  const queryClient = useQueryClient();
  const feedback = useMutationFeedback();
  useNotificationSocket();

  const [tab, setTab] = useState('all');
  const [page, setPage] = useState(1);
  const [clearAllOpen, setClearAllOpen] = useState(false);

  const readFilter = tab === 'unread' ? false : tab === 'read' ? true : undefined;

  const { data, isLoading } = useQuery({
    queryKey: ['notifications', 'list', tab, page],
    queryFn: () => notificationService.getNotifications({ page, limit: 20, read: readFilter }),
  });

  const { data: unreadRes } = useQuery({
    queryKey: ['notifications', 'unreadCount'],
    queryFn: () => notificationService.getUnreadCount(),
  });

  const notifications = data?.data || [];
  const pagination = data?.pagination;
  const unreadCount = unreadRes?.data?.unreadCount ?? 0;

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['notifications'] });

  const handleMarkRead = async (id) => {
    await notificationService.markAsRead(id);
    invalidate();
  };

  const handleMarkAllRead = async () => {
    await feedback.run(notificationService.markAllAsRead(), 'All notifications marked as read.');
    invalidate();
  };

  const handleDelete = async (id) => {
    await notificationService.deleteNotification(id);
    invalidate();
  };

  const handleClearAll = async () => {
    await feedback.run(notificationService.clearAll(), 'Notifications cleared.');
    setClearAllOpen(false);
    invalidate();
  };

  const typeIcon = (type) => {
    if (type?.startsWith('task_')) return ListChecks;
    if (type?.startsWith('project_') || type?.startsWith('member_')) return FolderKanban;
    return Bell;
  };

  return (
    <div className="max-w-full">
      <PageHeader
        title="Notifications"
        description="Stay on top of project and task activity relevant to you."
        actions={
          <>
            {unreadCount > 0 && (
              <Button variant="outline" onClick={handleMarkAllRead}>
                <CheckCheck className="h-4 w-4 mr-2" />
                Mark all read
              </Button>
            )}
            {notifications.length > 0 && (
              <Button variant="outline" className="text-red-600 hover:text-red-600" onClick={() => setClearAllOpen(true)}>
                <Trash2 className="h-4 w-4 mr-2" />
                Clear all
              </Button>
            )}
          </>
        }
      />

      <StatCardGrid columns={3}>
        <StatCard title="Unread" value={unreadCount} icon={Bell} color="text-blue-600" highlight={unreadCount > 0} index={0} />
        <StatCard title="Total" value={pagination?.total ?? 0} icon={ListChecks} color="text-violet-600" index={1} />
        <StatCard title="Read" value={(pagination?.total ?? 0) - unreadCount} icon={CheckCheck} color="text-emerald-600" index={2} />
      </StatCardGrid>

      <Tabs value={tab} onValueChange={(v) => { setTab(v); setPage(1); }}>
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="unread">Unread{unreadCount > 0 && ` (${unreadCount})`}</TabsTrigger>
          <TabsTrigger value="read">Read</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4">
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <NotificationRowSkeleton count={6} />
              ) : notifications.length === 0 ? (
                <EmptyState
    icon={<BellOffIcon className="h-8 w-8" />}
  title={
    tab === 'unread'
      ? 'No unread notifications'
      : tab === 'read'
      ? 'No read notifications'
      : 'No notifications'
  }
  description={
    tab === 'unread'
      ? 'You\'re up to date.'
      : tab === 'read'
      ? 'Your read notifications will appear here.'
      : 'You have no notifications yet.'
  }
/>
              ) : (
                <div className="divide-y">
                  {notifications.map((n) => {
                    const Icon = typeIcon(n.type);
                    return (
                      <div
                        key={n._id}
                        className={`flex items-start gap-3 p-4 transition-colors ${!n.read ? 'bg-primary/5' : ''}`}
                      >
                        <div className="h-9 w-9 rounded-full bg-muted flex items-center justify-center shrink-0">
                          <Icon className="h-4.5 w-4.5 text-muted-foreground" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-semibold truncate">{n.title}</p>
                            {!n.read && <span className="h-2 w-2 rounded-full bg-primary shrink-0" />}
                          </div>
                          <p className="text-sm text-muted-foreground mt-0.5">{n.message}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                            <span>{formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}</span>
                            {n.relatedProject?.name && <span>· {n.relatedProject.name}</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {!n.read && (
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleMarkRead(n._id)} title="Mark as read">
                              <CheckCheck className="h-4 w-4" />
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500" onClick={() => handleDelete(n._id)} title="Delete">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {pagination?.totalPages > 1 && (
            <div className="flex justify-center gap-2 mt-4">
              <Button variant="outline" size="sm" disabled={!pagination.hasPrevious} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <span className="text-sm text-muted-foreground self-center">
                Page {pagination.page} of {pagination.totalPages}
              </span>
              <Button variant="outline" size="sm" disabled={!pagination.hasNext} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <ConfirmDialog
        open={clearAllOpen}
        onOpenChange={setClearAllOpen}
        title="Clear all notifications?"
        description="This will permanently remove all your notifications. This can't be undone."
        confirmLabel="Clear all"
        onConfirm={handleClearAll}
      />

      <SuccessDialog {...feedback.successProps} />
      <ErrorDialog {...feedback.errorProps} />
    </div>
  );
}