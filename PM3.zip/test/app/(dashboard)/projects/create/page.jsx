'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Loader2,
  Check,
  ClipboardList,
  CalendarDays,
  Wallet,
  Eye,
  AlertCircle,
  Coins,
  Users,
  Search,
  X,
  UserPlus,
} from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import projectService from '@/services/project.service';
import userService from '@/services/user.service';
import { useDebounce } from '@/hooks/useDebounce';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/common/PageHeader';
import { SuccessDialog, ErrorDialog } from '@/components/common/AppDialogs';
import { validateDateRange } from '@/lib/dateValidation';
import { cn } from '@/lib/utils';

const typeOptions = ['internal', 'client', 'product'];
const priorityOptions = ['low', 'medium', 'high', 'critical'];
const teamRoleOptions = ['member', 'manager', 'viewer'];

const currencies = [
  { code: 'USD', symbol: '$', label: 'US Dollar' },
  { code: 'INR', symbol: '₹', label: 'Indian Rupee' },
  { code: 'EUR', symbol: '€', label: 'Euro' },
];

const steps = [
  { id: 1, label: 'Project info' },
  { id: 2, label: 'Schedule & budget' },
  { id: 3, label: 'Team' },
  { id: 4, label: 'Milestones' },
  { id: 5, label: 'Preview' },
];

const stepFields = {
  1: ['name'],
  2: ['startDate', 'endDate', 'estimatedHours', 'budget.estimated', 'budget.approved'],
};


const schema = z
  .object({
    name: z.string().min(1, 'Project name is required'),
    description: z.string().optional(),
    projectType: z.enum(typeOptions),
    priority: z.enum(priorityOptions),
    startDate: z.string().min(1, 'Start date & time is required'),
    endDate: z.string().min(1, 'End date & time is required'),
    estimatedHours: z.coerce.number().min(0),
    currency: z.enum(currencies.map((c) => c.code)),
    budget: z.object({
      estimated: z.coerce.number().min(0),
      approved: z.coerce.number().min(0),
    }),
  })
  .refine((data) => new Date(data.endDate) >= new Date(data.startDate), {
    message: 'End date & time must be after the start date & time',
    path: ['endDate'],
  });

const milestoneSchema = z
  .object({
    name: z.string().min(1, 'Milestone name is required'),
    description: z.string().optional(),
    startDate: z.string().min(1, 'Start date & time is required'),
    dueDate: z.string().min(1, 'Due date & time is required'),
  })
  .refine((data) => new Date(data.dueDate) >= new Date(data.startDate), {
    message: 'Due date & time must be after the start date & time',
    path: ['dueDate'],
  });

function FieldLabel({ children, required }) {
  return (
    <Label className="text-base font-medium text-foreground">
      {children}
      {required && <span className="text-red-500 ml-0.5">*</span>}
    </Label>
  );
}

function FieldError({ message }) {
  if (!message) return null;
  return (
    <p className="text-red-500 text-sm flex items-center gap-1 mt-1.5">
      <AlertCircle className="h-3.5 w-3.5" /> {message}
    </p>
  );
}

function SectionCard({ icon: Icon, title, description, children }) {
  return (
    <Card>
      <CardHeader className="pb-5">
        <div className="flex items-center gap-2.5">
          {Icon && (
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
              <Icon className="h-4.5 w-4.5" />
            </span>
          )}
          <div>
            <CardTitle className="text-xl font-semibold">{title}</CardTitle>
            {description && <CardDescription className="text-base">{description}</CardDescription>}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-7">{children}</CardContent>
    </Card>
  );
}

function StepIndicator({ currentStep }) {
  return (
    <div className="flex items-start w-full">
      {steps.map((step, idx) => {
        const isComplete = currentStep > step.id;
        const isActive = currentStep === step.id;
        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-sm font-semibold transition-colors',
                  isComplete && 'border-primary bg-primary text-primary-foreground',
                  isActive && 'border-primary text-primary',
                  !isComplete && !isActive && 'border-muted text-muted-foreground'
                )}
              >
                {isComplete ? <Check className="h-4.5 w-4.5" /> : step.id}
              </div>
              <span className={cn('mt-2 text-sm font-medium whitespace-nowrap', isActive || isComplete ? 'text-foreground' : 'text-muted-foreground')}>
                {step.label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <div className={cn('h-px flex-1 mx-4 mt-[18px]', isComplete ? 'bg-primary' : 'bg-border')} />
            )}
          </div>
        );
      })}
    </div>
  );
}

/** Formats a "YYYY-MM-DDTHH:mm" datetime-local value for the preview step. */
function formatLocalDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

export default function CreateProjectPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [currentStep, setCurrentStep] = useState(1);

  const [teamQuery, setTeamQuery] = useState('');
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [milestones, setMilestones] = useState([]);

  const debouncedTeamQuery = useDebounce(teamQuery, 400);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    watch,
    setValue,
    trigger,
  } = useForm({
    resolver: zodResolver(schema),
    mode: 'onChange',
    defaultValues: {
      projectType: 'internal',
      priority: 'medium',
      estimatedHours: 0,
      currency: 'USD',
      budget: { estimated: 0, approved: 0 },
    },
  });

  const milestoneForm = useForm({
    resolver: zodResolver(milestoneSchema),
    defaultValues: { name: '', description: '', startDate: '', dueDate: '' },
  });

  const projectStart = watch('startDate');
  const projectEnd = watch('endDate');
  const currencyCode = watch('currency');
  const currencySymbol = currencies.find((c) => c.code === currencyCode)?.symbol ?? '$';

  const msStart = milestoneForm.watch('startDate');
  const msDue = milestoneForm.watch('dueDate');

  const addMilestone = () => {
    milestoneForm.handleSubmit((data) => {
      const { startError, endError } = validateDateRange({
        start: data.startDate,
        end: data.dueDate,
        bounds: { min: projectStart, max: projectEnd },
        startLabel: 'Milestone start',
        endLabel: 'Milestone due date',
      });
      if (startError) {
        milestoneForm.setError('startDate', { type: 'manual', message: startError });
        return;
      }
      if (endError) {
        milestoneForm.setError('dueDate', { type: 'manual', message: endError });
        return;
      }
      setMilestones((prev) => [...prev, data]);
      milestoneForm.reset();
    })();
  };

  const removeMilestone = (index) => setMilestones((prev) => prev.filter((_, i) => i !== index));

  const { data: userResults, isFetching: isSearchingUsers } = useQuery({
    queryKey: ['userSearch', debouncedTeamQuery],
    queryFn: async () => {
      const res = await userService.getUsers({ search: debouncedTeamQuery, limit: 6 });
      return res.data || [];
    },
    enabled: debouncedTeamQuery.trim().length > 1,
  });

  const addMember = (user) => {
    if (selectedMembers.some((m) => m.userId === user._id)) return;
    setSelectedMembers((prev) => [...prev, { userId: user._id, name: user.name, email: user.email, role: 'member' }]);
  };
  const updateMemberRole = (userId, role) => setSelectedMembers((prev) => prev.map((m) => (m.userId === userId ? { ...m, role } : m)));
  const removeMember = (userId) => setSelectedMembers((prev) => prev.filter((m) => m.userId !== userId));

  const createMutation = useMutation({
    mutationFn: (payload) =>
      projectService.createProject({ ...payload, milestones: milestones.length > 0 ? milestones : undefined }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setShowSuccess(true);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to create project');
      setShowError(true);
    },
  });

  const onSubmit = (data) => {
    const { currency, ...payload } = data;
    createMutation.mutate(payload);
  };

  const nextStep = async () => {
    if (currentStep === 4) {
      setCurrentStep(currentStep + 1);
      return;
    }
    const fieldsToValidate = stepFields[currentStep];
    const valid = fieldsToValidate ? await trigger(fieldsToValidate) : true;
    if (valid && currentStep < steps.length) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleSuccessClose = () => {
    setShowSuccess(false);
    router.push('/projects');
  };

  return (
    <div className="min-h-screen max-w-full">
      <form onSubmit={handleSubmit(onSubmit)} className="w-full">
        <PageHeader showBack size="form" title="New project" description="Set up a project, its schedule, team and milestones." />

        <div className="rounded-2xl border border-border p-6 lg:p-10 space-y-8">
          <StepIndicator currentStep={currentStep} />

          {/* Step 1 — Project info */}
          <div className={cn('transition-opacity duration-300', currentStep === 1 ? 'block' : 'hidden')}>
            <SectionCard icon={ClipboardList} title="Project information" description="What this project is and who it's for.">
              <div className="space-y-2">
                <FieldLabel required>Project name</FieldLabel>
                <Input placeholder="e.g. Q4 Marketing Campaign" {...register('name')} className={cn('h-12 text-base w-full', errors.name && 'border-red-500 focus-visible:ring-red-500')} />
                <FieldError message={errors.name?.message} />
              </div>

              <div className="space-y-2">
                <FieldLabel>Description</FieldLabel>
                <Textarea placeholder="A couple of sentences on scope and goals…" className="min-h-[108px] resize-y text-base w-full" {...register('description')} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <FieldLabel>Type</FieldLabel>
                  <Select defaultValue={typeOptions[0]} onValueChange={(v) => setValue('projectType', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {typeOptions.map((t) => (
                        <SelectItem key={t} value={t} className="capitalize text-base">{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Priority</FieldLabel>
                  <Select defaultValue={priorityOptions[1]} onValueChange={(v) => setValue('priority', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorityOptions.map((p) => (
                        <SelectItem key={p} value={p} className="capitalize text-base">{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Step 2 — Schedule & budget */}
          <div className={cn('transition-opacity duration-300 space-y-8', currentStep === 2 ? 'block' : 'hidden')}>
            <SectionCard icon={CalendarDays} title="Schedule" description="When the project runs — pick both the date and the time.">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel required>Start date &amp; time</FieldLabel>
                  <Input type="datetime-local" className="h-12 text-base w-full" {...register('startDate')} />
                  <FieldError message={errors.startDate?.message} />
                </div>

                <div className="space-y-2">
                  <FieldLabel required>End date &amp; time</FieldLabel>
                  <Input type="datetime-local" className="h-12 text-base w-full" min={projectStart || undefined} {...register('endDate')} />
                  <FieldError message={errors.endDate?.message} />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel>Estimated hours</FieldLabel>
                  <Input type="number" placeholder="120" {...register('estimatedHours', { valueAsNumber: true })} className={cn('h-12 text-base w-full', errors.estimatedHours && 'border-red-500 focus-visible:ring-red-500')} />
                  <FieldError message={errors.estimatedHours?.message} />
                </div>
              </div>
            </SectionCard>

            <SectionCard icon={Wallet} title="Budget" description="Financial planning for the project.">
              <div className="space-y-2">
                <FieldLabel>Currency</FieldLabel>
                <Select defaultValue="USD" onValueChange={(v) => setValue('currency', v)}>
                  <SelectTrigger className="h-12 text-base w-full sm:w-64">
                    <div className="flex items-center gap-2">
                      <Coins className="h-4 w-4 text-muted-foreground shrink-0" />
                      <SelectValue />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((c) => (
                      <SelectItem key={c.code} value={c.code} className="text-base">
                        <span className="font-medium mr-1.5">{c.symbol}</span>
                        {c.label} ({c.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel>Estimated budget</FieldLabel>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-base pointer-events-none">{currencySymbol}</span>
                    <Input type="number" placeholder="100,000" {...register('budget.estimated', { valueAsNumber: true })} className="pl-9 h-12 text-base w-full" />
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Approved budget</FieldLabel>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-base pointer-events-none">{currencySymbol}</span>
                    <Input type="number" placeholder="100,000" {...register('budget.approved', { valueAsNumber: true })} className="pl-9 h-12 text-base w-full" />
                  </div>
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Step 3 — Team */}
          <div className={cn('transition-opacity duration-300', currentStep === 3 ? 'block' : 'hidden')}>
            <SectionCard icon={Users} title="Team members" description="Optional — add people now, or invite them later. You're added automatically as owner.">
              <div className="space-y-2">
                <FieldLabel>Search people</FieldLabel>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-muted-foreground" />
                  <Input placeholder="Search by name or email…" value={teamQuery} onChange={(e) => setTeamQuery(e.target.value)} className="h-12 pl-11 text-base w-full" />
                </div>

                {debouncedTeamQuery.trim().length > 1 && (
                  <div className="rounded-lg border border-border divide-y divide-border overflow-hidden mt-2">
                    {isSearchingUsers ? (
                      <div className="px-4 py-3 text-sm text-muted-foreground flex items-center gap-2">
                        <Loader2 className="h-3.5 w-3.5 animate-spin" /> Searching…
                      </div>
                    ) : userResults && userResults.length > 0 ? (
                      userResults.map((user) => {
                        const alreadyAdded = selectedMembers.some((m) => m.userId === user._id);
                        return (
                          <button
                            type="button"
                            key={user._id}
                            onClick={() => addMember(user)}
                            disabled={alreadyAdded}
                            className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-muted/50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="text-xs">{user.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">{user.name}</p>
                                <p className="text-xs text-muted-foreground">{user.email}</p>
                              </div>
                            </div>
                            {alreadyAdded ? <Badge variant="secondary">Added</Badge> : <UserPlus className="h-4 w-4 text-muted-foreground" />}
                          </button>
                        );
                      })
                    ) : (
                      <div className="px-4 py-3 text-sm text-muted-foreground">No matching people</div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <FieldLabel>Added members {selectedMembers.length > 0 && `(${selectedMembers.length})`}</FieldLabel>
                {selectedMembers.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground">
                    No team members added yet — you can always add people from the project page later.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {selectedMembers.map((member) => (
                      <div key={member.userId} className="flex items-center justify-between gap-3 rounded-lg border border-border px-4 py-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <Avatar className="h-9 w-9 shrink-0">
                            <AvatarFallback className="text-xs">{member.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{member.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{member.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Select value={member.role} onValueChange={(v) => updateMemberRole(member.userId, v)}>
                            <SelectTrigger className="h-9 w-[120px] text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {teamRoleOptions.map((r) => (
                                <SelectItem key={r} value={r} className="capitalize text-sm">{r}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button type="button" variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-red-600" onClick={() => removeMember(member.userId)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </SectionCard>
          </div>

          {/* Step 4 — Milestones */}
          <div className={cn('transition-opacity duration-300', currentStep === 4 ? 'block' : 'hidden')}>
            <SectionCard icon={ClipboardList} title="Milestones" description="Add key milestones for the project (optional). Dates include time.">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <FieldLabel required>Milestone name</FieldLabel>
                  <Input placeholder="e.g. MVP Foundation" {...milestoneForm.register('name')} />
                  <FieldError message={milestoneForm.formState.errors.name?.message} />
                </div>

                <div className="space-y-2">
                  <FieldLabel>Description</FieldLabel>
                  <Input placeholder="Optional description" {...milestoneForm.register('description')} />
                </div>

                <div className="space-y-2">
                  <FieldLabel required>Start date &amp; time</FieldLabel>
                  <Input
                    type="datetime-local"
                    className="h-12 text-base w-full"
                    min={projectStart || undefined}
                    max={projectEnd || undefined}
                    {...milestoneForm.register('startDate')}
                  />
                  <FieldError message={milestoneForm.formState.errors.startDate?.message} />
                </div>

                <div className="space-y-2">
                  <FieldLabel required>Due date &amp; time</FieldLabel>
                  <Input
                    type="datetime-local"
                    className="h-12 text-base w-full"
                    min={msStart || projectStart || undefined}
                    max={projectEnd || undefined}
                    {...milestoneForm.register('dueDate')}
                  />
                  <FieldError message={milestoneForm.formState.errors.dueDate?.message} />
                </div>
              </div>

              <Button type="button" onClick={addMilestone} className="w-full mt-6">
                + Add milestone
              </Button>

              {milestones.length > 0 && (
                <div className="mt-8">
                  <h4 className="font-medium mb-3">Added milestones ({milestones.length})</h4>
                  <div className="space-y-3">
                    {milestones.map((milestone, index) => (
                      <div key={index} className="flex items-center justify-between rounded-lg border p-4">
                        <div>
                          <p className="font-medium">{milestone.name}</p>
                          {milestone.description && <p className="text-sm text-muted-foreground mt-1">{milestone.description}</p>}
                          <p className="text-sm text-muted-foreground mt-2">
                            Start: {formatLocalDateTime(milestone.startDate)} • Due: {formatLocalDateTime(milestone.dueDate)}
                          </p>
                        </div>
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeMilestone(index)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </SectionCard>
          </div>

          {/* Step 5 — Preview */}
          <div className={cn('transition-opacity duration-300', currentStep === 5 ? 'block' : 'hidden')}>
            <SectionCard icon={Eye} title="Preview" description="All your project details — ready to create!">
              <div className="space-y-6">
                <div className="space-y-2">
                  <FieldLabel>Project name</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base font-medium">{watch('name') || '—'}</div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Description</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 min-h-[88px] text-base">{watch('description') || '—'}</div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
                  <div className="space-y-2">
                    <FieldLabel>Type</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">{watch('projectType')}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Priority</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">{watch('priority')}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Start</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{formatLocalDateTime(projectStart)}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>End</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{formatLocalDateTime(projectEnd)}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Estimated hours</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{watch('estimatedHours')}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Milestones ({milestones.length})</FieldLabel>
                  {milestones.length === 0 ? (
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base text-muted-foreground">No milestones added yet (optional).</div>
                  ) : (
                    <div className="space-y-3">
                      {milestones.map((milestone, index) => (
                        <div key={index} className="bg-muted/30 rounded-md px-4 py-3 text-sm">
                          <p className="font-medium">{milestone.name}</p>
                          {milestone.description && <p className="text-muted-foreground mt-1">{milestone.description}</p>}
                          <p className="text-xs text-muted-foreground mt-3">
                            Start: {formatLocalDateTime(milestone.startDate)} • Due: {formatLocalDateTime(milestone.dueDate)}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <FieldLabel>Team members {selectedMembers.length > 0 && `(${selectedMembers.length})`}</FieldLabel>
                  {selectedMembers.length === 0 ? (
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base text-muted-foreground">Just you, as owner — you can invite people any time.</div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {selectedMembers.map((member) => (
                        <Badge key={member.userId} variant="outline" className="gap-1.5 py-1.5 px-3 text-sm">
                          {member.name} <span className="text-muted-foreground capitalize">· {member.role}</span>
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Bottom navigation */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div>
              {currentStep > 1 && (
                <Button type="button" variant="outline" onClick={prevStep} className="h-12 px-6 text-base">
                  Previous
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3">
              {currentStep === steps.length && (
                <Button type="button" variant="outline" onClick={() => router.back()} className="h-12 px-6 text-base">
                  Cancel
                </Button>
              )}

              {currentStep < steps.length && (
                <Button type="button" onClick={nextStep} className="h-12 px-8 text-base">
                  Next
                </Button>
              )}

              {currentStep === steps.length && (
                <Button type="submit" disabled={isSubmitting || createMutation.isPending} className="h-12 px-8 text-base min-w-[180px]">
                  {isSubmitting || createMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Creating project…
                    </>
                  ) : (
                    'Create project'
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      </form>

      <SuccessDialog
        open={showSuccess}
        onOpenChange={setShowSuccess}
        title="Project created"
        description="Your project has been created successfully."
        actionLabel="Go to projects"
        onAction={handleSuccessClose}
      />
      <ErrorDialog
        open={showError}
        onOpenChange={setShowError}
        title="Creation failed"
        description={errorMessage}
      />
    </div>
  );
}