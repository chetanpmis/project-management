'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Loader2,
  Check,
  ClipboardList,
  CalendarDays,
  Wallet,
  Eye,
  AlertCircle,
  Coins,
  Users,
  Search,
  X,
  UserPlus,
  Gauge,
  ShieldQuestion,
} from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import projectService from '@/services/project.service';
import userService from '@/services/user.service';
import { useDebounce } from '@/hooks/useDebounce';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/common/PageHeader';
import { SuccessDialog, ErrorDialog } from '@/components/common/AppDialogs';
import { PageHeaderSkeleton } from '@/components/common/Skeletons';
import { validateDateRange } from '@/lib/dateValidation';
import { cn } from '@/lib/utils';

const statusOptions = ['planning', 'active', 'on_hold', 'completed', 'cancelled'];
const typeOptions = ['internal', 'client', 'product'];
const priorityOptions = ['low', 'medium', 'high', 'critical'];
const healthOptions = ['healthy', 'at-risk', 'critical'];
const visibilityOptions = ['private', 'public'];
const teamRoleOptions = ['member', 'manager', 'viewer'];

const currencies = [
  { code: 'USD', symbol: '$', label: 'US Dollar' },
  { code: 'INR', symbol: '₹', label: 'Indian Rupee' },
  { code: 'EUR', symbol: '€', label: 'Euro' },
];

const steps = [
  { id: 1, label: 'Project info' },
  { id: 2, label: 'Schedule & budget' },
  { id: 3, label: 'Team' },
  { id: 4, label: 'Preview' },
];

const stepFields = {
  1: ['name'],
  2: ['startDate', 'endDate', 'estimatedHours', 'budget.estimated', 'budget.approved'],
};

// datetime-local inputs give "YYYY-MM-DDTHH:mm" — stored and submitted as-is.
const schema = z
  .object({
    name: z.string().min(1, 'Project name is required'),
    description: z.string().optional(),
    projectType: z.enum(typeOptions),
    status: z.enum(statusOptions),
    priority: z.enum(priorityOptions),
    health: z.enum(healthOptions),
    visibility: z.enum(visibilityOptions),
    startDate: z.string().min(1, 'Start date & time is required'),
    endDate: z.string().min(1, 'End date & time is required'),
    estimatedHours: z.coerce.number().min(0),
    currency: z.enum(currencies.map((c) => c.code)),
    budget: z.object({
      estimated: z.coerce.number().min(0),
      approved: z.coerce.number().min(0),
    }),
  })
  .refine((data) => new Date(data.endDate) >= new Date(data.startDate), {
    message: 'End date & time must be after the start date & time',
    path: ['endDate'],
  });

function FieldLabel({ children, required }) {
  return (
    <Label className="text-base font-medium text-foreground">
      {children}
      {required && <span className="text-red-500 ml-0.5">*</span>}
    </Label>
  );
}

function FieldError({ message }) {
  if (!message) return null;
  return (
    <p className="text-red-500 text-sm flex items-center gap-1 mt-1.5">
      <AlertCircle className="h-3.5 w-3.5" /> {message}
    </p>
  );
}

function SectionCard({ icon: Icon, title, description, children }) {
  return (
    <Card>
      <CardHeader className="pb-5">
        <div className="flex items-center gap-2.5">
          {Icon && (
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
              <Icon className="h-4.5 w-4.5" />
            </span>
          )}
          <div>
            <CardTitle className="text-xl font-semibold">{title}</CardTitle>
            {description && <CardDescription className="text-base">{description}</CardDescription>}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-7">{children}</CardContent>
    </Card>
  );
}

function StepIndicator({ currentStep }) {
  return (
    <div className="flex items-start w-full">
      {steps.map((step, idx) => {
        const isComplete = currentStep > step.id;
        const isActive = currentStep === step.id;
        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-sm font-semibold transition-colors',
                  isComplete && 'border-primary bg-primary text-primary-foreground',
                  isActive && 'border-primary text-primary',
                  !isComplete && !isActive && 'border-muted text-muted-foreground'
                )}
              >
                {isComplete ? <Check className="h-4.5 w-4.5" /> : step.id}
              </div>
              <span className={cn('mt-2 text-sm font-medium whitespace-nowrap', isActive || isComplete ? 'text-foreground' : 'text-muted-foreground')}>
                {step.label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <div className={cn('h-px flex-1 mx-4 mt-[18px]', isComplete ? 'bg-primary' : 'bg-border')} />
            )}
          </div>
        );
      })}
    </div>
  );
}

/** ISO datetime -> "YYYY-MM-DDTHH:mm" for the datetime-local input's value. */
function toDatetimeLocal(value) {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function formatLocalDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

export default function EditProjectPage() {
  const { id: projectId } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [currentStep, setCurrentStep] = useState(1);

  const [teamQuery, setTeamQuery] = useState('');
  const [selectedMembers, setSelectedMembers] = useState([]);
  const debouncedTeamQuery = useDebounce(teamQuery, 400);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    watch,
    setValue,
    trigger,
    reset,
  } = useForm({
    resolver: zodResolver(schema),
    mode: 'onChange',
  });

  const { data: projectRes, isLoading } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => projectService.getProjectById(projectId),
    enabled: !!projectId,
  });

  const project = projectRes?.data;

  useEffect(() => {
    if (project) {
      reset({
        name: project.name,
        description: project.description || '',
        projectType: project.projectType,
        status: project.status,
        priority: project.priority,
        health: project.health || 'healthy',
        visibility: project.visibility,
        startDate: toDatetimeLocal(project.startDate),
        endDate: toDatetimeLocal(project.endDate),
        estimatedHours: project.estimatedHours || 0,
        currency: 'USD',
        budget: {
          estimated: project.budget?.estimated || 0,
          approved: project.budget?.approved || 0,
        },
      });

      if (project.team?.length) {
        setSelectedMembers(
          project.team.map((t) => ({
            userId: t.user._id,
            name: t.user.name,
            email: t.user.email,
            role: t.role,
          }))
        );
      }
    }
  }, [project, reset]);

  const projectStart = watch('startDate');
  const projectEnd = watch('endDate');
  const currencyCode = watch('currency');
  const currencySymbol = currencies.find((c) => c.code === currencyCode)?.symbol ?? '$';

  const { data: userResults, isFetching: isSearchingUsers } = useQuery({
    queryKey: ['userSearch', debouncedTeamQuery],
    queryFn: async () => {
      const res = await userService.getUsers({ search: debouncedTeamQuery, limit: 6 });
      return res.data || [];
    },
    enabled: debouncedTeamQuery.trim().length > 1,
  });

  const addMember = (user) => {
    if (selectedMembers.some((m) => m.userId === user._id)) return;
    setSelectedMembers((prev) => [...prev, { userId: user._id, name: user.name, email: user.email, role: 'member' }]);
  };
  const updateMemberRole = (userId, role) => setSelectedMembers((prev) => prev.map((m) => (m.userId === userId ? { ...m, role } : m)));
  const removeMember = (userId) => setSelectedMembers((prev) => prev.filter((m) => m.userId !== userId));

  const updateMutation = useMutation({
    mutationFn: (data) => projectService.updateProject(projectId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['project', projectId] });
      setShowSuccess(true);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to update project');
      setShowError(true);
    },
  });

  const onSubmit = (data) => {
    const { currency, ...payload } = data;
    updateMutation.mutate(payload);
  };

  const handleSuccessClose = () => {
    setShowSuccess(false);
    router.push(`/projects/${projectId}`);
  };

  const nextStep = async () => {
    const fieldsToValidate = stepFields[currentStep];
    const valid = fieldsToValidate ? await trigger(fieldsToValidate) : true;
    if (valid && currentStep < steps.length) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen max-w-4xl mx-auto p-6 lg:p-8 space-y-6">
        <PageHeaderSkeleton />
        <div className="rounded-2xl border p-10 space-y-6 animate-pulse">
          <div className="h-4 w-full bg-muted rounded" />
          <div className="h-24 w-full bg-muted rounded" />
          <div className="h-10 w-1/2 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen max-w-4xl mx-auto p-6 lg:p-8">
      <form onSubmit={handleSubmit(onSubmit)} className="w-full">
        <PageHeader showBack size="form" title="Edit project" description={project?.name} />

        <div className="rounded-2xl border border-border p-6 lg:p-10 space-y-8">
          <StepIndicator currentStep={currentStep} />

          {/* Step 1 — Project info */}
          <div className={cn('transition-opacity duration-300', currentStep === 1 ? 'block' : 'hidden')}>
            <SectionCard icon={ClipboardList} title="Project information" description="What this project is and who it's for.">
              <div className="space-y-2">
                <FieldLabel required>Project name</FieldLabel>
                <Input placeholder="e.g. Q4 Marketing Campaign" {...register('name')} className={cn('h-12 text-base w-full', errors.name && 'border-red-500 focus-visible:ring-red-500')} />
                <FieldError message={errors.name?.message} />
              </div>

              <div className="space-y-2">
                <FieldLabel>Description</FieldLabel>
                <Textarea placeholder="A couple of sentences on scope and goals…" className="min-h-[108px] resize-y text-base w-full" {...register('description')} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="space-y-2">
                  <FieldLabel>Type</FieldLabel>
                  <Select value={watch('projectType')} onValueChange={(v) => setValue('projectType', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {typeOptions.map((t) => (
                        <SelectItem key={t} value={t} className="capitalize text-base">{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Status</FieldLabel>
                  <Select value={watch('status')} onValueChange={(v) => setValue('status', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {statusOptions.map((s) => (
                        <SelectItem key={s} value={s} className="capitalize text-base">{s.replace('_', ' ')}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Priority</FieldLabel>
                  <Select value={watch('priority')} onValueChange={(v) => setValue('priority', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorityOptions.map((p) => (
                        <SelectItem key={p} value={p} className="capitalize text-base">{p}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <FieldLabel>
                    <span className="inline-flex items-center gap-1.5"><Gauge className="h-3.5 w-3.5" />Health</span>
                  </FieldLabel>
                  <Select value={watch('health')} onValueChange={(v) => setValue('health', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {healthOptions.map((h) => (
                        <SelectItem key={h} value={h} className="capitalize text-base">{h.replace('-', ' ')}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2 max-w-xs">
                <FieldLabel>
                  <span className="inline-flex items-center gap-1.5"><ShieldQuestion className="h-3.5 w-3.5" />Visibility</span>
                </FieldLabel>
                <Select value={watch('visibility')} onValueChange={(v) => setValue('visibility', v)}>
                  <SelectTrigger className="h-12 text-base w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {visibilityOptions.map((v) => (
                      <SelectItem key={v} value={v} className="capitalize text-base">{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </SectionCard>
          </div>

          {/* Step 2 — Schedule & budget */}
          <div className={cn('transition-opacity duration-300 space-y-8', currentStep === 2 ? 'block' : 'hidden')}>
            <SectionCard icon={CalendarDays} title="Schedule" description="When the project runs — pick both the date and the time.">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel required>Start date &amp; time</FieldLabel>
                  <Input type="datetime-local" className="h-12 text-base w-full" {...register('startDate')} />
                  <FieldError message={errors.startDate?.message} />
                </div>

                <div className="space-y-2">
                  <FieldLabel required>End date &amp; time</FieldLabel>
                  <Input type="datetime-local" className="h-12 text-base w-full" min={projectStart || undefined} {...register('endDate')} />
                  <FieldError message={errors.endDate?.message} />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel>Estimated hours</FieldLabel>
                  <Input type="number" placeholder="120" {...register('estimatedHours', { valueAsNumber: true })} className={cn('h-12 text-base w-full', errors.estimatedHours && 'border-red-500 focus-visible:ring-red-500')} />
                  <FieldError message={errors.estimatedHours?.message} />
                </div>
              </div>
            </SectionCard>

            <SectionCard icon={Wallet} title="Budget" description="Financial planning for the project.">
              <div className="space-y-2">
                <FieldLabel>Currency</FieldLabel>
                <Select value={currencyCode} onValueChange={(v) => setValue('currency', v)}>
                  <SelectTrigger className="h-12 text-base w-full sm:w-64">
                    <div className="flex items-center gap-2">
                      <Coins className="h-4 w-4 text-muted-foreground shrink-0" />
                      <SelectValue />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    {currencies.map((c) => (
                      <SelectItem key={c.code} value={c.code} className="text-base">
                        <span className="font-medium mr-1.5">{c.symbol}</span>
                        {c.label} ({c.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel>Estimated budget</FieldLabel>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-base pointer-events-none">{currencySymbol}</span>
                    <Input type="number" placeholder="100,000" {...register('budget.estimated', { valueAsNumber: true })} className="pl-9 h-12 text-base w-full" />
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Approved budget</FieldLabel>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-base pointer-events-none">{currencySymbol}</span>
                    <Input type="number" placeholder="100,000" {...register('budget.approved', { valueAsNumber: true })} className="pl-9 h-12 text-base w-full" />
                  </div>
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Step 3 — Team (read-only summary; manage membership from the project's Team tab) */}
          <div className={cn('transition-opacity duration-300', currentStep === 3 ? 'block' : 'hidden')}>
            <SectionCard icon={Users} title="Team members" description="Add people here, or manage roles and permissions from the project's Team tab after saving.">
              <div className="space-y-2">
                <FieldLabel>Search people</FieldLabel>
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-muted-foreground" />
                  <Input placeholder="Search by name or email…" value={teamQuery} onChange={(e) => setTeamQuery(e.target.value)} className="h-12 pl-11 text-base w-full" />
                </div>

                {debouncedTeamQuery.trim().length > 1 && (
                  <div className="rounded-lg border border-border divide-y divide-border overflow-hidden mt-2">
                    {isSearchingUsers ? (
                      <div className="px-4 py-3 text-sm text-muted-foreground flex items-center gap-2">
                        <Loader2 className="h-3.5 w-3.5 animate-spin" /> Searching…
                      </div>
                    ) : userResults && userResults.length > 0 ? (
                      userResults.map((user) => {
                        const alreadyAdded = selectedMembers.some((m) => m.userId === user._id);
                        return (
                          <button
                            type="button"
                            key={user._id}
                            onClick={() => addMember(user)}
                            disabled={alreadyAdded}
                            className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-muted/50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback className="text-xs">{user.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">{user.name}</p>
                                <p className="text-xs text-muted-foreground">{user.email}</p>
                              </div>
                            </div>
                            {alreadyAdded ? <Badge variant="secondary">Added</Badge> : <UserPlus className="h-4 w-4 text-muted-foreground" />}
                          </button>
                        );
                      })
                    ) : (
                      <div className="px-4 py-3 text-sm text-muted-foreground">No matching people</div>
                    )}
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <FieldLabel>Team {selectedMembers.length > 0 && `(${selectedMembers.length})`}</FieldLabel>
                {selectedMembers.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground">
                    No team members yet.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {selectedMembers.map((member) => (
                      <div key={member.userId} className="flex items-center justify-between gap-3 rounded-lg border border-border px-4 py-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <Avatar className="h-9 w-9 shrink-0">
                            <AvatarFallback className="text-xs">{member.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{member.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{member.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <Select value={member.role} onValueChange={(v) => updateMemberRole(member.userId, v)} disabled={member.role === 'owner'}>
                            <SelectTrigger className="h-9 w-[120px] text-sm">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {teamRoleOptions.map((r) => (
                                <SelectItem key={r} value={r} className="capitalize text-sm">{r}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {member.role !== 'owner' && (
                            <Button type="button" variant="ghost" size="icon" className="h-9 w-9 text-muted-foreground hover:text-red-600" onClick={() => removeMember(member.userId)}>
                              <X className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </SectionCard>
          </div>

          {/* Step 4 — Preview */}
          <div className={cn('transition-opacity duration-300', currentStep === 4 ? 'block' : 'hidden')}>
            <SectionCard icon={Eye} title="Preview" description="Review your changes before saving.">
              <div className="space-y-6">
                <div className="space-y-2">
                  <FieldLabel>Project name</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base font-medium">{watch('name') || '—'}</div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Description</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 min-h-[88px] text-base">{watch('description') || '—'}</div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
                  <div className="space-y-2">
                    <FieldLabel>Status</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">{watch('status')?.replace('_', ' ')}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Priority</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">{watch('priority')}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Start</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{formatLocalDateTime(projectStart)}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>End</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{formatLocalDateTime(projectEnd)}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Estimated hours</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{watch('estimatedHours')}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Team members {selectedMembers.length > 0 && `(${selectedMembers.length})`}</FieldLabel>
                  <div className="flex flex-wrap gap-2">
                    {selectedMembers.map((member) => (
                      <Badge key={member.userId} variant="outline" className="gap-1.5 py-1.5 px-3 text-sm">
                        {member.name} <span className="text-muted-foreground capitalize">· {member.role}</span>
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Bottom navigation */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div>
              {currentStep > 1 && (
                <Button type="button" variant="outline" onClick={prevStep} className="h-12 px-6 text-base">
                  Previous
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3">
              {currentStep === steps.length && (
                <Button type="button" variant="outline" onClick={() => router.back()} className="h-12 px-6 text-base">
                  Cancel
                </Button>
              )}

              {currentStep < steps.length && (
                <Button type="button" onClick={nextStep} className="h-12 px-8 text-base">
                  Next
                </Button>
              )}

              {currentStep === steps.length && (
                <Button type="submit" disabled={isSubmitting || updateMutation.isPending} className="h-12 px-8 text-base min-w-[160px]">
                  {isSubmitting || updateMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Updating…
                    </>
                  ) : (
                    'Update project'
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      </form>

      <SuccessDialog
        open={showSuccess}
        onOpenChange={setShowSuccess}
        title="Project updated"
        description="Changes have been saved successfully."
        actionLabel="Go to project"
        onAction={handleSuccessClose}
      />
      <ErrorDialog
        open={showError}
        onOpenChange={setShowError}
        title="Update failed"
        description={errorMessage}
      />
    </div>
  );
}