"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Pencil,
  Trash2,
  Plus,
  Users,
  Clock,
  Wallet,
  CheckCircle2,
  AlertTriangle,
  Calendar as CalendarIcon,
  Globe,
  Lock,
  MoreVertical,
  GanttChartSquare,
  KanbanSquare,
  Maximize2,
  BarChart3,
  MessageSquare,
} from "lucide-react";
import projectService from "@/services/project.service";
import taskService from "@/services/task.service";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import TasksTable from "@/components/tasks/TasksTable";
import TaskFormDialog from "@/components/tasks/TaskFormDialog";
import ProjectGanttChart from "@/components/projects/ProjectGanttChart";
import KanbanBoard from "@/components/projects/KanbanBoard";
import PageHeader from "@/components/common/PageHeader";
import PermissionGate from "@/lib/permissionGate";
import { usePermission } from "@/hooks/usePermission";
import {
  ProjectStatusBadge,
  PriorityBadge,
  HealthBadge,
  MilestoneStatusBadge,
} from "@/components/common/StatusBadges";
import { CardListSkeleton, TableSkeleton } from "@/components/common/Skeletons";
import EmptyState from "@/components/feedback/EmptyState";
import {
  SuccessDialog,
  ErrorDialog,
  ConfirmDialog,
  useMutationFeedback,
} from "@/components/common/AppDialogs";
import StatCard, { StatCardGrid } from "@/components/common/StatCard";
import ProjectTeamPanel from "@/components/projects/ProjectTeamPanel";
import ProjectWorkloadTab from "@/components/projects/ProjectWorkloadTab";
import { PROJECT_PERMISSIONS } from "@/constants/projectPermissions";
import ProjectChatTab from "../../../../components/projects/ProjectChatTab";

export default function ProjectDetailsPage() {
  const { id } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const feedback = useMutationFeedback();

  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [deleteProjectOpen, setDeleteProjectOpen] = useState(false);
  const [isDeletingProject, setIsDeletingProject] = useState(false);

  const { data: projectRes, isLoading: isProjectLoading } = useQuery({
    queryKey: ["project", id],
    queryFn: () => projectService.getProjectById(id),
    enabled: !!id,
  });

  const { data: statsRes } = useQuery({
    queryKey: ["projectStats", id],
    queryFn: () => projectService.getProjectStats(id),
    enabled: !!id,
  });

  const { data: tasksRes, isLoading: isTasksLoading } = useQuery({
    queryKey: ["tasks", id],
    queryFn: () => taskService.getTasksByProject(id, { limit: 50 }),
    enabled: !!id,
  });
  const { data: chatUnreadRes } = useQuery({
    queryKey: ["chat", id, "unreadCount"],
    queryFn: () => chatService.getUnreadCount(id),
    refetchInterval: 15000,
    enabled: !!id,
  });

  const chatUnread = chatUnreadRes?.data?.unreadCount ?? 0;

  const project = projectRes?.data;
  const stats = statsRes?.data;
  const tasks = tasksRes?.data || [];

  const canEditProject = usePermission(
    project,
    PROJECT_PERMISSIONS.PROJECT_EDIT,
  );
  const canDeleteProject = usePermission(
    project,
    PROJECT_PERMISSIONS.PROJECT_DELETE,
  );

  const invalidateProject = () => {
    queryClient.invalidateQueries({ queryKey: ["project", id] });
    queryClient.invalidateQueries({ queryKey: ["projectStats", id] });
    queryClient.invalidateQueries({ queryKey: ["kanban", id] }); // ← Added for Kanban
  };

  const handleConfirmDeleteProject = async () => {
    setIsDeletingProject(true);
    try {
      await projectService.deleteProject(id);
      router.push("/projects");
    } catch (err) {
      setIsDeletingProject(false);
      setDeleteProjectOpen(false);
      feedback
        .run(
          Promise.reject(err),
          "",
          err?.message || "Could not delete this project.",
        )
        .catch(() => {});
    }
  };

  if (isProjectLoading) {
    return (
      <div className="max-w-6xl mx-auto p-6 lg:p-8 space-y-6">
        <PageHeader loading />
        <StatCardGrid columns={4}>
          {[...Array(4)].map((_, i) => (
            <StatCard key={i} loading />
          ))}
        </StatCardGrid>
        <CardListSkeleton count={3} height="h-16" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <EmptyState
          title="Project not found"
          description="This project may have been deleted, or you may not have access to it."
          action={
            <Button variant="outline" onClick={() => router.push("/projects")}>
              Back to projects
            </Button>
          }
        />
      </div>
    );
  }

  const budget = project.budget || {};
  const spentPct =
    budget.approved > 0
      ? Math.min(100, Math.round((budget.spent / budget.approved) * 100))
      : 0;
  const milestones = (project.milestones || []).sort(
    (a, b) => new Date(a.startDate) - new Date(b.startDate),
  );
  const pendingCount = milestones.filter((m) => m.status === "pending").length;
  const inProgressCount = milestones.filter(
    (m) => m.status === "in-progress",
  ).length;
  const completedCount = milestones.filter(
    (m) => m.status === "completed",
  ).length;

  const handleFullScreen = () => router.push(`/projects/${id}/gantt`);

  return (
    <div className="max-w-full mx-auto ">
      <PageHeader
        showBack
        title={project.name}
        eyebrow={project.projectCode}
        description={project.description}
        badges={[
          <ProjectStatusBadge key="status" status={project.status} />,
          <PriorityBadge key="priority" priority={project.priority} />,
          <HealthBadge key="health" health={project.health} />,
          <Badge key="vis" variant="outline" className="capitalize gap-1">
            {project.visibility === "private" ? (
              <Lock className="h-3 w-3" />
            ) : (
              <Globe className="h-3 w-3" />
            )}
            {project.visibility}
          </Badge>,
        ]}
        actions={
          <>
            {canEditProject && (
              <Button
                variant="outline"
                onClick={() => router.push(`/projects/${id}/edit`)}
              >
                <Pencil className="h-4 w-4 mr-2" />
                Edit
              </Button>
            )}
            {canDeleteProject && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    className="text-red-600 focus:text-red-600"
                    onClick={() => setDeleteProjectOpen(true)}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete project
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </>
        }
      />

      <StatCardGrid columns={4}>
        <StatCard
          title="Progress"
          value={`${stats?.progress ?? project.progress ?? 0}%`}
          sub={
            stats
              ? `${stats.completedTasks}/${stats.totalTasks} tasks done`
              : undefined
          }
          icon={CheckCircle2}
          color="text-emerald-600"
          index={0}
        />
        <StatCard
          title="Overdue tasks"
          value={stats?.overdueTasks ?? 0}
          icon={AlertTriangle}
          color="text-red-600"
          highlight={(stats?.overdueTasks ?? 0) > 0}
          index={1}
        />
        <StatCard
          title="Hours logged"
          value={`${project.loggedHours ?? 0}`}
          sub={`of ${project.estimatedHours ?? 0} estimated`}
          icon={Clock}
          color="text-blue-600"
          index={2}
        />
        <StatCard
          title="Team"
          value={project.team?.length ?? 0}
          sub={
            stats?.overloadedMembers
              ? `${stats.overloadedMembers} overloaded`
              : undefined
          }
          icon={Users}
          color="text-violet-600"
          index={3}
        />
      </StatCardGrid>

      <Tabs defaultValue="overview" className="mt-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="milestones">Milestones</TabsTrigger>
          <TabsTrigger value="tasks">
            Tasks{tasks.length > 0 && ` (${tasks.length})`}
          </TabsTrigger>
          <TabsTrigger value="team">
            Team ({project.team?.length ?? 0})
          </TabsTrigger>
          <TabsTrigger value="chat" className="gap-1.5 relative">
            <MessageSquare className="h-3.5 w-3.5" />
            Chat
            {chatUnread > 0 && (
              <span className="absolute -top-1.5 -right-2 h-4 min-w-4 px-1 rounded-full bg-red-500 text-white text-[10px] leading-4 text-center">
                {chatUnread > 9 ? "9+" : chatUnread}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="workload">Workload</TabsTrigger>
          <TabsTrigger value="reports" className="gap-1.5">
            <GanttChartSquare className="h-3.5 w-3.5" />
            Reports
          </TabsTrigger>
        </TabsList>

        {/* Overview */}
        <TabsContent value="overview" className="space-y-6 mt-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CalendarIcon className="h-4.5 w-4.5 text-primary" />
                  Timeline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Start date</span>
                  <span className="font-medium">
                    {project.startDate
                      ? new Date(project.startDate).toLocaleDateString()
                      : "—"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">End date</span>
                  <span className="font-medium">
                    {project.endDate
                      ? new Date(project.endDate).toLocaleDateString()
                      : "—"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type</span>
                  <span className="font-medium capitalize">
                    {project.projectType}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Owner</span>
                  <span className="font-medium">{project.owner?.name}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wallet className="h-4.5 w-4.5 text-primary" />
                  Budget
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <p className="text-muted-foreground">Estimated</p>
                    <p className="font-semibold">{budget.estimated ?? 0}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Approved</p>
                    <p className="font-semibold">{budget.approved ?? 0}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Spent</p>
                    <p className="font-semibold">{budget.spent ?? 0}</p>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Spent of approved</span>
                    <span>{spentPct}%</span>
                  </div>
                  <Progress value={spentPct} className="h-2" />
                </div>
                <p className="text-sm text-muted-foreground">
                  Remaining:{" "}
                  <span className="font-medium text-foreground">
                    {budget.remaining ?? 0}
                  </span>
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Milestones */}
        <TabsContent value="milestones" className="space-y-5 mt-4">
          <StatCardGrid columns={3}>
            <Card>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">Pending</p>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-2xl font-bold">{pendingCount}</span>
                  <MilestoneStatusBadge status="pending" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">In progress</p>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-2xl font-bold">{inProgressCount}</span>
                  <MilestoneStatusBadge status="in-progress" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">Completed</p>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-2xl font-bold">{completedCount}</span>
                  <MilestoneStatusBadge status="completed" />
                </div>
              </CardContent>
            </Card>
          </StatCardGrid>

          {milestones.length === 0 ? (
            <EmptyState
              compact
              title="No milestones yet"
              description="Milestones you add to this project will show up here."
            />
          ) : (
            <div className="space-y-3">
              {milestones.map((milestone, index) => (
                <Card
                  key={milestone._id}
                  className="transition-all duration-200 hover:shadow-md hover:border-primary/40"
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold">
                        {index + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold truncate">
                            {milestone.name}
                          </h3>
                          <MilestoneStatusBadge status={milestone.status} />
                        </div>
                        {milestone.description && (
                          <p className="mt-1 text-sm text-muted-foreground line-clamp-1">
                            {milestone.description}
                          </p>
                        )}
                        <div className="mt-3 flex flex-wrap items-center gap-5 text-xs text-muted-foreground">
                          <span>
                            <strong className="text-foreground">Start:</strong>{" "}
                            {new Date(milestone.startDate).toLocaleDateString()}
                          </span>
                          <span>
                            <strong className="text-foreground">Due:</strong>{" "}
                            {new Date(milestone.dueDate).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <div className="w-52 shrink-0">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-muted-foreground">
                            Progress
                          </span>
                          <span className="font-semibold">
                            {milestone.progress}%
                          </span>
                        </div>
                        <Progress value={milestone.progress} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Tasks */}
        <TabsContent value="tasks" className="space-y-4 mt-4">
          <div className="flex justify-end">
            <PermissionGate
              project={project}
              permission={PROJECT_PERMISSIONS.TASK_CREATE}
              inline
            >
              <Button onClick={() => setShowTaskDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add task
              </Button>
            </PermissionGate>
          </div>
          {isTasksLoading ? (
            <TableSkeleton rows={4} columns={8} />
          ) : (
            <TasksTable
              tasks={tasks}
              isLoading={false}
              projectId={id}
              onEdit={() => {}}
              onTaskDeleted={invalidateProject}
              canEdit
              canDelete
            />
          )}
        </TabsContent>

        {/* Team */}
        <TabsContent value="team" className="mt-4">
          <ProjectTeamPanel
            project={project}
            isLoading={false}
            onChanged={invalidateProject}
          />
        </TabsContent>

        <TabsContent value="chat" className="mt-4">
          <ProjectChatTab project={project} />
        </TabsContent>

        {/* Workload */}
        <TabsContent value="workload" className="mt-4">
          <ProjectWorkloadTab project={project} />
        </TabsContent>

        {/* Reports */}
        <TabsContent
          value="reports"
          className="space-y-4 mt-4 bg-white px-4 py-4 rounded-lg border"
        >
          <Tabs defaultValue="gantt" className="w-full">
            <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
              <TabsList>
                <TabsTrigger value="gantt" className="gap-1.5">
                  <GanttChartSquare className="h-4 w-4" />
                  Gantt Chart
                </TabsTrigger>
                <TabsTrigger value="kanban" className="gap-1.5">
                  <KanbanSquare className="h-4 w-4" />
                  Kanban Board
                </TabsTrigger>
              </TabsList>

              <Button variant="outline" onClick={handleFullScreen}>
                <Maximize2 className="h-4 w-4 mr-2" />
                Full Screen Gantt
              </Button>
            </div>

            <TabsContent value="gantt">
              <ProjectGanttChart projectId={id} />
            </TabsContent>

            <TabsContent value="kanban">
              <KanbanBoard projectId={id} />
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>

      <TaskFormDialog
        open={showTaskDialog}
        onOpenChange={setShowTaskDialog}
        projectId={id}
        teamMembers={project.team || []}
        onCreated={invalidateProject}
      />

      <ConfirmDialog
        open={deleteProjectOpen}
        onOpenChange={setDeleteProjectOpen}
        title="Delete project?"
        description={`"${project.name}" and all of its tasks and milestones will be permanently removed. This can't be undone.`}
        confirmLabel="Delete"
        loading={isDeletingProject}
        onConfirm={handleConfirmDeleteProject}
      />

      <SuccessDialog {...feedback.successProps} />
      <ErrorDialog {...feedback.errorProps} />
    </div>
  );
}
