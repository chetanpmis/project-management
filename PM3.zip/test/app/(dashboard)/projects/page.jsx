'use client';

import { Plus } from 'lucide-react';
import { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { FolderKanban, CheckSquare, Clock3, PauseCircle, XCircle, PercentCircle } from 'lucide-react';

import projectService from '@/services/project.service';
import ProjectFilters from '@/components/projects/ProjectFilters';
import ProjectsTable from '@/components/projects/ProjectsTable';
import PageHeader from '@/components/common/PageHeader';
import StatCard, { StatCardGrid } from '@/components/common/StatCard';
import { StatGridSkeleton } from '@/components/common/Skeletons';
import { Button } from '@/components/ui/button';

export default function ProjectsPage() {
  const router = useRouter();
  const queryClient = useQueryClient();

  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [projectType, setProjectType] = useState('');
  const [priority, setPriority] = useState('');
  const [sortBy, setSortBy] = useState('createdAt');

  const { data: projectsData, isLoading, isFetching } = useQuery({
    queryKey: ['projects', search, status, projectType, priority, sortBy],
    queryFn: () => projectService.getProjects({ search, status, projectType, priority, sortBy }),
  });

  const projects = projectsData?.data || [];

  const stats = useMemo(() => {
    const counts = { total: 0, planning: 0, active: 0, on_hold: 0, completed: 0, cancelled: 0 };
    projects.forEach((p) => {
      counts.total++;
      if (counts[p.status] !== undefined) counts[p.status]++;
    });
    const completionRate = counts.total > 0 ? Math.round((counts.completed / counts.total) * 100) : 0;
    return { ...counts, completionRate };
  }, [projects]);

  const handleRefresh = () => queryClient.invalidateQueries({ queryKey: ['projects'] });
  const goToCreate = () => router.push('/projects/create');

  return (
    <div className="min-h-screen bg-background p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <PageHeader
          title="Projects"
          description="Manage and monitor all your projects."
          actions={
            <Button size="lg" onClick={goToCreate}>
              <Plus className="h-5 w-5 mr-2" />
              New project
            </Button>
          }
        />

        {isLoading ? (
          <div className="mb-8">
            <StatGridSkeleton count={6} columns={6} />
          </div>
        ) : (
          <div className="mb-8">
            <StatCardGrid columns={6}>
              <StatCard title="Total" value={stats.total} icon={FolderKanban} color="text-slate-600" index={0} />
              <StatCard title="Planning" value={stats.planning} icon={Clock3} color="text-blue-600" index={1} />
              <StatCard title="Active" value={stats.active} icon={CheckSquare} color="text-emerald-600" index={2} />
              <StatCard title="On hold" value={stats.on_hold} icon={PauseCircle} color="text-amber-600" index={3} />
              <StatCard title="Completed" value={stats.completed} icon={CheckSquare} color="text-blue-600" index={4} />
              <StatCard title="Completion rate" value={`${stats.completionRate}%`} icon={PercentCircle} color="text-violet-600" index={5} />
            </StatCardGrid>
          </div>
        )}

        <ProjectFilters
          search={search}
          setSearch={setSearch}
          status={status}
          setStatus={setStatus}
          projectType={projectType}
          setProjectType={setProjectType}
          priority={priority}
          setPriority={setPriority}
          sortBy={sortBy}
          setSortBy={setSortBy}
          onRefresh={handleRefresh}
          isLoading={isFetching}
        />

        <div className="mt-6">
          <ProjectsTable projects={projects} isLoading={isLoading} onDeleted={handleRefresh} onCreateProject={goToCreate} />
        </div>
      </div>
    </div>
  );
}