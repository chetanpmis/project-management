'use client';

import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import {
  FolderKanban,
  CheckSquare,
  ListTodo,
  AlertTriangle,
  TrendingUp,
  CalendarClock,
  Plus,
  Pencil,
  Trash2,
  UserPlus,
  UserMinus,
  MessageSquare,
  Paperclip,
  Eye,
  Flag,
  Wallet,
  Clock,
  ArrowRight,
} from 'lucide-react';
import Link from 'next/link';

import dashboardService from '@/services/dashboard.service';
import StatCard, { StatCardGrid } from '@/components/common/StatCard';
import { StatGridSkeleton, CardListSkeleton } from '@/components/common/Skeletons';
import ErrorState from '@/components/feedback/ErrorState';
import EmptyState from '@/components/feedback/EmptyState';
import { TaskStatusBadge, PriorityBadge } from '@/components/common/StatusBadges';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TASK_STATUS_CONFIG } from '@/lib/statusConfig';
import { cn } from '@/lib/utils';

function greeting() {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

const ACTIVITY_META = {
  task_created: { icon: Plus, color: 'text-emerald-600 bg-emerald-50' },
  task_updated: { icon: Pencil, color: 'text-blue-600 bg-blue-50' },
  task_deleted: { icon: Trash2, color: 'text-red-600 bg-red-50' },
  task_status_changed: { icon: Flag, color: 'text-violet-600 bg-violet-50' },
  task_assigned: { icon: UserPlus, color: 'text-blue-600 bg-blue-50' },
  task_unassigned: { icon: UserMinus, color: 'text-slate-600 bg-slate-100' },
  checklist_updated: { icon: CheckSquare, color: 'text-emerald-600 bg-emerald-50' },
  comment_added: { icon: MessageSquare, color: 'text-blue-600 bg-blue-50' },
  comment_deleted: { icon: MessageSquare, color: 'text-red-600 bg-red-50' },
  file_uploaded: { icon: Paperclip, color: 'text-blue-600 bg-blue-50' },
  file_deleted: { icon: Paperclip, color: 'text-red-600 bg-red-50' },
  attachment_added: { icon: Paperclip, color: 'text-blue-600 bg-blue-50' },
  attachment_removed: { icon: Paperclip, color: 'text-red-600 bg-red-50' },
  watcher_added: { icon: Eye, color: 'text-blue-600 bg-blue-50' },
  watcher_removed: { icon: Eye, color: 'text-slate-600 bg-slate-100' },
  member_added: { icon: UserPlus, color: 'text-emerald-600 bg-emerald-50' },
  member_removed: { icon: UserMinus, color: 'text-red-600 bg-red-50' },
  member_role_changed: { icon: Pencil, color: 'text-amber-600 bg-amber-50' },
  member_updated: { icon: Pencil, color: 'text-amber-600 bg-amber-50' },
  project_created: { icon: FolderKanban, color: 'text-emerald-600 bg-emerald-50' },
  project_updated: { icon: Pencil, color: 'text-blue-600 bg-blue-50' },
  project_archived: { icon: FolderKanban, color: 'text-slate-600 bg-slate-100' },
  project_deleted: { icon: Trash2, color: 'text-red-600 bg-red-50' },
  budget_updated: { icon: Wallet, color: 'text-amber-600 bg-amber-50' },
  expense_added: { icon: Wallet, color: 'text-amber-600 bg-amber-50' },
  expense_approved: { icon: Wallet, color: 'text-emerald-600 bg-emerald-50' },
  milestone_created: { icon: Flag, color: 'text-violet-600 bg-violet-50' },
  milestone_completed: { icon: Flag, color: 'text-emerald-600 bg-emerald-50' },
  milestone_removed: { icon: Flag, color: 'text-red-600 bg-red-50' },
  work_log_added: { icon: Clock, color: 'text-blue-600 bg-blue-50' },
  work_log_approved: { icon: Clock, color: 'text-emerald-600 bg-emerald-50' },
  workload_updated: { icon: Clock, color: 'text-blue-600 bg-blue-50' },
};

function activityMeta(type) {
  return ACTIVITY_META[type] || { icon: Pencil, color: 'text-slate-600 bg-slate-100' };
}

function relativeTime(dateStr) {
  const date = new Date(dateStr);
  const diffMs = Date.now() - date.getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString();
}

function dueLabel(dueDate) {
  const due = new Date(dueDate);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diffDays = Math.round((due.setHours(0, 0, 0, 0) - today.getTime()) / (24 * 60 * 60 * 1000));
  if (diffDays < 0) return { text: `${Math.abs(diffDays)}d overdue`, tone: 'text-red-600 font-semibold' };
  if (diffDays === 0) return { text: 'Due today', tone: 'text-amber-600 font-semibold' };
  if (diffDays === 1) return { text: 'Due tomorrow', tone: 'text-amber-600' };
  return { text: `Due in ${diffDays}d`, tone: 'text-muted-foreground' };
}

export default function DashboardPage() {
  const now = new Date();
  const currentDateTime =
    now.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }) +
    ', ' +
    now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['dashboardSummary'],
    queryFn: () => dashboardService.getSummary(),
  });

  const {
    stats = {},
    myWork = { total: 0, dueToday: 0, overdue: 0, byStatus: [] },
    upcomingWork = [],
    recentProjects = [],
    recentActivity = [],
  } = data || {};

  const hasMyWork = myWork.byStatus.some((s) => s.value > 0);

  // Keys line up exactly with TASK_STATUS_CONFIG (todo / in-progress / review / completed)
  const chartData = useMemo(
    () =>
      myWork.byStatus.map((entry) => ({
        ...entry,
        name: TASK_STATUS_CONFIG[entry.key]?.label || entry.name,
        color: TASK_STATUS_CONFIG[entry.key]?.hex || '#94a3b8',
      })),
    [myWork.byStatus]
  );

  if (isLoading) {
    return (
      <div className="space-y-8 p-6">
        <div className="space-y-2">
          <div className="h-9 w-64 bg-muted rounded animate-pulse" />
          <div className="h-4 w-96 bg-muted rounded animate-pulse" />
        </div>
        <StatGridSkeleton count={4} columns={4} />
        <div className="grid gap-6 lg:grid-cols-3">
          <CardListSkeleton count={1} height="h-72" />
          <div className="lg:col-span-2"><CardListSkeleton count={1} height="h-72" /></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <ErrorState title="Couldn't load your dashboard" description={error.message} onRetry={refetch} />
      </div>
    );
  }

  return (
    <div className="space-y-8 p-6 max-w-[1600px] mx-auto">
      <div>
        <h1 className="text-4xl font-bold tracking-tight">{greeting()} 👋</h1>
        <p className="mt-2 text-muted-foreground">{`Here's what's happening with your work today. ${currentDateTime}`}</p>
      </div>

      {/* ===== Task overview stats (scoped to tasks assigned to me) ===== */}
      <StatCardGrid columns={4}>
        <StatCard title="My tasks" value={myWork.total} icon={ListTodo} color="text-blue-600" index={0} sub={`${stats.totalTasks ?? 0} across ${stats.totalProjects ?? 0} projects`} />
        <StatCard title="Due today" value={myWork.dueToday} icon={CalendarClock} color="text-amber-600" index={1} highlight={myWork.dueToday > 0} />
        <StatCard title="Overdue" value={myWork.overdue} icon={AlertTriangle} color="text-red-600" index={2} highlight={myWork.overdue > 0} />
        <StatCard title="Completed" value={stats.completedTasks ?? 0} icon={CheckSquare} color="text-emerald-600" index={3} sub={`${stats.completionRate ?? 0}% completion rate`} />
      </StatCardGrid>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* ===== My tasks — status pie chart ===== */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-xl">Task overview</CardTitle>
          </CardHeader>
          <CardContent>
            {hasMyWork ? (
              <>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={chartData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={2}>
                        {chartData.map((entry) => (
                          <Cell key={entry.key} fill={entry.color} stroke="none" />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {chartData.map((entry) => (
                    <div key={entry.key} className="flex items-center justify-between text-sm rounded-md px-2.5 py-1.5 bg-muted/40">
                      <span className="flex items-center gap-2 text-muted-foreground">
                        <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: entry.color }} />
                        {entry.name}
                      </span>
                      <span className="font-semibold">{entry.value}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <EmptyState compact icon={<ListTodo className="h-6 w-6" />} title="Nothing assigned yet" description="Tasks assigned to you will show up here." />
            )}
          </CardContent>
        </Card>

        {/* ===== Upcoming tasks (next 7 days) ===== */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-xl">Upcoming — next 7 days</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {upcomingWork.length === 0 ? (
              <div className="p-6">
                <EmptyState compact icon={<CalendarClock className="h-6 w-6" />} title="Nothing due soon" description="Tasks assigned to you and due in the next 7 days will show up here." />
              </div>
            ) : (
              <div className="divide-y">
                {upcomingWork.map((task) => {
                  const due = dueLabel(task.dueDate);
                  return (
                    <Link
                      key={task._id}
                      href={`/tasks/${task._id}`}
                      className="flex items-center justify-between gap-4 px-6 py-4 hover:bg-muted/40 transition-colors group"
                    >
                      <div className="min-w-0">
                        <p className="font-medium truncate">{task.title}</p>
                        <p className="text-xs text-muted-foreground truncate mt-0.5">{task.project?.name}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        {task.priority && <PriorityBadge priority={task.priority} className="hidden sm:inline-flex" />}
                        <TaskStatusBadge status={task.status} />
                        <span className={cn('text-xs w-24 text-right', due.tone)}>{due.text}</span>
                        <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* ===== Recent projects ===== */}
        <Card className="lg:col-span-2 overflow-hidden">
          <CardHeader className="pb-3">
            <CardTitle className="text-xl">Recent projects</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {recentProjects.length === 0 && (
                <div className="p-6">
                  <EmptyState compact icon={<FolderKanban className="h-6 w-6" />} title="No projects yet" description="Projects you're part of will show up here." />
                </div>
              )}
              {recentProjects.map((project) => (
                <Link key={project._id} href={`/projects/${project._id}`} className="block p-6 hover:bg-muted/40 transition-colors">
                  <div className="flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <h3 className="font-semibold text-lg truncate">{project.name}</h3>
                      {project.description && <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{project.description}</p>}
                    </div>
                    <div className="text-2xl font-bold shrink-0">{project.progress ?? 0}%</div>
                  </div>
                  <Progress value={project.progress ?? 0} className="h-2 mt-4" />
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* ===== Efficiency ===== */}
        <div className="space-y-6">
          <Card>
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground flex items-center gap-1.5">
                <TrendingUp className="h-3.5 w-3.5" />
                Overall completion rate
              </p>
              <div className="flex items-end gap-2 mt-2">
                <h2 className="text-4xl font-bold">{stats.completionRate || 0}%</h2>
                <span className="text-xs text-muted-foreground mb-1.5">
                  {stats.completedTasks || 0}/{stats.totalTasks || 0}
                </span>
              </div>
              <Progress value={stats.completionRate || 0} className="h-2 mt-3" />
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground flex items-center gap-1.5">
                <TrendingUp className="h-3.5 w-3.5" />
                Efficiency this month
              </p>
              <div className="flex items-end gap-2 mt-2">
                <h2 className="text-4xl font-bold">{stats.thisMonth?.efficiency || 0}%</h2>
                <span className="text-xs text-muted-foreground mb-1.5">
                  {stats.thisMonth?.completedTasks || 0}/{stats.thisMonth?.totalTasks || 0}
                </span>
              </div>
              <Progress value={stats.thisMonth?.efficiency || 0} className="h-2 mt-3" />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ===== Recent Activity ===== */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-xl">Recent activity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1">
          {recentActivity.length === 0 && (
            <EmptyState compact title="No recent activity" description="Activity on your projects and tasks will show up here." />
          )}
          {recentActivity.map((activity, i) => {
            const meta = activityMeta(activity.type);
            const Icon = meta.icon;
            return (
              <div key={activity._id || i} className="flex gap-3 py-2.5 -mx-2 px-2 rounded-lg hover:bg-muted/40 transition-colors">
                <span className={cn('flex h-8 w-8 items-center justify-center rounded-full shrink-0', meta.color)}>
                  <Icon className="h-4 w-4" />
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">{activity.description}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {activity.project?.name && <span className="font-medium">{activity.project.name}</span>}
                    {activity.project?.name && ' · '}
                    by {activity.user?.name} · {relativeTime(activity.createdAt)}
                  </p>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}