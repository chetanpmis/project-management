'use client';

import { useState, useRef, useCallback } from 'react';
import { useParams } from 'next/navigation';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Loader2,
  Pencil,
  Play,
  Pause,
  CheckCircle2,
  Paperclip,
  X,
  Plus,
  UserPlus,
  UploadCloud,
  Clock,
  FileText,
  Trash2,
  AlertCircle,
} from 'lucide-react';
import taskService from '@/services/task.service';
import CommentSection from '@/components/tasks/CommentSection';
import TaskFormDialog from '@/components/tasks/TaskFormDialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { hasPermission } from '@/lib/permissions';
import useAuthStore from '@/store/auth-store';
import PageHeader from '@/components/common/PageHeader';
import { TaskStatusBadge, PriorityBadge } from '@/components/common/StatusBadges';
import { ConfirmDialog } from '@/components/common/AppDialogs';
import ErrorState from '@/components/feedback/ErrorState';

const MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024;
const CHECKLIST_DEBOUNCE_MS = 500;

function formatSeconds(totalSeconds = 0) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
}

function formatBytes(bytes = 0) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function TaskDetailPage({ currentUserId, teamMembers = [], project = null }) {
  const { id: taskId } = useParams();
  const queryClient = useQueryClient();
  const { user } = useAuthStore();

  const [editOpen, setEditOpen] = useState(false);
  const [newChecklistItem, setNewChecklistItem] = useState('');

  const [watcherDialogOpen, setWatcherDialogOpen] = useState(false);
  const [attachDialogOpen, setAttachDialogOpen] = useState(false);
  const [isDragActive, setIsDragActive] = useState(false);
  const [attachError, setAttachError] = useState('');
  const [pendingFile, setPendingFile] = useState(null);
  const [removeChecklistTarget, setRemoveChecklistTarget] = useState(null);
  const [removeAttachmentTarget, setRemoveAttachmentTarget] = useState(null);
  const fileInputRef = useRef(null);

  const checklistDebounceRef = useRef({});

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['task', taskId],
    queryFn: () => taskService.getTaskById(taskId),
    enabled: !!taskId,
  });

  const { data: projectTasksData } = useQuery({
    queryKey: ['tasks', data?.data?.project?._id],
    queryFn: () => taskService.getTasksByProject(data.data.project._id),
    enabled: !!data?.data?.project?._id,
  });

  const { data: timerData } = useQuery({
    queryKey: ['timer', taskId],
    queryFn: () => taskService.getTimerStatus(taskId),
    enabled: !!taskId,
    refetchInterval: 5000,
  });

  const task = data?.data;
  const projectTasks = projectTasksData?.data || [];
  const timerRunning = timerData?.data?.isRunning;
  const displaySeconds = timerRunning ? timerData?.data?.elapsedSeconds ?? task?.timeSpent : task?.timeSpent;

  const isCompleted = task?.status === 'completed';

  const invalidateTask = () => {
    queryClient.invalidateQueries({ queryKey: ['task', taskId] });
    queryClient.invalidateQueries({ queryKey: ['timer', taskId] });
  };

  const startTimerMutation = useMutation({ mutationFn: () => taskService.startTimer(taskId), onSuccess: invalidateTask });
  const stopTimerMutation = useMutation({ mutationFn: () => taskService.stopTimer(taskId), onSuccess: invalidateTask });
  const resumeTimerMutation = useMutation({ mutationFn: () => taskService.resumeTimer(taskId), onSuccess: invalidateTask });
  const finishTaskMutation = useMutation({ mutationFn: () => taskService.finishTask(taskId), onSuccess: invalidateTask });

  const addChecklistMutation = useMutation({
    mutationFn: (item) => taskService.addChecklistItem(taskId, item),
    onSuccess: () => {
      setNewChecklistItem('');
      invalidateTask();
    },
  });

  const toggleChecklistMutation = useMutation({
    mutationFn: ({ itemId, completed }) => taskService.toggleChecklistItem(taskId, itemId, completed),
    onError: () => invalidateTask(),
  });

  const applyOptimisticChecklist = useCallback(
    (itemId, completed) => {
      queryClient.setQueryData(['task', taskId], (old) => {
        if (!old?.data) return old;
        return {
          ...old,
          data: {
            ...old.data,
            checklist: old.data.checklist.map((c) => (c._id === itemId ? { ...c, completed } : c)),
          },
        };
      });
    },
    [queryClient, taskId]
  );

  const handleToggleChecklist = (itemId, completed) => {
    if (isCompleted) return;
    applyOptimisticChecklist(itemId, completed);
    if (checklistDebounceRef.current[itemId]) clearTimeout(checklistDebounceRef.current[itemId]);
    checklistDebounceRef.current[itemId] = setTimeout(() => {
      toggleChecklistMutation.mutate({ itemId, completed });
      delete checklistDebounceRef.current[itemId];
    }, CHECKLIST_DEBOUNCE_MS);
  };

  const removeChecklistMutation = useMutation({
    mutationFn: (itemId) => taskService.removeChecklistItem(taskId, itemId),
    onSuccess: () => {
      invalidateTask();
      setRemoveChecklistTarget(null);
    },
  });

  const addWatcherMutation = useMutation({
    mutationFn: (userId) => taskService.addWatcher(taskId, userId),
    onSuccess: invalidateTask,
  });
  const removeWatcherMutation = useMutation({ mutationFn: (userId) => taskService.removeWatcher(taskId, userId), onSuccess: invalidateTask });

  const addAttachmentMutation = useMutation({
    mutationFn: ({ filename, url }) => taskService.addAttachment(taskId, filename, url),
    onSuccess: () => {
      invalidateTask();
      setAttachDialogOpen(false);
      setPendingFile(null);
      setAttachError('');
    },
  });
  const removeAttachmentMutation = useMutation({
    mutationFn: (attachmentId) => taskService.removeAttachment(taskId, attachmentId),
    onSuccess: () => {
      invalidateTask();
      setRemoveAttachmentTarget(null);
    },
  });

  const validateAndStageFile = (file) => {
    if (!file) return;
    if (file.size > MAX_ATTACHMENT_BYTES) {
      setAttachError(`"${file.name}" is ${formatBytes(file.size)} — max allowed size is 25 MB.`);
      setPendingFile(null);
      return;
    }
    setAttachError('');
    setPendingFile(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragActive(false);
    validateAndStageFile(e.dataTransfer.files?.[0]);
  };

  const handleUploadConfirm = () => {
    if (!pendingFile) return;
    const url = URL.createObjectURL(pendingFile);
    addAttachmentMutation.mutate({ filename: pendingFile.name, url });
  };

  // === PERMISSION & ASSIGNEE CHECKS ===
  const isAssignee = task?.assignees?.some((a) => a._id === currentUserId);
  const isOwner = task?.owner?._id === currentUserId;

  const canFinishTask = (isAssignee || isOwner) && !isCompleted;
  const canStartTimer = (isAssignee || isOwner) && !isCompleted;
  const canStopTimer = timerRunning && canStartTimer;
  const canEditTask = hasPermission(task, user?.id, 'task.edit');
  const canDeleteAttachment = hasPermission(task, user?.id, 'file.delete');
  const canAddAttachment = hasPermission(task, user?.id, 'file.upload') && (isAssignee || isOwner) && !isCompleted;
  const canManageWatchers = hasPermission(task, user?.id, 'task.assign') && !isCompleted;

  const canAddChecklist = !isCompleted;
  const canToggleChecklist = !isCompleted;
  const canRemoveChecklist = !isCompleted;

  const checklistDone = task?.checklist?.filter((c) => c.completed).length || 0;
  const checklistTotal = task?.checklist?.length || 0;
  const checklistProgress = checklistTotal ? Math.round((checklistDone / checklistTotal) * 100) : 0;

  const allChecklistCompleted = checklistTotal > 0 && checklistDone === checklistTotal;
  const hasActiveTimerHistory = task?.workLogs?.length > 0;

  const watcherIds = new Set((task?.watchers || []).map((w) => w._id));
  const availableWatchers = teamMembers.filter((m) => !watcherIds.has(m._id));

  const isOverdue = task?.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed';

  if (isLoading) {
    return (
      <div className="w-full max-w-[1500px] mx-auto p-6 space-y-5">
        <div className="h-8 w-32 bg-muted rounded animate-pulse" />
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-5">
          <div className="space-y-5">
            <div className="h-40 bg-muted rounded-xl animate-pulse" />
            <div className="h-32 bg-muted rounded-xl animate-pulse" />
          </div>
          <div className="space-y-5">
            <div className="h-24 bg-muted rounded-xl animate-pulse" />
            <div className="h-24 bg-muted rounded-xl animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !task) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <ErrorState title="Couldn't load this task" description={error?.message} onRetry={refetch} />
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen bg-slate-50">
      <div className="w-full max-w-[1500px] mx-auto">
        <PageHeader
          showBack
          size="form"
          eyebrow={task.project?.name || 'No Project'}
          title={task.title}
          badges={[
            <TaskStatusBadge key="status" status={isOverdue ? 'overdue' : task.status} />,
            <PriorityBadge key="priority" priority={task.priority} />,
          ]}
          actions={
            <>
              {canFinishTask && (
                <Button
                  size="sm"
                  onClick={() => finishTaskMutation.mutate()}
                  disabled={finishTaskMutation.isPending || (checklistTotal > 0 && !allChecklistCompleted)}
                  className="gap-2"
                >
                  {finishTaskMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="h-4 w-4" />
                  )}
                  Finish Task
                </Button>
              )}

              {canEditTask && (
                <Button size="sm" variant="outline" onClick={() => setEditOpen(true)}>
                  <Pencil className="h-4 w-4 mr-1.5" />
                  Edit
                </Button>
              )}
            </>
          }
        />

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6 px-6 pb-10">
          {/* ================= MAIN COLUMN ================= */}
          <div className="space-y-6 min-w-0">
            {/* Metadata */}
            <div className="flex flex-wrap gap-x-8 gap-y-3 text-sm bg-white border rounded-xl p-5">
              {task.project && (
                <div>
                  <span className="text-xs text-muted-foreground block">PROJECT</span>
                  <p className="font-medium">{task.project.name}</p>
                </div>
              )}
              {task.milestone && (
                <div>
                  <span className="text-xs text-muted-foreground block">MILESTONE</span>
                  <p className="font-medium">{task.milestone.name}</p>
                </div>
              )}
              {task.dueDate && (
                <div>
                  <span className="text-xs text-muted-foreground block">DUE DATE</span>
                  <p className="font-medium">{new Date(task.dueDate).toLocaleDateString()}</p>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="bg-white border rounded-xl p-6 shadow-sm">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                Description
                {isCompleted && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded">Completed</span>}
              </h3>
              {task.description ? (
                <p className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">
                  {task.description}
                </p>
              ) : (
                <p className="text-sm text-muted-foreground italic">No description provided.</p>
              )}

              {task.tags?.length > 0 && (
                <div className="flex gap-1.5 flex-wrap mt-6">
                  {task.tags.map((t) => (
                    <span key={t} className="text-xs px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full font-medium">
                      #{t}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* ===== CHECKLIST ===== */}
            <div className="bg-white border rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold flex items-center gap-2">
                  Checklist
                  {checklistTotal > 0 && (
                    <span className="text-sm font-normal text-muted-foreground">
                      {checklistDone}/{checklistTotal} • {checklistProgress}%
                    </span>
                  )}
                </h2>
                {checklistTotal > 0 && (
                  <div className="w-24 bg-muted rounded-full h-1.5">
                    <div className="bg-emerald-600 h-1.5 rounded-full transition-all" style={{ width: `${checklistProgress}%` }} />
                  </div>
                )}
              </div>

              <ul className="space-y-1 mb-5">
                {task.checklist?.length > 0 ? (
                  task.checklist.map((c) => (
                    <li key={c._id} className="flex items-center gap-3 text-sm group rounded-lg px-3 py-2.5 -mx-3 hover:bg-slate-50 transition-colors">
                      <input
                        type="checkbox"
                        className="h-4 w-4 accent-emerald-600 mt-0.5"
                        checked={c.completed}
                        disabled={!canToggleChecklist}
                        onChange={(e) => handleToggleChecklist(c._id, e.target.checked)}
                      />
                      <span className={`flex-1 ${c.completed ? 'line-through text-muted-foreground' : ''}`}>
                        {c.item}
                      </span>
                      {canRemoveChecklist && (
                        <button
                          onClick={() => setRemoveChecklistTarget(c)}
                          className="text-muted-foreground hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </li>
                  ))
                ) : (
                  <li className="text-sm text-muted-foreground py-4 text-center">No checklist items yet.</li>
                )}
              </ul>

              {canAddChecklist && (
                <div className="flex gap-2">
                  <Input
                    className="flex-1"
                    placeholder="Add new checklist item..."
                    value={newChecklistItem}
                    onChange={(e) => setNewChecklistItem(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && newChecklistItem.trim()) {
                        addChecklistMutation.mutate(newChecklistItem.trim());
                      }
                    }}
                  />
                  <Button
                    size="sm"
                    onClick={() => newChecklistItem.trim() && addChecklistMutation.mutate(newChecklistItem.trim())}
                    disabled={addChecklistMutation.isPending || !newChecklistItem.trim()}
                  >
                    {addChecklistMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                  </Button>
                </div>
              )}
            </div>

            {/* ===== ATTACHMENTS ===== */}
            <div className="bg-white border rounded-xl p-6 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold flex items-center gap-2">
                  <Paperclip className="h-4 w-4" /> Attachments
                </h2>
                {canAddAttachment && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setAttachError('');
                      setPendingFile(null);
                      setAttachDialogOpen(true);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1.5" />
                    Add file
                  </Button>
                )}
              </div>

              <ul className="space-y-2">
                {task.attachments?.length > 0 ? (
                  task.attachments.map((att) => (
                    <li key={att._id} className="flex items-center justify-between group rounded-lg border p-3 hover:bg-slate-50">
                      <a
                        href={att.url}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-3 text-blue-600 hover:underline flex-1 min-w-0"
                      >
                        <FileText className="h-4 w-4 shrink-0" />
                        <span className="truncate">{att.filename}</span>
                      </a>
                      {canDeleteAttachment && !isCompleted && (
                        <button
                          onClick={() => setRemoveAttachmentTarget(att)}
                          className="text-muted-foreground hover:text-red-500 p-1"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </li>
                  ))
                ) : (
                  <li className="text-sm text-muted-foreground py-8 text-center border border-dashed rounded-xl">
                    No attachments yet
                  </li>
                )}
              </ul>
            </div>

            {/* ===== COMMENTS ===== */}
            <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
              <CommentSection taskId={taskId} currentUserId={currentUserId} disabled={isCompleted} />
            </div>
          </div>

          {/* ================= SIDEBAR ================= */}
          <div className="space-y-6">
            {/* Timer */}
            <div className="bg-white border rounded-xl p-5 shadow-sm">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-2 uppercase text-xs tracking-widest text-muted-foreground font-medium">
                  <Clock className="h-4 w-4" />
                  TIME TRACKED
                </div>
                {timerRunning && (
                  <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-medium">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    LIVE
                  </div>
                )}
              </div>

              <div className="text-3xl font-mono font-semibold mb-4 tracking-tighter">
                {formatSeconds(displaySeconds || 0)}
              </div>

              {!isCompleted && (
                <div className="flex gap-2">
                  {!timerRunning && canStartTimer && (
                    <Button
                      className="flex-1"
                      onClick={() => (hasActiveTimerHistory ? resumeTimerMutation.mutate() : startTimerMutation.mutate())}
                      disabled={startTimerMutation.isPending || resumeTimerMutation.isPending}
                    >
                      {startTimerMutation.isPending || resumeTimerMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Play className="mr-2 h-4 w-4" />
                      )}
                      {hasActiveTimerHistory ? 'Resume' : 'Start Timer'}
                    </Button>
                  )}
                  {timerRunning && canStopTimer && (
                    <Button
                      variant="secondary"
                      className="flex-1"
                      onClick={() => stopTimerMutation.mutate()}
                      disabled={stopTimerMutation.isPending}
                    >
                      {stopTimerMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Pause className="mr-2 h-4 w-4" />}
                      Stop
                    </Button>
                  )}
                </div>
              )}
            </div>

            {/* Assignees */}
            <div className="bg-white border rounded-xl p-5 shadow-sm">
              <div className="uppercase text-xs tracking-widest text-muted-foreground font-medium mb-3">ASSIGNEES</div>
              <div className="flex flex-wrap gap-2">
                {task.assignees?.length > 0 ? (
                  task.assignees.map((a) => (
                    <div key={a._id} className="px-3 py-1 bg-slate-100 rounded-full text-sm font-medium">
                      {a.name}
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No assignees</p>
                )}
              </div>
            </div>

            {/* Watchers */}
            <div className="bg-white border rounded-xl p-5 shadow-sm">
              <div className="flex justify-between items-center mb-3">
                <div className="uppercase text-xs tracking-widest text-muted-foreground font-medium">WATCHERS</div>
                {canManageWatchers && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-blue-600"
                    onClick={() => setWatcherDialogOpen(true)}
                  >
                    <UserPlus className="h-3.5 w-3.5 mr-1" /> Add
                  </Button>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                {task.watchers?.length > 0 ? (
                  task.watchers.map((w) => (
                    <div key={w._id} className="inline-flex items-center gap-1 px-3 py-1 bg-slate-100 rounded-full text-sm">
                      {w.name}
                      {(canManageWatchers || w._id === currentUserId) && (
                        <button onClick={() => removeWatcherMutation.mutate(w._id)} className="ml-1 text-red-400 hover:text-red-600">
                          <X className="h-3 w-3" />
                        </button>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">No watchers</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <TaskFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        projectId={task.project?._id}
        project={project}
        teamMembers={teamMembers}
        projectTasks={projectTasks}
        initialData={task}
        isEditing
        onCreated={invalidateTask}
      />

      <Dialog open={watcherDialogOpen} onOpenChange={setWatcherDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Watcher</DialogTitle>
          </DialogHeader>
          <div className="max-h-80 overflow-auto py-2">
            {availableWatchers.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">All team members are already watching.</p>
            ) : (
              availableWatchers.map((m) => (
                <button
                  key={m._id}
                  onClick={() => addWatcherMutation.mutate(m._id)}
                  className="w-full text-left px-4 py-3 hover:bg-slate-100 rounded-lg flex justify-between items-center"
                >
                  <div>
                    <div>{m.name}</div>
                    <div className="text-xs text-muted-foreground">{m.email}</div>
                  </div>
                </button>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={attachDialogOpen} onOpenChange={setAttachDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Attachment</DialogTitle>
          </DialogHeader>

          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragActive(true); }}
            onDragLeave={() => setIsDragActive(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-10 text-center cursor-pointer transition-all ${
              isDragActive ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:border-slate-300'
            }`}
          >
            <UploadCloud className={`mx-auto h-12 w-12 mb-4 ${isDragActive ? 'text-blue-500' : 'text-slate-400'}`} />
            <p className="font-medium">Drop file here or click to browse</p>
            <p className="text-xs text-muted-foreground mt-1">Maximum 25 MB</p>
            <input ref={fileInputRef} type="file" className="hidden" onChange={(e) => validateAndStageFile(e.target.files?.[0])} />
          </div>

          {pendingFile && (
            <div className="mt-4 p-3 bg-slate-50 rounded-lg flex items-center gap-3 text-sm">
              <FileText className="h-5 w-5 text-slate-500" />
              <div className="flex-1 truncate">{pendingFile.name}</div>
              <div className="text-xs text-muted-foreground">{formatBytes(pendingFile.size)}</div>
            </div>
          )}

          {attachError && (
            <div className="mt-3 flex items-center gap-2 text-red-600 text-sm">
              <AlertCircle className="h-4 w-4" /> {attachError}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setAttachDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleUploadConfirm} disabled={!pendingFile || !!attachError || addAttachmentMutation.isPending}>
              {addAttachmentMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!removeChecklistTarget}
        onOpenChange={(v) => !v && setRemoveChecklistTarget(null)}
        title="Remove checklist item?"
        description={`Are you sure you want to remove "${removeChecklistTarget?.item}"?`}
        confirmLabel="Remove"
        loading={removeChecklistMutation.isPending}
        onConfirm={() => removeChecklistMutation.mutate(removeChecklistTarget?._id)}
      />

      <ConfirmDialog
        open={!!removeAttachmentTarget}
        onOpenChange={(v) => !v && setRemoveAttachmentTarget(null)}
        title="Delete attachment?"
        description={`"${removeAttachmentTarget?.filename}" will be permanently deleted.`}
        confirmLabel="Delete"
        loading={removeAttachmentMutation.isPending}
        onConfirm={() => removeAttachmentMutation.mutate(removeAttachmentTarget?._id)}
      />
    </div>
  );
}