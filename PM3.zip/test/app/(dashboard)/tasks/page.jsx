'use client';

import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, ListTodo } from 'lucide-react';

import taskService from '@/services/task.service';
import TaskStatsCards from '@/components/tasks/TaskStatsCards';
import TasksTable from '@/components/tasks/TasksTable';
import TaskFormDialog from '@/components/tasks/TaskFormDialog';
import PageHeader from '@/components/common/PageHeader';
import EmptyState from '@/components/feedback/EmptyState';
import ErrorState from '@/components/feedback/ErrorState';
import { TableSkeleton } from '@/components/common/Skeletons';

import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

import { PROJECT_PERMISSIONS } from '@/constants/projectPermissions';

const FILTER_TYPES = { ALL: 'all', ASSIGNED: 'assigned', WATCHING: 'watching' };

const TAB_CONFIG = [
  { id: FILTER_TYPES.ALL, label: 'All tasks' },
  { id: FILTER_TYPES.ASSIGNED, label: 'My tasks' },
  { id: FILTER_TYPES.WATCHING, label: 'Watching' },
];

export default function TasksHomePage({ teamMembers = [], userPermissions = [] }) {
  const queryClient = useQueryClient();

  const [activeTab, setActiveTab] = useState(FILTER_TYPES.ALL);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const canCreateTask = userPermissions.includes(PROJECT_PERMISSIONS.TASK_CREATE);
  const canEditTask = userPermissions.includes(PROJECT_PERMISSIONS.TASK_EDIT);
  const canDeleteTask = userPermissions.includes(PROJECT_PERMISSIONS.TASK_DELETE);

  const { data: tasksData, isLoading: tasksLoading, isFetching, error: tasksError } = useQuery({
    queryKey: ['myTasks', activeTab],
    queryFn: () => taskService.getMyTasks({ type: activeTab, page: 1, limit: 100 }),
  });

  const tasks = tasksData?.data || tasksData || [];

  const refreshTasks = () => {
    queryClient.invalidateQueries({ queryKey: ['myTasks'] });
    queryClient.invalidateQueries({ queryKey: ['task-stats'] });
  };

  const handleOpenDialog = () => {
    setEditingTask(null);
    setDialogOpen(true);
  };

  const handleEditTask = (task) => {
    setEditingTask(task);
    setDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-background p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <PageHeader
          title="My Tasks"
          description="All tasks across projects."
          actions={
            canCreateTask && (
              <Button size="lg" onClick={handleOpenDialog} className="gap-2">
                <Plus className="h-5 w-5" />
                New task
              </Button>
            )
          }
        />

        <TaskStatsCards />

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-3 max-w-md">
            {TAB_CONFIG.map((tab) => (
              <TabsTrigger key={tab.id} value={tab.id}>{tab.label}</TabsTrigger>
            ))}
          </TabsList>

          {TAB_CONFIG.map((tab) => (
            <TabsContent key={tab.id} value={tab.id} className="space-y-4">
              {tasksLoading ? (
                <TableSkeleton rows={6} columns={8} />
              ) : tasksError ? (
                <ErrorState
                  title="Couldn't load tasks"
                  description={tasksError.message}
                  onRetry={refreshTasks}
                />
              ) : tasks.length === 0 ? (
                <EmptyState
                  icon={<ListTodo className="h-8 w-8" />}
                  title="No tasks here yet"
                  description="Tasks in this category will show up here once there are some."
                />
              ) : (
                <TasksTable
                  tasks={tasks}
                  isLoading={false}
                  projectId={null}
                  onEdit={handleEditTask}
                  onTaskDeleted={refreshTasks}
                  canEdit={canEditTask}
                  canDelete={canDeleteTask}
                />
              )}
            </TabsContent>
          ))}
        </Tabs>

        <TaskFormDialog
          open={dialogOpen}
          onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) setEditingTask(null);
          }}
          projectId={null}
          teamMembers={teamMembers}
          onCreated={() => { refreshTasks(); setDialogOpen(false); }}
          initialData={editingTask}
          isEditing={!!editingTask}
        />
      </div>
    </div>
  );
}