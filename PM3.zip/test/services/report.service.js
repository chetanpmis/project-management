import api from "../lib/axios";

const reportsService = {
  getProjectDashboard: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/dashboard`
    );
    return response.data;
  },

  getProjectGantt: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/gantt`
    );
    return response.data;
  },

  getProjectOverview: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/overview`
    );
    return response.data;
  },

  getProjectTaskStatus: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/task-status`
    );
    return response.data;
  },

  getProjectMilestones: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/milestones`
    );
    return response.data;
  },

  getProjectTeamPerformance: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/team-performance`
    );
    return response.data;
  },

  getProjectEstimatedVsActual: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/estimated-vs-actual`
    );
    return response.data;
  },

  getProjectOverdueTasks: async (projectId) => {
    const response = await api.get(
      `/reports/projects/${projectId}/overdue`
    );
    return response.data;
  },

  getProjectCompletionTrend: async (projectId, period = "30d") => {
    const response = await api.get(
      `/reports/projects/${projectId}/completion-trend`,
      {
        params: { period },
      }
    );
    return response.data;
  },
};

export default reportsService;