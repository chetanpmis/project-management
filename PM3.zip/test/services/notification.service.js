import api from "../lib/axios";

const notificationService = {
  getNotifications: async ({ page = 1, limit = 20, read, type } = {}) => {
    try {
      const params = { page, limit };
      if (read !== undefined) params.read = read;
      if (type) params.type = type;

      const response = await api.get('/notifications', { params });
      console.log('✅ getNotifications response:', response.data);
      return response.data;
    } catch (error) {
      console.error('❌ getNotifications failed:', error.response?.data || error.message);
      throw error;
    }
  },

  getUnreadCount: async () => {
    try {
      const response = await api.get('/notifications/unread-count');
      return response.data;
    } catch (error) {
      console.error('❌ getUnreadCount failed:', error.response?.data || error.message);
      throw error;
    }
  },

  markAsRead: async (notificationId) => {
    const response = await api.patch(`/notifications/${notificationId}/read`);
    return response.data;
  },

  markAllAsRead: async () => {
    const response = await api.patch('/notifications/read-all');
    return response.data;
  },

  deleteNotification: async (notificationId) => {
    const response = await api.delete(`/notifications/${notificationId}`);
    return response.data;
  },

  clearAll: async ({ onlyRead = false } = {}) => {
    const response = await api.delete('/notifications', { params: { onlyRead } });
    return response.data;
  },
};

export default notificationService;