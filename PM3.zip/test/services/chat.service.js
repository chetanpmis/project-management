import api from "../lib/axios";

const chatService = {
  getMessages: async (projectId, { page = 1, limit = 30 } = {}) => {
    const response = await api.get(`/projects/${projectId}/messages`, { params: { page, limit } });
    return response.data;
  },
  sendMessage: async (projectId, { content, mentions = [], replyTo = null }) => {
    const response = await api.post(`/projects/${projectId}/messages`, { content, mentions, replyTo });
    return response.data;
  },
  editMessage: async (messageId, { content, mentions }) => {
    const response = await api.put(`/messages/${messageId}`, { content, mentions });
    return response.data;
  },
  deleteMessage: async (messageId) => {
    const response = await api.delete(`/messages/${messageId}`);
    return response.data;
  },
  reactToMessage: async (messageId, emoji) => {
    const response = await api.post(`/messages/${messageId}/react`, { emoji });
    return response.data;
  },
  markRead: async (projectId) => {
    const response = await api.patch(`/projects/${projectId}/messages/read`);
    return response.data;
  },
  getUnreadCount: async (projectId) => {
    const response = await api.get(`/projects/${projectId}/messages/unread-count`);
    return response.data;
  },
};

export default chatService;