import api from "../lib/axios";

const workloadService = {
  getWorkload: async (projectId) => {
    const res = await api.get(`/projects/${projectId}/workload`);
    return res.data;
  },

  updateDailyCapacity: async (projectId, payload) => {
    const res = await api.patch(`/projects/${projectId}/daily-capacity`, payload);
    return res.data;
  },

  assignWorkload: async (projectId, userId, payload) => {
    const res = await api.patch(`/projects/${projectId}/workload/${userId}`, payload);
    return res.data;
  },

  recalculateUserWorkload: async (projectId, userId) => {
    const res = await api.patch(`/projects/${projectId}/workload/${userId}/recalculate`);
    return res.data;
  },
};

export default workloadService;