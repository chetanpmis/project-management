import api from "../lib/axios";

const userService = {
  // GET /users — supports ?search= for the team-member pickers.
  // If your listUsers controller doesn't support `search` yet, add it
  // (a $regex match on name/email, same pattern as projectController.list).
  getUsers: async (params = {}) => {
    const response = await api.get("/users", { params });
    return response.data;
  },

  getUserById: async (userId) => {
    const response = await api.get(`/users/${userId}`);
    return response.data;
  },

  getProfile: async () => {
    const response = await api.get("/users/profile");
    return response.data;
  },

  updateProfile: async (data) => {
    const response = await api.put("/users/profile", data);
    return response.data;
  },
};

export default userService;