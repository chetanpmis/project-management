import api from "../lib/axios";

const commentService = {
  getComments: async (taskId) => {
    const response = await api.get(`/tasks/${taskId}/comments`);
    return response.data;
  },

  addComment: async (taskId, content, mentions = []) => {
    const response = await api.post(`/tasks/${taskId}/comments`, {
      content,
      mentions,
    });
    return response.data;
  },

  updateComment: async (commentId, content) => {
    const response = await api.put(`/comments/${commentId}`, { content });
    return response.data;
  },

  deleteComment: async (commentId) => {
    const response = await api.delete(`/comments/${commentId}`);
    return response.data;
  },

  addReply: async (commentId, content, mentions = []) => {
    const response = await api.post(`/comments/${commentId}/replies`, {
      content,
      mentions,
    });
    return response.data;
  },
};

export default commentService;