'use client';

import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { useQueryClient } from '@tanstack/react-query';
import useAuthStore  from '@/store/auth-store';

export function useNotificationSocket() {
  const queryClient = useQueryClient();
  const socketRef = useRef(null);
  const { token } = useAuthStore();

  useEffect(() => {
    if (!token) return;

    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL, {
      auth: { token },
      transports: ['websocket'],
    });
    socketRef.current = socket;

    socket.on('notification:new', (notification) => {
      // Prepend into the first page of the notifications list
      queryClient.setQueryData(['notifications', 'list'], (old) => {
        if (!old) return old;
        return {
          ...old,
          data: [notification, ...old.data],
          unreadCount: (old.unreadCount ?? 0) + 1,
        };
      });

      queryClient.setQueryData(['notifications', 'unreadCount'], (old) => ({
        ...old,
        data: { unreadCount: (old?.data?.unreadCount ?? 0) + 1 },
      }));

      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    });

    socket.on('connect_error', (err) => console.warn('Notification socket error:', err.message));

    return () => socket.disconnect();
  }, [token, queryClient]);

  return socketRef;
}