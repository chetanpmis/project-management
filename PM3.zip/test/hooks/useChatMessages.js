'use client';

import { useInfiniteQuery } from '@tanstack/react-query';
import chatService from '@/services/chat.service';

export function useChatMessages(projectId) {
  const query = useInfiniteQuery({
    queryKey: ['chat', projectId],
    queryFn: ({ pageParam = 1 }) => chatService.getMessages(projectId, { page: pageParam, limit: 30 }),
    getNextPageParam: (lastPage) => {
      // Backend's `hasMore`/`totalPages` tell us if there's an older page left to fetch.
      // Our list endpoint returns page 1 = NEWEST 30. Page 2 = next older 30. etc.
      if (lastPage.pagination.page < lastPage.pagination.totalPages) {
        return lastPage.pagination.page + 1;
      }
      return undefined;
    },
    initialPageParam: 1,
    enabled: !!projectId,
  });

  // Each page from the API arrives newest-page-first in `query.data.pages`,
  // but within a page, messages are already oldest→newest (server does .reverse()).
  // Flatten by reversing PAGE order (older pages last-fetched go first), then
  // concatenating each page's messages in order.
  const messages = (query.data?.pages ?? [])
    .slice()
    .reverse()
    .flatMap((page) => page.data);

  return {
    messages,
    isLoading: query.isLoading,
    isFetchingOlder: query.isFetchingNextPage,
    hasOlder: query.hasNextPage,
    loadOlder: query.fetchNextPage,
    refetch: query.refetch,
  };
}