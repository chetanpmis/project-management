'use client';

import { useMemo } from 'react';
import useAuthStore from '@/store/auth-store';
import { hasPermission } from '@/lib/permissions';

/**
 * const canEditTeam = usePermission(project, PROJECT_PERMISSIONS.TEAM_EDIT);
 *
 * Centralizes the "who am I + does the project say I can do this" check so
 * components don't each re-derive `user.id` from the store and re-import
 * hasPermission separately.
 */
export function usePermission(project, permission) {
  const { user } = useAuthStore();
  return useMemo(() => hasPermission(project, user?._id || user?.id, permission), [project, user, permission]);
}

/** Batch version — returns a `{ [permission]: boolean }` map, handy for a
 * settings panel that needs to check many permissions at once. */
export function usePermissions(project, permissions = []) {
  const { user } = useAuthStore();
  return useMemo(() => {
    const uid = user?._id || user?.id;
    return permissions.reduce((acc, perm) => {
      acc[perm] = hasPermission(project, uid, perm);
      return acc;
    }, {});
  }, [project, user, permissions]);
}

export function useIsOwner(project) {
  const { user } = useAuthStore();
  const uid = user?._id || user?.id;
  return !!project && project.owner?._id?.toString() === uid?.toString();
}