'use client';

import { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { useQueryClient } from '@tanstack/react-query';
import useAuthStore  from '@/store/auth-store';

export function useProjectChatSocket(projectId) {
  const queryClient = useQueryClient();
  const socketRef = useRef(null);
  const { token, user } = useAuthStore();
  const [typingUsers, setTypingUsers] = useState([]); // [{userId, userName}]
  const typingTimeouts = useRef({});

  useEffect(() => {
    if (!token || !projectId) return;

    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL, { auth: { token }, transports: ['websocket'] });
    socketRef.current = socket;
    socket.emit('chat:join', projectId);

   socket.on('chat:message', (message) => {
  queryClient.setQueryData(['chat', projectId], (old) => {
    if (!old) return old;
    const pages = [...old.pages];
    pages[0] = { ...pages[0], data: [...pages[0].data, message] };
    return { ...old, pages };
  });
});

socket.on('chat:message:updated', (message) => {
  queryClient.setQueryData(['chat', projectId], (old) => {
    if (!old) return old;
    const pages = old.pages.map((page) => ({
      ...page,
      data: page.data.map((m) => (m._id === message._id ? message : m)),
    }));
    return { ...old, pages };
  });
});

socket.on('chat:read', ({ userId, messageIds }) => {
  queryClient.setQueryData(['chat', projectId], (old) => {
    if (!old) return old;
    const pages = old.pages.map((page) => ({
      ...page,
      data: page.data.map((m) =>
        messageIds.includes(m._id) && !m.readBy?.some((r) => r.user?._id === userId)
          ? { ...m, readBy: [...(m.readBy || []), { user: { _id: userId }, readAt: new Date() }] }
          : m
      ),
    }));
    return { ...old, pages };
  });
});

    socket.on('chat:typing', ({ userId, userName }) => {
      if (userId === user?.id) return;
      setTypingUsers((prev) => (prev.some((u) => u.userId === userId) ? prev : [...prev, { userId, userName }]));

      clearTimeout(typingTimeouts.current[userId]);
      typingTimeouts.current[userId] = setTimeout(() => {
        setTypingUsers((prev) => prev.filter((u) => u.userId !== userId));
      }, 3000); // clear if no new keystroke event within 3s
    });

  

    return () => {
      socket.emit('chat:leave', projectId);
      socket.disconnect();
      Object.values(typingTimeouts.current).forEach(clearTimeout);
    };
  }, [token, projectId, queryClient, user?.id]);

  const emitTyping = () => {
    socketRef.current?.emit('chat:typing', { projectId, userName: user?.name });
  };

  return { emitTyping, typingUsers };
}