import mongoose from 'mongoose';

const workloadSchema = new mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: true,
      index: true,
    },

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    // Workload for a single calendar day
    date: {
      type: Date,
      required: true,
      index: true,
    },

    // User capacity for this day
    dailyCapacity: {
      type: Number,
      default: 8,
      min: 0,
    },

    // Total planned hours for this day
    assignedHours: {
      type: Number,
      default: 0,
      min: 0,
    },

    // Percentage of capacity used
    utilization: {
      type: Number,
      default: 0,
      min: 0,
    },

    // True when assignedHours > dailyCapacity
    overloaded: {
      type: Boolean,
      default: false,
    },

    // Which tasks produced this workload
    tasks: [
      {
        task: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Task',
          required: true,
        },

        hours: {
          type: Number,
          required: true,
          min: 0,
        },
      },
    ],
  },
  {
    timestamps: true,
  }
);

// One workload record per project + user + day
workloadSchema.index(
  {
    project: 1,
    user: 1,
    date: 1,
  },
  {
    unique: true,
  }
);

export default mongoose.model('Workload', workloadSchema);