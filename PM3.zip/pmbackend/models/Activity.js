import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema({
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: {
    type: String,
    enum: [
        // Project
    "project_created",
    "project_updated",
    "project_archived",
    "project_deleted",

    // Team
    "member_added",
    "member_removed",
    "member_role_changed",
    "member_updated",

    // Task
    "task_created",
    "task_updated",
    "task_deleted",
    "task_status_changed",
    "task_assigned",
    "task_unassigned",

    // Checklist
    "checklist_updated",

    // Comments
    "comment_added",
    "comment_deleted",

    // Files / Attachments
    "file_uploaded",
    "file_deleted",
    "attachment_added",
    "attachment_removed",

    // Watchers
    "watcher_added",
    "watcher_removed",

    // Budget
    "budget_updated",
    "expense_added",
    "expense_approved",

    // Milestones
    "milestone_created",
    "milestone_completed",
    "milestone_removed",

    // Work Logs / Time
    "work_log_added",
    "work_log_approved",

    // Workload
    "workload_updated",
    ]
  },
  entity: String,
  entityId: mongoose.Schema.Types.ObjectId,
  previousValue: mongoose.Schema.Types.Mixed,
  newValue: mongoose.Schema.Types.Mixed,
  description: String,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Activity', activitySchema);