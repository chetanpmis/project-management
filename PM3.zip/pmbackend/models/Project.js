import mongoose from "mongoose";

const projectSchema = new mongoose.Schema(
  {
    projectCode: {
      type: String,
      required: true,
      unique: true,
      index: true,
      trim: true,
    },

    name: {
      type: String,
      required: true,
      trim: true,
    },

    description: {
      type: String,
      default: "",
      trim: true,
    },

    projectType: {
      type: String,
      enum: ["internal", "client", "product"],
      default: "internal",
    },

    status: {
      type: String,
      enum: [
        "planning",
        "active",
        "on_hold",
        "completed",
        "cancelled",
      ],
      default: "planning",
    },

    priority: {
      type: String,
      enum: ["low", "medium", "high", "critical"],
      default: "medium",
    },

    health: {
      type: String,
      enum: ["healthy", "at-risk", "critical"],
      default: "healthy",
    },

    visibility: {
      type: String,
      enum: ["private", "public"],
      default: "private",
    },

    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
         milestones: [
      {
        name: { type: String, required: true },
        description: String,
        startDate: { type: Date },                   
        dueDate: { type: Date, required: true },
        status: { 
          type: String, 
          enum: ['pending', 'in-progress', 'completed'], 
          default: 'pending' 
        },
        progress: { 
          type: Number, 
          default: 0, 
          min: 0, 
          max: 100 
        },
        completedAt: Date,
        priority: {
          type: String,
          enum: ['low', 'medium', 'high', 'critical'],
          default: 'medium'
        }
      }
    ],

    team: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          required: true,
        },

        role: {
          type: String,
          enum: ["owner", "manager", "member", "viewer"],
          default: "member",
        },

        permissions: {
          type: [String],
          default: [],
        },

        joinedAt: {
          type: Date,
          default: Date.now,
        },

        invitedBy: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
      },
    ],

    startDate: {
      type: Date,
    },

    endDate: {
      type: Date,
    },

    estimatedHours: {
      type: Number,
      default: 0,
      min: 0,
    },

    loggedHours: {
      type: Number,
      default: 0,
      min: 0,
    },

    budget: {
      estimated: {
        type: Number,
        default: 0,
        min: 0,
      },

      approved: {
        type: Number,
        default: 0,
        min: 0,
      },

      spent: {
        type: Number,
        default: 0,
        min: 0,
      },

      remaining: {
        type: Number,
        default: 0,
        min: 0,
      },
    },

    isDeleted: {
  type: Boolean,
  default: false,
},

deletedAt: {
  type: Date,
  default: null,
},

deletedBy: {
  type: mongoose.Schema.Types.ObjectId,
  ref: "User",
  default: null,
},

    progress: {
      type: Number,
      default: 0,
      min: 0,
      max: 100,
    },

    completedAt: {
      type: Date,
      default: null,
    },

    lastActivityAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("Project", projectSchema);