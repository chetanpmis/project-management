// ==================== 1. task.js (updated schema) ====================
import mongoose from 'mongoose';

const taskSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  assignees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  watchers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  status: { 
    type: String, 
    enum: ['todo', 'in-progress', 'review', 'completed'], 
    default: 'todo' 
  },
  priority: { type: String, enum: ['low', 'medium', 'high', 'critical'], default: 'medium' },
  startDate: Date,
  dueDate: Date,
  labels: [String],
  tags: [String],
  dependencies: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Task' }],
  subtasks: [{
    title: String,
    completed: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now },
    startDate: Date,
    dueDate: Date,
    assignees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    progress: { type: Number, default: 0 },
  }],
  checklist: [{
    item: String,
    completed: { type: Boolean, default: false }
  }],
  estimatedHours: Number,
  estimatedEffort: String,
  actualHours: { type: Number, default: 0 },
  timeSpent: { type: Number, default: 0 },
  attachments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'File' }], // now central File model
  comments: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Comment' }],
  workLogs: [{
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    seconds: { type: Number, default: 0 },
    date: Date,
    description: String,
    approved: Boolean,
    isTimer: { type: Boolean, default: false },
    stopped: { type: Boolean, default: false },
  }],
  milestone: { type: mongoose.Schema.Types.ObjectId, ref: 'Milestone', default: null },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
  isDeleted: {
  type: Boolean,
  default: false,
},


deletedAt: {
  type: Date,
  default: null,
},

deletedBy: {
  type: mongoose.Schema.Types.ObjectId,
  ref: 'User',
  default: null,
},
});

export default mongoose.model('Task', taskSchema);