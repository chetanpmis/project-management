
export const PROJECT_PERMISSIONS = {
  PROJECT_VIEW: "project.view",
  PROJECT_EDIT: "project.edit",
  PROJECT_DELETE: "project.delete",
  PROJECT_SETTINGS: "project.settings",

  TASK_VIEW: "task.view",
  TASK_CREATE: "task.create",
  TASK_EDIT: "task.edit",
  TASK_DELETE: "task.delete",
  TASK_ASSIGN: "task.assign",

  TEAM_VIEW: "team.view",
  TEAM_INVITE: "team.invite",
  TEAM_EDIT: "team.edit",
  TEAM_REMOVE: "team.remove",

  BUDGET_VIEW: "budget.view",
  BUDGET_MANAGE: "budget.manage",

  REPORT_VIEW: "report.view",

  FILE_VIEW: "file.view",
  FILE_UPLOAD: "file.upload",
  FILE_DELETE: "file.delete",

  TIME_VIEW: "time.view",
  TIME_MANAGE: "time.manage",

  ACTIVITY_VIEW: "activity.view",

  // ====================== NEW ======================
  WORKLOAD_MANAGE: "workload.manage",
};

const P = PROJECT_PERMISSIONS;

export const DEFAULT_ROLE_PERMISSIONS = {
  owner: Object.values(P),

  manager: [
    P.PROJECT_VIEW,
    P.PROJECT_EDIT,

    P.TASK_VIEW,
    P.TASK_CREATE,
    P.TASK_EDIT,
    P.TASK_DELETE,
    P.TASK_ASSIGN,

    P.TEAM_VIEW,
    P.TEAM_INVITE,
    P.TEAM_EDIT,
    P.TEAM_REMOVE,

    P.BUDGET_VIEW,

    P.REPORT_VIEW,

    P.FILE_VIEW,
    P.FILE_UPLOAD,
    P.FILE_DELETE,

    P.TIME_VIEW,
    P.TIME_MANAGE,

    P.ACTIVITY_VIEW,

    // ====================== NEW ======================
    P.WORKLOAD_MANAGE,
  ],

  member: [
    P.PROJECT_VIEW,

    P.TASK_VIEW,
    P.TASK_CREATE,
    P.TASK_EDIT,

    P.FILE_VIEW,
    P.FILE_UPLOAD,

    P.TIME_VIEW,

    P.ACTIVITY_VIEW,
  ],

  viewer: [
    P.PROJECT_VIEW,

    P.TASK_VIEW,

    P.REPORT_VIEW,

    P.FILE_VIEW,

    P.ACTIVITY_VIEW,
  ],
};