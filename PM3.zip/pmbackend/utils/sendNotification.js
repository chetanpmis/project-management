import Notification from '../models/Notification.js';
import { emitToUser } from './socket.js';
import { toUserId, toUserIds } from './userIdHelpers.js';

export const sendNotification = async ({
  userId,
  type,
  title,
  message,
  relatedTask = null,
  relatedProject = null,
  relatedUser = null,
  link = null,
}) => {
  try {
    const cleanUserId = toUserId(userId);
    if (!cleanUserId) {
      console.error('❌ sendNotification called without a valid userId:', userId);
      return null;
    }

    const notification = await Notification.create({
      user: cleanUserId,
      type,
      title,
      message,
      relatedTask,
      relatedProject,
      relatedUser: toUserId(relatedUser),
      link,
    });

    const populated = await notification.populate([
      { path: 'relatedTask', select: 'title status dueDate' },
      { path: 'relatedProject', select: 'name projectCode endDate' },
      { path: 'relatedUser', select: 'name email avatar' },
    ]);

    emitToUser(cleanUserId, 'notification:new', populated);
    return populated;
  } catch (error) {
    console.error('❌ Failed to send notification:', error);
    return null;
  }
};

// Send the SAME notification to a whole array of users at once — this is the
// piece you were missing. Use this instead of a raw `for...of` loop anywhere
// you're notifying multiple assignees/watchers/team members.
export const sendBulkNotification = async (userIds, { type, title, message, relatedTask = null, relatedProject = null, link = null, excludeUserId = null }) => {
  let ids = toUserIds(userIds);
  if (excludeUserId) {
    const excludeId = toUserId(excludeUserId);
    ids = ids.filter((id) => id !== excludeId);
  }
  return Promise.all(
    ids.map((userId) => sendNotification({ userId, type, title, message, relatedTask, relatedProject, link }))
  );
};

export const notifyProjectTeam = async (project, { type, title, message, relatedTask = null, link = null, excludeUserId = null }) => {
  const recipients = toUserIds([
    project.owner,
    ...(project.team || []).map((t) => t.user),
  ]);
  return sendBulkNotification(recipients, { type, title, message, relatedTask, relatedProject: project._id, link, excludeUserId });
};

export const notifyTaskParticipants = async (task, project, { type, title, message, link = null, excludeUserId = null }) => {
  const recipients = toUserIds([
    ...(task.assignees || []),
    ...(task.watchers || []),
    project?.owner,
  ]);
  return sendBulkNotification(recipients, {
    type, title, message,
    relatedTask: task._id,
    relatedProject: project?._id || task.project,
    link,
    excludeUserId,
  });
};

// Used by the deadline cron job. Prevents duplicate deadline/overdue
// notifications from firing more than once per calendar day per
// (user, type, relatedTask/relatedProject) triple. Since the cron logic is
// purely date-diff based (not a stored status flag), this is what stops a
// user from getting the same "due tomorrow" or "overdue" ping 20 times if
// the job runs more than once in a day, or is re-triggered manually.
export const sendNotificationOncePerDay = async ({
  userId,
  type,
  title,
  message,
  relatedTask = null,
  relatedProject = null,
  link = null,
}) => {
  const cleanUserId = toUserId(userId);
  if (!cleanUserId) {
    console.error('❌ sendNotificationOncePerDay called without a valid userId:', userId);
    return null;
  }

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const query = { user: cleanUserId, type, createdAt: { $gte: startOfDay } };
  if (relatedTask) query.relatedTask = toUserId(relatedTask) ? relatedTask : relatedTask;
  if (relatedProject) query.relatedProject = relatedProject;

  const alreadySent = await Notification.exists(query);
  if (alreadySent) return null;

  return sendNotification({ userId: cleanUserId, type, title, message, relatedTask, relatedProject, link });
};

// Bulk variant — send the same once-per-day notification to a whole array
// of recipients (e.g. all task assignees/watchers, or all project team
// members) in one call from the cron job.
export const sendBulkNotificationOncePerDay = async (userIds, { type, title, message, relatedTask = null, relatedProject = null, link = null, excludeUserId = null }) => {
  let ids = toUserIds(userIds);
  if (excludeUserId) {
    const excludeId = toUserId(excludeUserId);
    ids = ids.filter((id) => id !== excludeId);
  }
  return Promise.all(
    ids.map((userId) => sendNotificationOncePerDay({ userId, type, title, message, relatedTask, relatedProject, link }))
  );
};