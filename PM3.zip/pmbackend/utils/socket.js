import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';

let io;
const userSockets = new Map(); // userId -> Set<socketId>

export const initSocket = (server) => {
  io = new Server(server, {
    cors: {
      origin: process.env.CLIENT_URL || '*',
      methods: ['GET', 'POST'],
      credentials: true,
    },
  });

  // Auth handshake — expects the client to send its JWT the same way your authMiddleware expects it
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
      if (!token) return next(new Error('Authentication required'));

      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.id || decoded._id;
      next();
    } catch (err) {
      next(new Error('Invalid or expired token'));
    }
  });

  io.on('connection', (socket) => {
    const { userId } = socket;
    socket.join(`user:${userId}`);

    if (!userSockets.has(userId)) userSockets.set(userId, new Set());
    userSockets.get(userId).add(socket.id);

    console.log(`🔌 User ${userId} connected (${socket.id})`);

    // ── Project chat: join/leave a project's chat room ─────────────────
    // Frontend calls socket.emit('chat:join', projectId) when opening the
    // Chat tab, and 'chat:leave' when navigating away / unmounting.
    socket.on('chat:join', (projectId) => {
      if (!projectId) return;
      socket.join(`project:${projectId}`);
      console.log(`💬 User ${userId} joined chat room for project ${projectId}`);
    });

    socket.on('chat:leave', (projectId) => {
      if (!projectId) return;
      socket.leave(`project:${projectId}`);
      console.log(`💬 User ${userId} left chat room for project ${projectId}`);
    });

    // ── Typing indicator ────────────────────────────────────────────────
    // Broadcasts to everyone else in the room except the sender.
    socket.on('chat:typing', ({ projectId, userName }) => {
      if (!projectId) return;
      socket.to(`project:${projectId}`).emit('chat:typing', { userId, userName });
    });

    socket.on('disconnect', () => {
      const set = userSockets.get(userId);
      if (set) {
        set.delete(socket.id);
        if (set.size === 0) userSockets.delete(userId);
      }
      console.log(`🔌 User ${userId} disconnected (${socket.id})`);
    });
  });

  return io;
};

export const getIO = () => {
  if (!io) throw new Error('Socket.io not initialized. Call initSocket(server) first.');
  return io;
};

// ── Existing: per-user notification emit ────────────────────────────────
export const emitToUser = (userId, event, payload) => {
  if (!io || !userId) return;
  io.to(`user:${userId.toString()}`).emit(event, payload);
};

// ── New: per-project chat emit (used by chatController for live messages) ──
export const emitToProject = (projectId, event, payload) => {
  if (!io || !projectId) return;
  io.to(`project:${projectId.toString()}`).emit(event, payload);
};

export const isUserOnline = (userId) => userSockets.has(userId?.toString());