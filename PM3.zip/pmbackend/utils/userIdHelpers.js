// Safely extracts a clean ObjectId string from any shape:
// - a string id: "6a51d5..."
// - an ObjectId instance
// - a populated doc: { _id, name, email, ... }
// - null/undefined (returns null)
export const toUserId = (value) => {
  if (!value) return null;
  if (typeof value === 'string') return value;
  if (value._id) return value._id.toString();
  if (typeof value.toString === 'function') {
    const str = value.toString();
    // Guard against "[object Object]" from a plain object with no _id/toString override
    if (str === '[object Object]') return null;
    return str;
  }
  return null;
};

// Same, but for an array — normalizes, drops nulls, and dedupes.
export const toUserIds = (values = []) => {
  const ids = (values || []).map(toUserId).filter(Boolean);
  return [...new Set(ids)];
};