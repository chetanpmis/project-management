import cron from 'node-cron';
import Task from '../models/Task.js';
import Project from '../models/Project.js';
import { sendNotificationOncePerDay } from './sendNotification.js';


const daysBetween = (date, today) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  const t = new Date(today);
  t.setHours(0, 0, 0, 0);
  return Math.round((d - t) / (1000 * 60 * 60 * 24));
};

const checkTaskDeadlines = async () => {
  const today = new Date();
  const tasks = await Task.find({
    isDeleted: { $ne: true },
    status: { $ne: 'completed' },
    dueDate: { $ne: null },
  })
    .populate('assignees', '_id')
    .populate('watchers', '_id')
    .populate('project', 'name owner');

  for (const task of tasks) {
    if (!task.dueDate) continue;
    const diff = daysBetween(task.dueDate, today); // positive = days remaining, negative = overdue

    const recipients = new Set([
      ...(task.assignees || []).map(a => (a._id || a).toString()),
      ...(task.watchers || []).map(w => (w._id || w).toString()),
    ]);
    if (task.project?.owner) recipients.add(task.project.owner.toString());

    let type = null;
    let title = null;
    let message = null;

    if (diff === 6) {
      type = 'task_deadline';
      title = 'Deadline in 6 Days';
      message = `Task "${task.title}" is due in 6 days (${new Date(task.dueDate).toLocaleDateString()}).`;
    } else if (diff === 1) {
      type = 'task_deadline';
      title = 'Deadline Tomorrow';
      message = `Task "${task.title}" is due tomorrow (${new Date(task.dueDate).toLocaleDateString()}).`;
    } else if (diff === 0) {
      type = 'task_deadline';
      title = 'Due Today';
      message = `Task "${task.title}" is due today.`;
    } else if (diff < 0) {
      type = 'task_overdue';
      title = 'Deadline Missed';
      message = `Task "${task.title}" missed its deadline (${new Date(task.dueDate).toLocaleDateString()}) and is still not completed.`;
    }

    if (!type) continue;

    for (const userId of recipients) {
      await sendNotificationOncePerDay({
        userId, type, title, message,
        relatedTask: task._id,
        relatedProject: task.project?._id,
      });
    }
  }
};

const checkProjectDeadlines = async () => {
  const today = new Date();
  const projects = await Project.find({
    isDeleted: false,
    status: { $nin: ['completed', 'cancelled'] },
    endDate: { $ne: null },
  })
    .populate('owner', '_id')
    .populate('team.user', '_id');

  for (const project of projects) {
    if (!project.endDate) continue;
    const diff = daysBetween(project.endDate, today);

    const recipients = new Set([
      project.owner._id.toString(),
      ...(project.team || []).map(t => (t.user._id || t.user).toString()),
    ]);

    let type = null;
    let title = null;
    let message = null;

    if (diff === 6) {
      type = 'project_deadline';
      title = 'Project Deadline in 6 Days';
      message = `Project "${project.name}" is due in 6 days (${new Date(project.endDate).toLocaleDateString()}).`;
    } else if (diff === 1) {
      type = 'project_deadline';
      title = 'Project Deadline Tomorrow';
      message = `Project "${project.name}" is due tomorrow.`;
    } else if (diff === 0) {
      type = 'project_deadline';
      title = 'Project Due Today';
      message = `Project "${project.name}" is due today.`;
    } else if (diff < 0) {
      type = 'project_overdue';
      title = 'Project Deadline Missed';
      message = `Project "${project.name}" missed its deadline (${new Date(project.endDate).toLocaleDateString()}) and is still not marked completed.`;
    }

    if (!type) continue;

    for (const userId of recipients) {
      await sendNotificationOncePerDay({
        userId, type, title, message,
        relatedProject: project._id,
      });
    }
  }
};

export const runDeadlineChecks = async () => {
  try {
    await checkTaskDeadlines();
    await checkProjectDeadlines();
    console.log(`✅ Deadline check completed at ${new Date().toISOString()}`);
  } catch (error) {
    console.error('❌ Deadline check failed:', error);
  }
};

// Runs once daily at 8:00 AM server time
export const startDeadlineCron = () => {
  cron.schedule('0 8 * * *', runDeadlineChecks);
  console.log('🕗 Deadline notification cron scheduled (daily at 08:00).');
};