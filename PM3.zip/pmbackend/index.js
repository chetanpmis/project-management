import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import routes from './routes/index.js';
import { startDeadlineCron } from './utils/cronJobs.js';
import { initSocket } from './utils/socket.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ limit: '50mb', extended: true }));

app.use('/uploads', express.static(path.join(__dirname, '../uploads')));
console.log("MONGODB_URI:", process.env.MONGODB_URI);

try {
  await mongoose.connect(process.env.MONGODB_URI);

  console.log("✅ MongoDB Connected");
  console.log("Connection State:", mongoose.connection.readyState);
  console.log("Database:", mongoose.connection.name);
  console.log("Host:", mongoose.connection.host);
} catch (err) {
  console.error("❌ MongoDB Error");
  console.error("Name:", err.name);
  console.error("Message:", err.message);
  console.error(err);
}

app.use('/api', routes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date() });
});

const server = http.createServer(app);
initSocket(server);
startDeadlineCron()
server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
