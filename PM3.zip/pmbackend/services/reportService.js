
import Project from "../models/Project.js";
import Task from "../models/Task.js";

const TASK_SELECT_FIELDS = `
title
status
priority
progress
milestone
assignees
estimatedHours
actualHours
workLogs
dueDate
createdAt
`;

async function loadProjectData(projectId) {
  const [project, tasks] = await Promise.all([
    Project.findOne({
      _id: projectId,
      isDeleted: false,
    }).lean(),

    Task.find({
      project: projectId,
    })
      .select(TASK_SELECT_FIELDS)
      .populate("assignees", "name avatar email")
      .lean(),
  ]);

  if (!project) {
    throw new Error("Project not found");
  }

  return {
    project,
    tasks,
  };
}

function isTaskOverdue(task) {
  return (
    task.status !== "completed" &&
    task.dueDate &&
    new Date(task.dueDate) < new Date()
  );
}

function calculateProjectProgress(tasks) {
  if (!tasks.length) return 0;

  const total = tasks.reduce(
    (sum, task) => sum + (task.progress || 0),
    0
  );

  return Math.round(total / tasks.length);
}

function calculateMilestoneProgress(tasks) {
  if (!tasks.length) return 0;

  const total = tasks.reduce(
    (sum, task) => sum + (task.progress || 0),
    0
  );

  return Math.round(total / tasks.length);
}

function calculateMilestoneStatus(tasks) {
  if (!tasks.length) return "pending";

  if (tasks.every(task => task.status === "completed")) {
    return "completed";
  }

  if (
    tasks.some(
      task =>
        task.status !== "todo" ||
        (task.progress || 0) > 0
    )
  ) {
    return "in-progress";
  }

  return "pending";
}

function calculateTotalEstimatedHours(tasks) {
  return tasks.reduce(
    (sum, task) => sum + (task.estimatedHours || 0),
    0
  );
}

function calculateTotalActualHours(tasks) {
  let seconds = 0;

  for (const task of tasks) {
    if (!task.workLogs) continue;

    for (const log of task.workLogs) {
      seconds += log.seconds || 0;
    }
  }

  return Number((seconds / 3600).toFixed(2));
}


export async function getProjectOverview(projectId) {
  const { project, tasks } = await loadProjectData(projectId);

  const now = new Date();

  let completedTasks = 0;
  let inProgressTasks = 0;
  let todoTasks = 0;
  let reviewTasks = 0;
  let overdueTasks = 0;

  let totalEstimatedHours = 0;
  let totalActualSeconds = 0;

  const milestoneMap = new Map();

  for (const milestone of project.milestones || []) {
    milestoneMap.set(milestone._id.toString(), []);
  }

  for (const task of tasks) {
    // Task Counts
    switch (task.status) {
      case "completed":
        completedTasks++;
        break;

      case "todo":
        todoTasks++;
        break;

      case "review":
        reviewTasks++;
        break;

      default:
        inProgressTasks++;
    }

    // Overdue
    if (
      task.status !== "completed" &&
      task.dueDate &&
      new Date(task.dueDate) < now
    ) {
      overdueTasks++;
    }

    // Estimated Hours
    totalEstimatedHours += task.estimatedHours || 0;

    // Actual Hours
    if (task.workLogs?.length) {
      for (const log of task.workLogs) {
        totalActualSeconds += log.seconds || 0;
      }
    }

    // Group Tasks By Milestone
    if (task.milestone) {
      const id = task.milestone.toString();

      if (!milestoneMap.has(id)) {
        milestoneMap.set(id, []);
      }

      milestoneMap.get(id).push(task);
    }
  }

  // Calculate Milestone Progress Dynamically
  let completedMilestones = 0;

  for (const milestone of project.milestones || []) {
    const milestoneTasks =
      milestoneMap.get(milestone._id.toString()) || [];

    const progress =
      calculateMilestoneProgress(milestoneTasks);

    if (progress === 100) {
      completedMilestones++;
    }
  }

  return {
    project: {
      _id: project._id,
      name: project.name,
      status: project.status,
      priority: project.priority,
      health: project.health,
      startDate: project.startDate,
      endDate: project.endDate,
    },

    summary: {
      progress: calculateProjectProgress(tasks),

      totalMilestones: project.milestones.length,

      completedMilestones,

      totalTasks: tasks.length,

      completedTasks,

      inProgressTasks,

      reviewTasks,

      todoTasks,

      overdueTasks,

      teamMembers: project.team.length,

      estimatedHours: Number(
        totalEstimatedHours.toFixed(2)
      ),

      actualHours: Number(
        (totalActualSeconds / 3600).toFixed(2)
      ),

      remainingHours: Math.max(
        0,
        totalEstimatedHours -
          totalActualSeconds / 3600
      ),
    },
  };
}

/**
 * Task Status Report
 */
export async function getProjectTaskStatus(projectId) {
  const { tasks } = await loadProjectData(projectId);

  const report = {
    total: tasks.length,

    todo: 0,
    inProgress: 0,
    review: 0,
    completed: 0,
    overdue: 0,

    low: 0,
    medium: 0,
    high: 0,
    critical: 0,
  };

  const now = Date.now();

  for (const task of tasks) {
    // Status Counts
    switch (task.status) {
      case "todo":
        report.todo++;
        break;

      case "in-progress":
        report.inProgress++;
        break;

      case "review":
        report.review++;
        break;

      case "completed":
        report.completed++;
        break;
    }

    // Overdue (calculated, never trust stored value)
    if (
      task.status !== "completed" &&
      task.dueDate &&
      new Date(task.dueDate).getTime() < now
    ) {
      report.overdue++;
    }

    // Priority Counts
    switch (task.priority) {
      case "low":
        report.low++;
        break;

      case "medium":
        report.medium++;
        break;

      case "high":
        report.high++;
        break;

      case "critical":
        report.critical++;
        break;
    }
  }

  return report;
}


/**
 * Milestone Progress Report
 */
export async function getProjectMilestones(projectId) {
  const { project, tasks } = await loadProjectData(projectId);

  const milestoneTaskMap = new Map();

  // Initialize every milestone
  for (const milestone of project.milestones || []) {
    milestoneTaskMap.set(milestone._id.toString(), []);
  }

  // Group tasks by milestone
  for (const task of tasks) {
    if (!task.milestone) continue;

    const id = task.milestone.toString();

    if (!milestoneTaskMap.has(id)) {
      milestoneTaskMap.set(id, []);
    }

    milestoneTaskMap.get(id).push(task);
  }

  const now = Date.now();

  const report = (project.milestones || []).map((milestone) => {
    const milestoneTasks =
      milestoneTaskMap.get(milestone._id.toString()) || [];

    const totalTasks = milestoneTasks.length;

    let completedTasks = 0;
    let inProgressTasks = 0;
    let todoTasks = 0;
    let reviewTasks = 0;
    let overdueTasks = 0;

    let estimatedHours = 0;
    let actualSeconds = 0;

    for (const task of milestoneTasks) {
      switch (task.status) {
        case "completed":
          completedTasks++;
          break;

        case "review":
          reviewTasks++;
          break;

        case "todo":
          todoTasks++;
          break;

        default:
          inProgressTasks++;
      }

      if (
        task.status !== "completed" &&
        task.dueDate &&
        new Date(task.dueDate).getTime() < now
      ) {
        overdueTasks++;
      }

      estimatedHours += task.estimatedHours || 0;

      if (task.workLogs?.length) {
        for (const log of task.workLogs) {
          actualSeconds += log.seconds || 0;
        }
      }
    }

    const progress =
      calculateMilestoneProgress(milestoneTasks);

    const status =
      calculateMilestoneStatus(milestoneTasks);

    return {
      _id: milestone._id,
      name: milestone.name,
      description: milestone.description,

      startDate: milestone.startDate,
      dueDate: milestone.dueDate,

      priority: milestone.priority,

      progress,
      status,

      totalTasks,
      completedTasks,
      inProgressTasks,
      reviewTasks,
      todoTasks,
      overdueTasks,

      estimatedHours,

      actualHours: Number(
        (actualSeconds / 3600).toFixed(2)
      ),
    };
  });

  report.sort((a, b) => {
    return new Date(a.dueDate) - new Date(b.dueDate);
  });

  return report;
}


/**
 * Team Performance Report
 */
export async function getProjectTeamPerformance(projectId) {
  const { project, tasks } = await loadProjectData(projectId);

  const members = new Map();

  // Initialize project members
  for (const member of project.team || []) {
    members.set(member.user.toString(), {
      _id: member.user.toString(),
      role: member.role,

      name: "",

      assignedTasks: 0,
      completedTasks: 0,
      inProgressTasks: 0,
      reviewTasks: 0,
      todoTasks: 0,
      overdueTasks: 0,

      estimatedHours: 0,
      loggedHours: 0,

      totalProgress: 0,
    });
  }

  const now = Date.now();

  for (const task of tasks) {
    for (const assignee of task.assignees || []) {
      const id = assignee._id.toString();

      if (!members.has(id)) {
        members.set(id, {
          _id: id,
          role: "member",

          name: assignee.name,

          assignedTasks: 0,
          completedTasks: 0,
          inProgressTasks: 0,
          reviewTasks: 0,
          todoTasks: 0,
          overdueTasks: 0,

          estimatedHours: 0,
          loggedHours: 0,

          totalProgress: 0,
        });
      }

      const user = members.get(id);

      user.name = assignee.name;

      user.assignedTasks++;

      user.estimatedHours += task.estimatedHours || 0;

      user.totalProgress += task.progress || 0;

      switch (task.status) {
        case "completed":
          user.completedTasks++;
          break;

        case "review":
          user.reviewTasks++;
          break;

        case "todo":
          user.todoTasks++;
          break;

        default:
          user.inProgressTasks++;
      }

      if (
        task.status !== "completed" &&
        task.dueDate &&
        new Date(task.dueDate).getTime() < now
      ) {
        user.overdueTasks++;
      }
    }

    // Logged Hours
    for (const log of task.workLogs || []) {
      const id = log.user?.toString();

      if (!id || !members.has(id)) continue;

      members.get(id).loggedHours +=
        (log.seconds || 0) / 3600;
    }
  }

  return [...members.values()]
    .map(member => ({
      ...member,

      loggedHours: Number(
        member.loggedHours.toFixed(2)
      ),

      completionRate:
        member.assignedTasks === 0
          ? 0
          : Math.round(
              (member.completedTasks /
                member.assignedTasks) *
                100
            ),

      avgTaskProgress:
        member.assignedTasks === 0
          ? 0
          : Math.round(
              member.totalProgress /
                member.assignedTasks
            ),
    }))
    .sort(
      (a, b) => b.assignedTasks - a.assignedTasks
    );
}


/**
 * Estimated vs Actual Report
 */
export async function getProjectEstimatedVsActual(projectId) {
  const { tasks } = await loadProjectData(projectId);

  let estimatedHours = 0;
  let actualSeconds = 0;

  const breakdown = [];

  for (const task of tasks) {
    const taskEstimated = task.estimatedHours || 0;

    let taskActualSeconds = 0;

    if (task.workLogs?.length) {
      for (const log of task.workLogs) {
        taskActualSeconds += log.seconds || 0;
      }
    }

    const taskActualHours = Number(
      (taskActualSeconds / 3600).toFixed(2)
    );

    estimatedHours += taskEstimated;
    actualSeconds += taskActualSeconds;

    breakdown.push({
      _id: task._id,
      title: task.title,
      status: task.status,
      priority: task.priority,

      estimatedHours: taskEstimated,
      actualHours: taskActualHours,

      variance: Number(
        (taskActualHours - taskEstimated).toFixed(2)
      ),

      progress: task.progress || 0,
    });
  }

  const actualHours = Number(
    (actualSeconds / 3600).toFixed(2)
  );

  return {
    summary: {
      estimatedHours,
      actualHours,

      remainingHours: Math.max(
        0,
        Number((estimatedHours - actualHours).toFixed(2))
      ),

      variance: Number(
        (actualHours - estimatedHours).toFixed(2)
      ),

      utilization:
        estimatedHours === 0
          ? 0
          : Math.round(
              (actualHours / estimatedHours) * 100
            ),
    },

    breakdown: breakdown.sort(
      (a, b) => b.variance - a.variance
    ),
  };
}


/**
 * Overdue Tasks Report
 */
export async function getProjectOverdueTasks(projectId) {
  const { tasks } = await loadProjectData(projectId);

  const now = new Date();

  const overdueTasks = [];

  for (const task of tasks) {
    if (
      task.status === "completed" ||
      !task.dueDate ||
      new Date(task.dueDate) >= now
    ) {
      continue;
    }

    const totalSeconds = (task.workLogs || []).reduce(
      (sum, log) => sum + (log.seconds || 0),
      0
    );

    const dueDate = new Date(task.dueDate);

    const daysOverdue = Math.max(
      1,
      Math.ceil(
        (now.getTime() - dueDate.getTime()) /
          (1000 * 60 * 60 * 24)
      )
    );

    overdueTasks.push({
      _id: task._id,
      title: task.title,
      status: task.status,
      priority: task.priority,
      progress: task.progress || 0,

      dueDate,

      daysOverdue,

      assignees: task.assignees || [],

      estimatedHours: task.estimatedHours || 0,

      actualHours: Number(
        (totalSeconds / 3600).toFixed(2)
      ),
    });
  }

  overdueTasks.sort(
    (a, b) => b.daysOverdue - a.daysOverdue
  );

  return {
    summary: {
      totalOverdue: overdueTasks.length,

      critical: overdueTasks.filter(
        t => t.priority === "critical"
      ).length,

      high: overdueTasks.filter(
        t => t.priority === "high"
      ).length,

      medium: overdueTasks.filter(
        t => t.priority === "medium"
      ).length,

      low: overdueTasks.filter(
        t => t.priority === "low"
      ).length,
    },

    tasks: overdueTasks,
  };
}

/**
 * Completion Trend Report
 */
export async function getProjectCompletionTrend(
  projectId,
  period = "30d"
) {
  const { tasks } = await loadProjectData(projectId);

  const ranges = {
    "7d": 7,
    "30d": 30,
    "90d": 90,
    "6m": 180,
    "1y": 365,
  };

  const days = ranges[period] || 30;

  const today = new Date();

  const trendMap = new Map();

  // Initialize every day
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);

    date.setDate(today.getDate() - i);

    const key = date.toISOString().split("T")[0];

    trendMap.set(key, {
      date: key,
      created: 0,
      completed: 0,
    });
  }

  for (const task of tasks) {
    // Created
    if (task.createdAt) {
      const key = new Date(task.createdAt)
        .toISOString()
        .split("T")[0];

      if (trendMap.has(key)) {
        trendMap.get(key).created++;
      }
    }

    // Completed
    if (
      task.status === "completed" &&
      task.updatedAt
    ) {
      const key = new Date(task.updatedAt)
        .toISOString()
        .split("T")[0];

      if (trendMap.has(key)) {
        trendMap.get(key).completed++;
      }
    }
  }

  let cumulativeCompleted = 0;

  const trend = [...trendMap.values()].map((day) => {
    cumulativeCompleted += day.completed;

    return {
      ...day,
      cumulativeCompleted,
    };
  });

  return trend;
}

export {
  loadProjectData,
  isTaskOverdue,
  calculateProjectProgress,
  calculateMilestoneProgress,
  calculateMilestoneStatus,
  calculateTotalEstimatedHours,
  calculateTotalActualHours,
};