import Task from '../models/Task.js';
import Workload from '../models/Workload.js';
import Project from '../models/Project.js';
import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';

const SECONDS_PER_HOUR = 3600;
const DEFAULT_DAILY_CAPACITY = 8;

const hoursToSeconds = (hours) =>
  Math.round((Number(hours) || 0) * SECONDS_PER_HOUR);

const secondsToHours = (seconds) =>
  Math.round(((Number(seconds) || 0) / SECONDS_PER_HOUR) * 100) / 100;

const normalizeDate = (date) => {
  const d = date ? new Date(date) : new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};

const isWorkingDay = (date) => {
  const day = new Date(date).getDay();
  return day !== 0;
};

const getDateRange = (start, end) => {
  const dates = [];
  const s = start ? normalizeDate(start) : normalizeDate();
  const e = end ? normalizeDate(end) : s;
  if (e < s) return [s];
  const current = new Date(s);
  while (current <= e) {
    dates.push(new Date(current));
    current.setDate(current.getDate() + 1);
  }
  return dates;
};

const getWorkingDateRange = (start, end) => {
  return getDateRange(start, end).filter(isWorkingDay);
};

const dateKey = (date) => normalizeDate(date).toISOString().split("T")[0];

const recompute = (dailyCapacitySeconds, assignedSeconds) => {
  const capacity = Number(dailyCapacitySeconds) || 0;
  const assigned = Number(assignedSeconds) || 0;
  return {
    availableHours: Math.max(0, capacity - assigned),
    utilization: capacity > 0 ? Math.round((assigned / capacity) * 100) : 0,
    overloaded: assigned >= capacity,
  };
};

const checkWorkloadPermission = (project, userId, permission) => {
  const isOwner = project.owner.toString() === userId;
  const teamMember = project.team.find(
    (member) => member.user.toString() === userId
  );
  return (
    isOwner ||
    (teamMember && teamMember.permissions.includes(permission))
  );
};

export const recalcUserWorkload = async (projectId, userId) => {
  const project = await Project.findById(projectId)
    .select("startDate endDate")
    .lean();

  if (!project) return;

  const tasks = await Task.find({
    project: projectId,
    assignees: userId,
    isDeleted: { $ne: true },
    status: { $nin: ["completed", "cancelled"] },
  })
    .select("estimatedHours startDate dueDate")
    .lean();

  const secondsByDay = new Map();

  for (const task of tasks) {
    const totalSeconds = hoursToSeconds(task.estimatedHours);
    if (totalSeconds <= 0) continue;

    const start = task.startDate || task.dueDate || project.startDate;
    const end = task.dueDate || task.startDate || project.endDate;

    const workingDays = getWorkingDateRange(start, end);
    if (workingDays.length === 0) continue;

    const secondsPerDay = totalSeconds / workingDays.length;

    for (const day of workingDays) {
      const key = dateKey(day);
      secondsByDay.set(
        key,
        (secondsByDay.get(key) || 0) + secondsPerDay
      );
    }
  }

  const projectDays = getWorkingDateRange(
    project.startDate,
    project.endDate
  );

  const allKeys = new Set([
    ...projectDays.map(dateKey),
    ...secondsByDay.keys(),
  ]);

  const operations = [];

  for (const key of allKeys) {
    const date = normalizeDate(key);
    const assignedSeconds = Math.round(secondsByDay.get(key) || 0);
    const dailyCapacitySec = hoursToSeconds(DEFAULT_DAILY_CAPACITY);
    const result = recompute(dailyCapacitySec, assignedSeconds);

    operations.push({
      updateOne: {
        filter: {
          project: projectId,
          user: userId,
          date,
        },
        update: {
          $set: {
            assignedHours: assignedSeconds,
            dailyCapacity: dailyCapacitySec,
            availableHours: result.availableHours,
            utilization: result.utilization,
            overloaded: result.overloaded,
            updatedAt: new Date(),
          },
          $setOnInsert: {
            project: projectId,
            user: userId,
            date,
          },
        },
        upsert: true,
      },
    });
  }

  if (operations.length > 0) {
    await Workload.bulkWrite(operations);
  }

  // Delete stale workload records
  const existingWorkloads = await Workload.find({
    project: projectId,
    user: userId,
  }).lean();

  const validKeys = new Set(allKeys);

  const toDelete = existingWorkloads
    .filter((w) => {
      const wKey = dateKey(w.date);
      const isStaleDate = !validKeys.has(wKey);
      const hasNoTasks = secondsByDay.get(wKey) === undefined;
      const isDefaultCapacity = (w.dailyCapacity ?? hoursToSeconds(DEFAULT_DAILY_CAPACITY)) === hoursToSeconds(DEFAULT_DAILY_CAPACITY);
      return isStaleDate || (hasNoTasks && isDefaultCapacity);
    })
    .map((w) => w._id);

  if (toDelete.length > 0) {
    await Workload.deleteMany({ _id: { $in: toDelete } });
  }
};

export const recalcWorkloadForUsers = async (projectId, userIds = []) => {
  const uniqueIds = [...new Set((userIds || []).map((id) => id.toString()))];
  for (const userId of uniqueIds) {
    await recalcUserWorkload(projectId, userId);
  }
};

export const getWorkloadManagement = async (req, res) => {
  try {
    const { projectId } = req.params;
    const project = await Project.findById(projectId)
      .populate('team.user', 'name email avatar')
      .lean();

    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const canView = checkWorkloadPermission(project, req.user.id, PROJECT_PERMISSIONS.PROJECT_VIEW);
    if (!canView) return res.status(403).json({ success: false, message: 'No permission.' });

    const workload = await Workload.find({ project: projectId })
      .populate('user', 'name email avatar')
      .sort({ date: 1 })
      .lean();

    const formatted = workload.map((w) => {
      const dailyCapacitySec = w.dailyCapacity ?? hoursToSeconds(DEFAULT_DAILY_CAPACITY);
      const assignedSec = w.assignedHours || 0;
      const { availableHours: availableSec, utilization, overloaded } = recompute(dailyCapacitySec, assignedSec);

      return {
        _id: w._id,
        user: w.user,
        date: w.date,
        dailyCapacity: secondsToHours(dailyCapacitySec),
        assignedHours: secondsToHours(assignedSec),
        availableHours: secondsToHours(availableSec),
        utilization,
        overloaded,
      };
    });

    const summaryMap = new Map();
    formatted.forEach((w) => {
      const key = w.user?._id?.toString();
      if (!key) return;
      if (!summaryMap.has(key)) {
        summaryMap.set(key, {
          user: w.user,
          totalDays: 0,
          totalCapacity: 0,
          totalAssigned: 0,
          overloadedDays: 0,
          firstDate: w.date,
          lastDate: w.date,
        });
      }
      const s = summaryMap.get(key);
      s.totalDays += 1;
      s.totalCapacity += w.dailyCapacity;
      s.totalAssigned += w.assignedHours;
      if (w.overloaded) s.overloadedDays += 1;
      if (new Date(w.date) < new Date(s.firstDate)) s.firstDate = w.date;
      if (new Date(w.date) > new Date(s.lastDate)) s.lastDate = w.date;
    });

    const userSummaries = Array.from(summaryMap.values()).map((s) => ({
      ...s,
      totalCapacity: Math.round(s.totalCapacity * 100) / 100,
      totalAssigned: Math.round(s.totalAssigned * 100) / 100,
      avgUtilization: s.totalCapacity > 0 ? Math.round((s.totalAssigned / s.totalCapacity) * 100) : 0,
    }));

    res.json({
      success: true,
      data: {
        workload: formatted,
        userSummaries,
        projectPeriod: { startDate: project.startDate, endDate: project.endDate },
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateDailyCapacity = async (req, res) => {
  try {
    const { projectId } = req.params;
    const {
      userId,
      dailyCapacity,
      date,
      startDate,
      endDate,
      applyToWholeProject,
    } = req.body;

    if (!userId || dailyCapacity === undefined) {
      return res.status(400).json({
        success: false,
        message: "userId and dailyCapacity are required.",
      });
    }

    const project = await Project.findById(projectId).lean();

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    const canManage = checkWorkloadPermission(
      project,
      req.user.id,
      PROJECT_PERMISSIONS.WORKLOAD_MANAGE
    );

    if (!canManage) {
      return res.status(403).json({
        success: false,
        message: "No permission.",
      });
    }

    let dates = [];

    if (applyToWholeProject) {
      dates = getWorkingDateRange(
        project.startDate,
        project.endDate
      );
    } else if (startDate || endDate) {
      dates = getWorkingDateRange(
        startDate || endDate,
        endDate || startDate
      );
    } else {
      const targetDate = normalizeDate(date);
      if (isWorkingDay(targetDate)) {
        dates = [targetDate];
      }
    }

    const capacitySeconds = hoursToSeconds(dailyCapacity);

    const operations = dates.map((day) => ({
      updateOne: {
        filter: {
          project: projectId,
          user: userId,
          date: day,
        },
        update: {
          $set: {
            dailyCapacity: capacitySeconds,
            updatedAt: new Date(),
          },
          $setOnInsert: {
            project: projectId,
            user: userId,
            date: day,
            assignedHours: 0,
          },
        },
        upsert: true,
      },
    }));

    if (operations.length > 0) {
      await Workload.bulkWrite(operations);
    }

    const records = await Workload.find({
      project: projectId,
      user: userId,
      date: { $in: dates },
    }).populate("user", "name email avatar");

    const data = records.map((record) => ({
      ...record.toObject(),
      dailyCapacity: secondsToHours(record.dailyCapacity),
      assignedHours: secondsToHours(record.assignedHours),
      availableHours: secondsToHours(record.availableHours),
    }));

    res.json({
      success: true,
      message:
        data.length > 1
          ? `Daily capacity updated for ${data.length} day(s).`
          : "Daily capacity updated.",
      data: data.length === 1 ? data[0] : data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const initializeMemberWorkload = async (
  projectId,
  userId,
  dailyCapacity,
  project
) => {
  const dates = getWorkingDateRange(
    project.startDate,
    project.endDate
  );

  const capacitySeconds = hoursToSeconds(dailyCapacity || DEFAULT_DAILY_CAPACITY);

  const operations = dates.map((date) => {
    const result = recompute(capacitySeconds, 0);
    return {
      updateOne: {
        filter: {
          project: projectId,
          user: userId,
          date,
        },
        update: {
          $setOnInsert: {
            dailyCapacity: capacitySeconds,
            assignedHours: 0,
            availableHours: result.availableHours,
            utilization: result.utilization,
            overloaded: result.overloaded,
          },
        },
        upsert: true,
      },
    };
  });

  if (operations.length > 0) {
    await Workload.bulkWrite(operations);
  }
};

export const recalculateUserWorkload = async (req, res) => {
  try {
    const { projectId, userId } = req.params;
    const project = await Project.findById(projectId).lean();
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const canManage = checkWorkloadPermission(project, req.user.id, PROJECT_PERMISSIONS.WORKLOAD_MANAGE);
    if (!canManage) return res.status(403).json({ success: false, message: 'No permission.' });

    await recalcUserWorkload(projectId, userId);

    const records = await Workload.find({ project: projectId, user: userId })
      .populate('user', 'name email avatar')
      .sort({ date: 1 });

    const responseData = records.map((r) => ({
      ...r.toObject(),
      dailyCapacity: secondsToHours(r.dailyCapacity),
      assignedHours: secondsToHours(r.assignedHours),
      availableHours: secondsToHours(r.availableHours),
    }));

    res.json({ success: true, message: 'Workload recalculated from tasks.', data: responseData });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};