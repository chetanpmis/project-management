import mongoose from 'mongoose';
import Project from '../models/Project.js';
import Task from '../models/Task.js';
import Activity from '../models/Activity.js';

// Activity types that describe the project itself (or things everyone on
// the project should see regardless of task membership) — visible to any
// project member.
const PROJECT_SCOPED_ACTIVITY_TYPES = new Set([
  'project_created',
  'project_updated',
  'project_archived',
  'project_deleted',
  'member_added',
  'member_removed',
  'member_role_changed',
  'member_updated',
  'budget_updated',
  'expense_added',
  'expense_approved',
  'milestone_created',
  'milestone_completed',
  'milestone_removed',
  'workload_updated',
]);
// Everything else (task_created, task_updated, checklist_updated,
// comment_added, watcher_added, work_log_added, etc.) is task-scoped and
// only shown to people who are actually part of that task.

const ACTIVITY_CANDIDATE_LIMIT = 40; // over-fetch, then filter down to RESULT_LIMIT
const ACTIVITY_RESULT_LIMIT = 10;

export const getDashboardSummary = async (req, res) => {
  try {
    const userId = req.user.id;
    const userObjectId = new mongoose.Types.ObjectId(userId);

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const endOfToday = new Date(startOfToday.getTime() + 24 * 60 * 60 * 1000);
    const next7Days = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

    // Projects where user is owner or team member
    const myProjects = await Project.find({
      $or: [{ owner: userId }, { 'team.user': userId }],
      isDeleted: { $ne: true },
    })
      .select('_id name description progress updatedAt')
      .sort({ updatedAt: -1 })
      .limit(5);

    const projectIds = myProjects.map((project) => project._id);

    const [
      // ===== TASK STATS — scoped to tasks assigned to this user =====
      totalTasks,
      completedTasks,
      todoTasks,
      inProgressTasks,
      reviewTasks,
      overdueTasks,

      monthTotalTasks,
      monthCompletedTasks,

      // ===== MY WORK =====
      myAssignedTasks,
      myTasksDueToday,
      myTasksOverdue,
      myTasksUpcoming,
      myTaskStatusBreakdown,

      // ===== ACTIVITY (over-fetched candidates, filtered below) =====
      activityCandidates,
    ] = await Promise.all([
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        status: 'completed',
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        status: 'todo',
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        status: 'in-progress',
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        status: 'review',
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        dueDate: { $lt: startOfToday },
        status: { $ne: 'completed' },
        isDeleted: { $ne: true },
      }),

      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        createdAt: { $gte: startOfMonth },
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        status: 'completed',
        updatedAt: { $gte: startOfMonth },
        isDeleted: { $ne: true },
      }),

      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        dueDate: { $gte: startOfToday, $lt: endOfToday },
        status: { $ne: 'completed' },
        isDeleted: { $ne: true },
      }),
      Task.countDocuments({
        project: { $in: projectIds },
        assignees: userObjectId,
        dueDate: { $lt: startOfToday },
        status: { $ne: 'completed' },
        isDeleted: { $ne: true },
      }),
      Task.find({
        project: { $in: projectIds },
        assignees: userObjectId,
        dueDate: { $gte: now, $lte: next7Days },
        status: { $ne: 'completed' },
        isDeleted: { $ne: true },
      })
        .select('title dueDate status priority project')
        .populate('project', 'name')
        .sort({ dueDate: 1 })
        .limit(5),
      Task.aggregate([
        {
          $match: {
            project: { $in: projectIds },
            assignees: userObjectId,
            isDeleted: { $ne: true },
          },
        },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),

      Activity.find({ project: { $in: projectIds } })
        .populate('user', 'name avatar')
        .populate('project', 'name')
        .sort({ createdAt: -1 })
        .limit(ACTIVITY_CANDIDATE_LIMIT),
    ]);

    // ===========================
    // MY WORK STATUS MAP
    // ===========================
    const statusMap = { todo: 0, 'in-progress': 0, review: 0, completed: 0 };
    myTaskStatusBreakdown.forEach((status) => {
      if (status._id in statusMap) statusMap[status._id] = status.count;
    });

    // ===========================
    // FILTER ACTIVITY: project-scoped types pass through for any project
    // member; task-scoped types only pass if the user is an assignee,
    // watcher, or creator of that specific task.
    // ===========================
    const taskEntityIds = [
      ...new Set(
        activityCandidates
          .filter((a) => a.entity === 'Task' && !PROJECT_SCOPED_ACTIVITY_TYPES.has(a.type))
          .map((a) => String(a.entityId))
      ),
    ];

    let userTaskIdSet = new Set();
    if (taskEntityIds.length > 0) {
      const relatedTasks = await Task.find({
        _id: { $in: taskEntityIds.map((id) => new mongoose.Types.ObjectId(id)) },
      })
        .select('_id assignees watchers createdBy')
        .lean();

      userTaskIdSet = new Set(
        relatedTasks
          .filter(
            (t) =>
              (t.assignees || []).some((a) => String(a) === userId) ||
              (t.watchers || []).some((w) => String(w) === userId) ||
              String(t.createdBy) === userId
          )
          .map((t) => String(t._id))
      );
    }

    const recentActivity = activityCandidates
      .filter((a) => {
        if (PROJECT_SCOPED_ACTIVITY_TYPES.has(a.type) || a.entity !== 'Task') return true;
        return userTaskIdSet.has(String(a.entityId));
      })
      .slice(0, ACTIVITY_RESULT_LIMIT);

    // ===========================
    // EFFICIENCY
    // ===========================
    const overallEfficiency = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    const thisMonthEfficiency = monthTotalTasks > 0 ? Math.round((monthCompletedTasks / monthTotalTasks) * 100) : 0;

    // ===========================
    // RESPONSE
    // ===========================
    res.json({
      stats: {
        totalProjects: myProjects.length,
        totalTasks,
        completedTasks,
        todoTasks,
        inProgressTasks,
        reviewTasks,
        overdueTasks,
        completionRate: overallEfficiency,
        thisMonth: {
          totalTasks: monthTotalTasks,
          completedTasks: monthCompletedTasks,
          efficiency: thisMonthEfficiency,
        },
      },

      myWork: {
        total: myAssignedTasks,
        dueToday: myTasksDueToday,
        overdue: myTasksOverdue,
        byStatus: [
          { name: 'To Do', key: 'todo', value: statusMap.todo },
          { name: 'In Progress', key: 'in-progress', value: statusMap['in-progress'] },
          { name: 'Review', key: 'review', value: statusMap.review },
          { name: 'Completed', key: 'completed', value: statusMap.completed },
        ],
      },

      upcomingWork: myTasksUpcoming,
      recentProjects: myProjects,
      recentActivity,
    });
  } catch (error) {
    console.error('Dashboard summary error:', error);
    res.status(500).json({ error: error.message });
  }
};