import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import Workload from '../models/Workload.js';
import Project from '../models/Project.js';
import Comment from '../models/Comment.js';
import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';
import { sendNotification, notifyTaskParticipants,sendBulkNotification } from '../utils/sendNotification.js';
import File from '../models/File.js';

import fs from 'fs/promises';
import path from 'path';
import mongoose from 'mongoose';
import { recalcWorkloadForUsers } from './workloadController.js';
import { notifyProjectTeam } from '../utils/sendNotification.js';

const checkTaskPermission = async (userId, projectId, permission) => {
  const project = await Project.findById(projectId);
  if (!project) return false;
  if (project.owner.toString() === userId) return true;
  const teamMember = project.team.find((member) => member.user.toString() === userId);
  return teamMember && teamMember.permissions.includes(permission);
};

const validateTaskDates = ({ taskStart, taskDue, projectStart, projectEnd }) => {
  const start = taskStart ? new Date(taskStart) : null;
  const due = taskDue ? new Date(taskDue) : null;
  const pStart = projectStart ? new Date(projectStart) : null;
  const pEnd = projectEnd ? new Date(projectEnd) : null;

  if (start && due && start > due) return 'Due date cannot be before start date';
  if (pStart && start && start < pStart) return 'Task start date cannot be before project start date';
  if (pEnd && due && due > pEnd) return 'Task due date cannot be after project end date';
  return null;
};

const findCyclicDependency = (taskId, candidateIds, graph) => {
  for (const candidateId of candidateIds) {
    const visited = new Set();
    const dfs = (currentId) => {
      if (currentId === taskId) return true;
      if (visited.has(currentId)) return false;
      visited.add(currentId);
      return (graph.get(currentId) || []).some(dfs);
    };
    if (dfs(candidateId)) return candidateId;
  }
  return null;
};

// ====================== LIST ======================
export const listByProject = async (req, res) => {
  try {
    const { projectId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const search = req.query.search || '';
    const status = req.query.status || '';
    const priority = req.query.priority || '';
    const filterType = req.query.filterType || 'all';
    const sortBy = req.query.sortBy || 'createdAt';
    const sortOrder = req.query.sortOrder || 'desc';

    const hasPermission = await checkTaskPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

    let query = { project: projectId, isDeleted: { $ne: true } };

    if (filterType === 'assigned') query.assignees = req.user.id;
    else if (filterType === 'watching') query.watchers = req.user.id;

    if (search) query.$or = [{ title: { $regex: search, $options: 'i' } }, { description: { $regex: search, $options: 'i' } }, { tags: { $regex: search, $options: 'i' } }];
    if (status) query.status = status;
    if (priority) query.priority = priority;

    const total = await Task.countDocuments(query);
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'asc' ? 1 : -1;

    const tasks = await Task.find(query)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .populate('comments')
      .sort(sortOptions)
      .limit(limit)
      .skip((page - 1) * limit);

    res.json({
      success: true,
      data: tasks,
      pagination: {
        total, page, limit,
        pages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrevious: page > 1,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// ====================== MY TASKS ======================
export const getMyTasks = async (req, res) => {
  try {
    const { page = 1, limit = 10, type = "all", projectId } = req.query;
    const userId = req.user.id;

    let query = { isDeleted: { $ne: true } };
    if (projectId) query.project = projectId;

    switch (type) {
      case "assigned": query.assignees = userId; break;
      case "watching": query.watchers = userId; break;
      case "all":
      default:
        query.$or = [{ assignees: userId }, { watchers: userId }];
        break;
    }

    const total = await Task.countDocuments(query);

    const tasks = await Task.find(query)
      .populate("assignees", "name email avatar")
      .populate("watchers", "name email avatar")
      .populate("createdBy", "name email")
      .populate({ path: "comments", populate: { path: "author", select: "name email avatar" } })
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    res.json({
      success: true,
      data: tasks,
      filters: { type },
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / Number(limit)),
        hasNext: Number(page) < Math.ceil(total / Number(limit)),
        hasPrevious: Number(page) > 1,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// ====================== STATS ======================
export const getMyTaskStats = async (req, res) => {
  try {
    const { projectId } = req.query;
    const userId = req.user.id;

    const match = {
      isDeleted: { $ne: true },
      $or: [{ assignees: userId }, { watchers: userId }]
    };
    if (projectId) match.project = projectId;

    const stats = await Task.aggregate([
      { $match: match },
      { $group: {
        _id: null,
        total: { $sum: 1 },
        completed: { $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] } },
        pending: { $sum: { $cond: [{ $in: ['$status', ['todo', 'in-progress', 'review']] }, 1, 0] } }
      }}
    ]);

    const result = stats[0] || { total: 0, completed: 0, pending: 0 };

    const overdueDynamic = await Task.countDocuments({
      ...match,
      dueDate: { $lt: new Date() },
      status: { $ne: 'completed' }
    });

    const watchingCount = await Task.countDocuments({
      watchers: userId,
      isDeleted: { $ne: true },
      ...(projectId ? { project: projectId } : {})
    });

    const finalStats = {
      total: result.total,
      completed: result.completed,
      pending: result.pending,
      overdue: overdueDynamic,
      watching: watchingCount,
      completionRate: result.total > 0 ? Math.round((result.completed / result.total) * 100) : 0
    };

    res.json({ success: true, data: finalStats });
  } catch (error) {
    console.error("getMyTaskStats Error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

// ── Milestone status rules ──────────────────────────────────────────────
// pending      → milestone has 0 tasks under it
// in-progress  → milestone has ≥1 task and progress < 100% (any task activity moves it here)
// completed    → progress === 100%
//
// ── Project status/progress rules ───────────────────────────────────────
// progress     → recalculated from ALL tasks across the whole project (not just one milestone)
// planning → active   → the moment any task exists under the project (first sign of activity)
// active   → completed → only when every milestone is completed AND overall progress is 100%
// completed → active   → auto-reopens if progress drops back below 100% (task reopened/added)
// on_hold / cancelled are left alone — those are explicit human decisions, never auto-overridden.

const updateMilestoneProgress = async (projectId, milestoneId) => {
  const project = await Project.findById(projectId);
  if (!project) return;

  // 1. Sync the specific milestone this task belongs to
  if (milestoneId) {
    const milestone = project.milestones.find((m) => m._id.toString() === milestoneId.toString());

    if (milestone) {
      const tasks = await Task.find({
        project: projectId,
        milestone: milestoneId,
        isDeleted: { $ne: true },
      }).select('status');

      const totalTasks = tasks.length;
      const completedTasks = tasks.filter((t) => t.status === 'completed').length;
      const progress = totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100);

      let newStatus;
      if (totalTasks === 0) newStatus = 'pending';
      else if (progress === 100) newStatus = 'completed';
      else newStatus = 'in-progress'; // any task activity under a milestone lifts it out of "pending"

      const wasCompleted = milestone.status === 'completed';
      const nowCompleted = newStatus === 'completed';

      await Project.updateOne(
        { _id: projectId, 'milestones._id': milestoneId },
        {
          $set: {
            'milestones.$.progress': progress,
            'milestones.$.status': newStatus,
            'milestones.$.completedAt': nowCompleted ? new Date() : null,
          },
        }
      );

      // Notify the team the first time this milestone crosses into 100%
      if (!wasCompleted && nowCompleted) {
        const populated = await Project.findById(projectId)
          .populate('owner', 'name email avatar')
          .populate('team.user', 'name email avatar');

        await notifyProjectTeam(populated, {
          type: 'milestone_completed',
          title: 'Milestone Completed',
          message: `Milestone "${milestone.name}" in "${populated.name}" reached 100%.`,
        });
      }
    }
  }

  // 2. Always resync the parent project — its progress/status are derived from
  //    task+milestone state, never hand-edited, so this runs on every task mutation.
  await syncProjectProgressFromTasks(projectId);
};

const syncProjectProgressFromTasks = async (projectId) => {
  const project = await Project.findById(projectId);
  if (!project) return;

  const totalTasks = await Task.countDocuments({ project: projectId, isDeleted: { $ne: true } });
  const completedTasks = await Task.countDocuments({ project: projectId, isDeleted: { $ne: true }, status: 'completed' });

  const progress = totalTasks === 0 ? project.progress : Math.round((completedTasks / totalTasks) * 100);

  let newStatus = project.status;
  let completedAt = project.completedAt;

  // planning → active the instant any task exists — the project is no longer just an idea
  if (project.status === 'planning' && totalTasks > 0) {
    newStatus = 'active';
  }

  const allMilestonesDone =
    project.milestones.length === 0 || project.milestones.every((m) => m.status === 'completed');

  // active → completed only when EVERY milestone is done AND overall task progress hits 100%
  if (['planning', 'active'].includes(newStatus) && totalTasks > 0 && progress === 100 && allMilestonesDone) {
    newStatus = 'completed';
    completedAt = new Date();
  } else if (newStatus === 'completed' && (progress < 100 || !allMilestonesDone)) {
    // Reopened work (new task added, or a task un-completed) — pull it back out of "completed"
    newStatus = 'active';
    completedAt = null;
  }

  const statusChanged = newStatus !== project.status;

  await Project.updateOne(
    { _id: projectId },
    { $set: { progress, status: newStatus, completedAt, lastActivityAt: new Date() } }
  );

  // Only notify + log on meaningful auto-transitions, not on every single progress tick
  if (statusChanged && (newStatus === 'completed' || newStatus === 'active')) {
    const populated = await Project.findById(projectId)
      .populate('owner', 'name email avatar')
      .populate('team.user', 'name email avatar');

    await notifyProjectTeam(populated, {
      type: 'project_status_changed',
      title: newStatus === 'completed' ? 'Project Completed' : 'Project Now Active',
      message:
        newStatus === 'completed'
          ? `🎉 Project "${populated.name}" reached 100% completion.`
          : `Project "${populated.name}" is now active based on task activity.`,
    });

    // Use project.owner as the actor for this system-generated log entry —
    // there's no req.user in this scope since it runs off task mutations.
    await Activity.create({
      project: projectId,
      user: project.owner,
      type: 'project_status_changed',
      entity: 'Project',
      entityId: projectId,
      description: `Project status auto-updated to "${newStatus}" based on task activity`,
    });
  }
};

const notifyProjectTeamHelper = async (project, milestone) => {
  await notifyProjectTeam(project, {
    type: 'milestone_completed',
    title: 'Milestone Completed',
    message: `Milestone "${milestone.name}" in "${project.name}" reached 100%.`,
  });
};

const validateTaskAgainstMilestone = (taskStart, taskDue, milestone) => {
  if (!milestone) return null;

  const toDateOnly = (date) => {
    if (!date) return null;
    const d = new Date(date);
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  };

  const tStart = toDateOnly(taskStart);
  const tDue = toDateOnly(taskDue);
  const mStart = toDateOnly(milestone.startDate);
  const mDue = toDateOnly(milestone.dueDate);

  if (tStart && tDue && tStart > tDue) return "Task due date must be after task start date";
  if (mStart && tStart && tStart < mStart) return `Task start date cannot be before milestone start date (${mStart.toLocaleDateString()})`;
  if (mDue && tDue && tDue > mDue) return `Task due date cannot be after milestone due date (${mDue.toLocaleDateString()})`;
  return null;
};

export const create = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { projectId } = req.params;
    const { title, description, assignees, watchers, priority, dueDate, startDate, estimatedHours, labels, tags, estimatedEffort, dependencies = [], checklist = [], milestone } = req.body;

    const hasPermission = await checkTaskPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_CREATE);
    if (!hasPermission) {
      await session.abortTransaction();
      return res.status(403).json({ success: false, message: 'You do not have permission to create tasks in this project.' });
    }

    const project = await Project.findById(projectId).session(session);
    if (!project) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Project not found.' });
    }

    if (!milestone) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: 'Milestone is required when creating a task.' });
    }

    const milestoneDoc = project.milestones.find(m => m._id.toString() === milestone);
    if (!milestoneDoc) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: 'Invalid milestone.' });
    }

    const dateError = validateTaskDates({ taskStart: startDate, taskDue: dueDate, projectStart: project.startDate, projectEnd: project.endDate });
    if (dateError) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: dateError });
    }

    const milestoneDateError = validateTaskAgainstMilestone(startDate, dueDate, milestoneDoc);
    if (milestoneDateError) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: milestoneDateError });
    }

    let validDependencies = [];
    if (dependencies.length > 0) {
      const depIds = dependencies.map(d => d._id || d);
      const depTasks = await Task.find({ _id: { $in: depIds }, project: projectId, isDeleted: { $ne: true } }).session(session);
      if (depTasks.length !== depIds.length) {
        await session.abortTransaction();
        return res.status(400).json({ success: false, message: 'One or more dependencies are invalid for this project.' });
      }
      validDependencies = depIds;
    }

    const task = new Task({
      title, description, project: projectId, assignees: assignees || [], watchers: watchers || [],
      priority: priority || 'medium', dueDate, startDate, estimatedHours: Number(estimatedHours || 0),
      labels: labels || [], tags: tags || [], estimatedEffort: estimatedEffort || 'medium',
      createdBy: req.user.id, dependencies: validDependencies, checklist, milestone
    });

    await task.save({ session });

    if (assignees?.length) await recalcWorkloadForUsers(projectId, assignees);
    await updateMilestoneProgress(projectId, milestone);

   await sendBulkNotification(assignees, {
  type: 'task_assigned',
  title: 'New Task Assigned',
  message: `You have been assigned to task "${title}" in project "${project.name}"`,
  relatedTask: task._id,
  relatedProject: projectId,
});

    // NOTIFICATION: watchers + owner (excluding assignees already notified above + creator)
    await notifyTaskParticipants(task, project, {
      type: 'task_created',
      title: 'Task Created',
      message: `Task "${title}" was created in "${project.name}".`,
      excludeUserId: req.user.id,
    });

    await Activity.create([{
      project: projectId,
      user: req.user.id,
      type: 'task_created',
      entity: 'Task',
      entityId: task._id,
      description: `Task "${title}" created`
    }], { session });

    await session.commitTransaction();

    const populatedTask = await Task.findById(task._id)
      .populate("assignees", "name email avatar")
      .populate("watchers", "name email avatar")
      .populate("createdBy", "name email")
      .populate("dependencies");

    res.status(201).json({ success: true, message: 'Task created successfully.', data: populatedTask });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ success: false, error: error.message });
  } finally {
    session.endSession();
  }
};

export const update = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { id } = req.params;
    const oldTask = await Task.findById(id).session(session);
    if (!oldTask) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    const hasPermission = await checkTaskPermission(req.user.id, oldTask.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) {
      await session.abortTransaction();
      return res.status(403).json({ success: false, message: 'You do not have permission to edit this task.' });
    }

    const project = await Project.findById(oldTask.project).session(session);
    if (!project) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Project not found.' });
    }

    const { title, description, status, priority, dueDate, startDate, estimatedHours, assignees, watchers, labels, tags, estimatedEffort, dependencies, checklist, milestone } = req.body;

    const effectiveStart = startDate !== undefined ? startDate : oldTask.startDate;
    const effectiveDue = dueDate !== undefined ? dueDate : oldTask.dueDate;

    const dateError = validateTaskDates({ taskStart: effectiveStart, taskDue: effectiveDue, projectStart: project.startDate, projectEnd: project.endDate });
    if (dateError) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: dateError });
    }

    const previousAssignees = (oldTask.assignees || []).map(id => id.toString());
    const previousStatus = oldTask.status;
    const previousMilestone = oldTask.milestone;
    const previousTitle = oldTask.title;

    if (title !== undefined) oldTask.title = title;
    if (description !== undefined) oldTask.description = description;
    if (status !== undefined) oldTask.status = status;
    if (priority !== undefined) oldTask.priority = priority;
    if (dueDate !== undefined) oldTask.dueDate = dueDate;
    if (startDate !== undefined) oldTask.startDate = startDate;
    if (estimatedHours !== undefined) oldTask.estimatedHours = Number(estimatedHours);
    if (labels !== undefined) oldTask.labels = labels;
    if (tags !== undefined) oldTask.tags = tags;
    if (estimatedEffort !== undefined) oldTask.estimatedEffort = estimatedEffort;
    if (assignees !== undefined) oldTask.assignees = assignees;
    if (watchers !== undefined) oldTask.watchers = watchers;
    if (dependencies !== undefined) oldTask.dependencies = dependencies;
    if (checklist !== undefined) oldTask.checklist = checklist;
    if (milestone !== undefined) oldTask.milestone = milestone;

    oldTask.updatedAt = new Date();
    await oldTask.save({ session });

    const currentAssignees = (oldTask.assignees || []).map(id => id.toString());
    const usersToRecalculate = [...new Set([...previousAssignees, ...currentAssignees])];

    if (usersToRecalculate.length > 0) {
      await recalcWorkloadForUsers(oldTask.project, usersToRecalculate);
    }

    if (milestone !== undefined || (status !== undefined && status !== previousStatus)) {
      if (oldTask.milestone) await updateMilestoneProgress(oldTask.project, oldTask.milestone);
      if (previousMilestone && String(previousMilestone) !== String(oldTask.milestone)) {
        await updateMilestoneProgress(oldTask.project, previousMilestone);
      }
    }

    await session.commitTransaction();

    const updatedTask = await Task.findById(oldTask._id)
      .populate("assignees", "name email avatar")
      .populate("watchers", "name email avatar")
      .populate("createdBy", "name email")
      .populate("dependencies");

   
const newlyAssigned = currentAssignees.filter(a => !previousAssignees.includes(a));
await sendBulkNotification(newlyAssigned, {
  type: 'task_assigned',
  title: 'New Task Assigned',
  message: `You have been assigned to task "${updatedTask.title}" in project "${project.name}"`,
  relatedTask: updatedTask._id,
  relatedProject: project._id,
});
    // NOTIFICATION: status change
    if (status !== undefined && status !== previousStatus) {
      await notifyTaskParticipants(updatedTask, project, {
        type: 'task_status_changed',
        title: 'Task Status Changed',
        message: `Task "${updatedTask.title}" status changed from ${previousStatus} to ${status}.`,
        excludeUserId: req.user.id,
      });

      await Activity.create({
        project: oldTask.project,
        user: req.user.id,
        type: "task_status_changed",
        entity: "Task",
        entityId: oldTask._id,
        previousValue: previousStatus,
        newValue: status,
        description: `Task status changed from "${previousStatus}" to "${status}"`,
      });
    } else {
      // NOTIFICATION: generic update
      await notifyTaskParticipants(updatedTask, project, {
        type: 'task_updated',
        title: 'Task Updated',
        message: `Task "${updatedTask.title}" was updated.`,
        excludeUserId: req.user.id,
      });

      await Activity.create({
        project: oldTask.project,
        user: req.user.id,
        type: "task_updated",
        entity: "Task",
        entityId: oldTask._id,
        description: `Task "${updatedTask.title}" updated`,
      });
    }

    res.json({ success: true, message: 'Task updated successfully.', data: updatedTask });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ success: false, error: error.message });
  } finally {
    session.endSession();
  }
};

export const get = async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, isDeleted: { $ne: true } })
      .populate("project", "name")
      .populate("assignees", "name email avatar")
      .populate("watchers", "name email avatar")
      .populate("createdBy", "name email")
      .populate({ path: "comments", populate: { path: "author", select: "name email avatar" } })
      .populate("workLogs.user", "name email")
      .populate("dependencies")
      .populate("attachments");

    if (!task) return res.status(404).json({ success: false, message: "Task not found." });

    const hasPermission = await checkTaskPermission(req.user.id, task.project._id, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasPermission) return res.status(403).json({ success: false, message: "You do not have permission to view this task." });

    res.json({ success: true, data: task });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getTaskCreationData = async (req, res) => {
  try {
    const { projectId } = req.params;
    const userId = req.user.id;

    if (!projectId) return res.status(400).json({ success: false, message: 'Project ID is required.' });

    const hasCreatePermission = await checkTaskPermission(userId, projectId, PROJECT_PERMISSIONS.TASK_CREATE);
    if (!hasCreatePermission) return res.status(403).json({ success: false, message: 'You do not have permission to create tasks in this project.' });

    const hasViewPermission = await checkTaskPermission(userId, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasViewPermission) return res.status(403).json({ success: false, message: 'You do not have permission to view this project.' });

    const project = await Project.findById(projectId).populate('team.user', 'name email avatar').select('milestones team startDate endDate name');
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const milestones = project.milestones.map(m => ({
      _id: m._id, name: m.name, startDate: m.startDate, dueDate: m.dueDate, progress: m.progress || 0
    }));

    const teamMembers = project.team.map(member => ({
      user: { _id: member.user?._id, name: member.user?.name, email: member.user?.email, avatar: member.user?.avatar },
      role: member.role,
      permissions: member.permissions || []
    }));

    const projectTasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).select('_id title dueDate status').sort({ createdAt: -1 });

    res.json({
      success: true,
      data: { project: { name: project.name, startDate: project.startDate, endDate: project.endDate }, milestones, teamMembers, projectTasks }
    });
  } catch (error) {
    console.error('getTaskCreationData Error:', error);
    res.status(500).json({ success: false, message: 'Failed to load task creation data.', error: error.message });
  }
};

export const getUserTaskStats = async (req, res) => {
  try {
    const { projectId } = req.params;
    const hasPermission = await checkTaskPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

    const assignedTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, isDeleted: { $ne: true } });
    const watchingTasks = await Task.countDocuments({ project: projectId, watchers: req.user.id, isDeleted: { $ne: true } });
    const completedTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, status: 'completed', isDeleted: { $ne: true } });
    const overdueTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, status: { $ne: 'completed' }, dueDate: { $lt: new Date() }, isDeleted: { $ne: true } });
    const statusBreakdown = await Task.aggregate([{ $match: { project: projectId, assignees: req.user.id, isDeleted: { $ne: true } } }, { $group: { _id: '$status', count: { $sum: 1 } } }]);

    res.json({
      success: true,
      data: {
        assignedTasks, watchingTasks, completedTasks, overdueTasks,
        statusBreakdown: statusBreakdown.reduce((acc, item) => { acc[item._id] = item.count; return acc; }, {})
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const remove = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { id } = req.params;
    const task = await Task.findById(id)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .session(session);
    if (!task) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_DELETE);
    if (!hasPermission) {
      await session.abortTransaction();
      return res.status(403).json({ success: false, message: 'You do not have permission to delete this task.' });
    }

    const project = await Project.findById(task.project).session(session);

    task.isDeleted = true;
    task.deletedAt = new Date();
    task.deletedBy = req.user.id;
    await task.save({ session });

    const attachments = await File.find({ task: task._id }).session(session);
    for (const file of attachments) {
      if (file.url) {
        const filePath = path.join(process.cwd(), 'uploads', path.basename(file.url));
        try { await fs.unlink(filePath); } catch (err) {}
      }
    }

    await File.updateMany({ task: task._id }, { deleted: true, deletedAt: new Date() }).session(session);

    if (task.assignees?.length) await recalcWorkloadForUsers(task.project, task.assignees.map(a => a._id || a));
    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);

    await Activity.create([{
      project: task.project,
      user: req.user.id,
      type: 'task_deleted',
      entity: 'Task',
      entityId: task._id,
      description: `Task "${task.title}" deleted`
    }], { session });

    await session.commitTransaction();

    // NOTIFICATION: watchers + assignees + owner (post-commit, non-blocking to response)
    if (project) {
      await notifyTaskParticipants(task, project, {
        type: 'task_deleted',
        title: 'Task Deleted',
        message: `Task "${task.title}" was deleted from "${project.name}".`,
        excludeUserId: req.user.id,
      });
    }

    res.json({ success: true, message: 'Task deleted successfully.' });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ success: false, error: error.message });
  } finally {
    session.endSession();
  }
};

export const addWatcher = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });
    if (!task.watchers.includes(userId)) {
      task.watchers.push(userId);
      await task.save();
    }
    await Activity.create({ project: task.project, user: req.user.id, type: 'watcher_added', entity: 'Task', entityId: task._id, description: `Watcher added to task "${task.title}"` });
    const updatedTask = await Task.findById(id).populate('watchers', 'name email avatar');

    // NOTIFICATION: notify the new watcher
    await sendNotification({
      userId,
      type: 'watcher_added',
      title: 'Added as Watcher',
      message: `You're now watching task "${task.title}".`,
      relatedTask: task._id,
      relatedProject: task.project,
    });

    res.json({ success: true, message: 'Watcher added successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const removeWatcher = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });
    task.watchers = task.watchers.filter((id) => id.toString() !== userId);
    await task.save();
    await Activity.create({ project: task.project, user: req.user.id, type: 'watcher_removed', entity: 'Task', entityId: task._id, description: `Watcher removed from task "${task.title}"` });
    const updatedTask = await Task.findById(id).populate('watchers', 'name email avatar');
    res.json({ success: true, message: 'Watcher removed successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const addWorkLog = async (req, res) => {
  try {
    const { projectId, taskId } = req.params;
    const { hours, date, description } = req.body;
    const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    const hasPermission = await checkTaskPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TIME_MANAGE);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to add work logs.' });

    const durationSeconds = Math.floor(hours * 3600);
    task.workLogs.push({ user: req.user.id, seconds: durationSeconds, date: date || new Date(), description, approved: false });
    task.actualHours = (task.actualHours || 0) + hours;
    await task.save();

    const project = await Project.findById(projectId);

    await sendNotification({
      userId: task.assignees?.[0]?._id || task.assignees?.[0] || req.user.id,
      type: 'work_log_approved',
      title: 'Work Log Added',
      message: `Work log added for task "${task.title}"`,
      relatedTask: task._id,
      relatedProject: task.project,
    });

    // NOTIFICATION: other participants
    if (project) {
      await notifyTaskParticipants(task, project, {
        type: 'work_log_added',
        title: 'Work Log Added',
        message: `${hours}h logged on task "${task.title}".`,
        excludeUserId: req.user.id,
      });
    }

    await Activity.create({
      project: projectId,
      user: req.user.id,
      type: 'work_log_added',
      entity: 'Task',
      entityId: taskId,
      newValue: { hours, description },
      description: `Work log added: ${hours} hours`
    });

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('workLogs.user', 'name email');
    res.json({ success: true, message: 'Work log added successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const addAttachment = async (req, res) => {
  try {
    const { id } = req.params;
    const { filename, originalName, url, size, mimeType } = req.body;
    const task = await Task.findById(id).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    const fileRecord = new File({ task: task._id, filename, originalName, url, size, mimeType, uploadedBy: req.user.id });
    await fileRecord.save();

    task.attachments.push(fileRecord._id);
    await task.save();

    const project = await Project.findById(task.project);

    await sendNotification({
      userId: task.assignees?.[0]?._id || task.assignees?.[0] || req.user.id,
      type: 'file_uploaded',
      title: 'File Uploaded',
      message: `File "${filename}" added to task "${task.title}"`,
      relatedTask: task._id,
      relatedProject: task.project,
    });

    if (project) {
      await notifyTaskParticipants(task, project, {
        type: 'attachment_added',
        title: 'Attachment Added',
        message: `"${filename}" was added to task "${task.title}".`,
        excludeUserId: req.user.id,
      });
    }

    await Activity.create({ project: task.project, user: req.user.id, type: 'attachment_added', entity: 'Task', entityId: task._id, description: `Attachment "${filename}" added to task` });

    const updatedTask = await Task.findById(id)
      .populate('assignees', 'name email avatar')
      .populate({ path: 'attachments', populate: { path: 'uploadedBy', select: 'name email' } });
    res.json({ success: true, message: 'Attachment added successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const removeAttachment = async (req, res) => {
  try {
    const { id, attachmentId } = req.params;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });
    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    task.attachments = task.attachments.filter((att) => att.toString() !== attachmentId);
    await task.save();

    const file = await File.findById(attachmentId);
    if (file && file.url) {
      const filePath = path.join(process.cwd(), 'uploads', path.basename(file.url));
      try { await fs.unlink(filePath); } catch (err) {}
    }

    await File.updateOne({ _id: attachmentId, deleted: false }, { deleted: true, deletedAt: new Date() });

    await Activity.create({ project: task.project, user: req.user.id, type: 'attachment_removed', entity: 'Task', entityId: task._id, description: `Attachment removed from task` });

    const updatedTask = await Task.findById(id)
      .populate('assignees', 'name email avatar')
      .populate({ path: 'attachments', populate: { path: 'uploadedBy', select: 'name email' } });
    res.json({ success: true, message: 'Attachment removed successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getGanttData = async (req, res) => {
  try {
    const { projectId } = req.params;
    const hasPermission = await checkTaskPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });
    const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).populate('assignees', 'name').select('title startDate dueDate status priority progress');
    const ganttData = tasks.map((task) => {
      let progress = 50;
      if (task.status === 'todo') progress = 0;
      else if (task.status === 'in-progress') progress = 50;
      else if (task.status === 'review') progress = 75;
      else if (task.status === 'completed') progress = 100;
      return { id: task._id, name: task.title, start: task.startDate, end: task.dueDate, progress, type: 'task', assignee: task.assignees[0]?.name };
    });
    res.json({ success: true, data: ganttData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const startTimer = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'Permission denied' });

    const activeTimer = task.workLogs.find(log => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (activeTimer) return res.status(400).json({ success: false, message: "No active timer can be started because another timer is already running." });

    task.workLogs.push({ user: req.user.id, hours: 0, date: new Date(), description: 'Timer started', isTimer: true });
    await task.save();

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('workLogs.user', 'name email');

    res.json({ success: true, data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const stopTimer = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'Permission denied' });

    const lastTimerLog = task.workLogs.find(log => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (!lastTimerLog) return res.status(400).json({ success: false, message: 'No active timer' });

    const durationSeconds = Math.floor((Date.now() - new Date(lastTimerLog.date).getTime()) / 1000);
    lastTimerLog.seconds = durationSeconds;
    lastTimerLog.stopped = true;
    lastTimerLog.description = `Timer stopped (${durationSeconds}s)`;

    task.timeSpent = task.workLogs.reduce((sum, log) => sum + (log.seconds || 0), 0);
    await task.save();

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('workLogs.user', 'name email');

    res.json({ success: true, data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const resumeTimer = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'Permission denied' });

    const activeTimer = task.workLogs.find(log => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (activeTimer) return res.status(400).json({ success: false, message: "No active timer can be started because another timer is already running." });

    task.workLogs.push({ user: req.user.id, seconds: 0, date: new Date(), description: 'Timer resumed', isTimer: true, stopped: false });
    await task.save();

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('workLogs.user', 'name email');

    res.json({ success: true, data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const finishTask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'Permission denied' });

    const activeTimer = task.workLogs.find(log => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (activeTimer) {
      activeTimer.seconds = Math.floor((Date.now() - new Date(activeTimer.date).getTime()) / 1000);
      activeTimer.stopped = true;
      activeTimer.description = `Timer stopped (${activeTimer.seconds}s)`;
    }

    task.checklist.forEach((c) => { c.completed = true; });
    task.status = 'completed';
    task.timeSpent = task.workLogs.reduce((sum, log) => sum + (log.seconds || 0), 0);
    task.updatedAt = new Date();
    await task.save();

    if (task.assignees?.length) await recalcWorkloadForUsers(task.project, task.assignees.map(a => a._id || a));
    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);

    const project = await Project.findById(task.project);

    await Activity.create({
      project: task.project,
      user: req.user.id,
      type: 'task_status_changed',
      entity: 'Task',
      entityId: task._id,
      previousValue: 'in-progress',
      newValue: 'completed',
      description: `Task "${task.title}" marked as completed`,
    });

    // NOTIFICATION
    if (project) {
      await notifyTaskParticipants(task, project, {
        type: 'task_status_changed',
        title: 'Task Completed',
        message: `Task "${task.title}" was marked completed.`,
        excludeUserId: req.user.id,
      });
    }

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar');

    res.json({ success: true, message: 'Task marked as completed', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getTimerStatus = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const activeTimer = task.workLogs.find(log => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    const lastLogTime = activeTimer ? new Date(activeTimer.date) : null;

    res.json({
      success: true,
      data: {
        isRunning: !!activeTimer,
        elapsedSeconds: activeTimer ? Math.floor((Date.now() - lastLogTime.getTime()) / 1000) : 0,
        timeSpent: task.timeSpent,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const addChecklistItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { item } = req.body;
    if (!item || !item.trim()) return res.status(400).json({ success: false, message: 'Checklist item text is required.' });

    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    task.checklist.push({ item: item.trim(), completed: false });
    await task.save();

    await Activity.create({ project: task.project, user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id, description: `Checklist item "${item.trim()}" added` });

    res.status(201).json({ success: true, message: 'Checklist item added.', data: task.checklist });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const toggleChecklistItem = async (req, res) => {
  try {
    const { id, itemId } = req.params;
    const { completed } = req.body;

    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    const checklistItem = task.checklist.id(itemId);
    if (!checklistItem) return res.status(404).json({ success: false, message: 'Checklist item not found.' });

    checklistItem.completed = typeof completed === 'boolean' ? completed : !checklistItem.completed;
    task.updatedAt = new Date();
    await task.save();

    await Activity.create({ project: task.project, user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id, description: `Checklist item "${checklistItem.item}" marked ${checklistItem.completed ? 'complete' : 'incomplete'}` });

    res.json({ success: true, message: 'Checklist item updated.', data: task.checklist });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const removeChecklistItem = async (req, res) => {
  try {
    const { id, itemId } = req.params;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    task.checklist = task.checklist.filter((c) => c._id.toString() !== itemId);
    await task.save();

    await Activity.create({ project: task.project, user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id, description: `Checklist item removed` });

    res.json({ success: true, message: 'Checklist item removed.', data: task.checklist });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getKanbanBoards = async (req, res) => {
  try {
    const { projectId } = req.params;
    const hasPermission = await checkTaskPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'Access denied.' });

    const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } })
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .populate('dependencies')
      .sort({ order: 1 });

    const columns = getKanbanColumns();

    const tasksWithOverdue = tasks.map(task => {
      const taskObj = task.toObject ? task.toObject() : task._doc || task;
      let isOverdue = false;
      if (taskObj.dueDate && taskObj.status !== 'completed') {
        const dueDate = new Date(taskObj.dueDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        isOverdue = dueDate < today;
      }

      const checklist = taskObj.checklist || [];
      const checklistTotal = checklist.length;
      const checklistCompleted = checklist.filter(i => i.completed).length;
      const checklistPct = checklistTotal > 0 ? Math.round((checklistCompleted / checklistTotal) * 100) : 0;

      return { ...taskObj, isOverdue, checklistTotal, checklistCompleted, checklistPct };
    });

    const data = {
      columns,
      tasks: groupTasksByStatus(tasksWithOverdue),
      unassigned: tasksWithOverdue.filter(t => !t.milestone),
    };

    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const moveTask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const { targetColumn, beforeTaskId } = req.body;

    const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const project = await Project.findById(task.project);
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const hasPermission = await checkTaskPermission(req.user.id, project._id, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to move tasks.' });

    const oldStatus = task.status;
    task.status = targetColumn;

    let newOrder = 0;
    if (beforeTaskId) {
      const before = await Task.findById(beforeTaskId);
      newOrder = before ? before.order - 0.5 : 0;
    } else {
      const last = await Task.findOne({ project: task.project, status: targetColumn }).sort({ order: -1 });
      newOrder = last ? last.order + 1 : 0;
    }

    task.order = newOrder;
    await task.save();

    await Task.updateMany(
      { project: task.project, status: targetColumn, _id: { $ne: task._id }, order: { $gte: newOrder } },
      { $inc: { order: 1 } }
    );

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: 'task_moved',
      entity: 'Task',
      entityId: task._id,
      description: `Task "${task.title}" moved from "${oldStatus}" to "${targetColumn}"`,
    });

    // NOTIFICATION
    await notifyTaskParticipants(task, project, {
      type: 'task_moved',
      title: 'Task Moved',
      message: `Task "${task.title}" moved from ${oldStatus} to ${targetColumn}.`,
      excludeUserId: req.user.id,
    });

    if (task.assignees?.length) await recalcWorkloadForUsers(project._id, task.assignees.map(a => a._id || a));
    if (task.milestone) await updateMilestoneProgress(project._id, task.milestone);

    res.json({ success: true, message: 'Task moved successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

const getKanbanColumns = (statuses = ['todo', 'in-progress', 'review', 'completed']) => {
  return statuses.map(status => ({
    _id: status,
    name: status === 'todo' ? 'To Do' : status === 'in-progress' ? 'In Progress' : status === 'review' ? 'In Review' : 'Done',
    status,
    color: status === 'todo' ? '#6B7280' : status === 'in-progress' ? '#3B82F6' : status === 'review' ? '#8B5CF6' : '#10B981'
  }));
};

const groupTasksByStatus = (tasks) => {
  const groups = { todo: [], 'in-progress': [], review: [], completed: [] };
  tasks.forEach(task => {
    const status = task.status || 'todo';
    if (groups[status]) groups[status].push(task);
  });
  return groups;
};