import mongoose from "mongoose";
import Project from '../models/Project.js';
import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import User from "../models/User.js";
import Budget from '../models/Budget.js';
import Workload from '../models/Workload.js';
import File from '../models/File.js';
import { generateProjectCode } from '../utils/projectCodeGenerator.js';
import { DEFAULT_ROLE_PERMISSIONS } from '../constants/projectPermissions.js';
import { notifyProjectTeam, sendNotification } from '../utils/sendNotification.js';
import { toUserId, toUserIds } from '../utils/userIdHelpers.js';

export const list = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 10, 1);

    const { search, status, projectType, priority, sortBy, order } = req.query;

    const query = {
      isDeleted: false,
      $or: [{ owner: req.user.id }, { "team.user": req.user.id }],
    };

    if (search) {
      query.$and = [{
        $or: [
          { name: { $regex: search, $options: "i" } },
          { projectCode: { $regex: search, $options: "i" } },
        ],
      }];
    }

    if (status) query.status = status;
    if (projectType) query.projectType = projectType;
    if (priority) query.priority = priority;

    const total = await Project.countDocuments(query);
    const projects = await Project.find(query)
      .populate("owner", "name email")
      .populate("team.user", "name email")
      .sort({ [sortBy || "createdAt"]: order === "asc" ? 1 : -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    return res.json({
      success: true,
      data: projects,
      pagination: {
        total, page, limit,
        totalPages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrevious: page > 1,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const get = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const isOwner = project.owner._id.toString() === req.user.id;
    const isMember = project.team.some((t) => t.user._id.toString() === req.user.id);

    if (!isOwner && !isMember) return res.status(403).json({ success: false, message: "Access denied." });

    return res.json({ success: true, data: project });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== CREATE ======================
export const create = async (req, res) => {
  try {
    const {
      name, description, projectType, status, priority, visibility, health,
      startDate, endDate, estimatedHours, budget, milestones: bodyMilestones = [],
    } = req.body;

    const projectCode = await generateProjectCode(projectType);
    const estimatedBudget = Number(budget?.estimated || 0);
    const approvedBudget = Number(budget?.approved || estimatedBudget);
    const allMilestones = [...bodyMilestones];

    const project = new Project({
      projectCode,
      name,
      description,
      projectType: projectType || "internal",
      status: status || "planning",
      priority: priority || "medium",
      visibility: visibility || "private",
      health: health || "healthy",
      owner: req.user.id,
      startDate,
      endDate,
      estimatedHours: estimatedHours || 0,
      loggedHours: 0,
      budget: {
        estimated: estimatedBudget,
        approved: approvedBudget,
        spent: 0,
        remaining: approvedBudget,
      },
      progress: 0,
      lastActivityAt: new Date(),
      team: [{
        user: req.user.id,
        role: "owner",
        permissions: DEFAULT_ROLE_PERMISSIONS.owner,
        invitedBy: req.user.id,
      }],
      milestones: allMilestones,
    });

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "project_created",
      entity: "Project",
      entityId: project._id,
      description: `Project "${project.name}" created`,
    });

    const createdProject = await Project.findById(project._id)
      .populate("owner", "name email")
      .populate("team.user", "name email");
      
      await sendNotification({
  userId: req.user.id,
  type: 'project_created',
  title: '🎉 Project Created',
  message: `Congratulations! You created "${createdProject.name}". Project code: ${createdProject.projectCode}.`,
  relatedProject: createdProject._id,
});

    // NOTIFICATION: project created — notify team (currently just the owner, but future-proof)
    await notifyProjectTeam(createdProject, {
      type: 'project_created',
      title: 'Project Created',
      message: `Project "${createdProject.name}" was created.`,
      excludeUserId: req.user.id,
    });

    return res.status(201).json({
      success: true,
      message: "Project created successfully.",
      data: createdProject,
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== UPDATE ======================
export const update = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id);
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const isOwner = project.owner.toString() === req.user.id;
    const teamMember = project.team.find((t) => t.user.toString() === req.user.id);
    const canEdit = isOwner || (teamMember && teamMember.permissions.includes("project.edit"));
    if (!canEdit) return res.status(403).json({ success: false, message: "No permission." });

    const {
      name, description, projectType, status, priority, health, visibility,
      startDate, endDate, estimatedHours, budget, milestones: bodyMilestones = [],
    } = req.body;

    if (name !== undefined) project.name = name;
    if (description !== undefined) project.description = description;
    if (projectType !== undefined) project.projectType = projectType;
    if (priority !== undefined) project.priority = priority;
    if (health !== undefined) project.health = health;
    if (visibility !== undefined) project.visibility = visibility;
    if (startDate !== undefined) project.startDate = startDate;
    if (endDate !== undefined) project.endDate = endDate;
    if (estimatedHours !== undefined) project.estimatedHours = estimatedHours;

    if (status !== undefined) {
      project.status = status;
      if (status === "completed") {
        project.completedAt = new Date();
        project.progress = 100;
      } else {
        project.completedAt = null;
      }
    }

    if (budget) {
      if (budget.estimated !== undefined) project.budget.estimated = budget.estimated;
      if (budget.approved !== undefined) project.budget.approved = budget.approved;
      if (budget.spent !== undefined) project.budget.spent = budget.spent;
      project.budget.remaining = project.budget.approved - project.budget.spent;
    }

    const defaultMilestone = project.milestones.find((m) => m.name === "Project Milestone");
    if (defaultMilestone) {
      if (startDate !== undefined) defaultMilestone.startDate = startDate;
      if (endDate !== undefined) defaultMilestone.dueDate = endDate;
      if (priority !== undefined) defaultMilestone.priority = priority;
    }

    let newMilestonesAdded = [];
    if (bodyMilestones.length > 0) {
      const milestoneMap = new Map();
      project.milestones.forEach((m) => milestoneMap.set(m._id?.toString(), m));

      bodyMilestones.forEach((bodyMilestone) => {
        if (bodyMilestone._id) {
          const existing = milestoneMap.get(bodyMilestone._id.toString());
          if (existing) Object.assign(existing, bodyMilestone);
        } else {
          const newOrder = project.milestones.length + 1;
          const pushed = { ...bodyMilestone, order: newOrder };
          project.milestones.push(pushed);
          newMilestonesAdded.push(pushed);
        }
      });
    }

    project.lastActivityAt = new Date();
    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "project_updated",
      entity: "Project",
      entityId: project._id,
      description: `Updated project "${project.name}"`,
    });

    const updated = await Project.findById(project._id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    // NOTIFICATION: project updated
    await notifyProjectTeam(updated, {
      type: 'project_updated',
      title: 'Project Updated',
      message: `Project "${updated.name}" was updated by ${req.user.name || req.user.email || 'a team member'}.`,
      excludeUserId: req.user.id,
    });

    // NOTIFICATION: new milestones created
    if (newMilestonesAdded.length > 0) {
      for (const m of newMilestonesAdded) {
        await notifyProjectTeam(updated, {
          type: 'milestone_created',
          title: 'New Milestone',
          message: `Milestone "${m.name}" was added to "${updated.name}".`,
          excludeUserId: req.user.id,
        });
      }
    }

    return res.json({
      success: true,
      message: "Project updated successfully.",
      data: updated,
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const getStats = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findOne({ _id: id, isDeleted: { $ne: true } });
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const isOwner = project.owner.toString() === req.user.id;
    const isMember = project.team.some((m) => m.user.toString() === req.user.id);
    if (!isOwner && !isMember) return res.status(403).json({ success: false, message: "Access denied." });

    const totalTasks = await Task.countDocuments({ project: id, isDeleted: { $ne: true } });
    const completedTasks = await Task.countDocuments({ project: id, isDeleted: { $ne: true }, status: "completed" });
    const overdueTasks = await Task.countDocuments({
      project: id,
      isDeleted: { $ne: true },
      status: { $ne: "completed" },
      dueDate: { $lt: new Date() },
    });

    const budget = await Budget.findOne({ project: id });
    const workload = await Workload.find({ project: id });
    const overloadedMembers = workload.filter((m) => m.overloaded).length;

    // progress is the STORED field — recalculated on task/checklist actions,
    // never recomputed here from live counts.
    res.json({
      success: true,
      data: {
        projectCode: project.projectCode,
        projectName: project.name,
        status: project.status,
        priority: project.priority,
        health: project.health,
        progress: project.progress,
        totalTasks,
        completedTasks,
        pendingTasks: totalTasks - completedTasks,
        overdueTasks,
        teamMembers: project.team.length,
        estimatedHours: project.estimatedHours,
        loggedHours: project.loggedHours,
        budget: budget || project.budget,
        overloadedMembers,
        milestones: project.milestones,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};


export const addTeamMember = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { userId, role = "member", permissions } = req.body;

    console.log("\n========== ADD TEAM MEMBER ==========");
    console.log("Project ID:", projectId);
    console.log("User ID:", userId);
    console.log("Role:", role);
    console.log("Permissions:", permissions);
    console.log("Current User:", req.user.id);

    console.log("ProjectId Valid:", mongoose.Types.ObjectId.isValid(projectId));
    console.log("UserId Valid:", mongoose.Types.ObjectId.isValid(userId));

    if (!mongoose.Types.ObjectId.isValid(projectId)) {
      console.log("❌ Invalid Project ID");
      return res.status(400).json({
        success: false,
        message: "Invalid project id.",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      console.log("❌ Invalid User ID");
      return res.status(400).json({
        success: false,
        message: "Invalid user id.",
      });
    }

    const project = await Project.findById(projectId);

    if (!project) {
      console.log("❌ Project not found");
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    console.log("✅ Project Found:", project.name);

    const user = await User.findById(userId);

    if (!user) {
      console.log("❌ User not found");
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    console.log("✅ User Found:", user.name);

    const isOwner = project.owner.toString() === req.user.id;

    const currentMember = project.team.find(
      (t) => t.user.toString() === req.user.id
    );

    const canInvite =
      isOwner ||
      (currentMember &&
        currentMember.permissions.includes("team.invite"));

    console.log("isOwner:", isOwner);
    console.log("Current Member:", currentMember);
    console.log("canInvite:", canInvite);

    if (!canInvite) {
      console.log("❌ Failed: No permission");
      return res.status(403).json({
        success: false,
        message: "No permission to add members.",
      });
    }

    if (role === "manager" && !isOwner) {
      console.log("❌ Failed: Only owner can assign manager");
      return res.status(403).json({
        success: false,
        message: "Only owner can assign manager role.",
      });
    }

    if (project.owner.toString() === userId) {
      console.log("❌ Failed: User is project owner");
      return res.status(400).json({
        success: false,
        message: "Owner is already part of this project.",
      });
    }

    const alreadyExists = project.team.some(
      (t) => t.user.toString() === userId
    );

    console.log("Already Exists:", alreadyExists);

    if (alreadyExists) {
      console.log("❌ Failed: User already exists in team");
      return res.status(400).json({
        success: false,
        message: "User already in team.",
      });
    }

    const memberPermissions =
      permissions?.length
        ? permissions
        : DEFAULT_ROLE_PERMISSIONS[role] || [];

    console.log("Final Permissions:", memberPermissions);

    project.team.push({
      user: userId,
      role,
      permissions: memberPermissions,
      invitedBy: req.user.id,
    });

    project.lastActivityAt = new Date();

    console.log("Saving project...");
    await project.save();
    console.log("✅ Project saved");

    console.log("Creating activity...");
    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "member_added",
      entity: "User",
      entityId: userId,
      description: `${user.name} added as ${role}`,
    });
    console.log("✅ Activity created");

    console.log("Loading updated project...");
    const updated = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    console.log("✅ Updated project loaded");

    console.log("Sending invitation notification...");
    await sendNotification({
      userId,
      type: "project_invitation",
      title: "Added to Project",
      message: `You were added to project "${updated.name}" as ${role}.`,
      relatedProject: updated._id,
    });
    console.log("✅ Invitation notification sent");

    console.log("Sending team notification...");
    await notifyProjectTeam(updated, {
      type: "member_added",
      title: "New Team Member",
      message: `${user.name} joined "${updated.name}" as ${role}.`,
      excludeUserId: req.user.id,
    });
    console.log("✅ Team notification sent");

    console.log("========== SUCCESS ==========\n");

    return res.status(200).json({
      success: true,
      message: "Team member added successfully.",
      data: updated,
    });
  } catch (error) {
    console.error("\n========== ERROR ==========");
    console.error(error);
    console.error("Message:", error.message);
    console.error("Stack:", error.stack);
    console.error("===========================\n");

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const removeTeamMember = async (req, res) => {
  try {
    const { projectId, userId } = req.params;
    const project = await Project.findById(projectId);
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const isOwner = project.owner.toString() === req.user.id;
    const currentMember = project.team.find((t) => t.user.toString() === req.user.id);
    const canRemove = isOwner || (currentMember && currentMember.permissions.includes("team.remove"));

    if (!canRemove) return res.status(403).json({ success: false, message: "No permission to remove members." });

    const member = project.team.find((t) => t.user.toString() === userId);
    if (!member) return res.status(404).json({ success: false, message: "Member not found." });
    if (member.role === "owner") return res.status(400).json({ success: false, message: "Cannot remove owner." });
    if (member.role === "manager" && !isOwner) return res.status(403).json({ success: false, message: "Only owner can remove manager." });

    project.team = project.team.filter((t) => t.user.toString() !== userId);
    project.lastActivityAt = new Date();
    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "member_removed",
      entity: "User",
      entityId: userId,
      description: "Team member removed from project",
    });

    const updated = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    // NOTIFICATION: notify the removed user
    await sendNotification({
      userId,
      type: 'member_removed',
      title: 'Removed from Project',
      message: `You were removed from project "${updated.name}".`,
      relatedProject: updated._id,
    });

    // NOTIFICATION: notify remaining team
    await notifyProjectTeam(updated, {
      type: 'member_removed',
      title: 'Team Member Removed',
      message: `A member was removed from "${updated.name}".`,
      excludeUserId: req.user.id,
    });

    return res.json({ success: true, message: "Team member removed successfully.", data: updated });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const updateTeamMember = async (req, res) => {
  try {
    const { projectId, userId } = req.params;
    const { role, permissions } = req.body;

    const project = await Project.findById(projectId);
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const isOwner = project.owner.toString() === req.user.id;
    const currentMember = project.team.find((t) => t.user.toString() === req.user.id);
    const canEdit = isOwner || (currentMember && currentMember.permissions.includes("team.edit"));
    if (!canEdit) return res.status(403).json({ success: false, message: "No permission." });

    const member = project.team.find((t) => t.user.toString() === userId);
    if (!member) return res.status(404).json({ success: false, message: "Member not found." });
    if (member.role === "owner") return res.status(400).json({ success: false, message: "Cannot edit owner." });
    if (!isOwner && member.role === "manager") return res.status(403).json({ success: false, message: "Only owner can edit manager." });
    if (role === "manager" && !isOwner) return res.status(403).json({ success: false, message: "Only owner can assign manager role." });

    const oldRole = member.role;
    const oldPermissions = [...member.permissions];

    if (role) member.role = role;
    if (permissions) member.permissions = permissions;
    else if (role) member.permissions = DEFAULT_ROLE_PERMISSIONS[role];

    const roleChanged = oldRole !== member.role;
    const permissionsChanged = JSON.stringify([...oldPermissions].sort()) !== JSON.stringify([...member.permissions].sort());

    let activityType = "member_updated";
    let description = "Team member updated";

    if (roleChanged && permissionsChanged) {
      activityType = "member_role_changed";
      description = `${req.user.email} changed role from "${oldRole}" to "${member.role}" and updated permissions`;
    } else if (roleChanged) {
      activityType = "member_role_changed";
      description = `${req.user.email} changed role from "${oldRole}" to "${member.role}"`;
    } else if (permissionsChanged) {
      activityType = "member_updated";
      description = `${req.user.email} updated ${member.role} permissions`;
    }

    project.lastActivityAt = new Date();
    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: activityType,
      entity: "User",
      entityId: userId,
      previousValue: { role: oldRole, permissions: oldPermissions },
      newValue: { role: member.role, permissions: member.permissions },
      description,
    });

    const updated = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    // NOTIFICATION: notify the affected member directly
    if (roleChanged || permissionsChanged) {
      await sendNotification({
        userId,
        type: activityType,
        title: 'Your Role Was Updated',
        message: roleChanged
          ? `Your role in "${updated.name}" changed from ${oldRole} to ${member.role}.`
          : `Your permissions in "${updated.name}" were updated.`,
        relatedProject: updated._id,
      });
    }

    return res.json({
      success: true,
      message: "Team member updated successfully.",
      data: updated,
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const remove = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findById(id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });
    if (project.owner._id.toString() !== req.user.id) return res.status(403).json({ success: false, message: 'Only owner can delete.' });

    // NOTIFICATION: notify team BEFORE soft-deleting, while population is still valid
    await notifyProjectTeam(project, {
      type: 'project_deleted',
      title: 'Project Deleted',
      message: `Project "${project.name}" was deleted.`,
      excludeUserId: req.user.id,
    });

    project.isDeleted = true;
    project.deletedAt = new Date();
    project.deletedBy = req.user.id;
    await project.save();

    await Task.updateMany({ project: id, isDeleted: false }, {
      isDeleted: true,
      deletedAt: new Date(),
      deletedBy: req.user.id
    });

    await File.updateMany({ project: id, deleted: false }, {
      deleted: true,
      deletedAt: new Date()
    });

    await Activity.create({
      project: id,
      user: req.user.id,
      type: 'project_deleted',
      entity: 'Project',
      entityId: id,
      description: `Project "${project.name}" deleted`,
    });

    res.json({ success: true, message: 'Project deleted successfully (soft delete).' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const removeMilestone = async (req, res) => {
  try {
    const { projectId, milestoneId } = req.params;
    const project = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const isOwner = project.owner._id.toString() === req.user.id;
    const teamMember = project.team.find(t => t.user._id.toString() === req.user.id);
    if (!isOwner && !teamMember) return res.status(403).json({ success: false, message: 'No permission.' });

    const milestone = project.milestones.find(m => m._id.toString() === milestoneId);
    if (!milestone) return res.status(404).json({ success: false, message: 'Milestone not found.' });

    await Task.updateMany(
      { project: projectId, milestone: milestoneId, isDeleted: false },
      { $unset: { milestone: 1 } }
    );

    project.milestones = project.milestones.filter(m => m._id.toString() !== milestoneId);
    await project.save();

    await Activity.create({
      project: projectId,
      user: req.user.id,
      type: 'milestone_removed',
      entity: 'Milestone',
      entityId: milestoneId,
      description: `Milestone "${milestone.name}" permanently removed from project`,
    });

    // NOTIFICATION: notify team
    await notifyProjectTeam(project, {
      type: 'milestone_removed',
      title: 'Milestone Removed',
      message: `Milestone "${milestone.name}" was removed from "${project.name}".`,
      excludeUserId: req.user.id,
    });

    res.json({ success: true, message: 'Milestone permanently removed.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const allowedStatus = ["planning", "active", "on_hold", "completed", "cancelled"];

    if (!allowedStatus.includes(status)) return res.status(400).json({ success: false, message: "Invalid status." });

    const project = await Project.findById(id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const isOwner = project.owner._id.toString() === req.user.id;
    const teamMember = project.team.find((t) => t.user._id.toString() === req.user.id);
    const canEdit = isOwner || (teamMember && teamMember.permissions.includes("project.edit"));

    if (!canEdit) return res.status(403).json({ success: false, message: "No permission." });

    const previousStatus = project.status;
    project.status = status;

    if (status === "completed") {
      project.completedAt = new Date();
      project.progress = 100;
    } else {
      project.completedAt = null;
    }

    project.lastActivityAt = new Date();
    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: 'project_status_changed',
      entity: 'Project',
      entityId: project._id,
      description: `Status changed from "${previousStatus}" to "${status}"`,
    });

    // NOTIFICATION: notify team of status change
    await notifyProjectTeam(project, {
      type: 'project_status_changed',
      title: 'Project Status Changed',
      message: `"${project.name}" status changed from ${previousStatus} to ${status}.`,
      excludeUserId: req.user.id,
    });

    res.json({
      success: true,
      message: "Project status updated successfully.",
      data: { projectId: project._id, status: project.status, completedAt: project.completedAt },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};