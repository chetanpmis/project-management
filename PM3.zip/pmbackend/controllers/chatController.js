import Message from '../models/Message.js';
import Project from '../models/Project.js';
import { emitToProject } from '../utils/socket.js';
import { sendBulkNotification } from '../utils/sendNotification.js';
import { toUserIds } from '../utils/userIdHelpers.js';

const checkProjectMembership = async (userId, projectId) => {
  const project = await Project.findById(projectId);
  if (!project) return null;
  const isOwner = project.owner.toString() === userId;
  const isMember = project.team.some((t) => t.user.toString() === userId);
  if (!isOwner && !isMember) return null;
  return project;
};

const populateMessage = (query) =>
  query
    .populate('author', 'name email avatar')
    .populate('mentions', 'name email avatar')
    .populate('reactions.users', 'name')
    .populate('readBy.user', 'name')
    .populate({ path: 'replyTo', select: 'content author isDeleted', populate: { path: 'author', select: 'name' } });

// ====================== LIST ======================
// Soft-deleted messages are still returned (isDeleted: true, content stripped)
// so the UI can render "This message was deleted" in place, instead of the
// message vanishing from history entirely.
export const list = async (req, res) => {
  try {
    const { projectId } = req.params;
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 30, 1);

    const project = await checkProjectMembership(req.user.id, projectId);
    if (!project) return res.status(403).json({ success: false, message: 'Access denied.' });

    const query = { project: projectId };
    const total = await Message.countDocuments(query);

    const messages = await populateMessage(
      Message.find(query).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit)
    );

    const shaped = messages.reverse().map((m) => {
      const obj = m.toObject();
      if (obj.isDeleted) {
        obj.content = null;
        obj.mentions = [];
        obj.reactions = [];
      }
      return obj;
    });

    return res.json({
      success: true,
      data: shaped,
      pagination: { total, page, limit, totalPages: Math.ceil(total / limit), hasMore: page * limit < total },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== SEND ======================
export const create = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { content, mentions = [], replyTo = null } = req.body;

    if (!content?.trim()) return res.status(400).json({ success: false, message: 'Message content is required.' });

    const project = await checkProjectMembership(req.user.id, projectId);
    if (!project) return res.status(403).json({ success: false, message: 'Access denied.' });

    const validTeamIds = new Set([project.owner.toString(), ...project.team.map((t) => t.user.toString())]);
    const validMentions = toUserIds(mentions).filter((id) => validTeamIds.has(id));

    const message = await Message.create({
      project: projectId,
      author: req.user.id,
      content: content.trim(),
      mentions: validMentions,
      replyTo: replyTo || null,
      readBy: [{ user: req.user.id, readAt: new Date() }],
    });

    const populated = await populateMessage(Message.findById(message._id));

    emitToProject(projectId, 'chat:message', populated);

    if (validMentions.length > 0) {
      await sendBulkNotification(validMentions, {
        type: 'task_mentioned',
        title: `Mentioned by ${req.user.name || req.user.email || 'a teammate'}`,
        message: content.length > 140 ? `${content.slice(0, 140)}…` : content,
        relatedProject: projectId,
        excludeUserId: req.user.id,
      });
    }

    return res.status(201).json({ success: true, message: 'Message sent.', data: populated });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== EDIT ======================
export const update = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { content, mentions } = req.body;

    const message = await Message.findById(messageId);
    if (!message || message.isDeleted) return res.status(404).json({ success: false, message: 'Message not found.' });
    if (message.author.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'You can only edit your own messages.' });
    }

    if (content !== undefined) message.content = content.trim();
    if (mentions !== undefined) message.mentions = toUserIds(mentions);
    message.edited = true;
    message.editedAt = new Date();
    await message.save();

    const populated = await populateMessage(Message.findById(message._id));
    emitToProject(message.project.toString(), 'chat:message:updated', populated);

    return res.json({ success: true, message: 'Message updated.', data: populated });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== SOFT DELETE ======================
// Instead of removing the row (and instead of the frontend deleting it from
// the list), we flip isDeleted and re-broadcast the SAME message object so
// every client swaps its bubble to the "This message was deleted" placeholder.
export const remove = async (req, res) => {
  try {
    const { messageId } = req.params;
    const message = await Message.findById(messageId);
    if (!message || message.isDeleted) return res.status(404).json({ success: false, message: 'Message not found.' });

    const project = await Project.findById(message.project);
    const isAuthor = message.author.toString() === req.user.id;
    const isOwner = project?.owner.toString() === req.user.id;
    const teamMember = project?.team.find((t) => t.user.toString() === req.user.id);
    const isManager = teamMember?.role === 'manager';

    if (!isAuthor && !isOwner && !isManager) {
      return res.status(403).json({ success: false, message: 'You do not have permission to delete this message.' });
    }

    message.isDeleted = true;
    message.deletedAt = new Date();
    message.content = '';
    message.reactions = [];
    await message.save();

    const populated = await populateMessage(Message.findById(message._id));
    emitToProject(message.project.toString(), 'chat:message:updated', populated);

    return res.json({ success: true, message: 'Message deleted.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== REACT (toggle emoji) ======================
export const react = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { emoji } = req.body;
    if (!emoji) return res.status(400).json({ success: false, message: 'Emoji is required.' });

    const message = await Message.findById(messageId);
    if (!message || message.isDeleted) return res.status(404).json({ success: false, message: 'Message not found.' });

    let group = message.reactions.find((r) => r.emoji === emoji);
    if (!group) {
      group = { emoji, users: [req.user.id] };
      message.reactions.push(group);
    } else {
      const idx = group.users.findIndex((u) => u.toString() === req.user.id);
      if (idx >= 0) group.users.splice(idx, 1); // toggle off
      else group.users.push(req.user.id); // toggle on
    }

    // Drop empty reaction groups
    message.reactions = message.reactions.filter((r) => r.users.length > 0);
    await message.save();

    const populated = await populateMessage(Message.findById(message._id));
    emitToProject(message.project.toString(), 'chat:message:updated', populated);

    return res.json({ success: true, data: populated });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== MARK READ ======================
export const markRead = async (req, res) => {
  try {
    const { projectId } = req.params;
    const project = await checkProjectMembership(req.user.id, projectId);
    if (!project) return res.status(403).json({ success: false, message: 'Access denied.' });

    const unread = await Message.find({
      project: projectId,
      isDeleted: { $ne: true },
      'readBy.user': { $ne: req.user.id },
    });

    if (unread.length > 0) {
      await Message.updateMany(
        { _id: { $in: unread.map((m) => m._id) } },
        { $push: { readBy: { user: req.user.id, readAt: new Date() } } }
      );
      // Let other tabs viewing this project update read-receipt avatars live
      emitToProject(projectId, 'chat:read', { userId: req.user.id, messageIds: unread.map((m) => m._id) });
    }

    return res.json({ success: true, message: 'Chat marked as read.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== UNREAD COUNT ======================
export const getUnreadCount = async (req, res) => {
  try {
    const { projectId } = req.params;
    const project = await checkProjectMembership(req.user.id, projectId);
    if (!project) return res.status(403).json({ success: false, message: 'Access denied.' });

    const unreadCount = await Message.countDocuments({
      project: projectId,
      isDeleted: { $ne: true },
      author: { $ne: req.user.id },
      'readBy.user': { $ne: req.user.id },
    });

    return res.json({ success: true, data: { unreadCount } });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};