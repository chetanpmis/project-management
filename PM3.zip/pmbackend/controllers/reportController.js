import Project from "../models/Project.js";
import Task from "../models/Task.js";
import * as reportService from "../services/reportService.js";



const isOverdue = (task) => {
  if (!task.dueDate || task.status === "completed") return false;
  return new Date(task.dueDate).getTime() < Date.now();
};

const deriveMilestoneStatus = (tasks) => {
  if (!tasks.length) return "pending";
  if (tasks.every((t) => t.status === "completed")) return "completed";
  const started = tasks.some((t) => t.status !== "todo" || (t.progress ?? 0) > 0);
  return started ? "in-progress" : "pending";
};

// average of task progress — this is the ONLY source of truth for milestone progress
const computeMilestoneProgress = (tasks) => {
  if (!tasks.length) return 0;
  const total = tasks.reduce((sum, t) => sum + (t.progress ?? 0), 0);
  return Math.round(total / tasks.length);
};

export const getProjectGantt = async (req, res) => {
  try {
    const { projectId } = req.params;
    const userId = req.user.id;

    const project = await Project.findOne({
      _id: projectId,
      isDeleted: false,
    }).lean();

    if (!project) {
      return res.status(404).json({ success: false, message: "Project not found" });
    }

    const tasks = await Task.find({ project: projectId })
      .select(
        "_id title status priority progress startDate dueDate assignees watchers milestone dependencies"
      )
      .populate("assignees", "name avatar")
      .populate("watchers", "name avatar")
      .lean();

    const taskMap = new Map(tasks.map((t) => [t._id.toString(), t]));

    const ganttTasks = tasks.map((task) => {
      const assignees = task.assignees || [];
      const watchers = task.watchers || [];
      const isAssignedToMe = assignees.some((u) => u?._id?.toString() === userId.toString());
      const isWatcher = watchers.some((u) => u?._id?.toString() === userId.toString());
      const overdue = isOverdue(task);

      return {
        _id: task._id.toString(),
        title: task.title,
        startDate: task.startDate,
        dueDate: task.dueDate,
        status: overdue ? "overdue" : task.status, // computed, not stored
        priority: task.priority,
        progress: task.progress ?? 0,
        milestone: task.milestone ? task.milestone.toString() : null,
        assignees,
        watchers,
        isAssignedToMe,
        isWatcher,
        // gantt-task-react draws dependency arrows natively from this list
        dependencies: (task.dependencies || [])
          .map((d) => d.toString())
          .filter((id) => taskMap.has(id)), // drop refs to deleted tasks
      };
    });

    // group tasks by milestone id (task.milestone is the source of truth)
    const tasksByMilestone = new Map();
    const unassignedTasks = [];
    ganttTasks.forEach((t) => {
      if (!t.milestone) {
        unassignedTasks.push(t);
        return;
      }
      if (!tasksByMilestone.has(t.milestone)) tasksByMilestone.set(t.milestone, []);
      tasksByMilestone.get(t.milestone).push(t);
    });

    const milestones = (project.milestones || []).map((m) => {
      const mTasks = (tasksByMilestone.get(m._id.toString()) || []).sort(
        (a, b) => new Date(a.startDate || 0) - new Date(b.startDate || 0)
      );

      const derivedStart =
        m.startDate ||
        mTasks.reduce(
          (min, t) =>
            t.startDate && (!min || new Date(t.startDate) < min) ? new Date(t.startDate) : min,
          null
        );

      return {
        _id: m._id,
        name: m.name,
        description: m.description,
        startDate: derivedStart,
        dueDate: m.dueDate,
        priority: m.priority,
        status: deriveMilestoneStatus(mTasks),   // computed
        progress: computeMilestoneProgress(mTasks), // computed — never m.progress
        taskCount: mTasks.length,
        tasks: mTasks,
      };
    });

    const dependencies = [];
    ganttTasks.forEach((t) => {
      t.dependencies.forEach((depId) => {
        const dep = taskMap.get(depId);
        dependencies.push({
          from: depId,
          to: t._id,
          crossMilestone: !!(
            (dep?.milestone?.toString() || null) !== t.milestone &&
            (dep?.milestone || t.milestone)
          ),
        });
      });
    });

    return res.json({
      success: true,
      data: {
        project: {
          _id: project._id,
          name: project.name,
          startDate: project.startDate,
          endDate: project.endDate,
          progress: project.progress,
        },
        milestones,
        unassignedTasks,
        dependencies,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Failed to load gantt data" });
  }
};


export const getProjectReportsDashboard = async (req, res) => {
  try {
    const { projectId } = req.params;

    const [
      overview,
      taskStatus,
      milestones,
      teamPerformance,
      estimatedVsActual,
      overdue,
      completionTrend,
    ] = await Promise.all([
      reportService.getProjectOverview(projectId),
      reportService.getProjectTaskStatus(projectId),
      reportService.getProjectMilestones(projectId),
      reportService.getProjectTeamPerformance(projectId),
      reportService.getProjectEstimatedVsActual(projectId),
      reportService.getProjectOverdueTasks(projectId),
      reportService.getProjectCompletionTrend(projectId),
    ]);

    return res.json({
      success: true,
      data: {
        overview,
        taskStatus,
        milestones,
        teamPerformance,
        estimatedVsActual,
        overdue,
        completionTrend,
      },
    });
  } catch (error) {
    console.error("Dashboard Report Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to generate dashboard report.",
    });
  }
};





export const getProjectOverview = async (req, res) => {
  try {
    const { projectId } = req.params;

    const report = await reportService.getProjectOverview(projectId);

    return res.status(200).json({
      success: true,
      data: report,
    });
  } catch (error) {
    console.error("Project Overview Report Error:", error);

    if (error.message === "Project not found") {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to generate project overview report.",
    });
  }
};

/**
 * GET /reports/projects/:projectId/task-status
 */
export const getProjectTaskStatus = async (req, res) => {
  try {
    const { projectId } = req.params;

    const report =
      await reportService.getProjectTaskStatus(projectId);

    return res.status(200).json({
      success: true,
      data: report,
    });
  } catch (error) {
    console.error("Task Status Report Error:", error);

    if (error.message === "Project not found") {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to generate task status report.",
    });
  }
};


/**
 * GET /reports/projects/:projectId/milestones
 */
export const getProjectMilestones = async (req, res) => {
  try {
    const { projectId } = req.params;

    const report =
      await reportService.getProjectMilestones(projectId);

    return res.status(200).json({
      success: true,
      data: report,
    });
  } catch (error) {
    console.error("Milestone Report Error:", error);

    if (error.message === "Project not found") {
      return res.status(404).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Failed to generate milestone report.",
    });
  }
};


export const getProjectTeamPerformance = async (
  req,
  res
) => {
  try {
    const report =
      await reportService.getProjectTeamPerformance(
        req.params.projectId
      );

    return res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message:
        "Failed to generate team performance report.",
    });
  }
};


/**
 * GET /reports/projects/:projectId/estimated-vs-actual
 */
export const getProjectEstimatedVsActual = async (
  req,
  res
) => {
  try {
    const report =
      await reportService.getProjectEstimatedVsActual(
        req.params.projectId
      );

    return res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message:
        "Failed to generate estimated vs actual report.",
    });
  }
};


/**
 * GET /reports/projects/:projectId/overdue
 */
export const getProjectOverdueTasks = async (req, res) => {
  try {
    const report =
      await reportService.getProjectOverdueTasks(
        req.params.projectId
      );

    return res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    console.error("Overdue Report Error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to generate overdue tasks report.",
    });
  }
};

/**
 * GET /reports/projects/:projectId/completion-trend
 */
export const getProjectCompletionTrend = async (
  req,
  res
) => {
  try {
    const report =
      await reportService.getProjectCompletionTrend(
        req.params.projectId,
        req.query.period
      );

    return res.json({
      success: true,
      data: report,
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      success: false,
      message:
        "Failed to generate completion trend report.",
    });
  }
};

