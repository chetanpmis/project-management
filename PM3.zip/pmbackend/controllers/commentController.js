import Comment from '../models/Comment.js';
import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';
import Project from '../models/Project.js';

const checkTaskPermission = async (userId, projectId, permission) => {
  const project = await Project.findById(projectId);
  if (!project) return false;
  if (project.owner.toString() === userId) return true;
  const teamMember = project.team.find((member) => member.user.toString() === userId);
  return teamMember && teamMember.permissions.includes(permission);
};

// ====================== LIST COMMENTS FOR TASK ======================
export const listByTask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to view this task.' });

    const comments = await Comment.find({ task: taskId })
      .populate('author', 'name email avatar')
      .populate('mentions', 'name email')
      .populate('replies.author', 'name email avatar')
      .sort({ createdAt: 1 });

    res.json({ success: true, data: comments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// ====================== CREATE COMMENT ======================
export const create = async (req, res) => {
  try {
    const { taskId } = req.params;
    const { content, mentions = [], attachments = [] } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ success: false, message: 'Comment content is required.' });
    }

    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const hasPermission = await checkTaskPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!hasPermission) return res.status(403).json({ success: false, message: 'You do not have permission to comment on this task.' });

    const comment = await Comment.create({
      task: taskId,
      author: req.user.id,
      content: content.trim(),
      mentions,
      attachments,
    });

    task.comments.push(comment._id);
    await task.save();

    await Activity.create({
      project: task.project,
      user: req.user.id,
      type: 'comment_added',
      entity: 'Task',
      entityId: task._id,
      description: `Comment added on task "${task.title}"`,
    });

    const populated = await Comment.findById(comment._id)
      .populate('author', 'name email avatar')
      .populate('mentions', 'name email');

    res.status(201).json({ success: true, message: 'Comment added successfully.', data: populated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// ====================== UPDATE COMMENT ======================
export const update = async (req, res) => {
  try {
    const { commentId } = req.params;
    const { content } = req.body;

    const comment = await Comment.findById(commentId);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });

    if (comment.author.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'You can only edit your own comments.' });
    }

    comment.content = content;
    comment.edited = true;
    comment.editedAt = new Date();
    comment.updatedAt = new Date();
    await comment.save();

    const populated = await Comment.findById(comment._id)
      .populate('author', 'name email avatar')
      .populate('mentions', 'name email');

    res.json({ success: true, message: 'Comment updated successfully.', data: populated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// ====================== DELETE COMMENT ======================
export const remove = async (req, res) => {
  try {
    const { commentId } = req.params;
    const comment = await Comment.findById(commentId);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });

    if (comment.author.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'You can only delete your own comments.' });
    }

    await Task.findByIdAndUpdate(comment.task, { $pull: { comments: comment._id } });
    await Comment.findByIdAndDelete(commentId);

    res.json({ success: true, message: 'Comment deleted successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// ====================== ADD REPLY ======================
export const addReply = async (req, res) => {
  try {
    const { commentId } = req.params;
    const { content, mentions = [] } = req.body;

    if (!content || !content.trim()) {
      return res.status(400).json({ success: false, message: 'Reply content is required.' });
    }

    const comment = await Comment.findById(commentId);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });

    comment.replies.push({ author: req.user.id, content: content.trim(), mentions });
    comment.updatedAt = new Date();
    await comment.save();

    const populated = await Comment.findById(comment._id)
      .populate('author', 'name email avatar')
      .populate('replies.author', 'name email avatar');

    res.status(201).json({ success: true, message: 'Reply added successfully.', data: populated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};