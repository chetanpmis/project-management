import Notification from '../models/Notification.js';

export const list = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 20, 1);
    const { read, type } = req.query;

    const query = { user: req.user.id };
    if (read !== undefined) query.read = read === 'true';
    if (type) query.type = type;

    const total = await Notification.countDocuments(query);
    const unreadCount = await Notification.countDocuments({ user: req.user.id, read: false });

    const notifications = await Notification.find(query)
      .populate('relatedTask', 'title status')
      .populate('relatedProject', 'name projectCode')
      .populate('relatedUser', 'name email avatar')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    return res.json({
      success: true,
      data: notifications,
      unreadCount,
      pagination: {
        total, page, limit,
        totalPages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrevious: page > 1,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const getUnreadCount = async (req, res) => {
  try {
    const unreadCount = await Notification.countDocuments({ user: req.user.id, read: false });
    return res.json({ success: true, data: { unreadCount } });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const markAsRead = async (req, res) => {
  try {
    const { id } = req.params;
    const notification = await Notification.findOne({ _id: id, user: req.user.id });
    if (!notification) return res.status(404).json({ success: false, message: 'Notification not found.' });

    notification.read = true;
    notification.readAt = new Date();
    await notification.save();

    return res.json({ success: true, message: 'Notification marked as read.', data: notification });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const markAllAsRead = async (req, res) => {
  try {
    await Notification.updateMany({ user: req.user.id, read: false }, { read: true, readAt: new Date() });
    return res.json({ success: true, message: 'All notifications marked as read.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const remove = async (req, res) => {
  try {
    const { id } = req.params;
    const notification = await Notification.findOneAndDelete({ _id: id, user: req.user.id });
    if (!notification) return res.status(404).json({ success: false, message: 'Notification not found.' });
    return res.json({ success: true, message: 'Notification deleted.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const removeAll = async (req, res) => {
  try {
    const { onlyRead } = req.query;
    const query = { user: req.user.id };
    if (onlyRead === 'true') query.read = true;

    await Notification.deleteMany(query);
    return res.json({ success: true, message: 'Notifications cleared.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};