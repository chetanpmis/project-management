import express from 'express';
import { authMiddleware, projectManagerMiddleware } from '../middleware/auth.js';
import * as authController from '../controllers/authController.js';
import * as userController from '../controllers/userController.js';
import * as workspaceController from '../controllers/workspaceController.js';
import * as projectController from '../controllers/projectController.js';
import * as taskController from '../controllers/taskController.js';
import * as dashboardController from '../controllers/dashboardController.js';
import * as commentController from '../controllers/commentController.js';
import * as reportController from '../controllers/reportController.js';
import * as notificationController from '../controllers/notificationController.js';
import * as chatController from '../controllers/chatController.js';

import { getWorkloadManagement, recalculateUserWorkload, updateDailyCapacity } from '../controllers/workloadController.js';

const router = express.Router();

// Auth routes
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);

// Dashboard route
router.get('/dashboard', authMiddleware, dashboardController.getDashboardSummary);

// User routes
router.get('/users/profile', authMiddleware, userController.getProfile);
router.put('/users/profile', authMiddleware, userController.updateProfile);
router.get('/users', authMiddleware, userController.listUsers);
router.get('/users/:id', authMiddleware, userController.getUser);

// Workspace routes
router.get('/workspaces', authMiddleware, workspaceController.list);
router.get('/workspaces/:id', authMiddleware, workspaceController.get);
router.post('/workspaces', authMiddleware, workspaceController.create);
router.put('/workspaces/:id', authMiddleware, workspaceController.update);
router.post('/workspaces/:id/members', authMiddleware, workspaceController.addMember);
router.delete('/workspaces/:id', authMiddleware, workspaceController.remove);

// Project routes
router.get('/projects', authMiddleware, projectController.list);
router.get('/projects/:id', authMiddleware, projectController.get);
router.post('/projects', authMiddleware, projectController.create);
router.put('/projects/:id', authMiddleware, projectController.update);
router.get('/projects/:id/stats', authMiddleware, projectController.getStats);
router.post('/projects/:projectId/team', authMiddleware, projectManagerMiddleware, projectController.addTeamMember);
router.delete('/projects/:projectId/team/:userId', authMiddleware, projectManagerMiddleware, projectController.removeTeamMember);
router.patch('/projects/:projectId/team/:userId', authMiddleware, projectController.updateTeamMember);
router.delete('/projects/:id', authMiddleware, projectController.remove);                   
router.patch('/projects/:id/status', authMiddleware, projectController.updateStatus);

// Task routes
router.get('/tasks/project/:projectId/stats', authMiddleware, taskController.getUserTaskStats);
router.get('/tasks/project/:projectId', authMiddleware, taskController.listByProject);

router.get('/tasks/me', authMiddleware, taskController.getMyTasks);
router.get('/tasks/me/stats', authMiddleware, taskController.getMyTaskStats);

router.get('/tasks/:id', authMiddleware, taskController.get);
router.post('/tasks/project/:projectId', authMiddleware, taskController.create);
router.put('/tasks/:id', authMiddleware, taskController.update);
router.delete('/tasks/:id', authMiddleware, taskController.remove);                    
router.get('/tasks/:projectId/creation-data', authMiddleware, taskController.getTaskCreationData);

router.post('/tasks/:taskId/start-timer', authMiddleware, taskController.startTimer);
router.post('/tasks/:taskId/stop-timer', authMiddleware, taskController.stopTimer);
router.post('/tasks/:taskId/resume-timer', authMiddleware, taskController.resumeTimer);
router.post('/tasks/:taskId/finish', authMiddleware, taskController.finishTask);
router.get('/tasks/:taskId/timer', authMiddleware, taskController.getTimerStatus);

// Watcher routes
router.post('/tasks/:id/watchers', authMiddleware, taskController.addWatcher);
router.delete('/tasks/:id/watchers', authMiddleware, taskController.removeWatcher);

// Attachment routes (now using central File model)
router.post('/tasks/:id/attachments', authMiddleware, taskController.addAttachment);
router.delete('/tasks/:id/attachments/:attachmentId', authMiddleware, taskController.removeAttachment);

// Work log routes
router.post('/tasks/:taskId/worklog/project/:projectId', authMiddleware, taskController.addWorkLog);

// Gantt route
router.get('/tasks/project/:projectId/gantt', authMiddleware, taskController.getGanttData);
router.post('/tasks/:id/checklist', authMiddleware, taskController.addChecklistItem);
router.patch('/tasks/:id/checklist/:itemId', authMiddleware, taskController.toggleChecklistItem);
router.delete('/tasks/:id/checklist/:itemId', authMiddleware, taskController.removeChecklistItem);

// Comment routes
router.get('/tasks/:taskId/comments', authMiddleware, commentController.listByTask);
router.post('/tasks/:taskId/comments', authMiddleware, commentController.create);
router.put('/comments/:commentId', authMiddleware, commentController.update);
router.delete('/comments/:commentId', authMiddleware, commentController.remove);
router.post('/comments/:commentId/replies', authMiddleware, commentController.addReply);

//Workload Management (team capacity & assignment)

router.get('/projects/:projectId/workload', authMiddleware, getWorkloadManagement);
router.patch('/projects/:projectId/daily-capacity', authMiddleware, updateDailyCapacity);
router.patch('/projects/:projectId/workload/:userId/recalculate', authMiddleware, recalculateUserWorkload);

router.get('/tasks/project/:projectId/kanban', authMiddleware, taskController.getKanbanBoards);
router.patch('/tasks/:taskId/move', authMiddleware, taskController.moveTask);

//Milestone Management (permanent removal)
router.delete('/projects/:projectId/milestone/:milestoneId', authMiddleware, projectController.removeMilestone);

// Report routes 
router.get(
  "/reports/projects/:projectId/gantt",
  authMiddleware,
  reportController.getProjectGantt
);

router.get(
  "/reports/projects/:projectId/overview",
  authMiddleware,
  reportController.getProjectOverview
);

router.get(
  "/reports/projects/:projectId/task-status",
  authMiddleware,
  reportController.getProjectTaskStatus
);

router.get(
  "/reports/projects/:projectId/milestones",
  authMiddleware,
  reportController.getProjectMilestones
);

router.get(
  "/reports/projects/:projectId/team-performance",
  authMiddleware,
  reportController.getProjectTeamPerformance
);

router.get(
  "/reports/projects/:projectId/estimated-vs-actual",
  authMiddleware,
  reportController.getProjectEstimatedVsActual
);

router.get(
  "/reports/projects/:projectId/overdue",
  authMiddleware,
  reportController.getProjectOverdueTasks
);

router.get(
  "/reports/projects/:projectId/completion-trend",
  authMiddleware,
  reportController.getProjectCompletionTrend
);

router.get(
  "/reports/projects/:projectId/dashboard",
  authMiddleware,
  reportController.getProjectReportsDashboard
);





router.get('/notifications', authMiddleware, notificationController.list);
router.get('/notifications/unread-count', authMiddleware, notificationController.getUnreadCount);
router.patch('/notifications/:id/read', authMiddleware, notificationController.markAsRead);
router.patch('/notifications/read-all', authMiddleware, notificationController.markAllAsRead);
router.delete('/notifications/:id', authMiddleware, notificationController.remove);
router.delete('/notifications', authMiddleware, notificationController.removeAll);



router.get('/projects/:projectId/messages', authMiddleware, chatController.list);
router.post('/projects/:projectId/messages', authMiddleware, chatController.create);
router.put('/messages/:messageId', authMiddleware, chatController.update);
router.delete('/messages/:messageId', authMiddleware, chatController.remove);
router.patch('/projects/:projectId/messages/read', authMiddleware, chatController.markRead);
router.get('/projects/:projectId/messages/unread-count', authMiddleware, chatController.getUnreadCount);
router.post('/messages/:messageId/react', authMiddleware, chatController.react);
export default router;