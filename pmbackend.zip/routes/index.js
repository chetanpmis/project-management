import express from 'express';
import { authMiddleware, projectManagerMiddleware } from '../middleware/auth.js';
import * as authController from '../controllers/authController.js';
import * as userController from '../controllers/userController.js';
import * as workspaceController from '../controllers/workspaceController.js';
import * as projectController from '../controllers/projectController.js';
import * as taskController from '../controllers/taskController.js';
import * as dashboardController from '../controllers/dashboardController.js';

const router = express.Router();

router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);

router.get('/dashboard', authMiddleware, dashboardController.getDashboardSummary);

router.get('/users/profile', authMiddleware, userController.getProfile);
router.put('/users/profile', authMiddleware, userController.updateProfile);
router.get('/users', authMiddleware, userController.listUsers);
router.get('/users/:id', authMiddleware, userController.getUser);

router.get('/workspaces', authMiddleware, workspaceController.list);
router.get('/workspaces/:id', authMiddleware, workspaceController.get);
router.post('/workspaces', authMiddleware, workspaceController.create);
router.put('/workspaces/:id', authMiddleware, workspaceController.update);
router.post('/workspaces/:id/members', authMiddleware, workspaceController.addMember);
router.delete('/workspaces/:id', authMiddleware, workspaceController.remove);


router.get('/projects', authMiddleware, projectController.list);
router.get('/projects/:id', authMiddleware, projectController.get);
router.post('/projects', authMiddleware, projectController.create);
router.put('/projects/:id', authMiddleware, projectController.update);
router.get('/projects/:id/stats', authMiddleware, projectController.getStats);
router.post('/projects/:projectId/team', authMiddleware, projectManagerMiddleware, projectController.addTeamMember);
router.delete('/projects/:projectId/team/:userId', authMiddleware, projectManagerMiddleware, projectController.removeTeamMember);
router.patch( "/projects/:projectId/team/:userId", authMiddleware, projectController.updateTeamMember);
router.delete( "/projects/:id", authMiddleware,projectController.remove);
router.patch("/projects/:id/status",authMiddleware,projectController.updateStatus);

router.get('/tasks/project/:projectId', authMiddleware, taskController.listByProject);
router.get('/tasks/:id', authMiddleware, taskController.get);
router.post('/tasks/project/:projectId', authMiddleware, taskController.create);
router.put('/tasks/:id', authMiddleware, taskController.update);
router.post('/tasks/:taskId/worklog/project/:projectId', authMiddleware, taskController.addWorkLog);
router.get('/tasks/project/:projectId/gantt', authMiddleware, taskController.getGanttData);

export default router;
