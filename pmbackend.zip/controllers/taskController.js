import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import Workload from '../models/Workload.js';

export const listByProject = async (req, res) => {
  try {
    const { projectId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const search = req.query.search || '';
    const status = req.query.status || '';
    const priority = req.query.priority || '';

    let query = { project: projectId };
    if (search) query.title = { $regex: search, $options: 'i' };
    if (status) query.status = status;
    if (priority) query.priority = priority;

    const total = await Task.countDocuments(query);
    const tasks = await Task.find(query)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email')
      .populate('createdBy', 'name email')
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });

    res.json({
      data: tasks,
      pagination: { total, page, limit, pages: Math.ceil(total / limit) }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const get = async (req, res) => {
  try {
    const task = await Task.findById(req.params.id)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email')
      .populate('createdBy', 'name email')
      .populate('comments');
    res.json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const create = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { title, description, assignees, priority, dueDate, startDate, estimatedHours } = req.body;
    
    const task = new Task({
      title,
      description,
      project: projectId,
      assignees: assignees || [],
      priority,
      dueDate,
      startDate,
      estimatedHours,
      createdBy: req.user.id
    });

    await task.save();

    if (assignees && assignees.length > 0) {
      for (const userId of assignees) {
        await Workload.create({
          project: projectId,
          user: userId,
          date: new Date(),
          assignedHours: estimatedHours || 0,
          tasks: [task._id]
        });
      }
    }

    await Activity.create({
      project: projectId,
      user: req.user.id,
      type: 'task_created',
      entity: 'Task',
      entityId: task._id,
      description: `Task "${title}" created`
    });

    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const update = async (req, res) => {
  try {
    const oldTask = await Task.findById(req.params.id);
    const task = await Task.findByIdAndUpdate(
      req.params.id,
      { ...req.body, updatedAt: new Date() },
      { new: true }
    );

    if (oldTask.status !== task.status) {
      await Activity.create({
        project: task.project,
        user: req.user.id,
        type: 'task_status_changed',
        entity: 'Task',
        entityId: task._id,
        previousValue: oldTask.status,
        newValue: task.status
      });
    }

    res.json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const addWorkLog = async (req, res) => {
  try {
    const { projectId, taskId } = req.params;
    const { hours, date, description } = req.body;

    const task = await Task.findById(taskId);
    task.workLogs.push({
      user: req.user.id,
      hours,
      date: date || new Date(),
      description,
      approved: false
    });
    task.actualHours = (task.actualHours || 0) + hours;
    await task.save();

    await Activity.create({
      project: projectId,
      user: req.user.id,
      type: 'work_log_added',
      entity: 'Task',
      entityId: taskId,
      newValue: { hours, description }
    });

    res.json(task);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getGanttData = async (req, res) => {
  try {
    const { projectId } = req.params;
    const tasks = await Task.find({ project: projectId })
      .populate('assignees', 'name')
      .select('title startDate dueDate status priority progress');

    const ganttData = tasks.map(task => ({
      id: task._id,
      name: task.title,
      start: task.startDate,
      end: task.dueDate,
      progress: task.status === 'done' ? 100 : 50,
      type: 'task',
      assignee: task.assignees[0]?.name
    }));

    res.json(ganttData);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
