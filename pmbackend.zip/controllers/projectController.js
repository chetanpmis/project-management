import Project from '../models/Project.js';
import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import User from "../models/User.js";
import Budget from '../models/Budget.js';
import Workload from '../models/Workload.js';
import { generateProjectCode } from '../utils/projectCodeGenerator.js';
import { DEFAULT_ROLE_PERMISSIONS } from '../constants/projectPermissions.js';

export const list = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 10, 1);

    const {
      search,
      status,
      projectType,
      priority,
      sortBy,
      order,
    } = req.query;

    const query = {
  isDeleted: false,
  $or: [
    { owner: req.user.id },
    { "team.user": req.user.id },
  ],
};

    if (search) {
      query.$and = [
        {
          $or: [
            {
              name: {
                $regex: search,
                $options: "i",
              },
            },
            {
              projectCode: {
                $regex: search,
                $options: "i",
              },
            },
          ],
        },
      ];
    }

    if (status) {
      query.status = status;
    }

    if (projectType) {
      query.projectType = projectType;
    }

    if (priority) {
      query.priority = priority;
    }

    const sortField = sortBy || "createdAt";

    const sortOrder = order === "asc" ? 1 : -1;

    const total = await Project.countDocuments(query);

    const projects = await Project.find(query)
      .populate("owner", "name email")
      .populate("team.user", "name email")
      .sort({
        [sortField]: sortOrder,
      })
      .skip((page - 1) * limit)
      .limit(limit);

    return res.json({
      success: true,

      data: projects,

      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrevious: page > 1,
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const get = async (req, res) => {
  try {
    const { id } = req.params;

    const project = await Project.findById(id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    const isOwner = project.owner._id.toString() === req.user.id;

    const isMember = project.team.some(
      (member) => member.user._id.toString() === req.user.id
    );

    if (!isOwner && !isMember) {
      return res.status(403).json({
        success: false,
        message: "You do not have permission to access this project.",
      });
    }

    return res.status(200).json({
      success: true,
      data: project,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};



export const create = async (req, res) => {
  try {
    const {
      name,
      description,
      projectType,
      status,
      priority,
      visibility,
      health,
      startDate,
      endDate,
      estimatedHours,
      budget,
    } = req.body;

    const projectCode = await generateProjectCode(projectType);

    const estimatedBudget = Number(budget?.estimated || 0);
    const approvedBudget = Number(budget?.approved || estimatedBudget);

    const project = new Project({
      projectCode,

      name,
      description,

      projectType: projectType || "internal",

      status: status || "planning",

      priority: priority || "medium",

      visibility: visibility || "private",

      health: health || "healthy",

      owner: req.user.id,

      startDate,

      endDate,

      estimatedHours: estimatedHours || 0,

      loggedHours: 0,

      budget: {
        estimated: estimatedBudget,
        approved: approvedBudget,
        spent: 0,
        remaining: approvedBudget,
      },

      progress: 0,

      lastActivityAt: new Date(),

      team: [
        {
          user: req.user.id,
          role: "owner",
          permissions: DEFAULT_ROLE_PERMISSIONS.owner,
          invitedBy: req.user.id,
        },
      ],
    });

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "project_created",
      entity: "Project",
      entityId: project._id,
      description: `Project "${project.name}" created`,
    });

    const createdProject = await Project.findById(project._id)
      .populate("owner", "name email")
      .populate("team.user", "name email");

    return res.status(201).json({
      success: true,
      message: "Project created successfully.",
      data: createdProject,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const update = async (req, res) => {
  try {
    const { id } = req.params;

    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    // Owner has full access
    const isOwner = project.owner.toString() === req.user.id;

    // Find logged-in user in team
    const teamMember = project.team.find(
      (member) => member.user.toString() === req.user.id
    );

    const canEdit =
      isOwner ||
      (teamMember &&
        teamMember.permissions.includes("project.edit"));

    if (!canEdit) {
      return res.status(403).json({
        success: false,
        message: "You don't have permission to edit this project.",
      });
    }

    const {
      name,
      description,
      projectType,
      status,
      priority,
      health,
      visibility,
      startDate,
      endDate,
      estimatedHours,
      budget,
    } = req.body;

    if (name !== undefined) project.name = name;
    if (description !== undefined) project.description = description;
    if (projectType !== undefined) project.projectType = projectType;
    if (priority !== undefined) project.priority = priority;
    if (health !== undefined) project.health = health;
    if (visibility !== undefined) project.visibility = visibility;
    if (startDate !== undefined) project.startDate = startDate;
    if (endDate !== undefined) project.endDate = endDate;
    if (estimatedHours !== undefined)
      project.estimatedHours = estimatedHours;

    if (status !== undefined) {
      project.status = status;

      if (status === "completed") {
        project.completedAt = new Date();
        project.progress = 100;
      } else {
        project.completedAt = null;
      }
    }

    if (budget) {
      if (budget.estimated !== undefined)
        project.budget.estimated = budget.estimated;

      if (budget.approved !== undefined)
        project.budget.approved = budget.approved;

      if (budget.spent !== undefined)
        project.budget.spent = budget.spent;

      project.budget.remaining =
        project.budget.approved - project.budget.spent;
    }

    project.lastActivityAt = new Date();

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "project_updated",
      entity: "Project",
      entityId: project._id,
      description: `Updated project "${project.name}"`,
    });

    const updatedProject = await Project.findById(project._id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    return res.status(200).json({
      success: true,
      message: "Project updated successfully.",
      data: updatedProject,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const getStats = async (req, res) => {
  try {
    const { id } = req.params;

    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    const isOwner = project.owner.toString() === req.user.id;

    const isMember = project.team.some(
      (member) => member.user.toString() === req.user.id
    );

    if (!isOwner && !isMember) {
      return res.status(403).json({
        success: false,
        message: "Access denied.",
      });
    }

    const totalTasks = await Task.countDocuments({
      project: id,
    });

    const completedTasks = await Task.countDocuments({
      project: id,
      status: "done",
    });

    const overdueTasks = await Task.countDocuments({
      project: id,
      status: {
        $ne: "done",
      },
      dueDate: {
        $lt: new Date(),
      },
    });

    const budget = await Budget.findOne({
      project: id,
    });

    const workload = await Workload.find({
      project: id,
    });

    const overloadedMembers = workload.filter(
      (member) => member.overloaded
    ).length;

    const progress =
      totalTasks === 0
        ? 0
        : Math.round((completedTasks / totalTasks) * 100);

    return res.status(200).json({
      success: true,
      data: {
        projectCode: project.projectCode,

        projectName: project.name,

        status: project.status,

        priority: project.priority,

        health: project.health,

        progress,

        totalTasks,

        completedTasks,

        pendingTasks: totalTasks - completedTasks,

        overdueTasks,

        teamMembers: project.team.length,

        estimatedHours: project.estimatedHours,

        loggedHours: project.loggedHours,

        budget: budget || project.budget,

        overloadedMembers,
      },
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};



export const addTeamMember = async (req, res) => {
  try {
    const { projectId } = req.params;
    const {
      userId,
      role = "member",
      permissions,
    } = req.body;

    const project = await Project.findById(projectId);

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    // Check user exists
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    // Owner check
    const isOwner =
      project.owner.toString() === req.user.id;

    // Logged-in member
    const currentMember = project.team.find(
      (member) =>
        member.user.toString() === req.user.id
    );

    // Permission check
    const canInvite =
      isOwner ||
      (
        currentMember &&
        currentMember.permissions.includes(
          "team.invite"
        )
      );

    if (!canInvite) {
      return res.status(403).json({
        success: false,
        message: "You don't have permission to add members.",
      });
    }

    // Only owner can create managers
    if (role === "manager" && !isOwner) {
      return res.status(403).json({
        success: false,
        message: "Only project owner can assign manager role.",
      });
    }

    // Prevent owner duplicate
    if (project.owner.toString() === userId) {
      return res.status(400).json({
        success: false,
        message: "Project owner is already part of this project.",
      });
    }

    // Prevent duplicate member
    const alreadyExists = project.team.some(
      (member) =>
        member.user.toString() === userId
    );

    if (alreadyExists) {
      return res.status(400).json({
        success: false,
        message: "User is already a project member.",
      });
    }

    project.team.push({
      user: userId,
      role,
      permissions:
        permissions?.length
          ? permissions
          : DEFAULT_ROLE_PERMISSIONS[role],
      invitedBy: req.user.id,
    });

    project.lastActivityAt = new Date();

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "member_added",
      entity: "User",
      entityId: userId,
      description: `${user.name} added as ${role}`,
    });

    const updatedProject = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    return res.status(200).json({
      success: true,
      message: "Team member added successfully.",
      data: updatedProject,
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const removeTeamMember = async (req, res) => {
  try {
    const { projectId, userId } = req.params;

    const project = await Project.findById(projectId);

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    const isOwner =
      project.owner.toString() === req.user.id;

    const currentMember = project.team.find(
      (member) =>
        member.user.toString() === req.user.id
    );

    const canRemove =
      isOwner ||
      (
        currentMember &&
        currentMember.permissions.includes("team.remove")
      );

    if (!canRemove) {
      return res.status(403).json({
        success: false,
        message: "You don't have permission to remove team members.",
      });
    }

    const member = project.team.find(
      (item) => item.user.toString() === userId
    );

    if (!member) {
      return res.status(404).json({
        success: false,
        message: "Team member not found.",
      });
    }

    // Owner can never be removed
    if (member.role === "owner") {
      return res.status(400).json({
        success: false,
        message: "Project owner cannot be removed.",
      });
    }

    // Only owner can remove managers
    if (
      member.role === "manager" &&
      !isOwner
    ) {
      return res.status(403).json({
        success: false,
        message: "Only the project owner can remove a manager.",
      });
    }

    project.team = project.team.filter(
      (item) =>
        item.user.toString() !== userId
    );

    project.lastActivityAt = new Date();

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "member_removed",
      entity: "User",
      entityId: userId,
      description: "Team member removed from project",
    });

    const updatedProject = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    return res.status(200).json({
      success: true,
      message: "Team member removed successfully.",
      data: updatedProject,
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateTeamMember = async (req, res) => {
  try {
    const { projectId, userId } = req.params;

    const {
      role,
      permissions,
    } = req.body;

    const project = await Project.findById(projectId);

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    const isOwner =
      project.owner.toString() === req.user.id;

    const currentMember = project.team.find(
      (member) =>
        member.user.toString() === req.user.id
    );

    const canEdit =
      isOwner ||
      (
        currentMember &&
        currentMember.permissions.includes("team.edit")
      );

    if (!canEdit) {
      return res.status(403).json({
        success: false,
        message: "You don't have permission to update team members.",
      });
    }

    const member = project.team.find(
      (member) =>
        member.user.toString() === userId
    );

    if (!member) {
      return res.status(404).json({
        success: false,
        message: "Team member not found.",
      });
    }

    // Owner cannot be edited
    if (member.role === "owner") {
      return res.status(400).json({
        success: false,
        message: "Project owner cannot be modified.",
      });
    }

    // Managers cannot edit other managers
    if (
      !isOwner &&
      member.role === "manager"
    ) {
      return res.status(403).json({
        success: false,
        message: "Only the project owner can edit a manager.",
      });
    }

    // Only owner can assign manager role
    if (
      role === "manager" &&
      !isOwner
    ) {
      return res.status(403).json({
        success: false,
        message: "Only the project owner can assign manager role.",
      });
    }

    if (role) {
      member.role = role;
    }

    if (permissions) {
      member.permissions = permissions;
    } else if (role) {
      member.permissions = DEFAULT_ROLE_PERMISSIONS[role];
    }

    project.lastActivityAt = new Date();

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "member_updated",
      entity: "User",
      entityId: userId,
      description: "Team member role updated",
    });

    const updatedProject = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    return res.status(200).json({
      success: true,
      message: "Team member updated successfully.",
      data: updatedProject,
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const remove = async (req, res) => {
  try {
    const { id } = req.params;

    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    // Only owner can delete
    if (project.owner.toString() !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: "Only the project owner can delete this project.",
      });
    }

    project.isDeleted = true;
    project.deletedAt = new Date();
    project.deletedBy = req.user.id;
    project.lastActivityAt = new Date();

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "project_deleted",
      entity: "Project",
      entityId: project._id,
      description: `Project "${project.name}" deleted`,
    });

    return res.status(200).json({
      success: true,
      message: "Project deleted successfully.",
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const allowedStatus = [
      "planning",
      "active",
      "on_hold",
      "completed",
      "cancelled",
    ];

    if (!allowedStatus.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid project status.",
      });
    }

    const project = await Project.findById(id);

    if (!project) {
      return res.status(404).json({
        success: false,
        message: "Project not found.",
      });
    }

    const isOwner = project.owner.toString() === req.user.id;

    const teamMember = project.team.find(
      (member) => member.user.toString() === req.user.id
    );

    const canEdit =
      isOwner ||
      (
        teamMember &&
        teamMember.permissions.includes("project.edit")
      );

    if (!canEdit) {
      return res.status(403).json({
        success: false,
        message: "You don't have permission to update project status.",
      });
    }

    const previousStatus = project.status;

    project.status = status;

    if (status === "completed") {
      project.completedAt = new Date();
      project.progress = 100;
    } else {
      project.completedAt = null;
    }

    project.lastActivityAt = new Date();

    await project.save();

    await Activity.create({
      project: project._id,
      user: req.user.id,
      type: "project_status_changed",
      entity: "Project",
      entityId: project._id,
      description: `Project status changed from "${previousStatus}" to "${status}"`,
    });

    return res.status(200).json({
      success: true,
      message: "Project status updated successfully.",
      data: {
        projectId: project._id,
        status: project.status,
        completedAt: project.completedAt,
      },
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};