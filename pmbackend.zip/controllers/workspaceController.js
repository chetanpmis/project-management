import Workspace from '../models/Workspace.js';

export const list = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const search = req.query.search || '';

    let query = {
      $or: [
        { owner: req.user.id },
        { 'members.user': req.user.id }
      ]
    };

    if (search) query.name = { $regex: search, $options: 'i' };

    const total = await Workspace.countDocuments(query);
    const workspaces = await Workspace.find(query)
      .populate('owner', 'name email')
      .populate('members.user', 'name email')
      .limit(limit)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });

    res.json({
      data: workspaces,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const get = async (req, res) => {
  try {
    const workspace = await Workspace.findById(req.params.id)
      .populate('owner', 'name email')
      .populate('members.user', 'name email');
    res.json(workspace);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const create = async (req, res) => {
  try {
    const { name, description } = req.body;
    const workspace = new Workspace({
      name,
      description,
      slug: name.toLowerCase().replace(/\s+/g, '-'),
      owner: req.user.id,
      members: [{ user: req.user.id, role: 'owner' }]
    });
    await workspace.save();
    res.status(201).json(workspace);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const update = async (req, res) => {
  try {
    const workspace = await Workspace.findById(req.params.id);
    if (workspace.owner.toString() !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    Object.assign(workspace, req.body);
    await workspace.save();
    res.json(workspace);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const addMember = async (req, res) => {
  try {
    const { userId, role } = req.body;
    const workspace = await Workspace.findById(req.params.id);
    if (workspace.owner.toString() !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    workspace.members.push({ user: userId, role: role || 'member' });
    await workspace.save();
    res.json(workspace);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const remove = async (req, res) => {
  try {
    const workspace = await Workspace.findById(req.params.id);
    if (workspace.owner.toString() !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized' });
    }
    await Workspace.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
