import mongoose from 'mongoose';
import Project from '../models/Project.js';
import Task from '../models/Task.js';
import Activity from '../models/Activity.js';

export const getDashboardSummary = async (req, res) => {
  try {
    const userId = req.user.id;
    const userObjectId = new mongoose.Types.ObjectId(userId);

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const endOfToday = new Date(startOfToday.getTime() + 24 * 60 * 60 * 1000);

    // Fetch project IDs ONCE, reuse everywhere (was 3 separate queries before)
    const myProjects = await Project.find({
      $or: [{ owner: userId }, { 'team.user': userId }]
    }).select('_id name description progress updatedAt owner');

    const projectIds = myProjects.map(p => p._id);

    const [
      totalTasks,
      completedTasks,
      monthTotalTasks,
      monthCompletedTasks,
      myTaskStatusBreakdown,
      recentActivity
    ] = await Promise.all([
      Task.countDocuments({ project: { $in: projectIds } }),

      Task.countDocuments({ project: { $in: projectIds }, status: 'done' }),

      // tasks created this month, scoped to my projects
      Task.countDocuments({
        project: { $in: projectIds },
        createdAt: { $gte: startOfMonth }
      }),

      // tasks completed this month (proxy: status done + updatedAt in month)
      Task.countDocuments({
        project: { $in: projectIds },
        status: 'done',
        updatedAt: { $gte: startOfMonth }
      }),

      // status breakdown for MY assigned tasks only -> feeds the pie chart
      Task.aggregate([
        { $match: { project: { $in: projectIds }, assignees: userObjectId } },
        { $group: { _id: '$status', count: { $sum: 1 } } }
      ]),

      Activity.find({ project: { $in: projectIds } })
        .populate('user', 'name')
        .sort({ createdAt: -1 })
        .limit(8)
    ]);

    // Recent projects, sorted, with progress
    const recentProjects = [...myProjects]
      .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
      .slice(0, 5);

    // My tasks: total + due today + overdue (for the "my task" box)
    const myTasksTotal = await Task.countDocuments({
      project: { $in: projectIds },
      assignees: userObjectId
    });

    const myTasksDueToday = await Task.countDocuments({
      project: { $in: projectIds },
      assignees: userObjectId,
      dueDate: { $gte: startOfToday, $lt: endOfToday },
      status: { $ne: 'done' }
    });

    const myTasksOverdue = await Task.countDocuments({
      project: { $in: projectIds },
      assignees: userObjectId,
      dueDate: { $lt: startOfToday },
      status: { $ne: 'done' }
    });

    // Normalize aggregate result into a flat, chart-friendly shape
    const statusMap = { todo: 0, 'in-progress': 0, review: 0, done: 0 };
    myTaskStatusBreakdown.forEach(s => {
      if (s._id in statusMap) statusMap[s._id] = s.count;
    });

    const overallEfficiency = totalTasks > 0
      ? Math.round((completedTasks / totalTasks) * 100)
      : 0;

    const monthEfficiency = monthTotalTasks > 0
      ? Math.round((monthCompletedTasks / monthTotalTasks) * 100)
      : 0;

    res.json({
      stats: {
        totalProjects: myProjects.length,
        totalTasks,
        completedTasks,
        completionRate: overallEfficiency,
        thisMonth: {
          totalTasks: monthTotalTasks,
          completedTasks: monthCompletedTasks,
          efficiency: monthEfficiency
        }
      },
      myTasks: {
        total: myTasksTotal,
        dueToday: myTasksDueToday,
        overdue: myTasksOverdue,
        byStatus: [
          { name: 'To Do', value: statusMap.todo, key: 'todo' },
          { name: 'In Progress', value: statusMap['in-progress'], key: 'in-progress' },
          { name: 'Review', value: statusMap.review, key: 'review' },
          { name: 'Done', value: statusMap.done, key: 'done' }
        ]
      },
      recentProjects,
      recentActivity
    });
  } catch (error) {
    console.error('Dashboard summary error:', error);
    res.status(500).json({ error: error.message });
  }
};