import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true, lowercase: true },
  password: { type: String, required: true },
  avatar: String,
  bio: String,
  role: { type: String, enum: ['admin', 'member'], default: 'member' },
  status: { type: String, enum: ['active', 'inactive'], default: 'active' },
  workingHours: {
    start: { type: Number, default: 9 },
    end: { type: Number, default: 17 }
  },
  dailyCapacity: { type: Number, default: 8 },
  weeklyCapacity: { type: Number, default: 40 },
  monthlyCapacity: { type: Number, default: 160 },
  leave: [{
    startDate: Date,
    endDate: Date,
    type: String,
    approved: Boolean
  }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model('User', userSchema);
