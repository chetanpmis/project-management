import mongoose from 'mongoose';

const workloadSchema = new mongoose.Schema({
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  date: { type: Date, required: true },
  dailyCapacity: { type: Number, default: 8 },
  assignedHours: { type: Number, default: 0 },
  availableHours: { type: Number, default: 8 },
  utilization: { type: Number, default: 0 },
  overloaded: { type: Boolean, default: false },
  tasks: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Task' }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model('Workload', workloadSchema);
