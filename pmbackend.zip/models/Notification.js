import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: {
    type: String,
    enum: [
      'task_assigned', 'task_mentioned', 'task_commented',
      'task_deadline', 'task_overdue',
      'budget_alert', 'expense_approved',
      'milestone_created', 'milestone_completed',
      'project_invitation', 'member_added',
      'file_uploaded', 'work_log_approved'
    ]
  },
  title: String,
  message: String,
  read: { type: Boolean, default: false },
  readAt: Date,
  relatedTask: { type: mongoose.Schema.Types.ObjectId, ref: 'Task' },
  relatedProject: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
  relatedUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  link: String,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Notification', notificationSchema);