import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema({
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: {
    type: String,
    enum: [
      'project_created', 'project_updated', 'project_archived',
      'member_added', 'member_removed', 'member_role_changed',
      'task_created', 'task_updated', 'task_deleted', 'task_status_changed',
      'task_assigned', 'task_unassigned',
      'comment_added', 'comment_deleted',
      'file_uploaded', 'file_deleted',
      'budget_updated', 'expense_added', 'expense_approved',
      'milestone_created', 'milestone_completed',
      'work_log_added', 'work_log_approved'
    ]
  },
  entity: String,
  entityId: mongoose.Schema.Types.ObjectId,
  previousValue: mongoose.Schema.Types.Mixed,
  newValue: mongoose.Schema.Types.Mixed,
  description: String,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.model('Activity', activitySchema);