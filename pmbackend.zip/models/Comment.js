import mongoose from 'mongoose';

const commentSchema = new mongoose.Schema({
  task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task', required: true },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  content: { type: String, required: true },
  mentions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  attachments: [{
    filename: String,
    url: String
  }],
  emoji: [String],
  replies: [{
    author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    content: String,
    mentions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    emoji: [String],
    createdAt: { type: Date, default: Date.now }
  }],
  edited: Boolean,
  editedAt: Date,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model('Comment', commentSchema);