import mongoose from "mongoose";


const budgetSchema = new mongoose.Schema({
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true },
  estimated: { type: Number, required: true },
  approved: { type: Number, required: true },
  spent: { type: Number, default: 0 },
  remaining: { type: Number, default: 0 },
  forecast: Number,
  utilization: { type: Number, default: 0 },
  categories: [{
    name: String,
    allocated: Number,
    spent: Number,
    remaining: Number
  }],
  alerts: [{
    threshold: Number,
    triggered: Boolean,
    triggeredAt: Date
  }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model('Budget', budgetSchema);
