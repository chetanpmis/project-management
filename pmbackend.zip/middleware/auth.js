import jwt from 'jsonwebtoken';

export const authMiddleware = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_secret_key');
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

export const adminMiddleware = (req, res, next) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

export const projectManagerMiddleware = async (req, res, next) => {
  const { projectId } = req.params;
  try {
    const Project = (await import('../models/Project.js')).default;
    const project = await Project.findById(projectId);
    const member = project.team.find(m => m.user.toString() === req.user.id);
    
    if (!member || !['owner', 'manager'].includes(member.role)) {
      return res.status(403).json({ error: 'Project manager access required' });
    }
    next();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
