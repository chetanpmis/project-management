import Project from "../models/Project.js";

const PREFIX = {
  internal: "INT",
  client: "CLI",
  product: "PRO",
};

export const generateProjectCode = async (projectType = "internal") => {
  const prefix = PREFIX[projectType] || "PRJ";

  const now = new Date();

  const yy = String(now.getFullYear()).slice(-2);
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");

  const datePart = `${yy}${mm}${dd}`;

  const regex = new RegExp(`^${prefix}-${datePart}-\\d{4}$`);

  const lastProject = await Project.findOne({
    projectCode: { $regex: regex },
  }).sort({ projectCode: -1 });

  let sequence = 1;

  if (lastProject) {
    const lastSequence = parseInt(lastProject.projectCode.split("-")[2], 10);

    if (!isNaN(lastSequence)) {
      sequence = lastSequence + 1;
    }
  }

  const sequencePart = String(sequence).padStart(4, "0");

  return `${prefix}-${datePart}-${sequencePart}`;
};