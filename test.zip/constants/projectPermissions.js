
export const DEFAULT_ROLE_PERMISSIONS = {
  owner: [
    'project.edit',
    'project.delete',
    'team.invite',
    'team.remove',
    'team.edit',
    'project.status',
    'project.view',
  ],
  manager: [
    'project.edit',
    'team.invite',
    'team.remove',
    'team.edit',
    'project.status',
    'project.view',
  ],
  member: [
    'project.view',
    'task.view',
    'task.create',
  ],
  viewer: [
    'project.view',
  ],
};