import {
LayoutDashboard,
FolderKanban,
CheckSquare,
Users,
Bell,
Settings,
Building2,
BarChart3,
CalendarDays,
} from "lucide-react";

export const navigation = [
{
title: "Dashboard",
href: "/dashboard",
icon: LayoutDashboard,
},

{
title: "Workspace",
icon: Building2,
children: [
{
title: "Overview",
href: "/workspace",
},
],
},

{
title: "Projects",
icon: FolderKanban,
children: [
{
title: "All Projects",
href: "/projects",
},
{
title: "Create Project",
href: "/projects/create",
},
],
},

{
title: "Tasks",
icon: CheckSquare,
children: [
{
title: "My Tasks",
href: "/tasks",
},
{
title: "Calendar",
href: "/tasks/calendar",
},
],
},

{
title: "Reports",
icon: BarChart3,
children: [
{
title: "Analytics",
href: "/reports/analytics",
},
{
title: "Budget",
href: "/reports/budget",
},
{
title: "Workload",
href: "/reports/workload",
},
],
},

{
title: "Users",
href: "/users",
icon: Users,
},

{
title: "Notifications",
href: "/notifications",
icon: Bell,
},

{
title: "Settings",
href: "/settings",
icon: Settings,
},
];
