import { create } from "zustand";

export const useUIStore = create((set) => ({
sidebarOpen: true,

toggleSidebar: () =>
set((state) => ({
sidebarOpen: !state.sidebarOpen,
})),

openSidebar: () =>
set({
sidebarOpen: true,
}),

closeSidebar: () =>
set({
sidebarOpen: false,
}),
}));
