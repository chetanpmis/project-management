"use client";

import { useRouter, usePathname } from "next/navigation";
import { Bell, Search, Menu } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

import useAuthStore from "@/store/auth-store";
import useSidebarStore from "../../store/sidebar.store";


export default function Header() {
  const router = useRouter();
  const pathname = usePathname();
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const { collapsed, toggleSidebar } = useSidebarStore();

  const pageName = pathname.split("/").filter(Boolean).pop()?.replace("-", " ") || "Dashboard";

  return (
    <header className="sticky top-0 z-50 border-b border-zinc-200 bg-white/95 backdrop-blur-md">
      <div className="flex h-16 items-center justify-between px-6">
        <div className="flex items-center gap-4">
          {/* Sidebar Toggle Button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="text-zinc-700 hover:text-black"
          >
            <Menu size={22} />
          </Button>

          {/* <h2 className="text-2xl font-semibold text-black capitalize">{pageName}</h2> */}
        </div>

        <div className="hidden w-full max-w-md lg:block">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
            <Input
              placeholder="Search projects, tasks..."
              className="border-zinc-200 bg-white pl-11 focus-visible:ring-black placeholder:text-zinc-400"
            />
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="relative text-zinc-700 hover:text-black">
            <Bell size={20} />
            <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-3 rounded-3xl bg-white border border-zinc-200 px-4 py-2 hover:border-zinc-300 transition">
                <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-semibold">
                  {user?.name ? getInitials(user.name) : "U"}
                </div>
                <div className="hidden md:block text-left">
                  <p className="text-sm font-semibold text-black">{user?.name}</p>
                  <p className="text-xs text-zinc-500 capitalize">{user?.role}</p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-white border-zinc-200">
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="text-red-600">
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}

const getInitials = (name) => {
  if (!name) return "U";
  return name
    .split(" ")
    .map((word) => word[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
};