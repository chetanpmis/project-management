
import React from "react";

export default function Logo({ collapsed = false }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-black font-bold text-2xl text-white">
        PF
      </div>
      {!collapsed && (
        <div>
          <h2 className="text-2xl font-semibold text-black">ProjectFlow</h2>
          <p className="text-xs text-zinc-500">Project Management</p>
        </div>
      )}
    </div>
  );
}