'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronUp, ChevronDown, Trash2, Settings } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { hasPermission } from '@/lib/permissions';

const StatusBadge = ({ status }) => {
  const colors = {
    planning: 'bg-blue-100 text-blue-700',
    active: 'bg-green-100 text-green-700',
    on_hold: 'bg-yellow-100 text-yellow-700',
    completed: 'bg-emerald-100 text-emerald-700',
    cancelled: 'bg-red-100 text-red-700',
  };
  return <Badge variant="secondary" className={colors[status]}>{status.replace('_', ' ').toUpperCase()}</Badge>;
};

const PriorityBadge = ({ priority }) => {
  const colors = {
    low: 'bg-gray-100 text-gray-700',
    medium: 'bg-blue-100 text-blue-700',
    high: 'bg-orange-100 text-orange-700',
    critical: 'bg-red-100 text-red-700',
  };
  return <Badge variant="secondary" className={colors[priority]}>{priority.toUpperCase()}</Badge>;
};

export default function ProjectsTable({ projects }) {
  const [sortField, setSortField] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [deleteId, setDeleteId] = useState(null);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);

  const sortedProjects = [...projects].sort((a, b) => {
    let aVal = a[sortField];
    let bVal = b[sortField];

    if (sortField === 'name') {
      aVal = a.name.toLowerCase();
      bVal = b.name.toLowerCase();
    }
    if (sortField === 'status') {
      aVal = a.status;
      bVal = b.status;
    }
    if (sortField === 'priority') {
      aVal = a.priority;
      bVal = b.priority;
    }

    if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
    if (aVal > bVal) return sortOrder === 'asc' ? 1 : -1;
    return 0;
  });

  const toggleSort = (field) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const handleDelete = async (id) => {
    await projectService.deleteProject(id);
    // Refresh handled in parent
  };

  const canDelete = (project) => {
    const isOwner = project.owner?._id === currentUserId;
    const isMember = project.team?.some((t) => t.user === currentUserId);
    return isOwner || hasPermission(project, currentUserId, 'project.delete');
  };

  return (
    <>
      <div className="rounded-2xl border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[140px] cursor-pointer" onClick={() => toggleSort('projectCode')}>
                Project Code {sortField === 'projectCode' && (sortOrder === 'asc' ? <ChevronUp className="inline h-4 w-4" /> : <ChevronDown className="inline h-4 w-4" />)}
              </TableHead>
              <TableHead className="cursor-pointer" onClick={() => toggleSort('name')}>
                Name {sortField === 'name' && (sortOrder === 'asc' ? <ChevronUp className="inline h-4 w-4" /> : <ChevronDown className="inline h-4 w-4" />)}
              </TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Progress</TableHead>
              <TableHead>Members</TableHead>
              <TableHead>Budget</TableHead>
              <TableHead>Dates</TableHead>
              <TableHead className="w-[120px]">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedProjects.map((project) => (
              <TableRow key={project._id} className="group">
                <TableCell className="font-mono">{project.projectCode}</TableCell>
                <TableCell>
                  <div className="font-medium">{project.name}</div>
                  <div className="text-sm text-muted-foreground line-clamp-1">{project.description}</div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{project.projectType}</Badge>
                </TableCell>
                <TableCell><StatusBadge status={project.status} /></TableCell>
                <TableCell><PriorityBadge priority={project.priority} /></TableCell>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="h-2 w-24 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary transition-all" style={{ width: `${project.progress}%` }} />
                    </div>
                    <span className="text-sm font-medium w-10">{project.progress}%</span>
                  </div>
                </TableCell>
                {/* <TableCell>
                  <div className="flex -space-x-2">
                    {project.team?.slice(0, 3).map((m) => (
                      <Avatar key={m._id} className="h-7 w-7 ring-2 ring-background">
                        <AvatarImage src={m.user?.avatar} />
                        <AvatarFallback>{m.user?.name?.[0]}</AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                </TableCell> */}
                <TableCell>
                  <div className="font-medium">${project.budget?.approved}</div>
                </TableCell>
                <TableCell>
                  {project.startDate && new Date(project.startDate).toLocaleDateString()}
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        Actions
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-52">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem asChild>
                        <a href={`/dashboard/projects/${project._id}`}>
                          Open Project
                        </a>
                      </DropdownMenuItem>

                      {/* Permission-based actions */}
                      {(hasPermission(project, currentUserId, 'project.edit') || project.owner?._id === currentUserId) && (
                        <DropdownMenuItem asChild>
                          <a href={`/dashboard/projects/${project._id}/edit`}>
                            Edit Project
                          </a>
                        </DropdownMenuItem>
                      )}

                      {(hasPermission(project, currentUserId, 'team.invite') || project.owner?._id === currentUserId) && (
                        <DropdownMenuItem asChild>
                          <a href={`/dashboard/projects/${project._id}/team`}>
                            Manage Team
                          </a>
                        </DropdownMenuItem>
                      )}

                      <DropdownMenuSeparator />

                      {canDelete(project) && (
                        <DropdownMenuItem
                          className="text-red-600"
                          onClick={() => {
                            setDeleteId(project._id);
                            setIsDeleteOpen(true);
                          }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete Project
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Project</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this project? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                handleDelete(deleteId);
                setIsDeleteOpen(false);
              }}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}