import { motion } from 'framer-motion';
import { Users, CheckCircle, Clock, AlertTriangle, XCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const StatCard = ({ title, value, icon: Icon, color }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -8 }}
    transition={{ duration: 0.2 }}
  >
    <Card className="h-full overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-5 w-5 ${color}`} />
      </CardHeader>
      <CardContent>
        <motion.div
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          className="text-4xl font-bold"
        >
          {value}
        </motion.div>
      </CardContent>
    </Card>
  </motion.div>
);

export default function ProjectStatsCards({ stats }) {
  const cards = [
    { title: 'Total Projects', value: stats.total || 0, icon: Users, color: 'text-blue-600' },
    { title: 'Planning', value: stats.planning || 0, icon: Clock, color: 'text-blue-600' },
    { title: 'Active', value: stats.active || 0, icon: CheckCircle, color: 'text-green-600' },
    { title: 'Completed', value: stats.completed || 0, icon: CheckCircle, color: 'text-emerald-600' },
    { title: 'Cancelled', value: stats.cancelled || 0, icon: XCircle, color: 'text-red-600' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
      {cards.map((card, i) => (
        <StatCard key={card.title} {...card} />
      ))}
    </div>
  );
}