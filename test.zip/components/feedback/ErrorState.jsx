"use client";

import { ReactNode } from "react";
import { motion } from "framer-motion";


export default function ErrorState({
  icon,
  title,
  description,
  action,
}) {
  return (
    <motion.div
      initial={{
        opacity: 0,
        scale: 0.96,
      }}
      animate={{
        opacity: 1,
        scale: 1,
      }}
      className="flex min-h-[420px] flex-col items-center justify-center rounded-xl border bg-destructive/5 p-8 text-center"
    >
      <div className="mb-6 rounded-full bg-destructive/10 p-6 text-destructive">
        {icon}
      </div>

      <h2 className="text-2xl font-semibold">
        {title}
      </h2>

      <p className="mt-3 max-w-md text-muted-foreground">
        {description}
      </p>

      {action && (
        <div className="mt-8">
          {action}
        </div>
      )}
    </motion.div>
  );
}