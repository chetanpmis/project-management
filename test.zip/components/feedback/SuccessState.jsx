"use client";

import { ReactNode } from "react";
import { motion } from "framer-motion";



export default function SuccessState({
  icon,
  title,
  description,
  action,
}) {
  return (
    <motion.div
      initial={{
        opacity: 0,
        y: 20,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      className="flex min-h-[420px] flex-col items-center justify-center rounded-xl border bg-emerald-500/5 p-8 text-center"
    >
      <motion.div
        initial={{
          scale: 0.8,
        }}
        animate={{
          scale: 1,
        }}
        transition={{
          type: "spring",
          stiffness: 180,
        }}
        className="mb-6 rounded-full bg-emerald-500/10 p-6 text-emerald-600 dark:text-emerald-400"
      >
        {icon}
      </motion.div>

      <h2 className="text-2xl font-semibold">
        {title}
      </h2>

      <p className="mt-3 max-w-md text-muted-foreground">
        {description}
      </p>

      {action && (
        <div className="mt-8">
          {action}
        </div>
      )}
    </motion.div>
  );
}