import api from "../lib/axios";

const projectService = {


  getProjects: async (params = {}) => {
    const response = await api.get("/projects", {
      params,
    });

    return response.data;
  },

  getProjectById: async (projectId) => {
    const response = await api.get(`/projects/${projectId}`);

    return response.data;
  },

  createProject: async (data) => {
    const response = await api.post("/projects", data);

    return response.data;
  },

  updateProject: async (projectId, data) => {
    const response = await api.put(`/projects/${projectId}`, data);

    return response.data;
  },

  deleteProject: async (projectId) => {
    const response = await api.delete(`/projects/${projectId}`);

    return response.data;
  },

  updateProjectStatus: async (projectId, status) => {
    const response = await api.patch(
      `/projects/${projectId}/status`,
      {
        status,
      }
    );

    return response.data;
  },

  getProjectStats: async (projectId) => {
    const response = await api.get(
      `/projects/${projectId}/stats`
    );

    return response.data;
  },

  // ==========================
  // Team
  // ==========================

  addTeamMember: async (projectId, data) => {
    const response = await api.post(
      `/projects/${projectId}/team`,
      data
    );

    return response.data;
  },

  updateTeamMember: async (
    projectId,
    userId,
    data
  ) => {
    const response = await api.patch(
      `/projects/${projectId}/team/${userId}`,
      data
    );

    return response.data;
  },

  removeTeamMember: async (
    projectId,
    userId
  ) => {
    const response = await api.delete(
      `/projects/${projectId}/team/${userId}`
    );

    return response.data;
  },
};

export default projectService;