
import useAuthStore from "../store/auth-store";   // adjust path
import api from "../lib/axios";

const authService = {
  register: async (userData) => {
    const response = await api.post("/auth/register", userData);
    return response.data;
  },

  login: async (credentials) => {
    try {
      const response = await api.post("/auth/login", credentials);

      if (response.data.token && response.data.user) {
        // Update Zustand store
        useAuthStore.getState().login(response.data.user, response.data.token);
      }

      return response.data;
    } catch (error) {
      throw error;
    }
  },
};

export default authService;