import { NextResponse } from "next/server";

export function middleware(request) {
  const token = request.cookies.get("token");

  const pathname = request.nextUrl.pathname;

  if (
    pathname.startsWith("/dashboard") &&
    !token
  ) {
    return NextResponse.redirect(
      new URL("/login", request.url)
    );
  }

  if (
    (pathname === "/login" ||
      pathname === "/register") &&
    token
  ) {
    return NextResponse.redirect(
      new URL("/dashboard", request.url)
    );
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/login",
    "/register",
  ],
};