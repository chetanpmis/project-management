


"use client";
// import "./globals.css";
// import { useEffect } from "react";
// import { Toaster } from "sonner";
// import useAuthStore from "@/store/auth-store";

// export default function RootLayout({ children }) {
//   const initialize = useAuthStore((state) => state.initialize);

//   useEffect(() => {
//     initialize();
//   }, []);

//   return (
//     <html lang="en">
//       <body className="bg-zinc-950 text-white">
//         {children}
//         <Toaster richColors position="top-right" />
//       </body>
//     </html>
//   );
// }





import "./globals.css";
import { Geist, Geist_Mono } from "next/font/google";

import { useEffect } from "react";
import { Toaster } from "sonner";
import useAuthStore from "@/store/auth-store";

const geist = Geist({
  variable: "--font-geist",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export default function RootLayout({
  children,
}) {

    const initialize = useAuthStore((state) => state.initialize);

  useEffect(() => {
    initialize();
  }, []);
  return (
    <html
      lang="en"
      className={`${geist.variable} ${geistMono.variable}`}
      suppressHydrationWarning
    >
      <body className="bg-zinc-950 text-white">
        {children}
        <Toaster richColors position="top-right" />
      </body>
    </html>
  );
}