"use client";

import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { FolderKanban, CheckSquare, Clock, ArrowUpRight, ListTodo } from "lucide-react";

import dashboardService from "@/services/dashboard.service";

const STATUS_COLORS = {
  todo: "#a1a1aa",       // zinc-400
  "in-progress": "#000000",
  review: "#f59e0b",     // amber-500
  done: "#10b981"        // emerald-500
};

export default function DashboardPage() {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentDateTime, setCurrentDateTime] = useState("");

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentDateTime(
        now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" }) +
        ", " +
        now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true })
      );
    };
    updateDateTime();
    const interval = setInterval(updateDateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  const fetchDashboard = useCallback(async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      if (!token) throw new Error("No token found. Please login again.");
      const data = await dashboardService.getSummary(token);
      setDashboardData(data);
    } catch (err) {
      setError(err.message || "Failed to load dashboard");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  if (loading) {
    return (
      <div className="flex h-[80vh] items-center justify-center">
        <div className="flex flex-col items-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-zinc-400"></div>
          <p className="mt-4 text-zinc-500">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return <div className="text-red-500 p-6">{error}</div>;
  }

  const {
    stats = {},
    myTasks = { total: 0, dueToday: 0, overdue: 0, byStatus: [] },
    recentProjects = [],
    recentActivity = []
  } = dashboardData || {};

  const hasMyTasks = myTasks.byStatus.some(s => s.value > 0);

  return (
    <div className="space-y-8 p-6">
      <div>
        <h1 className="text-4xl font-bold text-black">Good Morning 👋</h1>
        <p className="mt-2 text-zinc-500">{`Here's what's happening with your projects today. ${currentDateTime}`}</p>
      </div>

      {/* Top-level stats */}
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {[
          { title: "Total Projects", value: stats.totalProjects || 0, icon: FolderKanban },
          { title: "Total Tasks", value: stats.totalTasks || 0, icon: CheckSquare },
          { title: "My Open Tasks", value: myTasks.total || 0, icon: ListTodo },
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="rounded-3xl border border-zinc-200 bg-white p-6 hover:border-black transition-all"
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-zinc-500">{stat.title}</p>
                  <h2 className="text-4xl font-bold mt-3 text-black">{stat.value}</h2>
                </div>
                <div className="p-3 bg-zinc-100 rounded-2xl">
                  <Icon size={28} className="text-black" />
                </div>
              </div>
              <div className="flex items-center gap-2 text-green-600 mt-4 text-sm">
                <ArrowUpRight size={16} />
                <span className="text-zinc-500">this month</span>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* My Tasks pie chart */}
        <div className="rounded-3xl border border-zinc-200 bg-white p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-black">My Tasks</h2>
            <span className="text-sm text-zinc-500">
              {myTasks.dueToday} due today · {myTasks.overdue} overdue
            </span>
          </div>

          {hasMyTasks ? (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={myTasks.byStatus}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={2}
                  >
                    {myTasks.byStatus.map((entry) => (
                      <Cell key={entry.key} fill={STATUS_COLORS[entry.key]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <p className="text-zinc-500 py-16 text-center">No tasks assigned to you yet.</p>
          )}
        </div>

        {/* Recent Projects with progress bars */}
        <div className="lg:col-span-2 rounded-3xl border border-zinc-200 bg-white overflow-hidden">
          <div className="border-b border-zinc-200 p-6">
            <h2 className="text-xl font-semibold text-black">Recent Projects</h2>
          </div>
          <div className="divide-y divide-zinc-200">
            {recentProjects.length === 0 && (
              <p className="p-6 text-zinc-500">No projects yet.</p>
            )}
            {recentProjects.map((project) => (
              <div key={project._id} className="p-6 hover:bg-zinc-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-lg text-black">{project.name}</h3>
                    <p className="text-sm text-zinc-500 mt-1 line-clamp-1">{project.description}</p>
                  </div>
                  <div className="text-2xl font-bold text-black">{project.progress ?? 0}%</div>
                </div>
                <div className="mt-4 h-2 bg-zinc-200 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-black rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${project.progress ?? 0}%` }}
                    transition={{ duration: 0.6 }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="rounded-3xl border border-zinc-200 bg-white overflow-hidden">
        <div className="border-b border-zinc-200 p-6">
          <h2 className="text-xl font-semibold text-black">Recent Activity</h2>
        </div>
        <div className="p-6 space-y-6">
          {recentActivity.length === 0 && <p className="text-zinc-500">No recent activity.</p>}
          {recentActivity.map((activity, i) => (
            <div key={activity._id || i} className="flex gap-4">
              <div className="w-2 h-2 mt-2.5 rounded-full bg-emerald-500 flex-shrink-0" />
              <div className="flex-1">
                <p className="text-sm text-zinc-500">{activity.description}</p>
                <p className="text-xs text-zinc-500 mt-1">
                  by {activity.user?.name} • {new Date(activity.createdAt).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Efficiency — overall + this month, at the bottom as requested */}
      <div className="grid gap-6 md:grid-cols-2">
        <div className="rounded-3xl border border-zinc-200 bg-white p-6">
          <p className="text-sm text-zinc-500">Overall Efficiency (Completion Rate)</p>
          <div className="flex items-end gap-3 mt-3">
            <h2 className="text-5xl font-bold text-black">{stats.completionRate || 0}%</h2>
            <span className="text-sm text-zinc-500 mb-2">
              {stats.completedTasks || 0} / {stats.totalTasks || 0} tasks done
            </span>
          </div>
          <div className="mt-4 h-2 bg-zinc-200 rounded-full overflow-hidden">
            <div className="h-full bg-black rounded-full" style={{ width: `${stats.completionRate || 0}%` }} />
          </div>
        </div>

        <div className="rounded-3xl border border-zinc-200 bg-white p-6">
          <p className="text-sm text-zinc-500">Efficiency This Month</p>
          <div className="flex items-end gap-3 mt-3">
            <h2 className="text-5xl font-bold text-black">{stats.thisMonth?.efficiency || 0}%</h2>
            <span className="text-sm text-zinc-500 mb-2">
              {stats.thisMonth?.completedTasks || 0} / {stats.thisMonth?.totalTasks || 0} tasks
            </span>
          </div>
          <div className="mt-4 h-2 bg-zinc-200 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${stats.thisMonth?.efficiency || 0}%` }} />
          </div>
        </div>
      </div>
    </div>
  );
}