'use client';

import { useState } from 'react';
import { Plus, Search, RefreshCw } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useDebounce } from '@/hooks/useDebounce';
import projectService from '@/services/project.service';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';

import ProjectStatsCards from '@/components/projects/ProjectStatsCards';
import ProjectFilters from '@/components/projects/ProjectFilters';
import ProjectsTable from '@/components/projects/ProjectsTable';
import EmptyState from '@/components/feedback/EmptyState';
import { useRouter } from 'next/navigation';

export default function ProjectsPage() {
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [projectType, setProjectType] = useState('');
  const [priority, setPriority] = useState('');
  const [sortBy, setSortBy] = useState('createdAt');

  const debouncedSearch = useDebounce(search, 500);

  // Fetch projects
  const { data: projectsData, isLoading: isProjectsLoading } = useQuery({
    queryKey: ['projects', debouncedSearch, status, projectType, priority, sortBy],
    queryFn: async () => {
      const params = {
        page: 1,
        limit: 100,
        search: debouncedSearch || undefined,
        status: status || undefined,
        projectType: projectType || undefined,
        priority: priority || undefined,
        sortBy,
      };
      const res = await projectService.getProjects(params);
      return res.data;
    },
  });

  const projects = projectsData || [];

  // Stats
  const { data: statsData, isLoading: isStatsLoading } = useQuery({
    queryKey: ['projectStats'],
    queryFn: async () => {
      const res = await projectService.getProjectStats();
      const counts = { total: 0, planning: 0, active: 0, completed: 0, cancelled: 0 };
      res.data.forEach((p) => {
        counts.total++;
        counts[p.status]++;
      });
      return counts;
    },
  });

  const queryClient = useQueryClient();
  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['projects'] });
  };

  const handleNewProject = () => {
    router.push('/dashboard/projects/create');
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold tracking-tight">Projects</h1>
            <p className="text-muted-foreground mt-1 text-lg">
              Manage and monitor all your projects.
            </p>
          </div>

          <Button size="lg" onClick={handleNewProject}>
            <Plus className="h-5 w-5 mr-2" />
            New Project
          </Button>
        </div>

        {/* Stats Cards */}
        {isStatsLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-2xl" />
            ))}
          </div>
        ) : (
          <ProjectStatsCards stats={statsData || {}} />
        )}

        {/* Filters */}
        <ProjectFilters
          search={search}
          setSearch={setSearch}
          status={status}
          setStatus={setStatus}
          projectType={projectType}
          setProjectType={setProjectType}
          priority={priority}
          setPriority={setPriority}
          sortBy={sortBy}
          setSortBy={setSortBy}
          onRefresh={handleRefresh}
          isLoading={isProjectsLoading}
        />

        {/* Table / Empty State */}
        <div className="mt-8">
          {isProjectsLoading ? (
            <div className="space-y-6">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full rounded-2xl" />
              ))}
            </div>
          ) : projects.length === 0 ? (
            <EmptyState
              icon={<Plus className="h-12 w-12" />}
              title="No projects yet"
              description="Get started by creating your first project."
              action={
                <Button size="lg" onClick={handleNewProject}>
                  <Plus className="h-5 w-5 mr-2" />
                  Create Project
                </Button>
              }
            />
          ) : (
            <ProjectsTable projects={projects} />
          )}
        </div>
      </div>
    </div>
  );
}