'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  ArrowLeft,
  Loader2,
  CalendarIcon,
  CheckCircle2,
  Check,
  ClipboardList,
  CalendarDays,
  Wallet,
  Eye,
  AlertCircle,
  Coins,
} from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import projectService from '@/services/project.service';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';

const statusOptions = ['planning', 'active', 'on_hold'];
const typeOptions = ['internal', 'client', 'product'];
const priorityOptions = ['low', 'medium', 'high', 'critical'];
const visibilityOptions = ['private', 'public'];

const currencies = [
  { code: 'USD', symbol: '$', label: 'US Dollar' },
  { code: 'INR', symbol: '₹', label: 'Indian Rupee' },
  { code: 'EUR', symbol: '€', label: 'Euro' },
];

const steps = [
  { id: 1, label: 'Project Info' },
  { id: 2, label: 'Schedule & Budget' },
  { id: 3, label: 'Preview' },
];

// Fields that must be valid before leaving each step
const stepFields = {
  1: ['name'],
  2: ['startDate', 'endDate', 'estimatedHours', 'budget.estimated', 'budget.approved'],
};

const schema = z.object({
  name: z.string().min(1, 'Project name is required'),
  description: z.string().optional(),
  projectType: z.enum(typeOptions),
  status: z.enum(statusOptions),
  priority: z.enum(priorityOptions),
  visibility: z.enum(visibilityOptions),
  startDate: z.string().min(1, 'Start date is required'),
  endDate: z.string().min(1, 'End date is required'),
  estimatedHours: z.coerce.number().min(0, 'Must be 0 or greater'),
  currency: z.enum(currencies.map((c) => c.code)),
  budget: z.object({
    estimated: z.coerce.number().min(0, 'Must be 0 or greater'),
    approved: z.coerce.number().min(0, 'Must be 0 or greater'),
  }),
});

// Small helper so every field label reads the same way
function FieldLabel({ children, required }) {
  return (
    <Label className="text-base font-medium text-foreground">
      {children}
      {required && <span className="text-red-500 ml-0.5">*</span>}
    </Label>
  );
}

function FieldError({ message }) {
  if (!message) return null;
  return (
    <p className="text-red-500 text-sm flex items-center gap-1 mt-1.5">
      <AlertCircle className="h-3.5 w-3.5" /> {message}
    </p>
  );
}

function SectionCard({ icon: Icon, title, description, children }) {
  return (
    <Card className="">
      <CardHeader className="pb-5">
        <div className="flex items-center gap-2.5">
          {Icon && (
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
              <Icon className="h-4.5 w-4.5" />
            </span>
          )}
          <div>
            <CardTitle className="text-xl font-semibold">{title}</CardTitle>
            {description && (
              <CardDescription className="text-base">{description}</CardDescription>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-7">{children}</CardContent>
    </Card>
  );
}

// Step indicator — circle on top, label below the circle, connecting line runs through the circles
function StepIndicator({ currentStep }) {
  return (
    <div className="flex items-start w-full">
      {steps.map((step, idx) => {
        const isComplete = currentStep > step.id;
        const isActive = currentStep === step.id;
        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-sm font-semibold transition-colors',
                  isComplete && 'border-primary bg-primary text-primary-foreground',
                  isActive && 'border-primary text-primary',
                  !isComplete && !isActive && 'border-muted text-muted-foreground'
                )}
              >
                {isComplete ? <Check className="h-4.5 w-4.5" /> : step.id}
              </div>
              <span
                className={cn(
                  'mt-2 text-sm font-medium whitespace-nowrap',
                  isActive || isComplete ? 'text-foreground' : 'text-muted-foreground'
                )}
              >
                {step.label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <div
                className={cn(
                  'h-px flex-1 mx-4 mt-[18px]',
                  isComplete ? 'bg-primary' : 'bg-border'
                )}
              />
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function CreateProjectPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [currentStep, setCurrentStep] = useState(1);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    watch,
    setValue,
    trigger,
    setError,
  } = useForm({
    resolver: zodResolver(schema),
    mode: 'onChange',
    defaultValues: {
      projectType: 'internal',
      status: 'planning',
      priority: 'medium',
      visibility: 'private',
      estimatedHours: 0,
      currency: 'USD',
      budget: { estimated: 0, approved: 0 },
    },
  });

  const startDate = watch('startDate');
  const endDate = watch('endDate');
  const currencyCode = watch('currency');
  const currencySymbol = currencies.find((c) => c.code === currencyCode)?.symbol ?? '$';

  const handleEndDateSelect = (date) => {
    if (date && startDate && new Date(date) < new Date(startDate)) {
      setError('endDate', { type: 'manual', message: 'End date cannot be before start date' });
      return;
    }
    setValue('endDate', date ? date.toISOString().split('T')[0] : '');
    trigger('endDate');
  };

  const createMutation = useMutation({
    mutationFn: projectService.createProject,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setShowSuccess(true);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to create project');
      setShowError(true);
    },
  });

  const onSubmit = (data) => createMutation.mutate(data);

  const handleSuccessClose = () => {
    setShowSuccess(false);
    router.push('/projects');
  };

  const handleErrorClose = () => {
    setShowError(false);
    setErrorMessage('');
  };

  const nextStep = async () => {
    const fieldsToValidate = stepFields[currentStep];
    const valid = fieldsToValidate ? await trigger(fieldsToValidate) : true;
    if (valid && currentStep < 3) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleCancel = () => {
    router.push('/dashboard/projects');
  };

  return (
    <div className="min-h-screen ">
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="w-full "
      >
        {/* Header — separate from the form background, back button + title only */}
        <div className="flex items-center gap-3 py-4">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => router.back()}
            className="h-10 w-10 shrink-0 -ml-2"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-semibold leading-tight">New project</h1>
        </div>

        {/* Everything below — step indicator, form, actions — shares one background */}
        <div className="rounded-2xl border border-border p-6 lg:p-10 space-y-8">
          <StepIndicator currentStep={currentStep} />

        {/* Step 1 — Project Information */}
        <div className={cn('transition-opacity duration-300', currentStep === 1 ? 'block' : 'hidden')}>
          <SectionCard
            icon={ClipboardList}
            title="Project information"
            description="What this project is and who it's for."
          >
            <div className="space-y-2">
              <FieldLabel required>Project name</FieldLabel>
              <Input
                placeholder="e.g. Q4 Marketing Campaign"
                {...register('name')}
                className={cn('h-12 text-base w-full', errors.name && 'border-red-500 focus-visible:ring-red-500')}
              />
              <FieldError message={errors.name?.message} />
            </div>

            <div className="space-y-2">
              <FieldLabel>Description</FieldLabel>
              <Textarea
                placeholder="A couple of sentences on scope and goals…"
                className="min-h-[108px] resize-y text-base w-full"
                {...register('description')}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="space-y-2">
                <FieldLabel>Type</FieldLabel>
                <Select defaultValue={typeOptions[0]} onValueChange={(v) => setValue('projectType', v)}>
                  <SelectTrigger className="h-12 text-base w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {typeOptions.map((t) => (
                      <SelectItem key={t} value={t} className="capitalize text-base">
                        {t}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <FieldLabel>Status</FieldLabel>
                <Select defaultValue="planning" onValueChange={(v) => setValue('status', v)}>
                  <SelectTrigger className="h-12 text-base w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {statusOptions.map((s) => (
                      <SelectItem key={s} value={s} className="capitalize text-base">
                        {s.replace('_', ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <FieldLabel>Priority</FieldLabel>
                <Select defaultValue={priorityOptions[1]} onValueChange={(v) => setValue('priority', v)}>
                  <SelectTrigger className="h-12 text-base w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {priorityOptions.map((p) => (
                      <SelectItem key={p} value={p} className="capitalize text-base">
                        {p}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <FieldLabel>Visibility</FieldLabel>
                <Select defaultValue={visibilityOptions[0]} onValueChange={(v) => setValue('visibility', v)}>
                  <SelectTrigger className="h-12 text-base w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {visibilityOptions.map((v) => (
                      <SelectItem key={v} value={v} className="capitalize text-base">
                        {v}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </SectionCard>
        </div>

        {/* Step 2 — Schedule & Budget */}
        <div className={cn('transition-opacity duration-300 space-y-8', currentStep === 2 ? 'block' : 'hidden')}>
          <SectionCard icon={CalendarDays} title="Schedule" description="When the project runs, and how it's tracked.">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="space-y-2">
                <FieldLabel required>Start date</FieldLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className={cn(
                        'w-full h-12 justify-start font-normal text-base',
                        !startDate && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-5 w-5 shrink-0" />
                      {startDate ? new Date(startDate).toLocaleDateString() : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={startDate ? new Date(startDate) : undefined}
                      onSelect={(date) => setValue('startDate', date ? date.toISOString().split('T')[0] : '')}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FieldError message={errors.startDate?.message} />
              </div>

              <div className="space-y-2">
                <FieldLabel required>End date</FieldLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className={cn(
                        'w-full h-12 justify-start font-normal text-base',
                        !endDate && 'text-muted-foreground'
                      )}
                    >
                      <CalendarIcon className="mr-2 h-5 w-5 shrink-0" />
                      {endDate ? new Date(endDate).toLocaleDateString() : 'Pick a date'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={endDate ? new Date(endDate) : undefined}
                      onSelect={handleEndDateSelect}
                      disabled={(date) => startDate && date < new Date(startDate)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FieldError message={errors.endDate?.message} />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="space-y-2">
                <FieldLabel>Estimated hours</FieldLabel>
                <Input
                  type="number"
                  placeholder="120"
                  {...register('estimatedHours', { valueAsNumber: true })}
                  className={cn('h-12 text-base w-full', errors.estimatedHours && 'border-red-500 focus-visible:ring-red-500')}
                />
                <FieldError message={errors.estimatedHours?.message} />
              </div>
            </div>
          </SectionCard>

          <SectionCard icon={Wallet} title="Budget" description="Financial planning for the project.">
            <div className="space-y-2">
              <FieldLabel>Currency</FieldLabel>
              <Select
                defaultValue="USD"
                onValueChange={(v) => setValue('currency', v)}
              >
                <SelectTrigger className="h-12 text-base w-full sm:w-64">
                  <div className="flex items-center gap-2">
                    <Coins className="h-4 w-4 text-muted-foreground shrink-0" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((c) => (
                    <SelectItem key={c.code} value={c.code} className="text-base">
                      <span className="font-medium mr-1.5">{c.symbol}</span>
                      {c.label} ({c.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="space-y-2">
                <FieldLabel>Estimated budget</FieldLabel>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-base pointer-events-none">
                    {currencySymbol}
                  </span>
                  <Input
                    type="number"
                    placeholder="100,000"
                    {...register('budget.estimated', { valueAsNumber: true })}
                    className={cn('pl-9 h-12 text-base w-full', errors.budget?.estimated && 'border-red-500 focus-visible:ring-red-500')}
                  />
                </div>
                <FieldError message={errors.budget?.estimated?.message} />
              </div>

              <div className="space-y-2">
                <FieldLabel>Approved budget</FieldLabel>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-base pointer-events-none">
                    {currencySymbol}
                  </span>
                  <Input
                    type="number"
                    placeholder="100,000"
                    {...register('budget.approved', { valueAsNumber: true })}
                    className={cn('pl-9 h-12 text-base w-full', errors.budget?.approved && 'border-red-500 focus-visible:ring-red-500')}
                  />
                </div>
                <FieldError message={errors.budget?.approved?.message} />
              </div>
            </div>
          </SectionCard>
        </div>

        {/* Step 3 — Preview */}
        <div className={cn('transition-opacity duration-300', currentStep === 3 ? 'block' : 'hidden')}>
          <SectionCard icon={Eye} title="Preview" description="All your project details — ready to create!">
            <div className="space-y-6">
              <div className="space-y-2">
                <FieldLabel>Project name</FieldLabel>
                <div className="bg-muted/30 rounded-md px-4 py-3 text-base font-medium">
                  {watch('name') || '—'}
                </div>
              </div>

              <div className="space-y-2">
                <FieldLabel>Description</FieldLabel>
                <div className="bg-muted/30 rounded-md px-4 py-3 min-h-[88px] text-base">
                  {watch('description') || '—'}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="space-y-2">
                  <FieldLabel>Type</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">
                    {watch('projectType')}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Status</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">
                    {watch('status').replace('_', ' ')}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Priority</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">
                    {watch('priority')}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Visibility</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base capitalize">
                    {watch('visibility')}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Start date</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base">
                    {startDate ? new Date(startDate).toLocaleDateString() : '—'}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>End date</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base">
                    {endDate ? new Date(endDate).toLocaleDateString() : '—'}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Estimated hours</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base">
                    {watch('estimatedHours')}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Currency</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base">
                    {currencySymbol} {currencyCode}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Estimated budget</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base">
                    {currencySymbol}{watch('budget.estimated')}
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Approved budget</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base">
                    {currencySymbol}{watch('budget.approved')}
                  </div>
                </div>
              </div>
            </div>
          </SectionCard>
        </div>

        {/* Bottom navigation — Previous / Next / Cancel (preview only) / Submit (preview only), one row */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div>
            {currentStep > 1 && (
              <Button type="button" variant="outline" onClick={prevStep} className="h-12 px-6 text-base">
                Previous
              </Button>
            )}
          </div>

          <div className="flex items-center gap-3">
            {currentStep === 3 && (
              <Button type="button" variant="outline" onClick={handleCancel} className="h-12 px-6 text-base">
                Cancel
              </Button>
            )}

            {currentStep < 3 && (
              <Button type="button" onClick={nextStep} className="h-12 px-8 text-base">
                Next
              </Button>
            )}

            {currentStep === 3 && (
              <Button type="submit" disabled={isSubmitting} className="h-12 px-8 text-base min-w-[160px]">
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Creating…
                  </>
                ) : (
                  'Create project'
                )}
              </Button>
            )}
          </div>
        </div>
        </div>
      </form>

      {/* Success & Error dialogs */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-emerald-600">
              <CheckCircle2 className="h-5 w-5" />
              Project created
            </DialogTitle>
            <DialogDescription>
              Your new project is live in the dashboard.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button onClick={handleSuccessClose} className="w-full">
              Go to projects
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showError} onOpenChange={setShowError}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-600">
              <AlertCircle className="h-5 w-5" />
              {`Couldn't create project`}
            </DialogTitle>
            <DialogDescription>{errorMessage}</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={handleErrorClose} className="w-full">
              Try again
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}