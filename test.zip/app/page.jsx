"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import useAuthStore from "@/store/auth-store";
 

export default function HomePage() {
  const router = useRouter();

  useEffect(() => {
    // Initialize auth store
    useAuthStore.getState().initialize();

    const { token } = useAuthStore.getState();

    if (token) {
      router.replace("/dashboard");
    } else {
      router.replace("/login");
    }
  }, [router]);

  return (
    <div className="flex h-screen items-center justify-center bg-zinc-950">
      <div className="flex flex-col items-center gap-4">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-zinc-700 border-t-white"></div>
        <p className="text-sm text-zinc-400">Loading...</p>
      </div>
    </div>
  );
}