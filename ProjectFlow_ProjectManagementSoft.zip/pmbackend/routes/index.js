import express from 'express';
import { authMiddleware, projectManagerMiddleware } from '../middleware/auth.js';
import * as authController from '../controllers/authController.js';
import * as userController from '../controllers/userController.js';
import * as workspaceController from '../controllers/workspaceController.js';
import * as projectController from '../controllers/projectController.js';
import * as taskController from '../controllers/taskController.js';
import * as dashboardController from '../controllers/dashboardController.js';
import * as commentController from '../controllers/commentController.js';
import * as reportController from '../controllers/reportController.js';
import * as notificationController from '../controllers/notificationController.js';
import * as chatController from '../controllers/chatController.js';
import * as resourceController from '../controllers/resourceController.js';
import * as organizationController from '../controllers/organizationController.js';

import { handleUploadErrors, uploadResource } from '../middleware/uploadResource.js';
import { handleAvatarUploadErrors, uploadAvatar } from '../middleware/avatarUpload.js';

const router = express.Router();

// Auth routes
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);

// Dashboard route
router.get('/dashboard', authMiddleware, dashboardController.getDashboardSummary);

// User routes
router.get('/users/profile', authMiddleware, userController.getProfile);
router.put('/users/profile', authMiddleware, userController.updateProfile);
router.put('/users/profile/avatar', authMiddleware, uploadAvatar.single('avatar'), handleAvatarUploadErrors, userController.updateAvatar);
router.get('/users', authMiddleware, userController.listUsers);
router.get('/users/:id', authMiddleware, userController.getUser);
router.put('/users/profile/change-password', authMiddleware, userController.changePassword);
router.delete('/users/profile/avatar', authMiddleware, userController.deleteAvatar);

// Project routes (permissions are org-synced and enforced entirely server-side).
// Projects keep using Mongo _id — they don't have their own slug.
router.get('/projects', authMiddleware, projectController.list);
router.get('/projects/:id', authMiddleware, projectController.get);
router.post('/projects', authMiddleware, projectController.create);
router.put('/projects/:id', authMiddleware, projectController.update);
router.get('/projects/:id/stats', authMiddleware, projectController.getStats);
router.patch('/projects/:id/status', authMiddleware, projectController.updateStatus);
router.delete('/projects/:id', authMiddleware, projectController.remove);
router.patch('/projects/:id/restore', authMiddleware, projectController.restore);

router.post('/projects/:projectId/team', authMiddleware, projectController.addTeamMember);
router.delete('/projects/:projectId/team/:userId', authMiddleware, projectController.removeTeamMember);
router.patch('/projects/:projectId/team/:userId', authMiddleware, projectController.updateTeamMember);
router.delete('/projects/:projectId/milestone/:milestoneId', authMiddleware, projectController.removeMilestone);

// Task routes
router.get('/tasks/project/:projectId/stats', authMiddleware, taskController.getUserTaskStats);
router.get('/tasks/project/:projectId', authMiddleware, taskController.listByProject);

router.get('/tasks/me', authMiddleware, taskController.getMyTasks);
router.get('/tasks/me/stats', authMiddleware, taskController.getMyTaskStats);

router.get('/tasks/:id', authMiddleware, taskController.get);
router.post('/tasks/project/:projectId', authMiddleware, taskController.create);
router.put('/tasks/:id', authMiddleware, taskController.update);
router.delete('/tasks/:id', authMiddleware, taskController.remove);
router.get('/tasks/:projectId/creation-data', authMiddleware, taskController.getTaskCreationData);

router.post('/tasks/:taskId/start-timer', authMiddleware, taskController.startTimer);
router.post('/tasks/:taskId/stop-timer', authMiddleware, taskController.stopTimer);
router.post('/tasks/:taskId/resume-timer', authMiddleware, taskController.resumeTimer);
router.post('/tasks/:taskId/finish', authMiddleware, taskController.finishTask);
router.get('/tasks/:taskId/timer', authMiddleware, taskController.getTimerStatus);

// Watcher routes
router.post('/tasks/:id/watchers', authMiddleware, taskController.addWatcher);
router.delete('/tasks/:id/watchers', authMiddleware, taskController.removeWatcher);

// Attachment routes
router.post('/tasks/:id/attachments', authMiddleware, taskController.addAttachment);
router.delete('/tasks/:id/attachments/:attachmentId', authMiddleware, taskController.removeAttachment);

// Work log routes
router.post('/tasks/:taskId/worklog/project/:projectId', authMiddleware, taskController.addWorkLog);

// Gantt route
router.get('/tasks/project/:projectId/gantt', authMiddleware, taskController.getGanttData);
router.post('/tasks/:id/checklist', authMiddleware, taskController.addChecklistItem);
router.patch('/tasks/:id/checklist/:itemId', authMiddleware, taskController.toggleChecklistItem);
router.delete('/tasks/:id/checklist/:itemId', authMiddleware, taskController.removeChecklistItem);

// Comment routes
router.get('/tasks/:taskId/comments', authMiddleware, commentController.listByTask);
router.post('/tasks/:taskId/comments', authMiddleware, commentController.create);
router.put('/comments/:commentId', authMiddleware, commentController.update);
router.delete('/comments/:commentId', authMiddleware, commentController.remove);
router.post('/comments/:commentId/replies', authMiddleware, commentController.addReply);

router.get('/tasks/project/:projectId/kanban', authMiddleware, taskController.getKanbanBoards);
router.patch('/tasks/:taskId/move', authMiddleware, taskController.moveTask);

// Report routes
router.get('/reports/projects/:projectId/gantt', authMiddleware, reportController.getProjectGantt);
router.get('/reports/projects/:projectId/overview', authMiddleware, reportController.getProjectOverview);
router.get('/reports/projects/:projectId/task-status', authMiddleware, reportController.getProjectTaskStatus);
router.get('/reports/projects/:projectId/milestones', authMiddleware, reportController.getProjectMilestones);
router.get('/reports/projects/:projectId/team-performance', authMiddleware, reportController.getProjectTeamPerformance);
router.get('/reports/projects/:projectId/estimated-vs-actual', authMiddleware, reportController.getProjectEstimatedVsActual);
router.get('/reports/projects/:projectId/overdue', authMiddleware, reportController.getProjectOverdueTasks);
router.get('/reports/projects/:projectId/completion-trend', authMiddleware, reportController.getProjectCompletionTrend);
router.get('/reports/projects/:projectId/dashboard', authMiddleware, reportController.getProjectReportsDashboard);

router.get('/notifications', authMiddleware, notificationController.list);
router.get('/notifications/unread-count', authMiddleware, notificationController.getUnreadCount);
router.patch('/notifications/:id/read', authMiddleware, notificationController.markAsRead);
router.patch('/notifications/read-all', authMiddleware, notificationController.markAllAsRead);
router.delete('/notifications/:id', authMiddleware, notificationController.remove);
router.delete('/notifications', authMiddleware, notificationController.removeAll);

router.get('/projects/:projectId/messages', authMiddleware, chatController.list);
router.post('/projects/:projectId/messages', authMiddleware, chatController.create);
router.put('/messages/:messageId', authMiddleware, chatController.update);
router.delete('/messages/:messageId', authMiddleware, chatController.remove);
router.patch('/projects/:projectId/messages/read', authMiddleware, chatController.markRead);
router.get('/projects/:projectId/messages/unread-count', authMiddleware, chatController.getUnreadCount);
router.post('/messages/:messageId/react', authMiddleware, chatController.react);

/* Folders */
router.post('/projects/:projectId/folders', authMiddleware, resourceController.createFolder);
router.get('/projects/:projectId/folders', authMiddleware, resourceController.listFolders);
router.patch('/folders/:folderId', authMiddleware, resourceController.renameFolder);
router.delete('/folders/:folderId', authMiddleware, resourceController.deleteFolder);

/* Files — list / upload */
router.get('/projects/:projectId/files', authMiddleware, resourceController.listFiles);
router.post('/projects/:projectId/files', authMiddleware, uploadResource.single('file'), handleUploadErrors, resourceController.uploadFile);

/* Files — single-item operations */
router.get('/files/:fileId', authMiddleware, resourceController.getFile);
router.get('/files/:fileId/download', authMiddleware, resourceController.downloadFile);
router.patch('/files/:fileId/rename', authMiddleware, resourceController.renameFile);
router.patch('/files/:fileId/move', authMiddleware, resourceController.moveFile);
router.delete('/files/:fileId', authMiddleware, resourceController.deleteFile);
router.put('/files/:fileId/replace', authMiddleware, uploadResource.single('file'), handleUploadErrors, resourceController.replaceFile);

/* Versions */
router.get('/files/:fileId/versions', authMiddleware, resourceController.listVersions);
router.get('/files/:fileId/versions/:version/download', authMiddleware, resourceController.downloadVersion);
router.post('/files/:fileId/versions/:version/restore', authMiddleware, resourceController.restoreVersion);

/* Sharing */
router.post('/files/:fileId/share', authMiddleware, resourceController.shareFile);
router.delete('/files/:fileId/share/:userId', authMiddleware, resourceController.unshareFile);

// ============ Organization routes ============
router.post('/organizations', authMiddleware, organizationController.create);
router.get('/organizations', authMiddleware, organizationController.list);
router.get('/organizations/invites/me', authMiddleware, organizationController.listMyInvites);
router.get('/organizations/invitations/me', authMiddleware, organizationController.listMyInvites);

// Everything below is keyed by the organization SLUG (matches
// organization.service.js on the frontend), not the Mongo _id.
router.get('/organizations/:slug', authMiddleware, organizationController.get);
router.put('/organizations/:slug', authMiddleware, organizationController.update);
router.delete('/organizations/:slug', authMiddleware, organizationController.remove);

router.post('/organizations/:slug/invite', authMiddleware, organizationController.inviteMember);
router.patch('/organizations/:slug/invite/respond', authMiddleware, organizationController.respondToInvite);
router.get('/organizations/:slug/members', authMiddleware, organizationController.listMembers);
router.patch('/organizations/:slug/members/:userId/role', authMiddleware, organizationController.updateMemberRole);
router.patch('/organizations/:slug/members/:userId/permissions', authMiddleware, organizationController.updateMemberPermissions);
router.delete('/organizations/:slug/members/:userId', authMiddleware, organizationController.removeMember);

// Workload lives at the organization level only (removed from projects)
router.get('/organizations/:slug/workload', authMiddleware, organizationController.getOrgWorkload);

router.post('/organizations/:slug/invitations', authMiddleware, organizationController.inviteMember);
router.get('/organizations/:slug/invitations', authMiddleware, organizationController.listOrgInvitations);

// Invitation routes stay keyed by invitation id/token/code — these were
// never organization-slug routes to begin with.
router.get('/invitations/validate/:token', organizationController.validateInvitationToken);
router.get('/invitations/validate-code/:code', organizationController.validateInvitationCode);
router.post('/invitations/join-by-code', authMiddleware, organizationController.joinByCode);
router.get('/invitations/reject/:token', organizationController.declineInvitationByToken);
router.post('/invitations/:id/resend', authMiddleware, organizationController.resendInvitation);
router.delete('/invitations/:id', authMiddleware, organizationController.revokeInvitation);
router.patch('/invitations/:id/accept', authMiddleware, organizationController.acceptInvitation);
router.patch('/invitations/:id/decline', authMiddleware, organizationController.declineInvitation);

export default router;