// routes/organizations.js
import express from 'express';
import * as orgController from '../controllers/organizationController.js';

const router = express.Router();

// ====================== SLUG ROUTES (layout uses these) ======================
router.get('/:slug', orgController.get);
router.put('/:slug', orgController.update);
router.delete('/:slug', orgController.remove);

router.post('/:slug/invite', orgController.inviteMember);
router.get('/:slug/invitations', orgController.listOrgInvitations);
router.get('/:slug/members', orgController.listMembers);
router.get('/:slug/workload', orgController.getOrgWorkload);

router.patch('/:slug/members/:userId/role', orgController.updateMemberRole);
router.patch('/:slug/members/:userId/permissions', orgController.updateMemberPermissions);
router.delete('/:slug/members/:userId', orgController.removeMember);

// ====================== YOUR ORIGINAL ID ROUTES (kept 100%) ======================
router.post('/', orgController.create);
router.get('/', orgController.list);
router.get('/:id', orgController.get);
router.put('/:id', orgController.update);
router.delete('/:id', orgController.remove);

router.post('/:id/invite', orgController.inviteMember);
router.patch('/:id/invite/respond', orgController.respondToInvite);
router.get('/:id/members', orgController.listMembers);
router.patch('/:id/members/:userId/role', orgController.updateMemberRole);
router.patch('/:id/members/:userId/permissions', orgController.updateMemberPermissions);
router.delete('/:id/members/:userId', orgController.removeMember);

router.get('/invitations/validate/:token', orgController.validateInvitationToken);
router.get('/invitations/validate-code/:code', orgController.validateInvitationCode);
router.post('/invitations/join-by-code', orgController.joinByCode);
router.get('/invitations/reject/:token', orgController.declineInvitationByToken);
router.post('/invitations/:id/resend', orgController.resendInvitation);
router.delete('/invitations/:id', orgController.revokeInvitation);

router.get('/organizations/invitations/me', orgController.listMyInvites);
router.patch('/invitations/:id/accept', orgController.acceptInvitation);
router.patch('/invitations/:id/decline', orgController.declineInvitation);

export default router;