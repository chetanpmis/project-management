import mongoose from 'mongoose';

const activitySchema = new mongoose.Schema({
  organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
  project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', default: null, index: true },
  task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task', default: null, index: true },

  level: {
    type: String,
    enum: ['organization', 'project', 'task'],
    required: true,
    index: true,
  },

  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

  type: {
    type: String,
    enum: [
      // Organization
      'org_created', 'org_updated', 'org_deleted',
      'org_member_invited', 'org_member_joined', 'org_member_declined',
      'org_member_removed', 'org_member_left',
      'org_member_role_changed', 'org_member_permissions_changed',

      // Project
      'project_created', 'project_updated', 'project_archived', 'project_deleted',
      'project_restored', 'project_status_changed',

      // Team (project-level)
      'member_added', 'member_removed', 'member_role_changed',
      'member_permissions_changed', 'member_updated',

      // Task
      'task_created', 'task_updated', 'task_deleted', 'task_status_changed',
      'task_assigned', 'task_unassigned',

      // Checklist
      'checklist_updated',

      // Comments
      'comment_added', 'comment_deleted',

      // Files / Attachments
      'file_uploaded', 'file_deleted', 'attachment_added', 'attachment_removed',
      'file_renamed', 'file_moved', 'file_shared', 'file_unshared', 'file_replaced',

      // Watchers
      'watcher_added', 'watcher_removed',

      // Budget
      'budget_updated', 'expense_added', 'expense_approved',

      // Milestones
      'milestone_created', 'milestone_completed', 'milestone_removed',

      // Work Logs / Time
      'work_log_added', 'work_log_approved',

      // Workload
      'workload_updated',

      // Chat / Messages
      'chat_message_sent', 'chat_message_edited', 'chat_message_deleted',
    ],
    required: true,
  },
  entity: String,
  entityId: mongoose.Schema.Types.ObjectId,
  previousValue: mongoose.Schema.Types.Mixed,
  newValue: mongoose.Schema.Types.Mixed,
  description: String,
  createdAt: { type: Date, default: Date.now },
});

activitySchema.index({ organization: 1, level: 1, createdAt: -1 });
activitySchema.index({ project: 1, createdAt: -1 });
activitySchema.index({ task: 1, createdAt: -1 });

export default mongoose.model('Activity', activitySchema);