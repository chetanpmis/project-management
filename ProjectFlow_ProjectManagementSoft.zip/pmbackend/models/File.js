
import mongoose from 'mongoose';


const folderSchema = new mongoose.Schema(
  {
    project: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project',
      required: true,
      index: true,
    },

    name: {
      type: String,
      required: [true, 'Folder name is required.'],
      trim: true,
      maxlength: [100, 'Folder name cannot exceed 100 characters.'],
      set: (value) => value?.trim(),
      validate: {
        validator(value) {
          return typeof value === 'string' && value.trim().length > 0;
        },
        message: 'Folder name cannot be empty.',
      },
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    isDeleted: {
      type: Boolean,
      default: false,
      index: true,
    },

    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

// Unique folder name per project
folderSchema.index(
  {
    project: 1,
    name: 1,
    isDeleted: 1,
  },
  {
    unique: true,
  }
);



// Unique folder name per project (case-sensitive at DB level; controller
// does a case-insensitive check before insert for a friendlier error)
folderSchema.index({ project: 1, name: 1, isDeleted: 1 }, { unique: true });

/* ===========================
   File Version Schema
=========================== */
const versionSchema = new mongoose.Schema(
  {
    version: { type: Number, required: true },
    filename: { type: String, required: true },
    originalName: { type: String, required: true },
    url: { type: String, required: true },
    size: { type: Number, required: true },
    mimeType: { type: String, required: true },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    uploadedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

/* ===========================
   Shared User Schema
=========================== */
const sharedUserSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    permission: { type: String, enum: ['view', 'edit'], default: 'view' },
    sharedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    sharedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

/* ===========================
   File Schema
=========================== */
const fileSchema = new mongoose.Schema(
  {
    project: { type: mongoose.Schema.Types.ObjectId, ref: 'Project', required: true, index: true },
    task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task', default: null },
    folder: { type: mongoose.Schema.Types.ObjectId, ref: 'Folder', default: null, index: true },

    filename: { type: String, required: true, trim: true },
    originalName: { type: String, required: true },
    url: { type: String, required: true },
    size: { type: Number, required: true },
    mimeType: { type: String, required: true },

    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },

    visibility: { type: String, enum: ['team', 'private'], default: 'team' },
    sharedWith: [sharedUserSchema],

    currentVersion: { type: Number, default: 1 },
    versions: [versionSchema],

    isDeleted: { type: Boolean, default: false, index: true },
    deletedAt: Date,
  },
  { timestamps: true }
);

fileSchema.index({ project: 1, folder: 1, isDeleted: 1 });
fileSchema.index({ project: 1, uploadedBy: 1 });
fileSchema.index({ filename: 'text', originalName: 'text' });

/* ===========================
   Instance helper: can a given user access this file?
   (owner / manager / uploader / explicit share)
=========================== */
fileSchema.methods.isAccessibleBy = function (userId, projectRole) {
  const uid = userId.toString();
  if (projectRole === 'owner' || projectRole === 'manager') return true;
  if (this.uploadedBy.toString() === uid) return true;
  if (this.visibility === 'team') return true;
  return this.sharedWith.some((s) => s.user.toString() === uid);
};

fileSchema.methods.editPermissionFor = function (userId, projectRole) {
  const uid = userId.toString();
  if (projectRole === 'owner' || projectRole === 'manager') return true;
  if (this.uploadedBy.toString() === uid) return true;
  const share = this.sharedWith.find((s) => s.user.toString() === uid);
  return !!share && share.permission === 'edit';
};

export const Folder = mongoose.model('Folder', folderSchema);
const File = mongoose.model('File', fileSchema);
export default File;