
import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  type: {
    type: String,
    enum: [
      // Task lifecycle
      'task_assigned', 'task_created', 'task_updated', 'task_deleted', 'task_moved',
      'task_status_changed', 'task_mentioned', 'task_commented',
      // Deadlines
      'task_deadline', 'task_overdue', 'project_deadline', 'project_overdue',
      // Task sub-resources
      'watcher_added', 'watcher_removed', 'attachment_added', 'attachment_removed',
      'checklist_updated', 'work_log_added', 'work_log_approved',
      // Project lifecycle
      'project_created', 'project_updated', 'project_deleted', 'project_status_changed',
      'project_invitation','',
      // Team (project-level)
      'member_added', 'member_removed', 'member_updated', 'member_role_changed',
      // Milestones
      'milestone_created', 'milestone_completed', 'milestone_removed',
      // Budget
      'budget_alert', 'expense_approved',
      // Files
      'file_uploaded', 'file_deleted', 'attachment_added', 'attachment_removed',
      'file_renamed', 'file_moved', 'file_shared', 'file_unshared', 'file_replaced',

      // ---- Organization-level (NEW) ----
      'org_invitation',            // you were invited to join an org
      'org_invite_accepted',       // someone accepted your invite
      'org_invite_declined',       // someone declined your invite
      'org_member_removed',        // you were removed from an org
      'org_member_left',           // someone left the org you admin
      'org_role_changed',          // your role in the org changed
      'org_permissions_changed',   // your permissions in the org changed
      'org_updated',               // org settings/profile changed
      'org_deleted',               // org was deleted
      'org_admin_added',           // you were promoted to admin
    ],
    required: true,
  },
  title: String,
  message: String,
  read: { type: Boolean, default: false },
  readAt: Date,
  relatedOrganization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization' },
  relatedTask: { type: mongoose.Schema.Types.ObjectId, ref: 'Task' },
  relatedProject: { type: mongoose.Schema.Types.ObjectId, ref: 'Project' },
  relatedUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  link: String,
  createdAt: { type: Date, default: Date.now },
});

notificationSchema.index({ user: 1, read: 1, createdAt: -1 });
notificationSchema.index({ type: 1, relatedTask: 1, createdAt: -1 });
notificationSchema.index({ type: 1, relatedProject: 1, createdAt: -1 });
notificationSchema.index({ type: 1, relatedOrganization: 1, createdAt: -1 });

export default mongoose.model('Notification', notificationSchema);