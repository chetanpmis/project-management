import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true, lowercase: true },
  password: { type: String, required: true },
  avatar: String,
  bio: String,
  role: { type: String, enum: ['admin', 'member'], default: 'member' },
  status: { type: String, enum: ['active', 'inactive'], default: 'active' },
  dailyCapacity: { type: Number, default: 8 },
  workingDaysPerWeek: { type: Number, default: 5 },
 activeOrganization: {
  type: mongoose.Schema.Types.ObjectId,
  ref: "Organization",
  default: null,
},
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

export default mongoose.model('User', userSchema);
