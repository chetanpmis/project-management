import mongoose from 'mongoose';
import crypto from 'crypto';

const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I confusion

const generateCode = () => {
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += CODE_CHARS[crypto.randomInt(0, CODE_CHARS.length)];
  }
  return `${code.slice(0, 4)}-${code.slice(4)}`; // e.g. AB3D-9F2K
};

const invitationSchema = new mongoose.Schema(
  {
    organization: { type: mongoose.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    email: { type: String, required: true, lowercase: true, trim: true, index: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    role: { type: String, enum: ['admin', 'manager', 'member'], default: 'member' },
    permissions: { type: [String], default: [] },
    invitedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    token: { type: String, required: true, unique: true, index: true },
    code: { type: String, required: true, unique: true, index: true }, // human-typeable fallback
    status: {
      type: String,
      enum: ['pending', 'accepted', 'declined', 'expired', 'revoked'],
      default: 'pending',
      index: true,
    },
    expiresAt: { type: Date, required: true },
    acceptedAt: { type: Date, default: null },
    declinedAt: { type: Date, default: null },
    resendCount: { type: Number, default: 0 },
    lastResentAt: { type: Date, default: null },
  },
  { timestamps: true }
);

invitationSchema.index({ organization: 1, email: 1, status: 1 });

invitationSchema.statics.generateToken = () => crypto.randomBytes(32).toString('hex');
invitationSchema.statics.generateUniqueCode = async function () {
  // extremely low collision odds (33^8), but loop defensively
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = generateCode();
    const exists = await this.exists({ code });
    if (!exists) return code;
  }
  throw new Error('Could not generate a unique invitation code, please retry.');
};

invitationSchema.methods.isExpired = function () {
  return this.status === 'pending' && this.expiresAt < new Date();
};

export default mongoose.model('Invitation', invitationSchema);