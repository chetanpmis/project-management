import mongoose from "mongoose";

const organizationSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    slug: {
      type: String,
      required: true,
      unique: true,
      index: true,
      lowercase: true,
      trim: true,
    },
    description: { type: String, default: "", trim: true },

    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    logo: { type: String, default: null },

    members: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
          required: true,
        },
        role: {
          type: String,
          enum: ["owner", "admin", "manager", "member"], // 'owner' added
          default: "member",
        },
        permissions: { type: [String], default: [] }, // always resolved + saved at write time
        status: {
          type: String,
          enum: ["pending", "accepted", "declined", "removed"],
          default: "pending",
        },
        invitedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        invitedAt: { type: Date, default: Date.now },
        joinedAt: { type: Date, default: null },
      },
    ],

    settings: {
      defaultDailyCapacity: { type: Number, default: 8 },
      workingDaysPerWeek: { type: Number, default: 5 },
      allowMemberProjectCreation: { type: Boolean, default: false },
    },

    isDeleted: { type: Boolean, default: false },
    deletedAt: { type: Date, default: null },
  },
  { timestamps: true },
);

// Owner is always an accepted admin member — enforce at creation, not schema-level.
organizationSchema.index({ owner: 1 });
organizationSchema.index({ "members.user": 1 });

export default mongoose.model("Organization", organizationSchema);
