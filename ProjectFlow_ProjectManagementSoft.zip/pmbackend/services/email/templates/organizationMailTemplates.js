import { baseTemplate, toPlainText, detailsTable, badge } from '../base.js';

export const organizationInvitationTemplate = ({ organizationName, inviterName, role, inviteUrl }) => {
  const heading = `${inviterName} invited you to ${organizationName}`;
  const bodyHtml = `
    <p>You've been invited to join <strong>${organizationName}</strong> as ${badge(role)}.</p>
    <p>Accept the invitation to start collaborating with the team.</p>
  `;
  return {
    subject: `Invitation to join ${organizationName}`,
    html: baseTemplate({ preheader: `${inviterName} invited you to join ${organizationName}`, heading, bodyHtml, buttonText: 'Accept Invitation', buttonUrl: inviteUrl }),
    text: toPlainText([`${inviterName} invited you to join "${organizationName}" as ${role}.`], 'Accept Invitation', inviteUrl),
  };
};

export const organizationCreatedTemplate = ({ organizationName, ownerName, slug, description, orgUrl }) => {
  const heading = `${organizationName} is ready`;
  const bodyHtml = `
    <p>Hi ${ownerName}, your organization has been created successfully.</p>
    ${detailsTable([
      { label: 'Organization', value: organizationName, strong: true },
      { label: 'Slug', value: slug },
      { label: 'Description', value: description },
      { label: 'Role', value: 'Owner', strong: true },
    ])}
    <p>Invite your team and start creating projects.</p>
  `;
  return {
    subject: `${organizationName} is ready to go`,
    html: baseTemplate({ preheader: `Your organization "${organizationName}" was created`, heading, bodyHtml, buttonText: 'Open Organization', buttonUrl: orgUrl }),
    text: toPlainText([`Your organization "${organizationName}" (slug: ${slug}) has been created.`, description ? `Description: ${description}` : ''].filter(Boolean), 'Open Organization', orgUrl),
  };
};

export const invitationAcceptedTemplate = ({ organizationName, memberName, role, description, orgUrl }) => {
  const heading = `Welcome to ${organizationName}`;
  const bodyHtml = `
    <p>Hi ${memberName}, you're officially part of the team.</p>
    ${detailsTable([
      { label: 'Organization', value: organizationName, strong: true },
      { label: 'Role', value: role, strong: true },
      { label: 'About', value: description },
    ])}
    <p>Head to your dashboard to see what's already in motion.</p>
  `;
  return {
    subject: `You're now part of ${organizationName}`,
    html: baseTemplate({ preheader: `Welcome to ${organizationName}`, heading, bodyHtml, buttonText: 'Open Organization', buttonUrl: orgUrl }),
    text: toPlainText([`You've joined "${organizationName}" as ${role}.`, description ? `About: ${description}` : ''].filter(Boolean), 'Open Organization', orgUrl),
  };
};

export const memberRemovedTemplate = ({ organizationName, memberName, removedByName, supportUrl }) => {
  const heading = `You've been removed from ${organizationName}`;
  const bodyHtml = `
    <p>Hi ${memberName}, you no longer have access to <strong>${organizationName}</strong>${removedByName ? `. This action was taken by <strong>${removedByName}</strong>` : ''}.</p>
    <p>If you think this is a mistake, reach out to the organization owner.</p>
  `;
  return {
    subject: `Removed from ${organizationName}`,
    html: baseTemplate({ preheader: `You were removed from ${organizationName}`, heading, bodyHtml, buttonText: supportUrl ? 'Contact Support' : undefined, buttonUrl: supportUrl, footerNote: `Questions about this action? Contact the ${organizationName} owner.` }),
    text: toPlainText([`You've been removed from "${organizationName}"${removedByName ? ` by ${removedByName}` : ''}.`], supportUrl ? 'Contact Support' : undefined, supportUrl),
  };
};

export const memberRoleChangedTemplate = ({ organizationName, memberName, previousRole, newRole, orgUrl }) => {
  const heading = `Your role in ${organizationName} changed`;
  const bodyHtml = `
    <p>Hi ${memberName}, your role has been updated.</p>
    ${detailsTable([
      { label: 'Organization', value: organizationName, strong: true },
      { label: 'Previous role', value: previousRole },
      { label: 'New role', value: newRole, strong: true },
    ])}
  `;
  return {
    subject: `Your role in ${organizationName} was updated`,
    html: baseTemplate({ preheader: `Role updated in ${organizationName}`, heading, bodyHtml, buttonText: 'Open Organization', buttonUrl: orgUrl }),
    text: toPlainText([`Your role in "${organizationName}" changed from ${previousRole} to ${newRole}.`], 'Open Organization', orgUrl),
  };
};






export const organizationInvitationExistingUserTemplate = ({ organizationName, inviterName, role, inviteUrl, code, rejectUrl }) => {
  const heading = `${inviterName} invited you to ${organizationName}`;
  const bodyHtml = `
    <p>You've been invited to join <strong>${organizationName}</strong> as ${badge(role)}.</p>
    <p>You already have an account — log in and accept from your pending invitations.</p>
    <p>Having trouble with the link? Log in and enter this code under <strong>Join with a code</strong>:</p>
    <p style="font-size:20px;font-weight:700;letter-spacing:2px;">${code}</p>
    <p style="margin-top:20px;font-size:13px;color:#6b7280;">
      Didn't expect this? <a href="${rejectUrl}" style="color:#dc2626;">Reject this invitation</a>.
    </p>
  `;
  return {
    subject: `Invitation to join ${organizationName}`,
    html: baseTemplate({ preheader: `${inviterName} invited you to join ${organizationName}`, heading, bodyHtml, buttonText: 'View Invitation', buttonUrl: inviteUrl }),
    text: toPlainText(
      [`${inviterName} invited you to join "${organizationName}" as ${role}. Log in to accept.`, `Invitation code: ${code}`, `Reject: ${rejectUrl}`],
      'View Invitation',
      inviteUrl
    ),
  };
};

export const organizationInvitationNewUserTemplate = ({ organizationName, inviterName, role, registerUrl, code, rejectUrl }) => {
  const heading = `Join ${organizationName} on our platform`;
  const bodyHtml = `
    <p>${inviterName} invited you to join <strong>${organizationName}</strong> as ${badge(role)}.</p>
    <p>Create an account to join automatically. This invitation expires in 7 days.</p>
    <p>If the button doesn't work, register normally and enter this code under <strong>Join with a code</strong>:</p>
    <p style="font-size:20px;font-weight:700;letter-spacing:2px;">${code}</p>
    <p style="margin-top:20px;font-size:13px;color:#6b7280;">
      Didn't expect this? <a href="${rejectUrl}" style="color:#dc2626;">Reject this invitation</a>.
    </p>
  `;
  return {
    subject: `Create your account & join ${organizationName}`,
    html: baseTemplate({ preheader: `Create an account to join ${organizationName}`, heading, bodyHtml, buttonText: 'Create Account & Join', buttonUrl: registerUrl }),
    text: toPlainText(
      [`${inviterName} invited you to join "${organizationName}" as ${role}.`, `Invitation code: ${code}`, `Reject: ${rejectUrl}`, 'Create your account to join automatically (expires in 7 days).'],
      'Create Account & Join',
      registerUrl
    ),
  };
};
































