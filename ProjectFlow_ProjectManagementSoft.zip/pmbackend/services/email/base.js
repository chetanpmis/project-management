const APP_NAME = process.env.APP_NAME || 'Project Flow';
const CLIENT_URL = process.env.CLIENT_URL || process.env.FRONTEND_URL || 'http://localhost:3000';

export const buildAppUrl = (path = '') => `${CLIENT_URL}${path.startsWith('/') ? path : `/${path}`}`;

export const baseTemplate = ({ preheader = '', heading, bodyHtml, buttonText, buttonUrl, footerNote }) => `
<div style="font-family:'Segoe UI',Helvetica,Arial,sans-serif;max-width:600px;margin:0 auto;background:#fafafa;padding:32px 16px">
  <span style="display:none;max-height:0;overflow:hidden;opacity:0">${preheader}</span>
  <div style="background:#ffffff;border:1px solid #e5e5e5;border-radius:10px;overflow:hidden">
    <div style="background:#0a0a0a;padding:26px 32px">
      <h1 style="margin:0;color:#ffffff;font-size:18px;font-weight:700;letter-spacing:0.3px">${APP_NAME}</h1>
    </div>
    <div style="padding:36px 32px 12px">
      <h2 style="margin:0 0 18px;font-size:19px;line-height:1.4;color:#0a0a0a;font-weight:600">${heading}</h2>
      <div style="font-size:15px;line-height:1.65;color:#404040">${bodyHtml}</div>
      ${
        buttonText && buttonUrl
          ? `
      <div style="margin:32px 0 6px">
        <a href="${buttonUrl}" style="background:#0a0a0a;color:#ffffff;padding:13px 30px;text-decoration:none;border-radius:6px;font-size:14px;font-weight:600;display:inline-block">${buttonText}</a>
      </div>
      <p style="font-size:12px;color:#a3a3a3;word-break:break-all;margin-top:18px;line-height:1.5">
        Or copy this link:<br/><a href="${buttonUrl}" style="color:#525252;text-decoration:underline">${buttonUrl}</a>
      </p>`
          : ''
      }
    </div>
    <div style="background:#fafafa;padding:20px 32px;border-top:1px solid #e5e5e5;margin-top:20px">
      <p style="margin:0;font-size:12px;color:#a3a3a3;line-height:1.5">
        ${footerNote || `This is an automated message from ${APP_NAME}. Please don't reply directly to this email.`}
      </p>
      <p style="margin:6px 0 0;font-size:12px;color:#d4d4d4">© ${new Date().getFullYear()} ${APP_NAME}. All rights reserved.</p>
    </div>
  </div>
</div>
`;

export const toPlainText = (lines, buttonText, buttonUrl) => `
${lines.join('\n\n')}
${buttonText && buttonUrl ? `\n${buttonText}: ${buttonUrl}` : ''}
`.trim();

export const detailsTable = (rows) => `
  <table style="width:100%;border-collapse:collapse;margin:18px 0;font-size:14px">
    ${rows
      .filter((r) => r.value !== undefined && r.value !== null && r.value !== '')
      .map(
        (r) => `
      <tr>
        <td style="padding:9px 0;color:#737373;width:140px;vertical-align:top;border-bottom:1px solid #f0f0f0">${r.label}</td>
        <td style="padding:9px 0;color:#0a0a0a;border-bottom:1px solid #f0f0f0;${r.strong ? 'font-weight:600' : ''}">${r.value}</td>
      </tr>`,
      )
      .join('')}
  </table>
`;

export const badge = (text) => `
  <span style="display:inline-block;background:#0a0a0a;color:#ffffff;font-size:11px;font-weight:700;letter-spacing:0.4px;text-transform:uppercase;padding:4px 10px;border-radius:100px">${text}</span>
`;