import resend from "../../config/mail.js";


export const sendEmail = async ({
  to,
  subject,
  html,
  text,
  from = process.env.MAIL_FROM,
}) => {
  try {
    const { data, error } = await resend.emails.send({
      from: `${process.env.APP_NAME} <${from}>`,
      to: Array.isArray(to) ? to : [to],
      subject,
      html,
      text,
    });

    if (error) {
      throw new Error(error.message);
    }

    return data;
  } catch (err) {
    console.error("Email Error:", err);
    throw err;
  }
};