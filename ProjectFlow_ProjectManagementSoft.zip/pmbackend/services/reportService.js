// services/reportService.js
import Project from '../models/Project.js';
import Task from '../models/Task.js';
import {
  computeTaskProgress,
  computeMilestoneStats,
  computeProjectProgress,
  isTaskOverdue,
} from '../utils/progressEngine.js';

const PERIOD_DAYS = { '7d': 7, '30d': 30, '90d': 90, '6m': 182, '1y': 365 };

/* ============================================================
   Shared fetch — project + its live (non-deleted) tasks
============================================================ */
const getProjectWithTasks = async (projectId) => {
  const project = await Project.findOne({ _id: projectId, isDeleted: { $ne: true } })
    .populate('owner', 'name email avatar')
    .populate('team.user', 'name email avatar')
    .lean();

  if (!project) {
    const err = new Error('Project not found');
    err.status = 404;
    throw err;
  }

  // isDeleted excluded here so every report — overview, milestones, gantt,
  // trend, everything — automatically drops soft-deleted tasks.
  const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } })
    .select(
      'title status priority startDate dueDate milestone assignees watchers checklist estimatedHours actualHours workLogs createdAt updatedAt'
    )
    .lean();

  return { project, tasks };
};

const buildMilestoneReports = (project, tasks) =>
  (project.milestones || []).map((m) => {
    const mTasks = tasks.filter((t) => t.milestone && t.milestone.toString() === m._id.toString());
    const stats = computeMilestoneStats(mTasks);
    const estimatedHours = mTasks.reduce((s, t) => s + (t.estimatedHours || 0), 0);
    const actualHours = mTasks.reduce((s, t) => s + (t.actualHours || 0), 0);

    return {
      _id: m._id,
      name: m.name,
      description: m.description,
      status: stats.status, // dynamic — never m.status
      priority: m.priority,
      progress: stats.progress, // dynamic — never m.progress
      totalTasks: stats.totalTasks,
      completedTasks: stats.completedTasks,
      inProgressTasks: stats.inProgressTasks,
      todoTasks: stats.todoTasks,
      overdueTasks: stats.overdueTasks,
      estimatedHours: Math.round(estimatedHours * 10) / 10,
      actualHours: Math.round(actualHours * 10) / 10,
      startDate: m.startDate,
      dueDate: m.dueDate,
    };
  });

/* ============================================================
   Overview
============================================================ */
export const getProjectOverview = async (projectId) => {
  const { project, tasks } = await getProjectWithTasks(projectId);
  const milestoneReports = buildMilestoneReports(project, tasks);
  const unassignedTasks = tasks.filter((t) => !t.milestone);

  const progress = computeProjectProgress({ milestoneStatsList: milestoneReports, unassignedTasks });

  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const overdueTasks = tasks.filter(isTaskOverdue).length;
  const completedMilestones = milestoneReports.filter((m) => m.status === 'completed').length;

  const estimatedHours = tasks.reduce((s, t) => s + (t.estimatedHours || 0), 0);
  const actualHours = tasks.reduce((s, t) => s + (t.actualHours || 0), 0);

  return {
    project: {
      _id: project._id,
      name: project.name,
      projectCode: project.projectCode,
      status: project.status,
      priority: project.priority,
      health: project.health,
      startDate: project.startDate,
      endDate: project.endDate,
    },
    summary: {
      totalTasks: tasks.length,
      completedTasks,
      overdueTasks,
      totalMilestones: milestoneReports.length,
      completedMilestones,
      teamMembers: (project.team?.length || 0) + 1, // +owner
      estimatedHours: Math.round(estimatedHours * 10) / 10,
      actualHours: Math.round(actualHours * 10) / 10,
      remainingHours: Math.max(0, Math.round((estimatedHours - actualHours) * 10) / 10),
      progress, // dynamic — never project.progress
    },
  };
};

/* ============================================================
   Task status / priority breakdown
============================================================ */
export const getProjectTaskStatus = async (projectId) => {
  const { tasks } = await getProjectWithTasks(projectId);

  const statusCounts = { todo: 0, inProgress: 0, review: 0, completed: 0 };
  const priorityCounts = { low: 0, medium: 0, high: 0, critical: 0 };

  tasks.forEach((t) => {
    if (t.status === 'in-progress') statusCounts.inProgress += 1;
    else if (statusCounts[t.status] !== undefined) statusCounts[t.status] += 1;

    if (priorityCounts[t.priority] !== undefined) priorityCounts[t.priority] += 1;
  });

  return { ...statusCounts, ...priorityCounts };
};

/* ============================================================
   Milestones
============================================================ */
export const getProjectMilestones = async (projectId) => {
  const { project, tasks } = await getProjectWithTasks(projectId);
  return buildMilestoneReports(project, tasks);
};

/* ============================================================
   Team performance
============================================================ */
export const getProjectTeamPerformance = async (projectId) => {
  const { project, tasks } = await getProjectWithTasks(projectId);

  const members = [
    project.owner ? { _id: project.owner._id, name: project.owner.name } : null,
    ...(project.team || []).map((t) => (t.user ? { _id: t.user._id, name: t.user.name } : null)),
  ].filter(Boolean);

  return members.map((member) => {
    const assigned = tasks.filter((t) => (t.assignees || []).some((a) => a.toString() === member._id.toString()));
    const completed = assigned.filter((t) => t.status === 'completed').length;
    const overdue = assigned.filter(isTaskOverdue).length;

    const loggedSeconds = assigned.reduce((sum, t) => {
      const secs = (t.workLogs || [])
        .filter((w) => w.user?.toString() === member._id.toString())
        .reduce((s, w) => s + (w.seconds || 0), 0);
      return sum + secs;
    }, 0);

    return {
      _id: member._id,
      name: member.name,
      assignedTasks: assigned.length,
      completedTasks: completed,
      overdueTasks: overdue,
      loggedHours: Math.round((loggedSeconds / 3600) * 10) / 10,
      completionRate: assigned.length ? Math.round((completed / assigned.length) * 100) : 0,
    };
  });
};

/* ============================================================
   Estimated vs actual
============================================================ */
export const getProjectEstimatedVsActual = async (projectId) => {
  const { tasks } = await getProjectWithTasks(projectId);
  const withEstimates = tasks.filter((t) => t.estimatedHours);

  const estimatedHours = Math.round(withEstimates.reduce((s, t) => s + (t.estimatedHours || 0), 0) * 10) / 10;
  const actualHours = Math.round(withEstimates.reduce((s, t) => s + (t.actualHours || 0), 0) * 10) / 10;
  const variance = Math.round((actualHours - estimatedHours) * 10) / 10;
  const utilization = estimatedHours > 0 ? Math.round((actualHours / estimatedHours) * 100) : 0;

  const breakdown = withEstimates.map((t) => ({
    _id: t._id,
    title: t.title,
    estimatedHours: t.estimatedHours || 0,
    actualHours: t.actualHours || 0,
    variance: Math.round(((t.actualHours || 0) - (t.estimatedHours || 0)) * 10) / 10,
  }));

  return { summary: { estimatedHours, actualHours, variance, utilization }, breakdown };
};

/* ============================================================
   Overdue tasks
============================================================ */
export const getProjectOverdueTasks = async (projectId) => {
  const { tasks } = await getProjectWithTasks(projectId);

  const overdue = tasks
    .filter(isTaskOverdue)
    .map((t) => ({
      _id: t._id,
      title: t.title,
      priority: t.priority,
      progress: computeTaskProgress(t), // dynamic
      dueDate: t.dueDate,
      daysOverdue: Math.floor((Date.now() - new Date(t.dueDate).getTime()) / 86400000),
    }))
    .sort((a, b) => b.daysOverdue - a.daysOverdue);

  return { summary: { totalOverdue: overdue.length }, tasks: overdue };
};

/* ============================================================
   Completion trend
============================================================ */
export const getProjectCompletionTrend = async (projectId, period = '30d') => {
  const days = PERIOD_DAYS[period] || 30;
  const { tasks } = await getProjectWithTasks(projectId);

  const since = new Date();
  since.setDate(since.getDate() - days);
  since.setHours(0, 0, 0, 0);

  const dayKey = (d) => new Date(d).toISOString().slice(0, 10);

  const createdByDay = {};
  const completedByDay = {};

  tasks.forEach((t) => {
    const createdDate = new Date(t.createdAt);
    if (createdDate >= since) {
      const k = dayKey(createdDate);
      createdByDay[k] = (createdByDay[k] || 0) + 1;
    }

    // Task has no dedicated completedAt field, so updatedAt on a currently
    // completed task is used as a best-effort completion date.
    if (t.status === 'completed') {
      const completedDate = new Date(t.updatedAt || t.createdAt);
      if (completedDate >= since) {
        const k = dayKey(completedDate);
        completedByDay[k] = (completedByDay[k] || 0) + 1;
      }
    }
  });

  let cumulative = tasks.filter(
    (t) => t.status === 'completed' && new Date(t.updatedAt || t.createdAt) < since
  ).length;

  const result = [];
  for (let i = 0; i <= days; i++) {
    const d = new Date(since);
    d.setDate(d.getDate() + i);
    const k = dayKey(d);
    const completed = completedByDay[k] || 0;
    cumulative += completed;
    result.push({ date: k, created: createdByDay[k] || 0, completed, cumulativeCompleted: cumulative });
  }

  return result;
};