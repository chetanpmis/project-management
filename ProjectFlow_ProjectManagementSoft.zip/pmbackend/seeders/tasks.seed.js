import Task from "../models/Task.js";
import { context } from "./context.js";
import faker from "./utils/faker.js";
import { randomItems, randomNumber } from "./utils/helpers.js";

const seedTasks = async () => {
  console.log("\nCreating Tasks...");

  const allTasks = [];

  for (const project of context.projects) {
    console.log(project.name);

    const team = project.team.map(t => t.user);

    for (const milestone of project.milestones) {
      const library = [
        "Define requirements & user stories",
        "Create ER diagram & database design",
        "Plan API endpoints",
        "Build user authentication module",
        "Develop core dashboard",
        "Implement project CRUD API",
        "Add task management features",
        "Create reports & analytics module",
        "Write unit & integration tests",
        "Perform user acceptance testing",
        "Fix all critical bugs",
        "Deploy to production",
      ];

      for (const title of library) {
        const assignees = randomItems(team, randomNumber(1, 2));
        const watchers = randomItems(team, randomNumber(1, 3));

        const estimated = randomNumber(6, 45);
        const actual = Math.max(estimated - randomNumber(0, 12), 1);

        const startDate = faker.date.between({
          from: milestone.startDate,
          to: milestone.dueDate,
        });

        const dueDate = new Date(startDate);
        dueDate.setDate(dueDate.getDate() + randomNumber(2, 8));

        allTasks.push({
          title,
          description: faker.lorem.sentences(2),
          project: project._id,
          milestone: milestone._id,
          assignees,
          watchers,
          status: faker.helpers.arrayElement(["todo", "in-progress", "review", "completed"]),
          priority: faker.helpers.arrayElement(["low", "medium", "high", "critical"]),
          startDate,
          dueDate,
          labels: [milestone.name],
          tags: ["sprint-1", "feature"],
          estimatedHours: estimated,
          actualHours: actual,
          timeSpent: actual * 3600,
          createdBy: project.owner,
          checklist: [],
          subtasks: [],
          dependencies: [],
          workLogs: [],
          comments: [],
        });
      }
    }
  }

  const created = await Task.insertMany(allTasks);
  context.tasks = created;
  console.log(`✔ ${created.length} tasks created`);
};

export default seedTasks;