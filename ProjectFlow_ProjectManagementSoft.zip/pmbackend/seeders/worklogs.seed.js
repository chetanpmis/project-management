import Task from "../models/Task.js";
import { context } from "./context.js";
import faker from "./utils/faker.js";
import { randomNumber } from "./utils/helpers.js";

const WORK_DESCRIPTIONS = [
  "Implemented feature",
  "Fixed reported bugs",
  "Code review",
  "Refactored existing code",
  "Added validation",
  "Created API endpoints",
  "Integrated frontend",
  "Updated UI",
  "Optimized database query",
  "Wrote unit tests",
  "Documentation update",
  "Sprint planning changes",
  "Resolved merge conflicts",
  "Investigated production issue",
  "Performance optimization",
];

const seedWorklogs = async () => {
  console.log("\nCreating Worklogs...");

  let totalLogs = 0;

  for (const task of context.tasks) {
    if (!task.assignees.length) continue;

    const totalHours = task.actualHours || task.estimatedHours || randomNumber(6, 28);
    let remaining = totalHours;

    const logs = [];
    let day = 0;

    while (remaining > 0) {
      const user = task.assignees[randomNumber(0, task.assignees.length - 1)];
      const hours = Math.min(remaining, randomNumber(1, 5));
      remaining -= hours;

      logs.push({
        user,
        seconds: hours * 3600,
        date: faker.date.between({
          from: task.startDate,
          to: task.dueDate,
        }),
        description: faker.helpers.arrayElement(WORK_DESCRIPTIONS),
        approved: true,
        isTimer: Math.random() > 0.4,
        stopped: true,
      });

      day++;
    }

    task.workLogs = logs;
    task.timeSpent = logs.reduce((sum, log) => sum + log.seconds, 0);
    task.actualHours = task.timeSpent / 3600;

    await task.save();
    totalLogs += logs.length;
  }

  console.log(`✔ ${totalLogs} worklogs created`);
};

export default seedWorklogs;