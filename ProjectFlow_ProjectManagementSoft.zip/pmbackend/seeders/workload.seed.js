import Workload from "../models/Workload.js";
import { context } from "./context.js";

const dateKey = (date) => {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  return d.toISOString().split("T")[0];
};

const seedWorkload = async () => {
  console.log("\nCreating workload...");

  await Workload.deleteMany({});

  const map = new Map();

  for (const task of context.tasks) {
    if (!task.workLogs?.length) continue;

    for (const log of task.workLogs) {
      const key = [task.project.toString(), log.user.toString(), dateKey(log.date)].join("-");

      if (!map.has(key)) {
        map.set(key, {
          project: task.project,
          user: log.user,
          date: new Date(log.date),
          dailyCapacity: 8,
          assignedHours: 0,
          utilization: 0,
          overloaded: false,
          tasks: [],
        });
      }

      const workload = map.get(key);
      const hours = log.seconds / 3600;
      workload.assignedHours += hours;
      workload.tasks.push({ task: task._id, hours });
    }
  }

  const documents = [];
  for (const workload of map.values()) {
    workload.utilization = Number(((workload.assignedHours / workload.dailyCapacity) * 100).toFixed(1));
    workload.overloaded = workload.assignedHours > workload.dailyCapacity;

    documents.push(workload);
  }

  const created = await Workload.insertMany(documents);
  console.log(`✔ ${created.length} workload records created`);
};

export default seedWorkload;