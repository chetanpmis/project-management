import Comment from "../models/Comment.js";
import Task from "../models/Task.js";
import { context } from "./context.js";
import faker from "./utils/faker.js";
import { randomItems, randomNumber } from "./utils/helpers.js";

const COMMENTS = [
  "Looks good. I'll continue working on this.",
  "API is completed. Please review.",
  "Found a small issue while testing.",
  "Fixed the review comments.",
  "Need clarification on this requirement.",
  "Backend implementation is finished.",
  "Frontend integration completed.",
  "Waiting for QA approval.",
  "Merged into develop branch.",
  "Deployment is scheduled tomorrow.",
  "Added validation.",
  "Performance improved after optimization.",
  "Resolved merge conflict.",
  "Updated according to client feedback.",
  "This task is blocked by another task.",
];

const REPLIES = [
  "Looks good 👍",
  "Approved.",
  "I'll check it.",
  "Done.",
  "Please fix this.",
  "Thanks!",
  "Working on it.",
  "Will update soon.",
];

const seedComments = async () => {

  console.log("\nCreating Comments...\n");

  let total = 0;

  for (const task of context.tasks) {

    const project = context.projects.find(
      p => p._id.toString() === task.project.toString()
    );

    if (!project) continue;

    const team = project.team.map(t => t.user);

    const count = randomNumber(2,6);

    const taskComments = [];

    for (let i = 0; i < count; i++) {

      const author =
        randomItems(team,1)[0];

      const mentions =
        randomItems(team, randomNumber(0,2));

      const comment =
        await Comment.create({

          task: task._id,

          author,

          content:
            faker.helpers.arrayElement(COMMENTS),

          mentions,

          attachments: [],

          replies: []

        });

      const replyCount =
        randomNumber(0,3);

      for (let j = 0; j < replyCount; j++) {

        comment.replies.push({

          author:
            randomItems(team,1)[0],

          content:
            faker.helpers.arrayElement(REPLIES),

          mentions: []

        });

      }

      await comment.save();

      taskComments.push(comment._id);

      total++;

    }

    task.comments = taskComments;

    await task.save();

  }

  console.log(`✔ ${total} comments created`);

};

export default seedComments;