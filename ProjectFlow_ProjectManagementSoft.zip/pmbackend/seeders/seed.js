import dotenv from "dotenv";
import mongoose from "mongoose";

import seedUsers from "./users.seed.js";
import { seedProjects } from "./projects.seed.js";
import seedMilestones from "./milestones.seed.js";
import seedTasks from "./tasks.seed.js";
import seedDependencies from "./dependencies.seed.js";

import seedWorkload from "./workload.seed.js";   // <-- main workload creator
import seedComments from "./comments.seed.js";
import seedMessages from "./messages.seed.js";
import seedActivities from "./activities.seed.js";
import seedWorklogs from "./worklogs.seed.js";

dotenv.config();

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);

    console.log("Connected");
    console.log("🔄 Running fresh seed...\n");

    // Remove existing data first (important for dev)
    await mongoose.connection.db.dropDatabase();
    console.log("🧹 Database cleaned\n");

    // ==================== SEED ORDER ====================
    await seedUsers();
    await seedProjects();
    await seedMilestones();
    await seedTasks();
    await seedDependencies();
    await seedWorklogs()

    await seedWorkload();   
    await seedComments();
    await seedMessages();
    await seedActivities();

    console.log("\n✅ ALL SEEDS COMPLETED SUCCESSFULLY!");
    console.log("✅ Total Projects:", context.projects.length);
    console.log("✅ Total Tasks:", context.tasks.length);
    console.log("✅ Total Worklogs:", context.worklogs.length);
    console.log("✅ Total Comments:", context.comments.length);
    console.log("✅ Total Chat Messages:", context.messages.length);
    console.log("✅ Total Activities:", context.activities ? context.activities.length : 0);

    process.exit(0);
  } catch (err) {
    console.error("❌ Seed failed:", err.message);
    process.exit(1);
  }
};

seed();