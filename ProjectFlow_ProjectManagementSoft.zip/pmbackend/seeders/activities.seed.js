import Activity from "../models/Activity.js";
import { context } from "./context.js";
import faker from "./utils/faker.js";
import { randomItems, randomNumber } from "./utils/helpers.js";

const TYPES = [
  "project_created", "member_joined", "milestone_created", "task_created",
  "task_assigned", "task_updated", "task_completed", "comment_added",
  "worklog_added", "message_sent",
];

const seedActivities = async () => {
  console.log("\nCreating Activities...");

  const activities = [];

  for (const project of context.projects) {
    const team = project.team.map(t => t.user);

    // Project Created
    activities.push({
      project: project._id,
      user: project.owner,
      type: "project_created",
      entity: "Project",
      entityId: project._id,
      description: `Created project "${project.name}"`,
      createdAt: project.createdAt || new Date(),
    });

    // Members Joined
    project.team.forEach(member => {
      if (member.role === "owner") return;
      activities.push({
        project: project._id,
        user: member.user,
        type: "member_joined",
        entity: "Project",
        entityId: project._id,
        description: "Joined the project",
        createdAt: faker.date.between({
          from: project.createdAt,
          to: project.startDate,
        }),
      });
    });

    // Milestones
    project.milestones.forEach(ms => {
      activities.push({
        project: project._id,
        user: project.owner,
        type: "milestone_created",
        entity: "Milestone",
        entityId: ms._id,
        description: `Created milestone "${ms.name}"`,
        createdAt: ms.startDate,
      });
    });

    // Tasks + Worklogs
    const tasks = context.tasks.filter(t => t.project.toString() === project._id.toString());

    tasks.forEach(task => {
      const user = randomItems(team, 1)[0];

      activities.push({
        project: project._id,
        user,
        type: "task_created",
        entity: "Task",
        entityId: task._id,
        description: `Created task "${task.title}"`,
        createdAt: task.createdAt || new Date(),
      });

      if (task.assignees.length) {
        task.assignees.forEach(a => {
          activities.push({
            project: project._id,
            user,
            type: "task_assigned",
            entity: "Task",
            entityId: task._id,
            description: `Assigned task "${task.title}"`,
            createdAt: faker.date.recent(),
          });
        });
      }

      if (task.status === "completed") {
        activities.push({
          project: project._id,
          user,
          type: "task_completed",
          entity: "Task",
          entityId: task._id,
          description: `Completed "${task.title}"`,
          createdAt: task.updatedAt || new Date(),
        });
      }

      task.workLogs.forEach(log => {
        activities.push({
          project: project._id,
          user: log.user,
          type: "worklog_added",
          entity: "Task",
          entityId: task._id,
          description: `Logged ${log.seconds / 3600} hour(s)`,
          createdAt: log.date,
        });
      });
    });

    // Comments
    const tasksWithComments = context.tasks.filter(t => t.comments && t.comments.length);
    tasksWithComments.forEach(task => {
      task.comments.forEach(comment => {
        activities.push({
          project: project._id,
          user: comment.author,
          type: "comment_added",
          entity: "Comment",
          entityId: comment._id,
          description: `Added comment to "${task.title}"`,
          createdAt: new Date(),
        });
      });
    });

    // Chat Messages
    activities.push({
      project: project._id,
      user: team[0],
      type: "message_sent",
      entity: "Message",
      entityId: context.messages[0]?._id || project._id,
      description: "Sent chat message in project chat",
      createdAt: new Date(),
    });
  }

  await Activity.insertMany(activities);
  console.log(`✔ ${activities.length} activities created`);
};

export default seedActivities;