import bcrypt from "bcryptjs";
import User from "../models/User.js";
import { context } from "./context.js";
import faker from "./utils/faker.js";
import config from "./config.js";
import { randomNumber } from "./utils/helpers.js";

const bios = [
  "Frontend Developer",
  "Backend Developer",
  "Full Stack Developer",
  "UI/UX Designer",
  "QA Engineer",
];

const seedUsers = async () => {
  console.log("\nCreating Users... (only 5 members - no admin)\n");

  const password = await bcrypt.hash("123456", 10);

  const users = [];

  // 5 Team Members only
  for (let i = 0; i < config.USERS; i++) {
    const firstName = faker.person.firstName();
    const lastName = faker.person.lastName();

    const email =
      `${firstName}.${lastName}${i}`
        .toLowerCase()
        .replace(/[^a-z0-9.]/g, "") + "@gmail.com";

    users.push({
      name: `${firstName} ${lastName}`,
      email,
      password,
      avatar: faker.image.avatar(),
      bio: faker.helpers.arrayElement(bios),
      role: "member",
      status: "active",
      dailyCapacity: randomNumber(6, 8),
      workingDaysPerWeek: faker.helpers.arrayElement([5, 6]),
    });
  }

  const createdUsers = await User.insertMany(users);
  context.users = createdUsers;

  console.log(`✔ ${createdUsers.length} users created`);
  console.table(
    createdUsers.map((user) => ({
      Name: user.name,
      Email: user.email,
      Role: user.role,
    }))
  );
};

export default seedUsers;