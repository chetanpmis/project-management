import Task from "../models/Task.js";
import { context } from "./context.js";

const seedDependencies = async () => {
  console.log("\nCreating task dependencies...\n");

  let total = 0;

  for (const project of context.projects) {

    const tasks = context.tasks.filter(
      t => t.project.toString() === project._id.toString()
    );

    // group by milestone
    const grouped = {};

    tasks.forEach(task => {

      const key = task.milestone.toString();

      if (!grouped[key]) grouped[key] = [];

      grouped[key].push(task);

    });

    for (const milestoneId in grouped) {

      const milestoneTasks = grouped[milestoneId];

      for (let i = 1; i < milestoneTasks.length; i++) {

        const current = milestoneTasks[i];

        const previous = milestoneTasks[i - 1];

        current.dependencies = [previous._id];

        await current.save();

        total++;

      }

    }

  }

  console.log(`✔ ${total} dependencies created`);
};

export default seedDependencies;