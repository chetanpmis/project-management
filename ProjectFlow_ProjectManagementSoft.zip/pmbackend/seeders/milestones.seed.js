import Project from "../models/Project.js";
import { context } from "./context.js";
import faker from "./utils/faker.js";

const MILESTONE_LIST = [
  { name: "Requirement Analysis", duration: 7, priority: "high" },
  { name: "UI/UX Design", duration: 10, priority: "medium" },
  { name: "Backend Development", duration: 28, priority: "critical" },
  { name: "Frontend Development", duration: 22, priority: "high" },
  { name: "Testing & QA", duration: 12, priority: "medium" },
  { name: "Deployment", duration: 6, priority: "high" },
];

const seedMilestones = async () => {
  console.log("\nCreating milestones...");

  for (const project of context.projects) {
    const milestones = [];

    let currentDate = new Date(project.startDate);

    for (const item of MILESTONE_LIST) {
      // First milestone starts after first task (realistic)
      if (milestones.length === 0) {
        currentDate = faker.date.between({
          from: new Date(project.startDate),
          to: new Date(project.startDate).setDate(new Date(project.startDate).getDate() + 5),
        });
      }

      const startDate = new Date(currentDate);
      const dueDate = new Date(startDate);
      dueDate.setDate(dueDate.getDate() + item.duration);

      const progress = Math.random() * 100;
      const status = progress >= 100 ? "completed" : progress >= 30 ? "in-progress" : "pending";
      const completedAt = status === "completed" ? new Date() : null;

      milestones.push({
        name: item.name,
        description: `${item.name} phase`,
        startDate,
        dueDate,
        priority: item.priority,
        progress: Math.round(progress),
        status,
        completedAt,
      });

      currentDate = new Date(dueDate);
      currentDate.setDate(currentDate.getDate() + 2); // gap before next milestone
    }

    project.milestones = milestones;
    await project.save();
    context.milestones.set(project._id.toString(), milestones);

    console.log(`${project.name} -> ${milestones.length} milestones`);
  }
  console.log("✔ Milestones created");
};

export default seedMilestones;