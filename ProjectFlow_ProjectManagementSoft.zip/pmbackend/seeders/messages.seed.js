import Message from "../models/Message.js";
import { context } from "./context.js";
import { randomItems, randomNumber } from "./utils/helpers.js";
import faker from "./utils/faker.js";

const CHAT_MESSAGES = [
  "Good morning everyone.",
  "Sprint planning starts at 10 AM.",
  "API has been deployed to staging.",
  "Please review my PR.",
  "The authentication bug is fixed.",
  "Dashboard UI is ready.",
  "Need help with the reports module.",
  "Can someone review Task #24?",
  "Client approved the latest changes.",
  "Let's deploy this evening.",
  "Database migration completed.",
  "I'm working on notifications.",
  "Backend is ready for frontend integration.",
  "Performance has improved significantly.",
  "Please pull the latest changes.",
  "Today's build passed successfully.",
  "Timer module is completed.",
  "File upload feature is working.",
  "Meeting at 3 PM.",
  "Good job everyone 🎉"
];

const EMOJIS = [
  "👍",
  "❤️",
  "🔥",
  "😂",
  "👏",
  "🚀"
];

const seedMessages = async () => {

  console.log("\nCreating Project Chat...\n");

  let total = 0;

  for (const project of context.projects) {

    const team = project.team.map(t => t.user);

    const createdMessages = [];

    const count = randomNumber(80,150);

    for (let i = 0; i < count; i++) {

      const author = randomItems(team,1)[0];

      const mentions = randomItems(team, randomNumber(0,2));

      const reply =
        createdMessages.length > 10 &&
        Math.random() < 0.20
          ? randomItems(createdMessages,1)[0]._id
          : null;

      const reactions = [];

      const reactionUsers =
        randomItems(team, randomNumber(0,4));

      if(reactionUsers.length){

        reactions.push({

          emoji:
            faker.helpers.arrayElement(EMOJIS),

          users: reactionUsers

        });

      }

      const readBy = team.map(user => ({
        user,
        readAt: faker.date.recent({days:30})
      }));

      const message = await Message.create({

        project: project._id,

        author,

        content:
          faker.helpers.arrayElement(CHAT_MESSAGES),

        mentions,

        replyTo: reply,

        reactions,

        edited: Math.random() < 0.08,

        editedAt:
          Math.random() < 0.08
            ? faker.date.recent()
            : null,

        isDeleted:
          Math.random() < 0.02,

        deletedAt:
          Math.random() < 0.02
            ? faker.date.recent()
            : null,

        readBy

      });

      createdMessages.push(message);

      total++;

    }

    console.log(
      `${project.name} -> ${createdMessages.length} messages`
    );

  }

  console.log(`\n✔ ${total} chat messages created`);

};

export default seedMessages;