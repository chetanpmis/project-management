import Project from "../models/Project.js";
import faker from "./utils/faker.js";
import config from "./config.js";
import { context } from "./context.js";
import { randomItems, randomNumber } from "./utils/helpers.js";

const PROJECT_TYPES = ["internal", "client", "product"];
const PRIORITIES = ["low", "medium", "high", "critical"];
const HEALTH = ["healthy", "healthy", "healthy", "at-risk", "critical"];
const STATUS = ["planning", "active", "active", "active", "on_hold"];

const PROJECT_NAMES = [
  "Project Management SaaS",
  "E-Commerce Platform",
  "Inventory Management",
  "CRM System",
  "HR Management Portal",
  "Hospital Management",
  "School ERP",
  "Banking Dashboard",
];

const PREFIX = { internal: "INT", client: "CLI", product: "PRO" };

export const generateProjectCode = async (projectType = "internal") => {
  const prefix = PREFIX[projectType] || "PRJ";

  // Use Faker's fake date so codes are consistent and different
  const fakeNow = faker.date.past(2); // 2 years in the past

  const yy = String(fakeNow.getFullYear()).slice(-2);
  const mm = String(fakeNow.getMonth() + 1).padStart(2, "0");
  const dd = String(fakeNow.getDate()).padStart(2, "0");
  const datePart = `${yy}${mm}${dd}`;

  const regex = new RegExp(`^${prefix}-${datePart}-\\d{4}$`);

  // Find the last used code in DB (only this prefix/date)
  const lastProject = await Project.findOne({
    projectCode: { $regex: regex },
  }).sort({ projectCode: -1 });

  let sequence = 1;
  if (lastProject) {
    const lastSeq = Number(lastProject.projectCode.split("-")[2]);
    if (!isNaN(lastSeq)) sequence = lastSeq + 1;
  }

  const sequencePart = String(sequence).padStart(4, "0");
  return `${prefix}-${datePart}-${sequencePart}`;
};

export const seedProjects = async () => {
  console.log("\n================ PROJECT SEED ================\n");

  if (!context.users.length) {
    console.log("❌ No users found");
    return;
  }

  const projects = [];

  for (let i = 0; i < config.PROJECTS; i++) {
    console.log(`Creating Project ${i + 1}`);

    const owner = context.users[i % context.users.length]; // safe with 5 users
    const availableUsers = context.users.filter(u => u._id.toString() !== owner._id.toString());

    const teamMembers = randomItems(availableUsers, randomNumber(4, 7));
    const managers = teamMembers.slice(0, 2);
    const members = teamMembers.slice(2);

    const startDate = faker.date.between({ from: "2025-01-01", to: "2025-06-01" });
    const endDate = faker.date.future({ years: 1, refDate: startDate });

    const team = [];
    team.push({ user: owner._id, role: "owner", permissions: [], invitedBy: owner._id });
    managers.forEach(m => team.push({ user: m._id, role: "manager", permissions: [], invitedBy: owner._id }));
    members.forEach(m => team.push({ user: m._id, role: "member", permissions: [], invitedBy: owner._id }));

    const projectType = faker.helpers.arrayElement(PROJECT_TYPES);
    const projectCode = await generateProjectCode(projectType);

    const isSpecialProject = i === 0; // Special project: start Aug 2025, end Sep 2025, has tasks

    const progress = isSpecialProject ? 30 : randomNumber(25, 85);

    projects.push({
      projectCode,
      name: PROJECT_NAMES[i % PROJECT_NAMES.length],
      description: faker.lorem.paragraph(),
      projectType,
      status: faker.helpers.arrayElement(STATUS),
      priority: faker.helpers.arrayElement(PRIORITIES),
      health: faker.helpers.arrayElement(HEALTH),
      visibility: "private",
      owner: owner._id,
      team,
      startDate,
      endDate,
      estimatedHours: randomNumber(800, 2500),
      loggedHours: randomNumber(300, 1100),
      budget: {
        estimated: randomNumber(60000, 250000),
        approved: randomNumber(60000, 250000),
        spent: randomNumber(12000, 140000),
        remaining: randomNumber(12000, 140000),
      },
      progress,
      lastActivityAt: faker.date.recent(),
    });
  }

  const created = await Project.insertMany(projects);
  context.projects = created;
  console.log(`✔ ${created.length} projects created`);
};

export default seedProjects;