

import { Resend } from "resend";

const resend = new Resend("re_bznRNSUo_PV8SVnVqNAf8SAFx35Tkg4zU");

export default resend;