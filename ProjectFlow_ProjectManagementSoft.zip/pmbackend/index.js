import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';

import routes from './routes/index.js';
import { startDeadlineCron } from './utils/cronJobs.js';
import { initSocket } from './utils/socket.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ limit: '50mb', extended: true }));

app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

app.use((req, res, next) => {
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;

    console.log(
      `${req.method} ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`
    );
  });

  next();
});

try {
  await mongoose.connect(process.env.MONGODB_URI);

  console.log('✅ MongoDB Connected');
  console.log(`📦 Database: ${mongoose.connection.name}`);
} catch (err) {
  console.error('❌ MongoDB Connection Failed');
  console.error(err.message);
  process.exit(1);
}

app.use('/api', routes);

app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    status: 'OK',
    timestamp: new Date(),
  });
});

const server = http.createServer(app);

initSocket(server);
startDeadlineCron();

server.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});