export const ORG_PERMISSIONS = [
  'org.view',
  'org.settings.edit',
  'org.delete',
  'team.invite',
  'team.invite.manage',
  'team.remove',
  'team.role.edit',
  'team.permissions.edit',
  'project.create',
  'project.update',
  'project.delete',
];

export const DEFAULT_ORG_ROLE_PERMISSIONS = {
  owner: [
    'org.view', 'org.settings.edit', 'org.delete',
    'team.invite', 'team.invite.manage', 'team.remove', 'team.role.edit', 'team.permissions.edit',
    'project.create', 'project.update', 'project.delete',
  ],
  admin: [
    'org.view', 'org.settings.edit',
    'team.invite', 'team.invite.manage', 'team.remove', 'team.role.edit', 'team.permissions.edit',
    'project.create', 'project.update', 'project.delete',
  ],
  member: ['org.view'],
};

// 'manager' removed — organization-level roles are now: owner, admin, member.
export const ORG_ROLE_OPTIONS = ['admin', 'member'];

export const ORG_ROLE_META = {
  owner: { label: 'Owner', badgeClass: 'bg-amber-100 text-amber-700 border-amber-200' },
  admin: { label: 'Admin', badgeClass: 'bg-violet-100 text-violet-700 border-violet-200' },
  member: { label: 'Member', badgeClass: 'bg-zinc-100 text-zinc-700 border-zinc-200' },
};

export const ORG_PERMISSION_GROUPS = [
  { group: 'Organization', permissions: [
    { value: 'org.view', label: 'View organization' },
    { value: 'org.settings.edit', label: 'Edit organization settings' },
    { value: 'org.delete', label: 'Delete organization' },
  ]},
  { group: 'Team', permissions: [
    { value: 'team.invite', label: 'Invite members' },
    { value: 'team.invite.manage', label: 'Resend / revoke invitations' },
    { value: 'team.remove', label: 'Remove members' },
    { value: 'team.role.edit', label: 'Change member roles' },
    { value: 'team.permissions.edit', label: 'Edit member permissions' },
  ]},
  { group: 'Projects', permissions: [
    { value: 'project.create', label: 'Create projects' },
    { value: 'project.update', label: 'Update projects' },
    { value: 'project.delete', label: 'Delete projects' },
  ]},
];