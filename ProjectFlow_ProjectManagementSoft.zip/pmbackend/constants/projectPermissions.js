export const PROJECT_PERMISSIONS = [
  'project.view',
   'project.details.view',
  'project.edit',
  'project.delete',
  'project.status.edit',
  'project.settings.edit',

  'team.view',
  'team.invite',
  'team.remove',
  'team.role.edit',
  'team.permissions.edit',

  'milestone.view',
  'milestone.create',
  'milestone.edit',
  'milestone.delete',

  'task.view',
  'task.details.view',
  'task.create',
  'task.edit',
  'task.delete',
  'task.assign',

  'comment.view',
  'comment.create',
  'comment.edit',
  'comment.delete',


  'chat.view',
  'chat.edit',
  'chat.send',
  'chat.delete',

  'resource.view',
  'resource.upload',
  'resource.edit',
  'resource.delete',
  'resource.manage',
];


export const DEFAULT_ROLE_PERMISSIONS = {
  owner: [
    'project.view', 'project.details.view', 'project.edit', 'project.delete', 'project.status.edit', 'project.settings.edit',

    'team.view', 'team.invite', 'team.remove', 'team.role.edit', 'team.permissions.edit',

    'milestone.view', 'milestone.create', 'milestone.edit', 'milestone.delete',

    'task.view', 'task.details.view', 'task.create', 'task.edit', 'task.delete', 'task.assign',

    'comment.view', 'comment.create', 'comment.edit', 'comment.delete',

    'chat.view', 'chat.send', 'chat.delete', 'chat.edit',

    'resource.view', 'resource.upload', 'resource.edit', 'resource.delete', 'resource.manage',
  ],

  admin: [
    'project.view', 'project.details.view', 'project.edit', 'project.status.edit', 'project.settings.edit',

    'team.view', 'team.invite', 'team.remove', 'team.permissions.edit',

    'milestone.view', 'milestone.create', 'milestone.edit', 'milestone.delete',

    'task.view', 'task.details.view', 'task.create', 'task.edit', 'task.delete', 'task.assign',

    'comment.view', 'comment.create', 'comment.edit', 'comment.delete',

    'chat.view', 'chat.edit', 'chat.send', 'chat.delete',

    'resource.view', 'resource.upload', 'resource.edit', 'resource.delete', 'resource.manage',
  ],

  manager: [
    'project.view', 'project.details.view', 'project.edit', 'project.status.edit', 'project.settings.edit',

    'team.view', 'team.invite', 'team.remove', 'team.permissions.edit',

    'milestone.view', 'milestone.create', 'milestone.edit', 'milestone.delete',

    'task.view', 'task.details.view', 'task.create', 'task.edit', 'task.delete', 'task.assign',

    'comment.view', 'comment.create', 'comment.edit', 'comment.delete',

    'chat.view', 'chat.edit', 'chat.send', 'chat.delete',

    'resource.view', 'resource.upload', 'resource.edit', 'resource.delete', 'resource.manage',
  ],

  member: [
    'project.view', 'project.details.view',

    'team.view',

    'milestone.view', 'milestone.create',

    'task.view', 'task.details.view', 'task.create', 'task.edit', 'task.assign',

    'comment.view', 'comment.create', 'comment.edit',

    'chat.view', 'chat.edit', 'chat.send',

    'resource.view', 'resource.upload', 'resource.edit',
  ],

  viewer: [
    'project.view',
    'project.details.view',

    'team.view',
    'milestone.view',
    'task.view',
    'task.details.view',
    'comment.view',

    'resource.view',
  ],
};

// 'manager' removed from the source side since org roles are now
// owner/admin/member only. Org owners/admins get a project role of
// 'owner'/'admin' respectively; plain members default to 'member'.
export const ORG_ROLE_TO_PROJECT_ROLE = {
  owner: 'owner',
  admin: 'admin',
  member: 'member',
};