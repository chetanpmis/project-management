import mongoose from 'mongoose';
import Activity from '../models/Activity.js';


export const createActivity = async ({
  project,
  user,
  type,
  entity = null,
  entityId = null,
  description = null,
  previousValue = null,
  newValue = null,
}) => {
  try {
    const cleanProjectId = mongoose.Types.ObjectId.isValid(project)
      ? project
      : mongoose.Types.ObjectId(project);

    const cleanUserId = mongoose.Types.ObjectId.isValid(user)
      ? user
      : mongoose.Types.ObjectId(user);

    if (!cleanProjectId || !cleanUserId) {
      console.error('❌ createActivity: Invalid project or user ID');
      return null;
    }

    // Validate type against schema enum (prevents invalid activity types)
    const validTypes = [
      'project_created', 'project_updated', 'project_archived', 'project_deleted',
      'member_added', 'member_removed', 'member_role_changed', 'member_updated',
      'task_created', 'task_updated', 'task_deleted', 'task_status_changed',
      'task_assigned', 'task_unassigned', 'checklist_updated',
      'comment_added', 'comment_deleted',
      'file_uploaded', 'file_deleted', 'attachment_added', 'attachment_removed',
      'file_renamed', 'file_moved', 'file_shared', 'file_unshared', 'file_replaced',
      'watcher_added', 'watcher_removed',
      'budget_updated', 'expense_added', 'expense_approved',
      'milestone_created', 'milestone_completed', 'milestone_removed',
      'work_log_added', 'work_log_approved',
      'workload_updated',
      'chat_message_sent', 'chat_message_edited', 'chat_message_deleted'
    ];

    if (!validTypes.includes(type)) {
      console.error(`❌ createActivity: Invalid type "${type}"`);
      return null;
    }

    const activity = await Activity.create({
      project: cleanProjectId,
      user: cleanUserId,
      type,
      entity,
      entityId: entityId ? (mongoose.Types.ObjectId.isValid(entityId) ? entityId : entityId) : undefined,
      description,
      previousValue,
      newValue,
    });

    return activity;
  } catch (error) {
    console.error('❌ Failed to create activity:', error);
    return null;
  }
};