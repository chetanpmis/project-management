import Project from '../models/Project.js';
import Organization from '../models/Organization.js';
import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';

export const getId = (value) => (value?._id || value).toString();

export const isProjectOwner = (project, userId) => getId(project.owner) === getId(userId);

export const getProjectMember = (project, userId) => project.team.find((t) => getId(t.user) === getId(userId));

export const getOrgRole = (org, userId) => {
  if (!org) return null;
  if (getId(org.owner) === getId(userId)) return 'owner';
  const member = org.members.find((m) => getId(m.user) === getId(userId) && m.status === 'accepted');
  return member ? member.role : null;
};

// Only an org owner bypasses project-level permission checks. Org admins
// do not — they follow the same team.permissions array as everyone else.
export const hasOrgLevelBypass = (orgRole) => orgRole === 'owner';

export const loadOrgAndCheckMembership = async (organizationId, userId) => {
  const org = await Organization.findById(organizationId);
  if (!org || org.isDeleted) return { org: null, orgRole: null };
  const orgRole = getOrgRole(org, userId);
  return { org, orgRole };
};

export const hasProjectPermission = (project, orgRole, userId, permission) => {
  if (hasOrgLevelBypass(orgRole)) return true;
  if (isProjectOwner(project, userId)) return true;
  const member = getProjectMember(project, userId);
  if (!member) return false;
  return member.permissions.includes(permission);
};

export const buildPermissionContext = (project, orgRole, userId) => {
  const owner = isProjectOwner(project, userId);
  const bypass = hasOrgLevelBypass(orgRole);
  const member = getProjectMember(project, userId);
  const role = owner ? 'owner' : bypass ? orgRole : member?.role || null;
  const permissions = (owner || bypass) ? [...PROJECT_PERMISSIONS] : (member?.permissions || []);

  const can = PROJECT_PERMISSIONS.reduce((acc, perm) => {
    acc[perm] = owner || bypass || permissions.includes(perm);
    return acc;
  }, {});

  return {
    userId: userId?.toString(),
    isOwner: owner,
    isOrgLevel: bypass,
    role,
    orgRole,
    permissions,
    can,
  };
};

export const withPermissionContext = (project, orgRole, userId) => ({
  ...(project.toObject ? project.toObject() : project),
  currentUserPermissions: buildPermissionContext(project, orgRole, userId),
});

export const resolveAccess = async (project, userId) => {
  const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, userId);
  if (!org || !orgRole) return { allowed: false, orgRole: null };

  const owner = isProjectOwner(project, userId);
  const member = getProjectMember(project, userId);
  const bypass = hasOrgLevelBypass(orgRole);
  const allowed = owner || !!member || bypass || project.visibility === 'public';

  return { allowed, orgRole };
};

// Loads the project, resolves org membership + visibility access, then
// checks the specific permission. Used by task/comment controllers that
// only have a projectId, not an already-loaded project document.
export const checkProjectPermission = async (userId, projectId, permission) => {
  const project = await Project.findById(projectId);
  if (!project) return { allowed: false, project: null, orgRole: null };

  const { allowed: accessAllowed, orgRole } = await resolveAccess(project, userId);
  if (!accessAllowed) return { allowed: false, project, orgRole };

  return { allowed: hasProjectPermission(project, orgRole, userId, permission), project, orgRole };
};

export const logProjectActivity = async (Activity, project, userId, type, fields = {}) => {
  await Activity.create({
    organization: project.organization,
    project: project._id,
    level: 'project',
    user: userId,
    type,
    ...fields,
  });
};

export const isTaskAssignee = (task, userId) => (task.assignees || []).some((a) => getId(a) === getId(userId));
export const isTaskWatcher = (task, userId) => (task.watchers || []).some((w) => getId(w) === getId(userId));
export const isTaskCreator = (task, userId) => task.createdBy && getId(task.createdBy) === getId(userId);

export const attachTaskUserFlags = (taskObj, userId) => ({
  ...taskObj,
  isCurrentUserAssignee: isTaskAssignee(taskObj, userId),
  isCurrentUserWatcher: isTaskWatcher(taskObj, userId),
  isCurrentUserCreator: isTaskCreator(taskObj, userId),
});