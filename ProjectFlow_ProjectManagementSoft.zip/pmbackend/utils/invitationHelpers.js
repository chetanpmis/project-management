import Invitation from '../models/Invitation.js';

/** Expire any pending invitations whose expiresAt has passed. Call lazily
 * before reads that care about "current" pending state — cheap since it's
 * indexed on status+expiresAt-adjacent fields. */
export const expireStaleInvitations = async (filter = {}) => {
  await Invitation.updateMany(
    { status: 'pending', expiresAt: { $lt: new Date() }, ...filter },
    { $set: { status: 'expired' } }
  );
};