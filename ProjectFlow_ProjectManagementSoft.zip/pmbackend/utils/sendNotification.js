import Notification from '../models/Notification.js';
import { emitToUser } from './socket.js';
import { toUserId, toUserIds } from './userIdHelpers.js';

export const sendNotification = async ({
  userId,
  type,
  title,
  message,
  relatedTask = null,
  relatedProject = null,
  relatedOrganization = null,   // NEW
  relatedUser = null,
  link = null,
}) => {
  try {
    const cleanUserId = toUserId(userId);
    if (!cleanUserId) {
      console.error('❌ sendNotification called without a valid userId:', userId);
      return null;
    }

    const notification = await Notification.create({
      user: cleanUserId,
      type,
      title,
      message,
      relatedTask,
      relatedProject,
      relatedOrganization,
      relatedUser: toUserId(relatedUser),
      link,
    });

    const populated = await notification.populate([
      { path: 'relatedTask', select: 'title status dueDate' },
      { path: 'relatedProject', select: 'name projectCode endDate' },
      { path: 'relatedOrganization', select: 'name slug' },
      { path: 'relatedUser', select: 'name email avatar' },
    ]);

    emitToUser(cleanUserId, 'notification:new', populated);
    return populated;
  } catch (error) {
    console.error('❌ Failed to send notification:', error);
    return null;
  }
};


export const sendBulkNotification = async (userIds, opts) => {
  let ids = toUserIds(userIds);
  if (opts.excludeUserId) {
    const excludeId = toUserId(opts.excludeUserId);
    ids = ids.filter((id) => id !== excludeId);
  }
  return Promise.all(ids.map((userId) => sendNotification({ userId, ...opts })));
};

export const notifyProjectTeam = async (project, { type, title, message, relatedTask = null, link = null, excludeUserId = null }) => {
  const recipients = toUserIds([
    project.owner,
    ...(project.team || []).map((t) => t.user),
  ]);
  return sendBulkNotification(recipients, { type, title, message, relatedTask, relatedProject: project._id, link, excludeUserId });
};

export const notifyTaskParticipants = async (task, project, { type, title, message, link = null, excludeUserId = null }) => {
  const recipients = toUserIds([
    ...(task.assignees || []),
    ...(task.watchers || []),
    project?.owner,
  ]);
  return sendBulkNotification(recipients, {
    type, title, message,
    relatedTask: task._id,
    relatedProject: project?._id || task.project,
    link,
    excludeUserId,
  });
};


export const sendNotificationOncePerDay = async ({
  userId,
  type,
  title,
  message,
  relatedTask = null,
  relatedProject = null,
  link = null,
}) => {
  const cleanUserId = toUserId(userId);
  if (!cleanUserId) {
    console.error('❌ sendNotificationOncePerDay called without a valid userId:', userId);
    return null;
  }

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const query = { user: cleanUserId, type, createdAt: { $gte: startOfDay } };
  if (relatedTask) query.relatedTask = toUserId(relatedTask) ? relatedTask : relatedTask;
  if (relatedProject) query.relatedProject = relatedProject;

  const alreadySent = await Notification.exists(query);
  if (alreadySent) return null;

  return sendNotification({ userId: cleanUserId, type, title, message, relatedTask, relatedProject, link });
};


export const sendBulkNotificationOncePerDay = async (userIds, { type, title, message, relatedTask = null, relatedProject = null, link = null, excludeUserId = null }) => {
  let ids = toUserIds(userIds);
  if (excludeUserId) {
    const excludeId = toUserId(excludeUserId);
    ids = ids.filter((id) => id !== excludeId);
  }
  return Promise.all(
    ids.map((userId) => sendNotificationOncePerDay({ userId, type, title, message, relatedTask, relatedProject, link }))
  );
};

export const notifyOrgMembers = async (org, { type, title, message, link = null, excludeUserId = null }) => {
  const recipients = toUserIds(
    org.members.filter((m) => m.status === 'accepted').map((m) => m.user)
  );
  return sendBulkNotification(recipients, {
    type, title, message, relatedProject: null, link,
    excludeUserId,
    relatedOrganization: org._id,
  });
};