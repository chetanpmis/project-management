
const STATUS_PROGRESS = {
  todo: 0,
  'in-progress': 50,
  review: 75,
  completed: 100,
};

/**
 * Progress of a single task.
 * - Has a checklist → progress = % of checklist items completed.
 * - No checklist → progress is derived from status.
 */
export const computeTaskProgress = (task) => {
  const checklist = task.checklist || [];
  if (checklist.length > 0) {
    const done = checklist.filter((c) => c.completed).length;
    return Math.round((done / checklist.length) * 100);
  }
  return STATUS_PROGRESS[task.status] ?? 0;
};

export const isTaskOverdue = (task) => {
  if (!task.dueDate || task.status === 'completed') return false;
  return new Date(task.dueDate).getTime() < Date.now();
};

/**
 * Progress + status + counts for a milestone, derived purely from the live
 * (non-deleted) tasks under it — never from milestone.progress.
 */
export const computeMilestoneStats = (tasks) => {
  const total = tasks.length;
  if (total === 0) {
    return {
      progress: 0,
      status: 'pending',
      totalTasks: 0,
      completedTasks: 0,
      inProgressTasks: 0,
      todoTasks: 0,
      overdueTasks: 0,
    };
  }

  const progresses = tasks.map(computeTaskProgress);
  const progress = Math.round(progresses.reduce((a, b) => a + b, 0) / total);

  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const todoTasks = tasks.filter((t) => t.status === 'todo').length;
  const inProgressTasks = total - completedTasks - todoTasks;
  const overdueTasks = tasks.filter(isTaskOverdue).length;

  let status;
  if (progress === 100) status = 'completed';
  else if (progress > 0 || tasks.some((t) => t.status !== 'todo')) status = 'in-progress';
  else status = 'pending';

  return { progress, status, totalTasks: total, completedTasks, inProgressTasks, todoTasks, overdueTasks };
};

/**
 * Overall project progress.
 *
 * Each milestone counts as ONE unit — its own computed progress — and each
 * task that isn't under any milestone counts as its own unit. The project's
 * progress is the average across all units. This is what makes finishing a
 * milestone actually move project progress, instead of a milestone with 40
 * small tasks diluting a milestone with 2 large ones under a flat task-count
 * average.
 */
export const computeProjectProgress = ({ milestoneStatsList = [], unassignedTasks = [] }) => {
  const units = [
    ...milestoneStatsList.map((m) => m.progress),
    ...unassignedTasks.map(computeTaskProgress),
  ];
  if (units.length === 0) return 0;
  return Math.round(units.reduce((a, b) => a + b, 0) / units.length);
};