
import mongoose from 'mongoose';
import Activity from '../models/Activity.js';

const toObjectId = (id) => (id && mongoose.Types.ObjectId.isValid(id) ? id : null);

export const createActivity = async ({
  organization,
  project = null,
  task = null,
  level,
  user,
  type,
  entity = null,
  entityId = null,
  description = null,
  previousValue = null,
  newValue = null,
}) => {
  try {
    const orgId = toObjectId(organization);
    const userId = toObjectId(user);

    if (!orgId) {
      console.error('❌ createActivity: Invalid or missing organization ID');
      return null;
    }
    if (!userId) {
      console.error('❌ createActivity: Invalid or missing user ID');
      return null;
    }
    if (!['organization', 'project', 'task'].includes(level)) {
      console.error(`❌ createActivity: Invalid level "${level}"`);
      return null;
    }
    if (level === 'project' && !toObjectId(project)) {
      console.error('❌ createActivity: level=project requires a valid project ID');
      return null;
    }
    if (level === 'task' && !toObjectId(task)) {
      console.error('❌ createActivity: level=task requires a valid task ID');
      return null;
    }

    return await Activity.create({
      organization: orgId,
      project: toObjectId(project),
      task: toObjectId(task),
      level,
      user: userId,
      type,
      entity,
      entityId: toObjectId(entityId),
      description,
      previousValue,
      newValue,
    });
  } catch (error) {
    console.error('❌ Failed to create activity:', error);
    return null;
  }
};

// Convenience wrapper — keeps organizationController call sites short.
export const logOrgActivity = (organization, user, type, rest = {}) =>
  createActivity({ organization, level: 'organization', user, type, ...rest });