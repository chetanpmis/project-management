import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

const AVATAR_UPLOAD_ROOT = path.resolve('uploads', 'avatars');
const MAX_FILE_SIZE = 2 * 1024 * 1024; // 2MB

const ALLOWED_MIME_TYPES = new Set([
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
  'image/gif',
]);

const ensureDir = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      ensureDir(AVATAR_UPLOAD_ROOT);
      cb(null, AVATAR_UPLOAD_ROOT);
    } catch (err) {
      cb(err);
    }
  },

  filename: (req, file, cb) => {
    const unique = crypto.randomBytes(16).toString('hex');
    const ext = path.extname(file.originalname).toLowerCase();

    cb(null, `${Date.now()}-${unique}${ext}`);
  },
});

const fileFilter = (req, file, cb) => {
  if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
    return cb(new Error('Only PNG, JPG, JPEG, WEBP and GIF images are allowed.'));
  }

  cb(null, true);
};

export const uploadAvatar = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: MAX_FILE_SIZE,
    files: 1,
  },
});

export const handleAvatarUploadErrors = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        success: false,
        message: `Avatar exceeds ${MAX_FILE_SIZE / (1024 * 1024)}MB.`,
      });
    }

    return res.status(400).json({
      success: false,
      message: err.message,
    });
  }

  if (err) {
    return res.status(400).json({
      success: false,
      message: err.message || 'Avatar upload failed.',
    });
  }

  next();
};


export const AVATAR_MAX_FILE_SIZE = MAX_FILE_SIZE;