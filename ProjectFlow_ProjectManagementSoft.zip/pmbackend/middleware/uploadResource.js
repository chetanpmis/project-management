
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

const UPLOAD_ROOT = path.resolve('uploads', 'resources');

// Keep the allow-list explicit and boring — this is the main line of
// defense against someone uploading an executable disguised as a doc.
const ALLOWED_MIME_TYPES = new Set([
  'image/png',
  'image/jpeg',
  'image/gif',
  'image/webp',
  'image/svg+xml',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'text/plain',
  'text/csv',
  'application/zip',
  'application/json',
]);

const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB — adjust to your infra

const ensureDir = (dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      const projectId = req.params.projectId || req.body.projectId;
      if (!projectId) return cb(new Error('Project ID is required for upload.'));
      const dest = path.join(UPLOAD_ROOT, projectId.toString());
      ensureDir(dest);
      cb(null, dest);
    } catch (err) {
      cb(err);
    }
  },
  filename: (req, file, cb) => {
    const unique = crypto.randomBytes(16).toString('hex');
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${unique}${ext}`);
  },
});

const fileFilter = (req, file, cb) => {
  if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
    return cb(new Error(`File type "${file.mimetype}" is not allowed.`));
  }
  cb(null, true);
};

export const uploadResource = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_FILE_SIZE, files: 1 },
});

// Normalizes multer errors into the API's standard error envelope instead
// of letting them bubble up as raw stack traces.
export const handleUploadErrors = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ success: false, message: `File exceeds the ${MAX_FILE_SIZE / (1024 * 1024)}MB limit.` });
    }
    return res.status(400).json({ success: false, message: err.message });
  }
  if (err) {
    return res.status(400).json({ success: false, message: err.message || 'Upload failed.' });
  }
  next();
};

export const RESOURCE_UPLOAD_ROOT = UPLOAD_ROOT;
export const RESOURCE_MAX_FILE_SIZE = MAX_FILE_SIZE;