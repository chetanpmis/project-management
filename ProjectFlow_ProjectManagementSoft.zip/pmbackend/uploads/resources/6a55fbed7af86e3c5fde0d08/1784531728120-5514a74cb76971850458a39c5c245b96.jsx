'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  ArrowLeft,
  Pencil,
  Trash2,
  Plus,
  Users,
  Clock,
  Wallet,
  CheckCircle2,
  AlertTriangle,
  Calendar as CalendarIcon,
  Shield,
  Globe,
  Lock,
  MoreVertical,
  UserPlus,
  UserMinus,
  Loader2,
} from 'lucide-react';
import projectService from '@/services/project.service';
import taskService from '@/services/task.service';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import TasksTable from '@/components/tasks/TasksTable';
import TaskFormDialog from '@/components/tasks/TaskFormDialog';
import AddMemberDialog from '@/components/projects/AddMemberDialog';
import { cn } from '@/lib/utils';

const statusStyles = {
  planning: 'bg-slate-100 text-slate-700 border-slate-200',
  active: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  on_hold: 'bg-amber-100 text-amber-700 border-amber-200',
  completed: 'bg-blue-100 text-blue-700 border-blue-200',
  cancelled: 'bg-red-100 text-red-700 border-red-200',
};

const healthStyles = {
  healthy: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  'at-risk': 'bg-amber-100 text-amber-700 border-amber-200',
  critical: 'bg-red-100 text-red-700 border-red-200',
};

const priorityStyles = {
  low: 'bg-slate-100 text-slate-700 border-slate-200',
  medium: 'bg-blue-100 text-blue-700 border-blue-200',
  high: 'bg-orange-100 text-orange-700 border-orange-200',
  critical: 'bg-red-100 text-red-700 border-red-200',
};

const milestoneStatusStyles = {
  pending: 'bg-slate-100 text-slate-700 border-slate-200',
  'in-progress': 'bg-amber-100 text-amber-700 border-amber-200',
  completed: 'bg-emerald-100 text-emerald-700 border-emerald-200',
};

// --- Safe helpers -----------------------------------------------------

/** Formats a date string safely; returns a fallback instead of "Invalid Date". */
function formatDate(value, fallback = '—') {
  if (!value) return fallback;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return fallback;
  return d.toLocaleDateString();
}

/** Clamp any numeric-ish value into a 0-100 range for progress bars. */
function clampPct(value) {
  const n = Number(value);
  if (Number.isNaN(n)) return 0;
  return Math.min(100, Math.max(0, Math.round(n)));
}

function StatBlock({ icon: Icon, label, value, sub }) {
  return (
    <Card>
      <CardContent className="p-5 flex items-start gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
          <Icon className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="text-xl font-semibold truncate">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

export default function ProjectDetailsPage() {
  const { id } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showMemberDialog, setShowMemberDialog] = useState(false);
  const [actionError, setActionError] = useState('');

  const {
    data: projectRes,
    isLoading: isProjectLoading,
    isError: isProjectError,
    error: projectError,
    refetch: refetchProject,
  } = useQuery({
    queryKey: ['project', id],
    queryFn: () => projectService.getProjectById(id),
    enabled: !!id,
  });

  const { data: statsRes } = useQuery({
    queryKey: ['projectStats', id],
    queryFn: () => projectService.getProjectStats(id),
    enabled: !!id,
  });

  const { data: tasksRes, isLoading: isTasksLoading } = useQuery({
    queryKey: ['tasks', id],
    queryFn: () => taskService.getTasksByProject(id, { limit: 50 }),
    enabled: !!id,
  });

  const project = projectRes?.data;
  const stats = statsRes?.data;
  const tasks = tasksRes?.data ?? [];

  const invalidateProject = () => {
    queryClient.invalidateQueries({ queryKey: ['project', id] });
    queryClient.invalidateQueries({ queryKey: ['projectStats', id] });
  };

  // --- Mutations (gives us proper pending/error state instead of silent failures) ---

  const removeMemberMutation = useMutation({
    mutationFn: (userId) => projectService.removeTeamMember(id, userId),
    onSuccess: () => {
      setActionError('');
      invalidateProject();
    },
    onError: (err) => {
      setActionError(err?.response?.data?.message || err?.message || 'Failed to remove member.');
    },
  });

  const deleteProjectMutation = useMutation({
    mutationFn: () => projectService.deleteProject(id),
    onSuccess: () => router.push('/projects'),
    onError: (err) => {
      setActionError(err?.response?.data?.message || err?.message || 'Failed to delete project.');
    },
  });

  const handleRemoveMember = (userId) => {
    if (!userId) return;
    if (!confirm('Remove this member from the project?')) return;
    removeMemberMutation.mutate(userId);
  };

  const handleDeleteProject = () => {
    if (!confirm('Delete this project? This cannot be undone.')) return;
    deleteProjectMutation.mutate();
  };

  if (isProjectLoading) {
    return (
      <div className="max-w-6xl mx-auto p-8 space-y-6">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-40 w-full rounded-2xl" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  if (isProjectError) {
    return (
      <div className="max-w-3xl mx-auto p-8 text-center space-y-4">
        <AlertTriangle className="h-8 w-8 text-red-500 mx-auto" />
        <p className="text-lg font-medium">Couldn't load this project</p>
        <p className="text-sm text-muted-foreground">
          {projectError?.response?.data?.message || projectError?.message || 'Something went wrong.'}
        </p>
        <div className="flex justify-center gap-2">
          <Button variant="outline" onClick={() => refetchProject()}>
            Try again
          </Button>
          <Button variant="ghost" onClick={() => router.push('/projects')}>
            Back to projects
          </Button>
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-3xl mx-auto p-8 text-center">
        <p className="text-lg font-medium">Project not found</p>
        <Button className="mt-4" variant="outline" onClick={() => router.push('/projects')}>
          Back to projects
        </Button>
      </div>
    );
  }

  const budget = project.budget || {};
  const spentPct = budget.approved > 0 ? clampPct((budget.spent / budget.approved) * 100) : 0;

  // Copy before sorting — never mutate query-cache data in place.
  const milestones = [...(project.milestones || [])].sort(
    (a, b) => new Date(a.startDate ?? 0) - new Date(b.startDate ?? 0)
  );

  const pendingCount = milestones.filter((m) => m.status === 'pending').length;
  const inProgressCount = milestones.filter((m) => m.status === 'in-progress').length;
  const completedCount = milestones.filter((m) => m.status === 'completed').length;

  const team = project.team || [];

  return (
    <div className="max-w-6xl mx-auto p-8 space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <Button variant="ghost" size="icon" className="h-10 w-10 -ml-2 mt-1" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-3xl font-bold tracking-tight">{project.name}</h1>
              {project.projectCode && (
                <Badge variant="outline" className="font-mono text-xs">
                  {project.projectCode}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2 mt-2 flex-wrap">
              <Badge className={cn('capitalize border', statusStyles[project.status] ?? statusStyles.planning)}>
                {project.status?.replace('_', ' ') ?? 'Unknown'}
              </Badge>
              <Badge className={cn('capitalize border', priorityStyles[project.priority] ?? priorityStyles.low)}>
                {project.priority ?? 'low'} priority
              </Badge>
              <Badge className={cn('capitalize border', healthStyles[project.health] ?? healthStyles.healthy)}>
                {project.health ?? 'healthy'}
              </Badge>
              <Badge variant="outline" className="capitalize gap-1">
                {project.visibility === 'private' ? <Lock className="h-3 w-3" /> : <Globe className="h-3 w-3" />}
                {project.visibility ?? 'private'}
              </Badge>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button variant="outline" onClick={() => router.push(`/projects/${id}/edit`)}>
            <Pencil className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" disabled={deleteProjectMutation.isPending}>
                {deleteProjectMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <MoreVertical className="h-4 w-4" />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                className="text-red-600 focus:text-red-600"
                onClick={handleDeleteProject}
                disabled={deleteProjectMutation.isPending}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete project
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {actionError && (
        <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>{actionError}</span>
          <Button variant="ghost" size="sm" className="ml-auto h-7 px-2 text-red-700" onClick={() => setActionError('')}>
            Dismiss
          </Button>
        </div>
      )}

      {project.description && (
        <p className="text-muted-foreground max-w-3xl leading-relaxed">{project.description}</p>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatBlock
          icon={CheckCircle2}
          label="Progress"
          value={`${stats?.progress ?? project.progress ?? 0}%`}
          sub={stats ? `${stats.completedTasks ?? 0}/${stats.totalTasks ?? 0} tasks done` : undefined}
        />
        <StatBlock icon={AlertTriangle} label="Overdue tasks" value={stats?.overdueTasks ?? 0} />
        <StatBlock
          icon={Clock}
          label="Hours logged"
          value={`${project.loggedHours ?? 0}`}
          sub={`of ${project.estimatedHours ?? 0} estimated`}
        />
        <StatBlock
          icon={Users}
          label="Team"
          value={team.length}
          sub={stats?.overloadedMembers ? `${stats.overloadedMembers} overloaded` : undefined}
        />
      </div>

      {/* Tabs */}
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="milestones">Milestones</TabsTrigger>
          <TabsTrigger value="tasks">Tasks{tasks.length > 0 && ` (${tasks.length})`}</TabsTrigger>
          <TabsTrigger value="team">Team ({team.length})</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CalendarIcon className="h-4.5 w-4.5 text-primary" />
                  Timeline
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Start date</span>
                  <span className="font-medium">{formatDate(project.startDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">End date</span>
                  <span className="font-medium">{formatDate(project.endDate)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Type</span>
                  <span className="font-medium capitalize">{project.projectType ?? '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Owner</span>
                  <span className="font-medium">{project.owner?.name ?? '—'}</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Wallet className="h-4.5 w-4.5 text-primary" />
                  Budget
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <p className="text-muted-foreground">Estimated</p>
                    <p className="font-semibold">{budget.estimated ?? 0}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Approved</p>
                    <p className="font-semibold">{budget.approved ?? 0}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Spent</p>
                    <p className="font-semibold">{budget.spent ?? 0}</p>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Spent of approved</span>
                    <span>{spentPct}%</span>
                  </div>
                  <Progress value={spentPct} className="h-2" />
                </div>
                <p className="text-sm text-muted-foreground">
                  Remaining: <span className="font-medium text-foreground">{budget.remaining ?? 0}</span>
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Milestones Tab */}
        <TabsContent value="milestones" className="space-y-6 mt-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Milestones</h2>
              <p className="text-muted-foreground">
                {milestones.length} milestone{milestones.length !== 1 ? 's' : ''}
              </p>
            </div>
          </div>

          {/* Status Summary */}
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <Badge className={milestoneStatusStyles.pending}>{pendingCount} Pending</Badge>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <Badge className={milestoneStatusStyles['in-progress']}>{inProgressCount} In Progress</Badge>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <Badge className={milestoneStatusStyles.completed}>{completedCount} Completed</Badge>
              </CardContent>
            </Card>
          </div>

          {milestones.length === 0 ? (
            <Card>
              <CardContent className="p-10 text-center text-muted-foreground">No milestones added yet.</CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {milestones.map((milestone, index) => (
                <Card key={milestone._id ?? index} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div className="text-xl font-semibold text-primary">#{index + 1}</div>
                          <h4 className="font-semibold text-lg">{milestone.name ?? 'Untitled milestone'}</h4>
                          <Badge className={cn('capitalize', milestoneStatusStyles[milestone.status] ?? milestoneStatusStyles.pending)}>
                            {(milestone.status ?? 'pending').replace('-', ' ')}
                          </Badge>
                        </div>

                        {milestone.description && (
                          <p className="text-muted-foreground mt-3 leading-relaxed">{milestone.description}</p>
                        )}

                        <div className="mt-5 grid grid-cols-2 gap-6 text-sm">
                          <div>
                            <span className="text-muted-foreground block">Start Date</span>
                            <p className="font-medium">{formatDate(milestone.startDate)}</p>
                          </div>
                          <div>
                            <span className="text-muted-foreground block">Due Date</span>
                            <p className="font-medium">{formatDate(milestone.dueDate)}</p>
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-3xl font-bold text-primary">{clampPct(milestone.progress)}%</div>
                        <Progress value={clampPct(milestone.progress)} className="h-2.5 w-28 mt-3" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Tasks Tab */}
        <TabsContent value="tasks" className="space-y-4 mt-6">
          <div className="flex justify-end">
            <Button onClick={() => setShowTaskDialog(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add Task
            </Button>
          </div>

          {isTasksLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full rounded-xl" />
              ))}
            </div>
          ) : tasks.length === 0 ? (
            <Card>
              <CardContent className="p-10 text-center text-muted-foreground">
                No tasks yet. Add the first one to get moving.
              </CardContent>
            </Card>
          ) : (
            <TasksTable
              tasks={tasks}
              projectId={id}
              onEdit={() => {}}
              onTaskDeleted={invalidateProject}
              canEdit={true}
              canDelete={true}
            />
          )}
        </TabsContent>

        {/* Team Tab */}
        <TabsContent value="team" className="space-y-4 mt-6">
          <div className="flex justify-end">
            <Button onClick={() => setShowMemberDialog(true)}>
              <UserPlus className="h-4 w-4 mr-2" />
              Add Member
            </Button>
          </div>

          {team.length === 0 ? (
            <Card>
              <CardContent className="p-10 text-center text-muted-foreground">
                No team members yet. Add someone to get started.
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {team.map((member) => {
                const memberId = member.user?._id || member._id;
                const isRemoving =
                  removeMemberMutation.isPending && removeMemberMutation.variables === member.user?._id;
                const name = member.user?.name ?? 'Unknown user';
                const initials = member.user?.name?.slice(0, 2)?.toUpperCase() ?? '?';

                return (
                  <Card key={memberId ?? name}>
                    <CardContent className="p-4 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>{initials}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="font-medium truncate">{name}</p>
                          <p className="text-sm text-muted-foreground truncate">
                            {member.user?.email ?? 'No email on file'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <Badge variant="outline" className="capitalize gap-1">
                          <Shield className="h-3 w-3" />
                          {member.role ?? 'member'}
                        </Badge>
                        {member.role !== 'owner' && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-9 w-9 text-muted-foreground hover:text-red-600"
                            disabled={isRemoving}
                            onClick={() => handleRemoveMember(member.user?._id)}
                          >
                            {isRemoving ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <UserMinus className="h-4 w-4" />
                            )}
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <TaskFormDialog
        open={showTaskDialog}
        onOpenChange={setShowTaskDialog}
        projectId={id}
        teamMembers={team}
        onCreated={invalidateProject}
      />

      <AddMemberDialog
        open={showMemberDialog}
        onOpenChange={setShowMemberDialog}
        projectId={id}
        existingMemberIds={team.map((m) => m.user?._id).filter(Boolean)}
        onAdded={invalidateProject}
      />
    </div>
  );
}
