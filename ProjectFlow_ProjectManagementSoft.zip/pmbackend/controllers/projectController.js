// import mongoose from "mongoose";
// import Project from '../models/Project.js';
// import Task from '../models/Task.js';
// import Activity from '../models/Activity.js';
// import User from "../models/User.js";
// import Organization from "../models/Organization.js";
// import File from '../models/File.js';
// import { generateProjectCode } from '../utils/projectCodeGenerator.js';
// import { PROJECT_PERMISSIONS, DEFAULT_ROLE_PERMISSIONS, ORG_ROLE_TO_PROJECT_ROLE } from '../constants/projectPermissions.js';
// import { sendNotification, sendBulkNotification } from '../utils/sendNotification.js';
// import { projectLink, projectTeamLink, projectTrashLink } from '../utils/routeLinks.js';

// const getId = (value) => (value?._id || value).toString();
// const isProjectOwner = (project, userId) => getId(project.owner) === getId(userId);
// const getProjectMember = (project, userId) => project.team.find((t) => getId(t.user) === getId(userId));

// const getOrgRole = (org, userId) => {
//   if (!org) return null;
//   if (getId(org.owner) === getId(userId)) return 'owner';
//   const member = org.members.find((m) => getId(m.user) === getId(userId) && m.status === 'accepted');
//   return member ? member.role : null;
// };

// // Org owners AND org admins bypass project-level permission checks and can
// // see/manage every project in the organization. Previously this only
// // covered 'owner', which meant org admins got 403 "Access denied" on
// // project list/get/restore for any project they hadn't personally created
// // or been added to. Org roles are: owner, admin, member ('manager' removed
// // at the org level — project-level roles still include 'manager').
// const hasOrgLevelBypass = (orgRole) => orgRole === 'owner';

// const hasProjectPermission = (project, orgRole, userId, permission) => {
//   if (hasOrgLevelBypass(orgRole)) return true;

//   if (isProjectOwner(project, userId)) return true;

//   const member = getProjectMember(project, userId);
//   if (!member) return false;

//   return member.permissions.includes(permission);
// };

// const buildPermissionContext = (project, orgRole, userId) => {
//   const owner = isProjectOwner(project, userId);
//   const bypass = hasOrgLevelBypass(orgRole);
//   const member = getProjectMember(project, userId);
//   // Reflect the org role directly instead of hardcoding 'manager' for any
//   // non-owner bypass — an org admin should show as 'admin', not 'manager'.
//   const role = owner ? 'owner' : bypass ? orgRole : member?.role || null;
//   const permissions = (owner || bypass) ? [...PROJECT_PERMISSIONS] : (member?.permissions || []);

//   const can = PROJECT_PERMISSIONS.reduce((acc, perm) => {
//     acc[perm] = owner || bypass || permissions.includes(perm);
//     return acc;
//   }, {});

//   return {
//     userId: userId?.toString(),
//     isOwner: owner,
//     isOrgLevel: bypass,
//     role,
//     orgRole,
//     permissions,
//     can,
//   };
// };

// const withPermissionContext = (project, orgRole, userId) => ({
//   ...(project.toObject ? project.toObject() : project),
//   currentUserPermissions: buildPermissionContext(project, orgRole, userId),
// });

// const loadOrgAndCheckMembership = async (organizationId, userId) => {
//   const org = await Organization.findById(organizationId);
//   if (!org || org.isDeleted) return { org: null, orgRole: null };
//   const orgRole = getOrgRole(org, userId);
//   return { org, orgRole };
// };

// const resolveAccess = async (project, userId) => {
//   const { org, orgRole } = await loadOrgAndCheckMembership(
//     project.organization,
//     userId
//   );

//   if (!org || !orgRole) {
//     return {
//       allowed: false,
//       orgRole: null,
//     };
//   }

//   const owner = isProjectOwner(project, userId);
//   const member = getProjectMember(project, userId);
//   const bypass = hasOrgLevelBypass(orgRole);

//   const allowed =
//     owner ||
//     !!member ||
//     bypass ||
//     project.visibility === "public";

//   return {
//     allowed,
//     orgRole,
//   };
// };

// // Helper to log a project-level activity with the fields the Activity
// // schema actually requires (organization + level). All Activity.create()
// // calls in this file were previously missing these required fields.
// const logProjectActivity = async (project, userId, type, fields = {}) => {
//   await Activity.create({
//     organization: project.organization,
//     project: project._id,
//     level: 'project',
//     user: userId,
//     type,
//     ...fields,
//   });
// };

// export const list = async (req, res) => {
//   try {
//     const page = Math.max(parseInt(req.query.page) || 1, 1);
//     const limit = Math.max(parseInt(req.query.limit) || 10, 1);
//     const { search, status, projectType, priority, sortBy, order, organization, isDeleted } = req.query;

//     if (!organization) {
//       return res.status(400).json({ success: false, message: "organization is required." });
//     }

//     const { org, orgRole } = await loadOrgAndCheckMembership(organization, req.user.id);
//     if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });

//     const query = { organization, isDeleted: isDeleted === 'true' };

//     // Org owners/admins bypass the membership filter and see every project
//     // in the organization. Everyone else only sees projects they own, are
//     // on the team of, or that are public.
//     if (!hasOrgLevelBypass(orgRole)) {
//       query.$or = [{ owner: req.user.id }, { "team.user": req.user.id }, { visibility: 'public' }];
//     }

//     if (search) {
//       query.$and = [{
//         $or: [
//           { name: { $regex: search, $options: "i" } },
//           { projectCode: { $regex: search, $options: "i" } },
//         ],
//       }];
//     }

//     if (status) query.status = status;
//     if (projectType) query.projectType = projectType;
//     if (priority) query.priority = priority;

//     const total = await Project.countDocuments(query);
//     const projects = await Project.find(query)
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar")
//       .sort({ [sortBy || "createdAt"]: order === "asc" ? 1 : -1 })
//       .skip((page - 1) * limit)
//       .limit(limit);

//     return res.json({
//       success: true,
//       data: projects.map((p) => withPermissionContext(p, orgRole, req.user.id)),
//       pagination: {
//         total, page, limit,
//         totalPages: Math.ceil(total / limit),
//         hasNext: page * limit < total,
//         hasPrevious: page > 1,
//       },
//     });
//   } catch (error) {
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const get = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const project = await Project.findOne({ _id: id, isDeleted: false })
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar")
//       .populate("team.invitedBy", "name email");

//     if (!project) return res.status(404).json({ success: false, message: "Project not found." });

//     const { allowed, orgRole } = await resolveAccess(project, req.user.id);
//     if (!allowed) return res.status(403).json({ success: false, message: "Access denied." });

//     return res.json({ success: true, data: withPermissionContext(project, orgRole, req.user.id) });
//   } catch (error) {
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const create = async (req, res) => {
//   try {
//     console.log("========== CREATE PROJECT ==========");
//     console.log("Request User:", req.user);
//     console.log("Request Body:", req.body);

//     const {
//       organization,
//       name,
//       description,
//       projectType,
//       status,
//       priority,
//       visibility,
//       health,
//       startDate,
//       endDate,
//       estimatedHours,
//       milestones: bodyMilestones = [],
//     } = req.body;

//     console.log("Organization ID:", organization);

//     if (!organization) {
//       console.log("Organization missing.");
//       return res.status(400).json({
//         success: false,
//         message: "organization is required.",
//       });
//     }

//     const { org, orgRole } = await loadOrgAndCheckMembership(
//       organization,
//       req.user.id
//     );

//     console.log("Organization Found:", !!org);
//     console.log("Organization Role:", orgRole);

//     if (org) {
//       console.log("Organization Owner:", getId(org.owner));
//       console.log(
//         "Organization Members:",
//         org.members.map((m) => ({
//           user: getId(m.user),
//           role: m.role,
//           status: m.status,
//           permissions: m.permissions,
//         }))
//       );
//     }

//     if (!org || !orgRole) {
//       console.log("Access denied. User is not a member.");
//       return res.status(403).json({
//         success: false,
//         message: "Access denied.",
//       });
//     }

//     const member = org.members.find((m) => getId(m.user) === req.user.id);

//     console.log("Current Member:", member);

//     const bypass = hasOrgLevelBypass(orgRole);
//     console.log("Has Org Bypass:", bypass);

//     console.log(
//       "Has project.create:",
//       member?.permissions?.includes("project.create")
//     );

//     if (
//       !bypass &&
//       !member?.permissions?.includes("project.create")
//     ) {
//       console.log("Permission denied to create project.");
//       return res.status(403).json({
//         success: false,
//         message: "No permission to create projects in this organization.",
//       });
//     }

//     const projectCode = await generateProjectCode(projectType);

//     console.log("Generated Project Code:", projectCode);

//     const creatorId = getId(req.user.id);
//     console.log("Creator ID:", creatorId);

//     const leadershipIds = new Set();

//     if (getId(org.owner) !== creatorId) {
//       leadershipIds.add(getId(org.owner));
//       console.log("Added Organization Owner:", getId(org.owner));
//     }

//     org.members
//       .filter(
//         (m) =>
//           m.role === "admin" &&
//           m.status === "accepted" &&
//           getId(m.user) !== creatorId
//       )
//       .forEach((m) => {
//         leadershipIds.add(getId(m.user));
//         console.log("Added Organization Admin:", getId(m.user));
//       });

//     console.log("Leadership IDs:", [...leadershipIds]);

//     const autoTeamEntries = [...leadershipIds].map((userId) => ({
//       user: userId,
//       role: userId === getId(org.owner) ? "owner" : "admin",
//       permissions:
//         userId === getId(org.owner)
//           ? DEFAULT_ROLE_PERMISSIONS.owner
//           : DEFAULT_ROLE_PERMISSIONS.admin,
//       invitedBy: req.user.id,
//     }));

//     console.log("Auto Team Entries:", autoTeamEntries);

//     const project = new Project({
//       organization,
//       projectCode,
//       name,
//       description,
//       projectType: projectType || "internal",
//       status: status || "planning",
//       priority: priority || "medium",
//       visibility: visibility || "private",
//       health: health || "healthy",
//       owner: req.user.id,
//       startDate,
//       endDate,
//       estimatedHours: estimatedHours || 0,
//       loggedHours: 0,
//       progress: 0,
//       lastActivityAt: new Date(),
//       team: [
//         {
//           user: req.user.id,
//           role: "owner",
//           permissions: DEFAULT_ROLE_PERMISSIONS.owner,
//           invitedBy: req.user.id,
//         },
//         ...autoTeamEntries,
//       ],
//       milestones: bodyMilestones.map((m, idx) => ({
//         ...m,
//         order: idx + 1,
//       })),
//     });

//     console.log("Saving project...");

//     await project.save();

//     console.log("Project Saved:", project._id);

//     await logProjectActivity(project, req.user.id, "project_created", {
//       entity: "Project",
//       entityId: project._id,
//       description: `Project "${project.name}" created`,
//     });

//     console.log("Activity logged.");

//     const createdProject = await Project.findById(project._id)
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");

//     console.log("Project populated.");

//     await sendNotification({
//       userId: req.user.id,
//       type: "project_created",
//       title: "Project Created",
//       message: `You created "${createdProject.name}" (${createdProject.projectCode}).`,
//       relatedProject: createdProject._id,
//       link: projectLink(createdProject._id),
//     });

//     console.log("Creator notification sent.");

//     if (autoTeamEntries.length) {
//       console.log(
//         "Sending bulk notification to:",
//         autoTeamEntries.map((e) => e.user)
//       );

//       await sendBulkNotification(
//         autoTeamEntries.map((e) => e.user),
//         {
//           type: "member_added",
//           title: "Added to Project",
//           message: `You were automatically added to "${createdProject.name}" as an organization ${orgRole === "owner" ? "owner" : "admin"}.`,
//           relatedProject: createdProject._id,
//           link: projectLink(createdProject._id),
//         }
//       );

//       console.log("Bulk notification sent.");
//     }

//     console.log("Project creation completed successfully.");
//     console.log("====================================");

//     return res.status(201).json({
//       success: true,
//       message: "Project created successfully.",
//       data: withPermissionContext(createdProject, orgRole, req.user.id),
//     });
//   } catch (error) {
//     console.error("========== CREATE PROJECT ERROR ==========");
//     console.error(error);
//     console.error("==========================================");

//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

// export const update = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const project = await Project.findOne({ _id: id, isDeleted: false });
//     if (!project) return res.status(404).json({ success: false, message: "Project not found." });

//     const { allowed, orgRole } = await resolveAccess(project, req.user.id);
//     if (!allowed) return res.status(403).json({ success: false, message: "Access denied." });
//     if (!hasProjectPermission(project, orgRole, req.user.id, 'project.edit')) {
//       return res.status(403).json({ success: false, message: "No permission to edit this project." });
//     }

//     const {
//       name, description, projectType, status, priority, health, visibility,
//       startDate, endDate, estimatedHours, milestones: bodyMilestones = [],
//     } = req.body;

//     if (name !== undefined) project.name = name;
//     if (description !== undefined) project.description = description;
//     if (projectType !== undefined) project.projectType = projectType;
//     if (priority !== undefined) project.priority = priority;
//     if (health !== undefined) project.health = health;
//     if (visibility !== undefined) project.visibility = visibility;
//     if (startDate !== undefined) project.startDate = startDate;
//     if (endDate !== undefined) project.endDate = endDate;
//     if (estimatedHours !== undefined) project.estimatedHours = estimatedHours;

//     if (status !== undefined) {
//       if (!hasProjectPermission(project, orgRole, req.user.id, 'project.status.edit')) {
//         return res.status(403).json({ success: false, message: "No permission to change project status." });
//       }
//       project.status = status;
//       if (status === "completed") {
//         project.completedAt = new Date();
//         project.progress = 100;
//       } else {
//         project.completedAt = null;
//       }
//     }

//     const defaultMilestone = project.milestones.find((m) => m.name === "Project Milestone");
//     if (defaultMilestone) {
//       if (startDate !== undefined) defaultMilestone.startDate = startDate;
//       if (endDate !== undefined) defaultMilestone.dueDate = endDate;
//       if (priority !== undefined) defaultMilestone.priority = priority;
//     }

//     if (bodyMilestones.length > 0) {
//       if (!hasProjectPermission(project, orgRole, req.user.id, 'milestone.edit')) {
//         return res.status(403).json({ success: false, message: "No permission to edit milestones." });
//       }
//       const milestoneMap = new Map();
//       project.milestones.forEach((m) => milestoneMap.set(m._id?.toString(), m));

//       bodyMilestones.forEach((bodyMilestone) => {
//         if (bodyMilestone._id) {
//           const existing = milestoneMap.get(bodyMilestone._id.toString());
//           if (existing) Object.assign(existing, bodyMilestone);
//         } else {
//           if (!hasProjectPermission(project, orgRole, req.user.id, 'milestone.create')) return;
//           const newOrder = project.milestones.length + 1;
//           project.milestones.push({ ...bodyMilestone, order: newOrder });
//         }
//       });
//     }

//     project.lastActivityAt = new Date();
//     await project.save();

//     await logProjectActivity(project, req.user.id, 'project_updated', {
//       entity: 'Project',
//       entityId: project._id,
//       description: `Updated project "${project.name}"`,
//     });

//     const updated = await Project.findById(project._id)
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");

//     return res.json({
//       success: true,
//       message: "Project updated successfully.",
//       data: withPermissionContext(updated, orgRole, req.user.id),
//     });
//   } catch (error) {
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const getStats = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const project = await Project.findOne({ _id: id, isDeleted: { $ne: true } });
//     if (!project) return res.status(404).json({ success: false, message: "Project not found." });

//     const { allowed, orgRole } = await resolveAccess(project, req.user.id);
//     if (!allowed) return res.status(403).json({ success: false, message: "Access denied." });

//     const totalTasks = await Task.countDocuments({ project: id, isDeleted: { $ne: true } });
//     const completedTasks = await Task.countDocuments({ project: id, isDeleted: { $ne: true }, status: "completed" });
//     const overdueTasks = await Task.countDocuments({
//       project: id,
//       isDeleted: { $ne: true },
//       status: { $ne: "completed" },
//       dueDate: { $lt: new Date() },
//     });

//     const now = new Date();
//     const isProjectOverdue = !!(project.endDate && project.endDate < now && project.status !== 'completed' && project.status !== 'cancelled');

//     res.json({
//       success: true,
//       data: {
//         projectCode: project.projectCode,
//         projectName: project.name,
//         status: project.status,
//         priority: project.priority,
//         health: project.health,
//         progress: project.progress,
//         totalTasks,
//         completedTasks,
//         pendingTasks: totalTasks - completedTasks,
//         overdueTasks,
//         teamMembers: project.team.length,
//         estimatedHours: project.estimatedHours,
//         loggedHours: project.loggedHours,
//         isOverdue: isProjectOverdue,
//         endDate: project.endDate,
//         milestones: project.milestones,
//       },
//       currentUserPermissions: buildPermissionContext(project, orgRole, req.user.id),
//     });
//   } catch (error) {
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const addTeamMember = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const { userId, role, permissions } = req.body;

//     if (!mongoose.Types.ObjectId.isValid(projectId)) return res.status(400).json({ success: false, message: "Invalid project id." });
//     if (!mongoose.Types.ObjectId.isValid(userId)) return res.status(400).json({ success: false, message: "Invalid user id." });

//     const project = await Project.findOne({ _id: projectId, isDeleted: false });
//     if (!project) return res.status(404).json({ success: false, message: "Project not found." });

//     const { org, orgRole: requesterOrgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
//     if (!org || !requesterOrgRole) return res.status(403).json({ success: false, message: "Access denied." });
//     if (!hasProjectPermission(project, requesterOrgRole, req.user.id, 'team.invite')) {
//       return res.status(403).json({ success: false, message: "No permission to add members." });
//     }

//     const user = await User.findById(userId);
//     if (!user) return res.status(404).json({ success: false, message: "User not found." });

//     const targetOrgRole = getOrgRole(org, userId);
//     if (!targetOrgRole) {
//       return res.status(400).json({ success: false, message: "User must be a member of this organization before being added to a project." });
//     }

//     if (getId(project.owner) === userId) {
//       return res.status(400).json({ success: false, message: "Owner is already part of this project." });
//     }
//     if (project.team.some((t) => getId(t.user) === userId)) {
//       return res.status(400).json({ success: false, message: "User already in team." });
//     }

//     const resolvedRole = role || ORG_ROLE_TO_PROJECT_ROLE[targetOrgRole] || 'member';

//     if (resolvedRole === 'manager' && requesterOrgRole !== 'owner' && requesterOrgRole !== 'admin') {
//       return res.status(403).json({ success: false, message: "Only an organization owner/admin can assign the manager role." });
//     }
//     const resolvedPermissions = permissions?.length ? permissions : (DEFAULT_ROLE_PERMISSIONS[resolvedRole] || []);

//     project.team.push({
//       user: userId,
//       role: resolvedRole,
//       permissions: resolvedPermissions,
//       invitedBy: req.user.id,
//     });

//     project.lastActivityAt = new Date();
//     await project.save();

//     await logProjectActivity(project, req.user.id, 'member_added', {
//       entity: 'User',
//       entityId: userId,
//       description: `${user.name} added as ${resolvedRole}`,
//     });

//     const updated = await Project.findById(projectId)
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");

//     await sendNotification({
//       userId,
//       type: "member_added",
//       title: "Added to Project",
//       message: `You were added to "${updated.name}" as ${resolvedRole}.`,
//       relatedProject: updated._id,
//       link: projectLink(updated._id),
//     });

//     return res.status(200).json({
//       success: true,
//       message: "Team member added successfully.",
//       data: withPermissionContext(updated, requesterOrgRole, req.user.id),
//     });
//   } catch (error) {
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const removeTeamMember = async (req, res) => {
//   try {
//     const { projectId, userId } = req.params;
//     const project = await Project.findOne({ _id: projectId, isDeleted: false })
//       .populate("team.user", "name email avatar");
//     if (!project) return res.status(404).json({ success: false, message: "Project not found." });

//     const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
//     if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
//     if (!hasProjectPermission(project, orgRole, req.user.id, 'team.remove')) {
//       return res.status(403).json({ success: false, message: "No permission to remove members." });
//     }

//     const member = project.team.find((t) => getId(t.user) === userId);
//     if (!member) return res.status(404).json({ success: false, message: "Member not found." });

//     if (member.role === "owner" || getId(member.user) === getId(project.owner)) {
//       return res.status(400).json({ success: false, message: "Cannot remove the project owner." });
//     }

//     const removedUserName = member.user?.name || 'A team member';
//     project.team = project.team.filter((t) => getId(t.user) !== userId);
//     project.lastActivityAt = new Date();
//     await project.save();

//     await logProjectActivity(project, req.user.id, 'member_removed', {
//       entity: 'User',
//       entityId: userId,
//       description: `${removedUserName} removed from project`,
//     });

//     const updated = await Project.findById(projectId)
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");

//     await sendNotification({
//       userId,
//       type: 'project_member_removed',
//       title: 'Removed from Project',
//       message: `You were removed from "${updated.name}".`,
//       relatedProject: updated._id,
//       link: projectTrashLink(),
//     });

//     const remainingRecipients = [updated.owner, ...updated.team.map((t) => t.user)]
//       .filter((u) => getId(u) !== req.user.id);

//     await sendBulkNotification(remainingRecipients, {
//       type: 'project_member_removed',
//       title: 'Team Member Removed',
//       message: `${removedUserName} was removed from "${updated.name}".`,
//       relatedProject: updated._id,
//       link: projectTeamLink(updated._id),
//     });

//     return res.json({ success: true, message: "Team member removed successfully.", data: withPermissionContext(updated, orgRole, req.user.id) });
//   } catch (error) {
//     return res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const updateTeamMember = async (req, res) => {
//   try {
//     const { projectId, userId } = req.params;
//     const { role, permissions } = req.body;

//     console.log("\n========== UPDATE TEAM MEMBER ==========");
//     console.log("Request User:", {
//       id: req.user.id,
//       email: req.user.email,
//       role: req.user.role,
//     });
//     console.log("Project ID:", projectId);
//     console.log("Target User ID:", userId);
//     console.log("Request Body:", req.body);

//     const project = await Project.findOne({ _id: projectId, isDeleted: false });
//     if (!project) {
//       console.log("❌ Project not found.");
//       return res.status(404).json({ success: false, message: "Project not found." });
//     }

//     console.log("Project:", {
//       id: project._id,
//       name: project.name,
//       organization: project.organization,
//     });

//     const { org, orgRole } = await loadOrgAndCheckMembership(
//       project.organization,
//       req.user.id
//     );

//     if (!org || !orgRole) {
//       console.log("❌ User is not an organization member.");
//       return res.status(403).json({ success: false, message: "Access denied." });
//     }

//     console.log("Organization Role:", orgRole);

//     const member = project.team.find((t) => getId(t.user) === userId);

//     if (!member) {
//       console.log("❌ Team member not found.");
//       return res.status(404).json({ success: false, message: "Member not found." });
//     }

//     console.log("\n----- BEFORE UPDATE -----");
//     console.log("Current Role:", member.role);
//     console.log("Current Permissions:", member.permissions);

//     const editingRole = role !== undefined;
//     const editingPermissions = permissions !== undefined;

//     console.log("Editing Role:", editingRole);
//     console.log("Editing Permissions:", editingPermissions);

//     if (
//       editingRole &&
//       !hasProjectPermission(project, orgRole, req.user.id, "team.role.edit")
//     ) {
//       console.log("❌ Missing permission: team.role.edit");
//       return res.status(403).json({
//         success: false,
//         message: "No permission to change member roles.",
//       });
//     }

//     if (
//       editingPermissions &&
//       !hasProjectPermission(
//         project,
//         orgRole,
//         req.user.id,
//         "team.permissions.edit"
//       )
//     ) {
//       console.log("❌ Missing permission: team.permissions.edit");
//       return res.status(403).json({
//         success: false,
//         message: "No permission to change member permissions.",
//       });
//     }

//     if (
//       role === "manager" &&
//       orgRole !== "owner" &&
//       orgRole !== "admin"
//     ) {
//       console.log("❌ Only organization owner/admin can assign manager.");
//       return res.status(403).json({
//         success: false,
//         message:
//           "Only an organization owner/admin can assign the manager role.",
//       });
//     }

//     const canEditSelf = getId(member.user) === getId(req.user.id);

//     const hasEditPermission =
//       hasProjectPermission(project, orgRole, req.user.id, "team.role.edit") ||
//       hasProjectPermission(
//         project,
//         orgRole,
//         req.user.id,
//         "team.permissions.edit"
//       );

//     console.log("Can Edit Self:", canEditSelf);
//     console.log("Has Edit Permission:", hasEditPermission);

//     if (!canEditSelf && !hasEditPermission) {
//       console.log("❌ No permission to edit this member.");
//       return res.status(403).json({
//         success: false,
//         message: "No permission to edit this member's role/permissions.",
//       });
//     }

//     const oldRole = member.role;
//     const oldPermissions = [...member.permissions];

//     console.log("\n----- REQUESTED UPDATE -----");
//     console.log("Requested Role:", role);
//     console.log("Requested Permissions:", permissions);

//     if (editingRole) {
//       member.role = role;
//     }

//     if (editingPermissions) {
//       console.log("Updating custom permissions...");
//       member.permissions = permissions;
//     } else if (editingRole) {
//       console.log("Applying default permissions for role:", role);
//       console.log(
//         "Default Permissions:",
//         DEFAULT_ROLE_PERMISSIONS[role] || []
//       );
//       member.permissions = DEFAULT_ROLE_PERMISSIONS[role] || [];
//     }

//     console.log("\n----- AFTER UPDATE -----");
//     console.log("New Role:", member.role);
//     console.log("New Permissions:", member.permissions);

//     const addedPermissions = member.permissions.filter(
//       (p) => !oldPermissions.includes(p)
//     );

//     const removedPermissions = oldPermissions.filter(
//       (p) => !member.permissions.includes(p)
//     );

//     console.log("\n----- PERMISSION CHANGES -----");
//     console.log("Old Permissions:", oldPermissions);
//     console.log("New Permissions:", member.permissions);
//     console.log("Added Permissions:", addedPermissions);
//     console.log("Removed Permissions:", removedPermissions);

//     const roleChanged = oldRole !== member.role;

//     const permissionsChanged =
//       JSON.stringify([...oldPermissions].sort()) !==
//       JSON.stringify([...member.permissions].sort());

//     console.log("\n----- CHANGE SUMMARY -----");
//     console.log("Role Changed:", roleChanged);
//     console.log("Permissions Changed:", permissionsChanged);

//     project.lastActivityAt = new Date();
//     await project.save();

//     if (roleChanged || permissionsChanged) {
//       await logProjectActivity(
//         project,
//         req.user.id,
//         roleChanged
//           ? "member_role_changed"
//           : "member_permissions_changed",
//         {
//           entity: "User",
//           entityId: userId,
//           previousValue: {
//             role: oldRole,
//             permissions: oldPermissions,
//           },
//           newValue: {
//             role: member.role,
//             permissions: member.permissions,
//           },
//           description: roleChanged
//             ? `Role changed from "${oldRole}" to "${member.role}"`
//             : `Permissions updated for ${member.role}`,
//         }
//       );

//       await sendNotification({
//         userId,
//         type: "member_updated",
//         title: "Your Project Access Changed",
//         message: roleChanged
//           ? `Your role in "${project.name}" changed from ${oldRole} to ${member.role}.`
//           : `Your permissions in "${project.name}" were updated.`,
//         relatedProject: project._id,
//         link: projectLink(project._id),
//       });
//     }

//     const updated = await Project.findById(projectId)
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");

//     console.log("✅ Team member updated successfully.");
//     console.log("========================================\n");

//     return res.json({
//       success: true,
//       message: "Team member updated successfully.",
//       data: withPermissionContext(updated, orgRole, req.user.id),
//     });
//   } catch (error) {
//     console.error("❌ UPDATE TEAM MEMBER ERROR:", error);
//     return res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// };

// export const remove = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const project = await Project.findOne({ _id: id, isDeleted: false })
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");
//     if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

//     const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
//     if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
//     if (!hasProjectPermission(project, orgRole, req.user.id, 'project.delete')) {
//       return res.status(403).json({ success: false, message: 'No permission to delete this project.' });
//     }

//     project.isDeleted = true;
//     project.deletedAt = new Date();
//     project.deletedBy = req.user.id;
//     await project.save();

//     await Task.updateMany({ project: id, isDeleted: false }, {
//       isDeleted: true,
//       deletedAt: new Date(),
//       deletedBy: req.user.id,
//     });

//     await File.updateMany({ project: id, deleted: false }, {
//       deleted: true,
//       deletedAt: new Date(),
//     });

//     await logProjectActivity(project, req.user.id, 'project_deleted', {
//       entity: 'Project',
//       entityId: id,
//       description: `Project "${project.name}" deleted`,
//     });

//     const recipients = [project.owner, ...project.team.map((t) => t.user)]
//       .filter((u) => getId(u) !== req.user.id);

//     await sendBulkNotification(recipients, {
//       type: 'project_deleted',
//       title: 'Project Deleted',
//       message: `"${project.name}" was deleted. It can be restored within 30 days.`,
//       relatedProject: project._id,
//       link: projectTrashLink(),
//     });

//     res.json({ success: true, message: 'Project deleted successfully. It can be restored from the trash.' });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const restore = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const project = await Project.findOne({ _id: id, isDeleted: true })
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");
//     if (!project) return res.status(404).json({ success: false, message: 'Deleted project not found.' });

//     const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
//     if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
//     if (!hasOrgLevelBypass(orgRole) && getId(project.deletedBy) !== req.user.id && !isProjectOwner(project, req.user.id)) {
//       return res.status(403).json({ success: false, message: 'No permission to restore this project.' });
//     }

//     project.isDeleted = false;
//     project.deletedAt = null;
//     project.deletedBy = null;
//     await project.save();

//     await Task.updateMany({ project: id, deletedAt: { $ne: null } }, {
//       isDeleted: false,
//       deletedAt: null,
//       deletedBy: null,
//     });

//     await File.updateMany({ project: id, deleted: true }, {
//       deleted: false,
//       deletedAt: null,
//     });

//     await logProjectActivity(project, req.user.id, 'project_restored', {
//       entity: 'Project',
//       entityId: id,
//       description: `Project "${project.name}" restored`,
//     });

//     const recipients = [project.owner, ...project.team.map((t) => t.user)]
//       .filter((u) => getId(u) !== req.user.id);

//     await sendBulkNotification(recipients, {
//       type: 'project_restored',
//       title: 'Project Restored',
//       message: `"${project.name}" was restored.`,
//       relatedProject: project._id,
//       link: projectLink(project._id),
//     });

//     res.json({ success: true, message: 'Project restored successfully.' });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const removeMilestone = async (req, res) => {
//   try {
//     const { projectId, milestoneId } = req.params;
//     const project = await Project.findOne({ _id: projectId, isDeleted: false })
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");
//     if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

//     const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
//     if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
//     if (!hasProjectPermission(project, orgRole, req.user.id, 'milestone.delete')) {
//       return res.status(403).json({ success: false, message: 'No permission to delete milestones.' });
//     }

//     const milestone = project.milestones.find(m => m._id.toString() === milestoneId);
//     if (!milestone) return res.status(404).json({ success: false, message: 'Milestone not found.' });

//     await Task.updateMany(
//       { project: projectId, milestone: milestoneId, isDeleted: false },
//       { $unset: { milestone: 1 } }
//     );

//     project.milestones = project.milestones.filter(m => m._id.toString() !== milestoneId);
//     project.lastActivityAt = new Date();
//     await project.save();

//     await logProjectActivity(project, req.user.id, 'milestone_removed', {
//       entity: 'Milestone',
//       entityId: milestoneId,
//       description: `Milestone "${milestone.name}" removed from project`,
//     });

//     const updated = await Project.findById(projectId)
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");

//     res.json({ success: true, message: 'Milestone removed.', data: withPermissionContext(updated, orgRole, req.user.id) });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const updateStatus = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { status } = req.body;
//     const allowedStatus = ["planning", "active", "on_hold", "completed", "cancelled"];

//     if (!allowedStatus.includes(status)) return res.status(400).json({ success: false, message: "Invalid status." });

//     const project = await Project.findOne({ _id: id, isDeleted: false })
//       .populate("owner", "name email avatar")
//       .populate("team.user", "name email avatar");
//     if (!project) return res.status(404).json({ success: false, message: "Project not found." });

//     const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
//     if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
//     if (!hasProjectPermission(project, orgRole, req.user.id, 'project.status.edit')) {
//       return res.status(403).json({ success: false, message: "No permission to change project status." });
//     }

//     const previousStatus = project.status;
//     project.status = status;

//     if (status === "completed") {
//       project.completedAt = new Date();
//       project.progress = 100;
//     } else {
//       project.completedAt = null;
//     }

//     project.lastActivityAt = new Date();
//     await project.save();

//     await logProjectActivity(project, req.user.id, 'project_status_changed', {
//       entity: 'Project',
//       entityId: project._id,
//       description: `Status changed from "${previousStatus}" to "${status}"`,
//     });

//     res.json({
//       success: true,
//       message: "Project status updated successfully.",
//       data: { projectId: project._id, status: project.status, progress: project.progress, completedAt: project.completedAt },
//     });
//   } catch (error) {
//     res.status(500).json({ success: false, message: error.message });
//   }
// };

// export const runDeadlineReminders = async () => {
//   const now = new Date();
//   const warningWindowStart = now;
//   const warningWindowEnd = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
//   const startOfToday = new Date(now); startOfToday.setHours(0, 0, 0, 0);

//   const candidates = await Project.find({
//     isDeleted: false,
//     status: { $nin: ['completed', 'cancelled'] },
//     endDate: { $ne: null },
//     $or: [
//       { lastDeadlineReminderAt: null },
//       { lastDeadlineReminderAt: { $lt: startOfToday } },
//     ],
//   })
//     .populate("owner", "name email")
//     .populate("team.user", "name email");

//   for (const project of candidates) {
//     const isUpcoming = project.endDate >= warningWindowStart && project.endDate <= warningWindowEnd;
//     const isOverdue = project.endDate < now;
//     if (!isUpcoming && !isOverdue) continue;

//     const recipients = [project.owner, ...project.team.map((t) => t.user)];

//     await sendBulkNotification(recipients, {
//       type: isOverdue ? 'project_deadline_overdue' : 'project_deadline_upcoming',
//       title: isOverdue ? 'Project Deadline Passed' : 'Project Deadline Approaching',
//       message: isOverdue
//         ? `"${project.name}" is now past its deadline.`
//         : `"${project.name}" is due soon.`,
//       relatedProject: project._id,
//       link: projectLink(project._id),
//     });

//     project.lastDeadlineReminderAt = now;
//     await project.save();
//   }
// };


//v2

import mongoose from "mongoose";
import Project from '../models/Project.js';
import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import User from "../models/User.js";
import Organization from "../models/Organization.js";
import File from '../models/File.js';
import { generateProjectCode } from '../utils/projectCodeGenerator.js';
import { PROJECT_PERMISSIONS, DEFAULT_ROLE_PERMISSIONS, ORG_ROLE_TO_PROJECT_ROLE } from '../constants/projectPermissions.js';
import { sendNotification, sendBulkNotification } from '../utils/sendNotification.js';
import { projectLink, projectTeamLink, projectTrashLink } from '../utils/routeLinks.js';
import {
  getId,
  isProjectOwner,
  getProjectMember,
  getOrgRole,
  hasOrgLevelBypass,
  hasProjectPermission,
  buildPermissionContext,
  withPermissionContext,
  loadOrgAndCheckMembership,
  resolveAccess,
  logProjectActivity as logActivity,
} from '../utils/permissions.js';


export const list = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 10, 1);
    const { search, status, projectType, priority, sortBy, order, organization, isDeleted } = req.query;

    if (!organization) {
      return res.status(400).json({ success: false, message: "organization is required." });
    }

    const { org, orgRole } = await loadOrgAndCheckMembership(organization, req.user.id);
    if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });

    const query = { organization, isDeleted: isDeleted === 'true' };

    // Org owners/admins bypass the membership filter and see every project
    // in the organization. Everyone else only sees projects they own, are
    // on the team of, or that are public.
    if (!hasOrgLevelBypass(orgRole)) {
      query.$or = [{ owner: req.user.id }, { "team.user": req.user.id }, { visibility: 'public' }];
    }

    if (search) {
      query.$and = [{
        $or: [
          { name: { $regex: search, $options: "i" } },
          { projectCode: { $regex: search, $options: "i" } },
        ],
      }];
    }

    if (status) query.status = status;
    if (projectType) query.projectType = projectType;
    if (priority) query.priority = priority;

    const total = await Project.countDocuments(query);
    const projects = await Project.find(query)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar")
      .sort({ [sortBy || "createdAt"]: order === "asc" ? 1 : -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    return res.json({
      success: true,
      data: projects.map((p) => withPermissionContext(p, orgRole, req.user.id)),
      pagination: {
        total, page, limit,
        totalPages: Math.ceil(total / limit),
        hasNext: page * limit < total,
        hasPrevious: page > 1,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const get = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findOne({ _id: id, isDeleted: false })
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar")
      .populate("team.invitedBy", "name email");

    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const { allowed, orgRole } = await resolveAccess(project, req.user.id);
    if (!allowed) return res.status(403).json({ success: false, message: "Access denied." });

    return res.json({ success: true, data: withPermissionContext(project, orgRole, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const create = async (req, res) => {
  try {
    console.log("========== CREATE PROJECT ==========");
    console.log("Request User:", req.user);
    console.log("Request Body:", req.body);

    const {
      organization,
      name,
      description,
      projectType,
      status,
      priority,
      visibility,
      health,
      startDate,
      endDate,
      estimatedHours,
      milestones: bodyMilestones = [],
    } = req.body;

    console.log("Organization ID:", organization);

    if (!organization) {
      console.log("Organization missing.");
      return res.status(400).json({
        success: false,
        message: "organization is required.",
      });
    }

    const { org, orgRole } = await loadOrgAndCheckMembership(
      organization,
      req.user.id
    );

    console.log("Organization Found:", !!org);
    console.log("Organization Role:", orgRole);

    if (org) {
      console.log("Organization Owner:", getId(org.owner));
      console.log(
        "Organization Members:",
        org.members.map((m) => ({
          user: getId(m.user),
          role: m.role,
          status: m.status,
          permissions: m.permissions,
        }))
      );
    }

    if (!org || !orgRole) {
      console.log("Access denied. User is not a member.");
      return res.status(403).json({
        success: false,
        message: "Access denied.",
      });
    }

    const member = org.members.find((m) => getId(m.user) === req.user.id);

    console.log("Current Member:", member);

    const bypass = hasOrgLevelBypass(orgRole);
    console.log("Has Org Bypass:", bypass);

    console.log(
      "Has project.create:",
      member?.permissions?.includes("project.create")
    );

    if (
      !bypass &&
      !member?.permissions?.includes("project.create")
    ) {
      console.log("Permission denied to create project.");
      return res.status(403).json({
        success: false,
        message: "No permission to create projects in this organization.",
      });
    }

    const projectCode = await generateProjectCode(projectType);

    console.log("Generated Project Code:", projectCode);

    const creatorId = getId(req.user.id);
    console.log("Creator ID:", creatorId);

    const leadershipIds = new Set();

    if (getId(org.owner) !== creatorId) {
      leadershipIds.add(getId(org.owner));
      console.log("Added Organization Owner:", getId(org.owner));
    }

    org.members
      .filter(
        (m) =>
          m.role === "admin" &&
          m.status === "accepted" &&
          getId(m.user) !== creatorId
      )
      .forEach((m) => {
        leadershipIds.add(getId(m.user));
        console.log("Added Organization Admin:", getId(m.user));
      });

    console.log("Leadership IDs:", [...leadershipIds]);

    const autoTeamEntries = [...leadershipIds].map((userId) => ({
      user: userId,
      role: userId === getId(org.owner) ? "owner" : "admin",
      permissions:
        userId === getId(org.owner)
          ? DEFAULT_ROLE_PERMISSIONS.owner
          : DEFAULT_ROLE_PERMISSIONS.admin,
      invitedBy: req.user.id,
    }));

    console.log("Auto Team Entries:", autoTeamEntries);

    const project = new Project({
      organization,
      projectCode,
      name,
      description,
      projectType: projectType || "internal",
      status: status || "planning",
      priority: priority || "medium",
      visibility: visibility || "private",
      health: health || "healthy",
      owner: req.user.id,
      startDate,
      endDate,
      estimatedHours: estimatedHours || 0,
      loggedHours: 0,
      progress: 0,
      lastActivityAt: new Date(),
      team: [
        {
          user: req.user.id,
          role: "owner",
          permissions: DEFAULT_ROLE_PERMISSIONS.owner,
          invitedBy: req.user.id,
        },
        ...autoTeamEntries,
      ],
      milestones: bodyMilestones.map((m, idx) => ({
        ...m,
        order: idx + 1,
      })),
    });

    console.log("Saving project...");

    await project.save();

    console.log("Project Saved:", project._id);

    await logProjectActivity(project, req.user.id, "project_created", {
      entity: "Project",
      entityId: project._id,
      description: `Project "${project.name}" created`,
    });

    console.log("Activity logged.");

    const createdProject = await Project.findById(project._id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    console.log("Project populated.");

    await sendNotification({
      userId: req.user.id,
      type: "project_created",
      title: "Project Created",
      message: `You created "${createdProject.name}" (${createdProject.projectCode}).`,
      relatedProject: createdProject._id,
      link: projectLink(createdProject._id),
    });

    console.log("Creator notification sent.");

    if (autoTeamEntries.length) {
      console.log(
        "Sending bulk notification to:",
        autoTeamEntries.map((e) => e.user)
      );

      await sendBulkNotification(
        autoTeamEntries.map((e) => e.user),
        {
          type: "member_added",
          title: "Added to Project",
          message: `You were automatically added to "${createdProject.name}" as an organization ${orgRole === "owner" ? "owner" : "admin"}.`,
          relatedProject: createdProject._id,
          link: projectLink(createdProject._id),
        }
      );

      console.log("Bulk notification sent.");
    }

    console.log("Project creation completed successfully.");
    console.log("====================================");

    return res.status(201).json({
      success: true,
      message: "Project created successfully.",
      data: withPermissionContext(createdProject, orgRole, req.user.id),
    });
  } catch (error) {
    console.error("========== CREATE PROJECT ERROR ==========");
    console.error(error);
    console.error("==========================================");

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const update = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findOne({ _id: id, isDeleted: false });
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const { allowed, orgRole } = await resolveAccess(project, req.user.id);
    if (!allowed) return res.status(403).json({ success: false, message: "Access denied." });
    if (!hasProjectPermission(project, orgRole, req.user.id, 'project.edit')) {
      return res.status(403).json({ success: false, message: "No permission to edit this project." });
    }

    const {
      name, description, projectType, status, priority, health, visibility,
      startDate, endDate, estimatedHours, milestones: bodyMilestones = [],
    } = req.body;

    if (name !== undefined) project.name = name;
    if (description !== undefined) project.description = description;
    if (projectType !== undefined) project.projectType = projectType;
    if (priority !== undefined) project.priority = priority;
    if (health !== undefined) project.health = health;
    if (visibility !== undefined) project.visibility = visibility;
    if (startDate !== undefined) project.startDate = startDate;
    if (endDate !== undefined) project.endDate = endDate;
    if (estimatedHours !== undefined) project.estimatedHours = estimatedHours;

    if (status !== undefined) {
      if (!hasProjectPermission(project, orgRole, req.user.id, 'project.status.edit')) {
        return res.status(403).json({ success: false, message: "No permission to change project status." });
      }
      project.status = status;
      if (status === "completed") {
        project.completedAt = new Date();
        project.progress = 100;
      } else {
        project.completedAt = null;
      }
    }

    const defaultMilestone = project.milestones.find((m) => m.name === "Project Milestone");
    if (defaultMilestone) {
      if (startDate !== undefined) defaultMilestone.startDate = startDate;
      if (endDate !== undefined) defaultMilestone.dueDate = endDate;
      if (priority !== undefined) defaultMilestone.priority = priority;
    }

    if (bodyMilestones.length > 0) {
      if (!hasProjectPermission(project, orgRole, req.user.id, 'milestone.edit')) {
        return res.status(403).json({ success: false, message: "No permission to edit milestones." });
      }
      const milestoneMap = new Map();
      project.milestones.forEach((m) => milestoneMap.set(m._id?.toString(), m));

      bodyMilestones.forEach((bodyMilestone) => {
        if (bodyMilestone._id) {
          const existing = milestoneMap.get(bodyMilestone._id.toString());
          if (existing) Object.assign(existing, bodyMilestone);
        } else {
          if (!hasProjectPermission(project, orgRole, req.user.id, 'milestone.create')) return;
          const newOrder = project.milestones.length + 1;
          project.milestones.push({ ...bodyMilestone, order: newOrder });
        }
      });
    }

    project.lastActivityAt = new Date();
    await project.save();

    await logProjectActivity(project, req.user.id, 'project_updated', {
      entity: 'Project',
      entityId: project._id,
      description: `Updated project "${project.name}"`,
    });

    const updated = await Project.findById(project._id)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    return res.json({
      success: true,
      message: "Project updated successfully.",
      data: withPermissionContext(updated, orgRole, req.user.id),
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const getStats = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findOne({ _id: id, isDeleted: { $ne: true } });
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const { allowed, orgRole } = await resolveAccess(project, req.user.id);
    if (!allowed) return res.status(403).json({ success: false, message: "Access denied." });

    const totalTasks = await Task.countDocuments({ project: id, isDeleted: { $ne: true } });
    const completedTasks = await Task.countDocuments({ project: id, isDeleted: { $ne: true }, status: "completed" });
    const overdueTasks = await Task.countDocuments({
      project: id,
      isDeleted: { $ne: true },
      status: { $ne: "completed" },
      dueDate: { $lt: new Date() },
    });

    const now = new Date();
    const isProjectOverdue = !!(project.endDate && project.endDate < now && project.status !== 'completed' && project.status !== 'cancelled');

    res.json({
      success: true,
      data: {
        projectCode: project.projectCode,
        projectName: project.name,
        status: project.status,
        priority: project.priority,
        health: project.health,
        progress: project.progress,
        totalTasks,
        completedTasks,
        pendingTasks: totalTasks - completedTasks,
        overdueTasks,
        teamMembers: project.team.length,
        estimatedHours: project.estimatedHours,
        loggedHours: project.loggedHours,
        isOverdue: isProjectOverdue,
        endDate: project.endDate,
        milestones: project.milestones,
      },
      currentUserPermissions: buildPermissionContext(project, orgRole, req.user.id),
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const addTeamMember = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { userId, role, permissions } = req.body;

    if (!mongoose.Types.ObjectId.isValid(projectId)) return res.status(400).json({ success: false, message: "Invalid project id." });
    if (!mongoose.Types.ObjectId.isValid(userId)) return res.status(400).json({ success: false, message: "Invalid user id." });

    const project = await Project.findOne({ _id: projectId, isDeleted: false });
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const { org, orgRole: requesterOrgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
    if (!org || !requesterOrgRole) return res.status(403).json({ success: false, message: "Access denied." });
    if (!hasProjectPermission(project, requesterOrgRole, req.user.id, 'team.invite')) {
      return res.status(403).json({ success: false, message: "No permission to add members." });
    }

    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: "User not found." });

    const targetOrgRole = getOrgRole(org, userId);
    if (!targetOrgRole) {
      return res.status(400).json({ success: false, message: "User must be a member of this organization before being added to a project." });
    }

    if (getId(project.owner) === userId) {
      return res.status(400).json({ success: false, message: "Owner is already part of this project." });
    }
    if (project.team.some((t) => getId(t.user) === userId)) {
      return res.status(400).json({ success: false, message: "User already in team." });
    }

    const resolvedRole = role || ORG_ROLE_TO_PROJECT_ROLE[targetOrgRole] || 'member';

    if (resolvedRole === 'manager' && requesterOrgRole !== 'owner' && requesterOrgRole !== 'admin') {
      return res.status(403).json({ success: false, message: "Only an organization owner/admin can assign the manager role." });
    }
    const resolvedPermissions = permissions?.length ? permissions : (DEFAULT_ROLE_PERMISSIONS[resolvedRole] || []);

    project.team.push({
      user: userId,
      role: resolvedRole,
      permissions: resolvedPermissions,
      invitedBy: req.user.id,
    });

    project.lastActivityAt = new Date();
    await project.save();

    await logProjectActivity(project, req.user.id, 'member_added', {
      entity: 'User',
      entityId: userId,
      description: `${user.name} added as ${resolvedRole}`,
    });

    const updated = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    await sendNotification({
      userId,
      type: "member_added",
      title: "Added to Project",
      message: `You were added to "${updated.name}" as ${resolvedRole}.`,
      relatedProject: updated._id,
      link: projectLink(updated._id),
    });

    return res.status(200).json({
      success: true,
      message: "Team member added successfully.",
      data: withPermissionContext(updated, requesterOrgRole, req.user.id),
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const removeTeamMember = async (req, res) => {
  try {
    const { projectId, userId } = req.params;
    const project = await Project.findOne({ _id: projectId, isDeleted: false })
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
    if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
    if (!hasProjectPermission(project, orgRole, req.user.id, 'team.remove')) {
      return res.status(403).json({ success: false, message: "No permission to remove members." });
    }

    const member = project.team.find((t) => getId(t.user) === userId);
    if (!member) return res.status(404).json({ success: false, message: "Member not found." });

    if (member.role === "owner" || getId(member.user) === getId(project.owner)) {
      return res.status(400).json({ success: false, message: "Cannot remove the project owner." });
    }

    const removedUserName = member.user?.name || 'A team member';
    project.team = project.team.filter((t) => getId(t.user) !== userId);
    project.lastActivityAt = new Date();
    await project.save();

    await logProjectActivity(project, req.user.id, 'member_removed', {
      entity: 'User',
      entityId: userId,
      description: `${removedUserName} removed from project`,
    });

    const updated = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    await sendNotification({
      userId,
      type: 'project_member_removed',
      title: 'Removed from Project',
      message: `You were removed from "${updated.name}".`,
      relatedProject: updated._id,
      link: projectTrashLink(),
    });

    const remainingRecipients = [updated.owner, ...updated.team.map((t) => t.user)]
      .filter((u) => getId(u) !== req.user.id);

    await sendBulkNotification(remainingRecipients, {
      type: 'project_member_removed',
      title: 'Team Member Removed',
      message: `${removedUserName} was removed from "${updated.name}".`,
      relatedProject: updated._id,
      link: projectTeamLink(updated._id),
    });

    return res.json({ success: true, message: "Team member removed successfully.", data: withPermissionContext(updated, orgRole, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

export const updateTeamMember = async (req, res) => {
  try {
    const { projectId, userId } = req.params;
    const { role, permissions } = req.body;

    console.log("\n========== UPDATE TEAM MEMBER ==========");
    console.log("Request User:", {
      id: req.user.id,
      email: req.user.email,
      role: req.user.role,
    });
    console.log("Project ID:", projectId);
    console.log("Target User ID:", userId);
    console.log("Request Body:", req.body);

    const project = await Project.findOne({ _id: projectId, isDeleted: false });
    if (!project) {
      console.log("❌ Project not found.");
      return res.status(404).json({ success: false, message: "Project not found." });
    }

    console.log("Project:", {
      id: project._id,
      name: project.name,
      organization: project.organization,
    });

    const { org, orgRole } = await loadOrgAndCheckMembership(
      project.organization,
      req.user.id
    );

    if (!org || !orgRole) {
      console.log("❌ User is not an organization member.");
      return res.status(403).json({ success: false, message: "Access denied." });
    }

    console.log("Organization Role:", orgRole);

    const member = project.team.find((t) => getId(t.user) === userId);

    if (!member) {
      console.log("❌ Team member not found.");
      return res.status(404).json({ success: false, message: "Member not found." });
    }

    console.log("\n----- BEFORE UPDATE -----");
    console.log("Current Role:", member.role);
    console.log("Current Permissions:", member.permissions);

    const editingRole = role !== undefined;
    const editingPermissions = permissions !== undefined;

    console.log("Editing Role:", editingRole);
    console.log("Editing Permissions:", editingPermissions);

    if (
      editingRole &&
      !hasProjectPermission(project, orgRole, req.user.id, "team.role.edit")
    ) {
      console.log("❌ Missing permission: team.role.edit");
      return res.status(403).json({
        success: false,
        message: "No permission to change member roles.",
      });
    }

    if (
      editingPermissions &&
      !hasProjectPermission(
        project,
        orgRole,
        req.user.id,
        "team.permissions.edit"
      )
    ) {
      console.log("❌ Missing permission: team.permissions.edit");
      return res.status(403).json({
        success: false,
        message: "No permission to change member permissions.",
      });
    }

    if (
      role === "manager" &&
      orgRole !== "owner" &&
      orgRole !== "admin"
    ) {
      console.log("❌ Only organization owner/admin can assign manager.");
      return res.status(403).json({
        success: false,
        message:
          "Only an organization owner/admin can assign the manager role.",
      });
    }

    const canEditSelf = getId(member.user) === getId(req.user.id);

    const hasEditPermission =
      hasProjectPermission(project, orgRole, req.user.id, "team.role.edit") ||
      hasProjectPermission(
        project,
        orgRole,
        req.user.id,
        "team.permissions.edit"
      );

    console.log("Can Edit Self:", canEditSelf);
    console.log("Has Edit Permission:", hasEditPermission);

    if (!canEditSelf && !hasEditPermission) {
      console.log("❌ No permission to edit this member.");
      return res.status(403).json({
        success: false,
        message: "No permission to edit this member's role/permissions.",
      });
    }

    const oldRole = member.role;
    const oldPermissions = [...member.permissions];

    console.log("\n----- REQUESTED UPDATE -----");
    console.log("Requested Role:", role);
    console.log("Requested Permissions:", permissions);

    if (editingRole) {
      member.role = role;
    }

    if (editingPermissions) {
      console.log("Updating custom permissions...");
      member.permissions = permissions;
    } else if (editingRole) {
      console.log("Applying default permissions for role:", role);
      console.log(
        "Default Permissions:",
        DEFAULT_ROLE_PERMISSIONS[role] || []
      );
      member.permissions = DEFAULT_ROLE_PERMISSIONS[role] || [];
    }

    console.log("\n----- AFTER UPDATE -----");
    console.log("New Role:", member.role);
    console.log("New Permissions:", member.permissions);

    const addedPermissions = member.permissions.filter(
      (p) => !oldPermissions.includes(p)
    );

    const removedPermissions = oldPermissions.filter(
      (p) => !member.permissions.includes(p)
    );

    console.log("\n----- PERMISSION CHANGES -----");
    console.log("Old Permissions:", oldPermissions);
    console.log("New Permissions:", member.permissions);
    console.log("Added Permissions:", addedPermissions);
    console.log("Removed Permissions:", removedPermissions);

    const roleChanged = oldRole !== member.role;

    const permissionsChanged =
      JSON.stringify([...oldPermissions].sort()) !==
      JSON.stringify([...member.permissions].sort());

    console.log("\n----- CHANGE SUMMARY -----");
    console.log("Role Changed:", roleChanged);
    console.log("Permissions Changed:", permissionsChanged);

    project.lastActivityAt = new Date();
    await project.save();

    if (roleChanged || permissionsChanged) {
      await logProjectActivity(
        project,
        req.user.id,
        roleChanged
          ? "member_role_changed"
          : "member_permissions_changed",
        {
          entity: "User",
          entityId: userId,
          previousValue: {
            role: oldRole,
            permissions: oldPermissions,
          },
          newValue: {
            role: member.role,
            permissions: member.permissions,
          },
          description: roleChanged
            ? `Role changed from "${oldRole}" to "${member.role}"`
            : `Permissions updated for ${member.role}`,
        }
      );

      await sendNotification({
        userId,
        type: "member_updated",
        title: "Your Project Access Changed",
        message: roleChanged
          ? `Your role in "${project.name}" changed from ${oldRole} to ${member.role}.`
          : `Your permissions in "${project.name}" were updated.`,
        relatedProject: project._id,
        link: projectLink(project._id),
      });
    }

    const updated = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    console.log("✅ Team member updated successfully.");
    console.log("========================================\n");

    return res.json({
      success: true,
      message: "Team member updated successfully.",
      data: withPermissionContext(updated, orgRole, req.user.id),
    });
  } catch (error) {
    console.error("❌ UPDATE TEAM MEMBER ERROR:", error);
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const remove = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findOne({ _id: id, isDeleted: false })
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
    if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
    if (!hasProjectPermission(project, orgRole, req.user.id, 'project.delete')) {
      return res.status(403).json({ success: false, message: 'No permission to delete this project.' });
    }

    project.isDeleted = true;
    project.deletedAt = new Date();
    project.deletedBy = req.user.id;
    await project.save();

    await Task.updateMany({ project: id, isDeleted: false }, {
      isDeleted: true,
      deletedAt: new Date(),
      deletedBy: req.user.id,
    });

    await File.updateMany({ project: id, deleted: false }, {
      deleted: true,
      deletedAt: new Date(),
    });

    await logProjectActivity(project, req.user.id, 'project_deleted', {
      entity: 'Project',
      entityId: id,
      description: `Project "${project.name}" deleted`,
    });

    const recipients = [project.owner, ...project.team.map((t) => t.user)]
      .filter((u) => getId(u) !== req.user.id);

    await sendBulkNotification(recipients, {
      type: 'project_deleted',
      title: 'Project Deleted',
      message: `"${project.name}" was deleted. It can be restored within 30 days.`,
      relatedProject: project._id,
      link: projectTrashLink(),
    });

    res.json({ success: true, message: 'Project deleted successfully. It can be restored from the trash.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const restore = async (req, res) => {
  try {
    const { id } = req.params;
    const project = await Project.findOne({ _id: id, isDeleted: true })
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: 'Deleted project not found.' });

    const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
    if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
    if (!hasOrgLevelBypass(orgRole) && getId(project.deletedBy) !== req.user.id && !isProjectOwner(project, req.user.id)) {
      return res.status(403).json({ success: false, message: 'No permission to restore this project.' });
    }

    project.isDeleted = false;
    project.deletedAt = null;
    project.deletedBy = null;
    await project.save();

    await Task.updateMany({ project: id, deletedAt: { $ne: null } }, {
      isDeleted: false,
      deletedAt: null,
      deletedBy: null,
    });

    await File.updateMany({ project: id, deleted: true }, {
      deleted: false,
      deletedAt: null,
    });

    await logProjectActivity(project, req.user.id, 'project_restored', {
      entity: 'Project',
      entityId: id,
      description: `Project "${project.name}" restored`,
    });

    const recipients = [project.owner, ...project.team.map((t) => t.user)]
      .filter((u) => getId(u) !== req.user.id);

    await sendBulkNotification(recipients, {
      type: 'project_restored',
      title: 'Project Restored',
      message: `"${project.name}" was restored.`,
      relatedProject: project._id,
      link: projectLink(project._id),
    });

    res.json({ success: true, message: 'Project restored successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const removeMilestone = async (req, res) => {
  try {
    const { projectId, milestoneId } = req.params;
    const project = await Project.findOne({ _id: projectId, isDeleted: false })
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
    if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
    if (!hasProjectPermission(project, orgRole, req.user.id, 'milestone.delete')) {
      return res.status(403).json({ success: false, message: 'No permission to delete milestones.' });
    }

    const milestone = project.milestones.find(m => m._id.toString() === milestoneId);
    if (!milestone) return res.status(404).json({ success: false, message: 'Milestone not found.' });

    await Task.updateMany(
      { project: projectId, milestone: milestoneId, isDeleted: false },
      { $unset: { milestone: 1 } }
    );

    project.milestones = project.milestones.filter(m => m._id.toString() !== milestoneId);
    project.lastActivityAt = new Date();
    await project.save();

    await logProjectActivity(project, req.user.id, 'milestone_removed', {
      entity: 'Milestone',
      entityId: milestoneId,
      description: `Milestone "${milestone.name}" removed from project`,
    });

    const updated = await Project.findById(projectId)
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");

    res.json({ success: true, message: 'Milestone removed.', data: withPermissionContext(updated, orgRole, req.user.id) });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const allowedStatus = ["planning", "active", "on_hold", "completed", "cancelled"];

    if (!allowedStatus.includes(status)) return res.status(400).json({ success: false, message: "Invalid status." });

    const project = await Project.findOne({ _id: id, isDeleted: false })
      .populate("owner", "name email avatar")
      .populate("team.user", "name email avatar");
    if (!project) return res.status(404).json({ success: false, message: "Project not found." });

    const { org, orgRole } = await loadOrgAndCheckMembership(project.organization, req.user.id);
    if (!org || !orgRole) return res.status(403).json({ success: false, message: "Access denied." });
    if (!hasProjectPermission(project, orgRole, req.user.id, 'project.status.edit')) {
      return res.status(403).json({ success: false, message: "No permission to change project status." });
    }

    const previousStatus = project.status;
    project.status = status;

    if (status === "completed") {
      project.completedAt = new Date();
      project.progress = 100;
    } else {
      project.completedAt = null;
    }

    project.lastActivityAt = new Date();
    await project.save();

    await logProjectActivity(project, req.user.id, 'project_status_changed', {
      entity: 'Project',
      entityId: project._id,
      description: `Status changed from "${previousStatus}" to "${status}"`,
    });

    res.json({
      success: true,
      message: "Project status updated successfully.",
      data: { projectId: project._id, status: project.status, progress: project.progress, completedAt: project.completedAt },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const runDeadlineReminders = async () => {
  const now = new Date();
  const warningWindowStart = now;
  const warningWindowEnd = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
  const startOfToday = new Date(now); startOfToday.setHours(0, 0, 0, 0);

  const candidates = await Project.find({
    isDeleted: false,
    status: { $nin: ['completed', 'cancelled'] },
    endDate: { $ne: null },
    $or: [
      { lastDeadlineReminderAt: null },
      { lastDeadlineReminderAt: { $lt: startOfToday } },
    ],
  })
    .populate("owner", "name email")
    .populate("team.user", "name email");

  for (const project of candidates) {
    const isUpcoming = project.endDate >= warningWindowStart && project.endDate <= warningWindowEnd;
    const isOverdue = project.endDate < now;
    if (!isUpcoming && !isOverdue) continue;

    const recipients = [project.owner, ...project.team.map((t) => t.user)];

    await sendBulkNotification(recipients, {
      type: isOverdue ? 'project_deadline_overdue' : 'project_deadline_upcoming',
      title: isOverdue ? 'Project Deadline Passed' : 'Project Deadline Approaching',
      message: isOverdue
        ? `"${project.name}" is now past its deadline.`
        : `"${project.name}" is due soon.`,
      relatedProject: project._id,
      link: projectLink(project._id),
    });

    project.lastDeadlineReminderAt = now;
    await project.save();
  }
};