
// import Task from '../models/Task.js';
// import Activity from '../models/Activity.js';
// import Project from '../models/Project.js';
// import Organization from '../models/Organization.js';
// import Comment from '../models/Comment.js';
// import File from '../models/File.js';
// import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';
// import { sendNotification, notifyTaskParticipants, sendBulkNotification, notifyProjectTeam } from '../utils/sendNotification.js';
// import { computeTaskProgress, computeMilestoneStats, computeProjectProgress } from '../utils/progressEngine.js';
// import { taskLink, projectLink } from '../utils/routeLinks.js';
// import { checkProjectPermission, isTaskAssignee, attachTaskUserFlags } from '../utils/permissions.js';

// import fs from 'fs/promises';
// import path from 'path';
// import mongoose from 'mongoose';
// import { recalcWorkloadForUsers } from './workloadController.js';

// const getOrgSlug = async (organizationId) => {
//   const org = await Organization.findById(organizationId).select('slug');
//   return org?.slug || '';
// };

// const validateTaskDates = ({ taskStart, taskDue, projectStart, projectEnd }) => {
//   const start = taskStart ? new Date(taskStart) : null;
//   const due = taskDue ? new Date(taskDue) : null;
//   const pStart = projectStart ? new Date(projectStart) : null;
//   const pEnd = projectEnd ? new Date(projectEnd) : null;

//   if (start && due && start > due) return 'Due date cannot be before start date';
//   if (pStart && start && start < pStart) return 'Task start date cannot be before project start date';
//   if (pEnd && due && due > pEnd) return 'Task due date cannot be after project end date';
//   return null;
// };

// const validateTaskAgainstMilestone = (taskStart, taskDue, milestone) => {
//   if (!milestone) return null;
//   const toDateOnly = (date) => {
//     if (!date) return null;
//     const d = new Date(date);
//     return new Date(d.getFullYear(), d.getMonth(), d.getDate());
//   };
//   const tStart = toDateOnly(taskStart);
//   const tDue = toDateOnly(taskDue);
//   const mStart = toDateOnly(milestone.startDate);
//   const mDue = toDateOnly(milestone.dueDate);

//   if (tStart && tDue && tStart > tDue) return 'Task due date must be after task start date';
//   if (mStart && tStart && tStart < mStart) return `Task start date cannot be before milestone start date (${mStart.toLocaleDateString()})`;
//   if (mDue && tDue && tDue > mDue) return `Task due date cannot be after milestone due date (${mDue.toLocaleDateString()})`;
//   return null;
// };

// export const listByProject = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const page = parseInt(req.query.page) || 1;
//     const limit = parseInt(req.query.limit) || 10;
//     const search = req.query.search || '';
//     const status = req.query.status || '';
//     const priority = req.query.priority || '';
//     const filterType = req.query.filterType || 'all';
//     const sortBy = req.query.sortBy || 'createdAt';
//     const sortOrder = req.query.sortOrder || 'desc';

//     const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

//     let query = { project: projectId, isDeleted: { $ne: true } };
//     if (filterType === 'assigned') query.assignees = req.user.id;
//     else if (filterType === 'watching') query.watchers = req.user.id;
//     if (search) query.$or = [{ title: { $regex: search, $options: 'i' } }, { description: { $regex: search, $options: 'i' } }, { tags: { $regex: search, $options: 'i' } }];
//     if (status) query.status = status;
//     if (priority) query.priority = priority;

//     const total = await Task.countDocuments(query);
//     const sortOptions = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

//     const tasks = await Task.find(query)
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('createdBy', 'name email')
//       .sort(sortOptions)
//       .limit(limit)
//       .skip((page - 1) * limit);

//     const tasksOut = tasks.map((t) => {
//       const obj = t.toObject();
//       obj.progress = computeTaskProgress(t);
//       return attachTaskUserFlags(obj, req.user.id);
//     });

//     res.json({
//       success: true,
//       data: tasksOut,
//       pagination: { total, page, limit, pages: Math.ceil(total / limit), hasNext: page * limit < total, hasPrevious: page > 1 },
//     });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const getMyTasks = async (req, res) => {
//   try {
//     const { page = 1, limit = 10, type = 'all', projectId } = req.query;
//     const userId = req.user.id;

//     let query = { isDeleted: { $ne: true } };
//     if (projectId) query.project = projectId;

//     switch (type) {
//       case 'assigned': query.assignees = userId; break;
//       case 'watching': query.watchers = userId; break;
//       default: query.$or = [{ assignees: userId }, { watchers: userId }];
//     }

//     const total = await Task.countDocuments(query);
//     const tasks = await Task.find(query)
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('createdBy', 'name email')
//       .sort({ createdAt: -1 })
//       .skip((Number(page) - 1) * Number(limit))
//       .limit(Number(limit));

//     const tasksOut = tasks.map((t) => {
//       const obj = t.toObject();
//       obj.progress = computeTaskProgress(t);
//       return attachTaskUserFlags(obj, userId);
//     });

//     res.json({
//       success: true,
//       data: tasksOut,
//       filters: { type },
//       pagination: {
//         total, page: Number(page), limit: Number(limit),
//         pages: Math.ceil(total / Number(limit)),
//         hasNext: Number(page) < Math.ceil(total / Number(limit)),
//         hasPrevious: Number(page) > 1,
//       },
//     });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const getMyTaskStats = async (req, res) => {
//   try {
//     const { projectId } = req.query;
//     const userId = new mongoose.Types.ObjectId(req.user.id);

//     const assignedMatch = { assignees: userId, isDeleted: { $ne: true } };
//     if (projectId) assignedMatch.project = new mongoose.Types.ObjectId(projectId);

//     const stats = await Task.aggregate([
//       { $match: assignedMatch },
//       { $group: {
//         _id: null,
//         total: { $sum: 1 },
//         completed: { $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] } },
//         pending: { $sum: { $cond: [{ $in: ['$status', ['todo', 'in-progress', 'review']] }, 1, 0] } },
//       } },
//     ]);

//     const result = stats[0] || { total: 0, completed: 0, pending: 0 };
//     const overdue = await Task.countDocuments({ ...assignedMatch, dueDate: { $lt: new Date() }, status: { $ne: 'completed' } });

//     const watchingQuery = { watchers: userId, isDeleted: { $ne: true } };
//     if (projectId) watchingQuery.project = new mongoose.Types.ObjectId(projectId);
//     const watching = await Task.countDocuments(watchingQuery);

//     res.json({
//       success: true,
//       data: {
//         total: result.total,
//         completed: result.completed,
//         pending: result.pending,
//         overdue,
//         watching,
//         completionRate: result.total > 0 ? Math.round((result.completed / result.total) * 100) : 0,
//       },
//     });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// const updateMilestoneProgress = async (projectId, milestoneId) => {
//   const project = await Project.findById(projectId);
//   if (!project) return;

//   if (milestoneId) {
//     const milestone = project.milestones.find((m) => m._id.toString() === milestoneId.toString());
//     if (milestone) {
//       const tasks = await Task.find({ project: projectId, milestone: milestoneId, isDeleted: { $ne: true } }).select('status checklist dueDate');
//       const stats = computeMilestoneStats(tasks);
//       const wasCompleted = milestone.status === 'completed';
//       const nowCompleted = stats.status === 'completed';

//       await Project.updateOne(
//         { _id: projectId, 'milestones._id': milestoneId },
//         { $set: { 'milestones.$.status': stats.status, 'milestones.$.progress': stats.progress, 'milestones.$.completedAt': nowCompleted ? new Date() : null } }
//       );

//       if (!wasCompleted && nowCompleted) {
//         const populated = await Project.findById(projectId).populate('owner', 'name email avatar').populate('team.user', 'name email avatar');
//         const orgSlug = await getOrgSlug(populated.organization);
//         await notifyProjectTeam(populated, {
//           type: 'milestone_completed',
//           title: 'Milestone Completed',
//           message: `Milestone "${milestone.name}" in "${populated.name}" reached 100%.`,
//           link: projectLink(orgSlug, populated._id),
//         });
//       }
//     }
//   }

//   await syncProjectProgressFromTasks(projectId);
// };

// const syncProjectProgressFromTasks = async (projectId) => {
//   const project = await Project.findById(projectId);
//   if (!project) return;

//   const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).select('status checklist milestone dueDate');
//   const totalTasks = tasks.length;

//   const milestoneStatsList = project.milestones.map((m) => computeMilestoneStats(tasks.filter((t) => t.milestone && t.milestone.toString() === m._id.toString())));
//   const unassignedTasks = tasks.filter((t) => !t.milestone);
//   const progress = computeProjectProgress({ milestoneStatsList, unassignedTasks });

//   let newStatus = project.status;
//   let completedAt = project.completedAt;

//   if (project.status === 'planning' && totalTasks > 0) newStatus = 'active';

//   const allMilestonesDone = project.milestones.length === 0 || project.milestones.every((m) => m.status === 'completed');

//   if (['planning', 'active'].includes(newStatus) && totalTasks > 0 && progress === 100 && allMilestonesDone) {
//     newStatus = 'completed';
//     completedAt = new Date();
//   } else if (newStatus === 'completed' && (progress < 100 || !allMilestonesDone)) {
//     newStatus = 'active';
//     completedAt = null;
//   }

//   const statusChanged = newStatus !== project.status;
//   await Project.updateOne({ _id: projectId }, { $set: { progress, status: newStatus, completedAt, lastActivityAt: new Date() } });

//   if (statusChanged && (newStatus === 'completed' || newStatus === 'active')) {
//     const populated = await Project.findById(projectId).populate('owner', 'name email avatar').populate('team.user', 'name email avatar');
//     const orgSlug = await getOrgSlug(populated.organization);

//     await notifyProjectTeam(populated, {
//       type: 'project_status_changed',
//       title: newStatus === 'completed' ? 'Project Completed' : 'Project Now Active',
//       message: newStatus === 'completed' ? `Project "${populated.name}" reached 100% completion.` : `Project "${populated.name}" is now active based on task activity.`,
//       link: projectLink(orgSlug, populated._id),
//     });

//     await Activity.create({
//       organization: populated.organization,
//       project: projectId,
//       level: 'project',
//       user: project.owner,
//       type: 'project_status_changed',
//       entity: 'Project',
//       entityId: projectId,
//       description: `Project status auto-updated to "${newStatus}" based on task activity`,
//     });
//   }
// };

// export const create = async (req, res) => {
//   const session = await mongoose.startSession();
//   session.startTransaction();
//   try {
//     const { projectId } = req.params;
//     const { title, description, assignees, watchers, priority, dueDate, startDate, estimatedHours, labels, tags, estimatedEffort, dependencies = [], checklist = [], milestone } = req.body;

//     const { allowed, project } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_CREATE);
//     if (!allowed) {
//       await session.abortTransaction();
//       return res.status(403).json({ success: false, message: 'You do not have permission to create tasks in this project.' });
//     }
//     if (!project) {
//       await session.abortTransaction();
//       return res.status(404).json({ success: false, message: 'Project not found.' });
//     }

//     if (!milestone) {
//       await session.abortTransaction();
//       return res.status(400).json({ success: false, message: 'Milestone is required when creating a task.' });
//     }

//     const milestoneDoc = project.milestones.find((m) => m._id.toString() === milestone);
//     if (!milestoneDoc) {
//       await session.abortTransaction();
//       return res.status(400).json({ success: false, message: 'Invalid milestone.' });
//     }

//     const dateError = validateTaskDates({ taskStart: startDate, taskDue: dueDate, projectStart: project.startDate, projectEnd: project.endDate });
//     if (dateError) {
//       await session.abortTransaction();
//       return res.status(400).json({ success: false, message: dateError });
//     }

//     const milestoneDateError = validateTaskAgainstMilestone(startDate, dueDate, milestoneDoc);
//     if (milestoneDateError) {
//       await session.abortTransaction();
//       return res.status(400).json({ success: false, message: milestoneDateError });
//     }

//     let validDependencies = [];
//     if (dependencies.length > 0) {
//       const depIds = dependencies.map((d) => d._id || d);
//       const depTasks = await Task.find({ _id: { $in: depIds }, project: projectId, isDeleted: { $ne: true } }).session(session);
//       if (depTasks.length !== depIds.length) {
//         await session.abortTransaction();
//         return res.status(400).json({ success: false, message: 'One or more dependencies are invalid for this project.' });
//       }
//       validDependencies = depIds;
//     }

//     const task = new Task({
//       title, description, project: projectId, assignees: assignees || [], watchers: watchers || [],
//       priority: priority || 'medium', dueDate, startDate, estimatedHours: Number(estimatedHours || 0),
//       labels: labels || [], tags: tags || [], estimatedEffort: estimatedEffort || 'medium',
//       createdBy: req.user.id, dependencies: validDependencies, checklist, milestone,
//     });

//     await task.save({ session });

//     if (assignees?.length) await recalcWorkloadForUsers(projectId, assignees);
//     await updateMilestoneProgress(projectId, milestone);

//     const orgSlug = await getOrgSlug(project.organization);
//     const link = taskLink(orgSlug, projectId, task._id);

//     await sendBulkNotification(assignees, {
//       type: 'task_assigned',
//       title: 'New Task Assigned',
//       message: `You have been assigned to task "${title}" in project "${project.name}"`,
//       relatedTask: task._id,
//       relatedProject: projectId,
//       link,
//     });

//     await notifyTaskParticipants(task, project, {
//       type: 'task_created',
//       title: 'Task Created',
//       message: `Task "${title}" was created in "${project.name}".`,
//       excludeUserId: req.user.id,
//       link,
//     });

//     await Activity.create([{
//       organization: project.organization,
//       project: projectId,
//       level: 'task',
//       task: task._id,
//       user: req.user.id,
//       type: 'task_created',
//       entity: 'Task',
//       entityId: task._id,
//       description: `Task "${title}" created`,
//     }], { session });

//     await session.commitTransaction();

//     const populatedTask = await Task.findById(task._id)
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('createdBy', 'name email')
//       .populate('dependencies');

//     const taskObj = populatedTask.toObject();
//     taskObj.progress = computeTaskProgress(populatedTask);

//     res.status(201).json({ success: true, message: 'Task created successfully.', data: attachTaskUserFlags(taskObj, req.user.id) });
//   } catch (error) {
//     await session.abortTransaction();
//     res.status(500).json({ success: false, error: error.message });
//   } finally {
//     session.endSession();
//   }
// };

// export const update = async (req, res) => {
//   const session = await mongoose.startSession();
//   session.startTransaction();
//   try {
//     const { id } = req.params;
//     const oldTask = await Task.findById(id).session(session);
//     if (!oldTask) {
//       await session.abortTransaction();
//       return res.status(404).json({ success: false, message: 'Task not found.' });
//     }

//     const { allowed, project } = await checkProjectPermission(req.user.id, oldTask.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) {
//       await session.abortTransaction();
//       return res.status(403).json({ success: false, message: 'You do not have permission to edit this task.' });
//     }
//     if (!project) {
//       await session.abortTransaction();
//       return res.status(404).json({ success: false, message: 'Project not found.' });
//     }

//     const { title, description, status, priority, dueDate, startDate, estimatedHours, assignees, watchers, labels, tags, estimatedEffort, dependencies, checklist, milestone } = req.body;

//     const effectiveStart = startDate !== undefined ? startDate : oldTask.startDate;
//     const effectiveDue = dueDate !== undefined ? dueDate : oldTask.dueDate;

//     const dateError = validateTaskDates({ taskStart: effectiveStart, taskDue: effectiveDue, projectStart: project.startDate, projectEnd: project.endDate });
//     if (dateError) {
//       await session.abortTransaction();
//       return res.status(400).json({ success: false, message: dateError });
//     }

//     const previousAssignees = (oldTask.assignees || []).map((id) => id.toString());
//     const previousStatus = oldTask.status;
//     const previousMilestone = oldTask.milestone;

//     if (title !== undefined) oldTask.title = title;
//     if (description !== undefined) oldTask.description = description;
//     if (status !== undefined) oldTask.status = status;
//     if (priority !== undefined) oldTask.priority = priority;
//     if (dueDate !== undefined) oldTask.dueDate = dueDate;
//     if (startDate !== undefined) oldTask.startDate = startDate;
//     if (estimatedHours !== undefined) oldTask.estimatedHours = Number(estimatedHours);
//     if (labels !== undefined) oldTask.labels = labels;
//     if (tags !== undefined) oldTask.tags = tags;
//     if (estimatedEffort !== undefined) oldTask.estimatedEffort = estimatedEffort;
//     if (assignees !== undefined) oldTask.assignees = assignees;
//     if (watchers !== undefined) oldTask.watchers = watchers;
//     if (dependencies !== undefined) oldTask.dependencies = dependencies;
//     if (checklist !== undefined) oldTask.checklist = checklist;
//     if (milestone !== undefined) oldTask.milestone = milestone;

//     oldTask.updatedAt = new Date();
//     await oldTask.save({ session });

//     const currentAssignees = (oldTask.assignees || []).map((id) => id.toString());
//     const usersToRecalculate = [...new Set([...previousAssignees, ...currentAssignees])];
//     if (usersToRecalculate.length > 0) await recalcWorkloadForUsers(oldTask.project, usersToRecalculate);

//     const checklistChanged = checklist !== undefined;
//     if (milestone !== undefined || checklistChanged || (status !== undefined && status !== previousStatus)) {
//       if (oldTask.milestone) await updateMilestoneProgress(oldTask.project, oldTask.milestone);
//       if (previousMilestone && String(previousMilestone) !== String(oldTask.milestone)) await updateMilestoneProgress(oldTask.project, previousMilestone);
//       if (!oldTask.milestone && !previousMilestone) await syncProjectProgressFromTasks(oldTask.project);
//     }

//     await session.commitTransaction();

//     const updatedTask = await Task.findById(oldTask._id)
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('createdBy', 'name email')
//       .populate('dependencies');

//     const orgSlug = await getOrgSlug(project.organization);
//     const link = taskLink(orgSlug, project._id, updatedTask._id);

//     const newlyAssigned = currentAssignees.filter((a) => !previousAssignees.includes(a));
//     await sendBulkNotification(newlyAssigned, {
//       type: 'task_assigned',
//       title: 'New Task Assigned',
//       message: `You have been assigned to task "${updatedTask.title}" in project "${project.name}"`,
//       relatedTask: updatedTask._id,
//       relatedProject: project._id,
//       link,
//     });

//     if (status !== undefined && status !== previousStatus) {
//       await notifyTaskParticipants(updatedTask, project, {
//         type: 'task_status_changed',
//         title: 'Task Status Changed',
//         message: `Task "${updatedTask.title}" status changed from ${previousStatus} to ${status}.`,
//         excludeUserId: req.user.id,
//         link,
//       });

//       await Activity.create({
//         organization: project.organization,
//         project: oldTask.project,
//         level: 'task',
//         task: oldTask._id,
//         user: req.user.id,
//         type: 'task_status_changed',
//         entity: 'Task',
//         entityId: oldTask._id,
//         previousValue: previousStatus,
//         newValue: status,
//         description: `Task status changed from "${previousStatus}" to "${status}"`,
//       });
//     } else {
//       await notifyTaskParticipants(updatedTask, project, {
//         type: 'task_updated',
//         title: 'Task Updated',
//         message: `Task "${updatedTask.title}" was updated.`,
//         excludeUserId: req.user.id,
//         link,
//       });

//       await Activity.create({
//         organization: project.organization,
//         project: oldTask.project,
//         level: 'task',
//         task: oldTask._id,
//         user: req.user.id,
//         type: 'task_updated',
//         entity: 'Task',
//         entityId: oldTask._id,
//         description: `Task "${updatedTask.title}" updated`,
//       });
//     }

//     const taskObj = updatedTask.toObject();
//     taskObj.progress = computeTaskProgress(updatedTask);

//     res.json({ success: true, message: 'Task updated successfully.', data: attachTaskUserFlags(taskObj, req.user.id) });
//   } catch (error) {
//     await session.abortTransaction();
//     res.status(500).json({ success: false, error: error.message });
//   } finally {
//     session.endSession();
//   }
// };

// export const get = async (req, res) => {
//   try {
//     const task = await Task.findOne({ _id: req.params.id, isDeleted: { $ne: true } })
//       .populate('project', 'name organization milestones')
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('createdBy', 'name email')
//       .populate({ path: 'comments', populate: { path: 'author', select: 'name email avatar' } })
//       .populate('workLogs.user', 'name email')
//       .populate('dependencies')
//       .populate('attachments');

//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed } = await checkProjectPermission(req.user.id, task.project._id, PROJECT_PERMISSIONS.TASK_DETAILS_VIEW);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view this task.' });

//     const taskObj = task.toObject();
//     taskObj.progress = computeTaskProgress(task);

//     const milestoneDoc = task.milestone
//       ? task.project?.milestones?.find((m) => m._id.toString() === task.milestone.toString())
//       : null;

//     taskObj.milestone = milestoneDoc
//       ? { _id: milestoneDoc._id, name: milestoneDoc.name, startDate: milestoneDoc.startDate, dueDate: milestoneDoc.dueDate, status: milestoneDoc.status }
//       : null;

//     taskObj.project = { _id: task.project._id, name: task.project.name, organization: task.project.organization };

//     res.json({ success: true, data: attachTaskUserFlags(taskObj, req.user.id) });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const getTaskCreationData = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const userId = req.user.id;
//     if (!projectId) return res.status(400).json({ success: false, message: 'Project ID is required.' });

//     const { allowed: canCreate } = await checkProjectPermission(userId, projectId, PROJECT_PERMISSIONS.TASK_CREATE);
//     if (!canCreate) return res.status(403).json({ success: false, message: 'You do not have permission to create tasks in this project.' });

//     const { allowed: canView } = await checkProjectPermission(userId, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
//     if (!canView) return res.status(403).json({ success: false, message: 'You do not have permission to view this project.' });

//     const project = await Project.findById(projectId).populate('team.user', 'name email avatar').select('milestones team startDate endDate name');
//     if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

//     const milestones = project.milestones.map((m) => ({ _id: m._id, name: m.name, startDate: m.startDate, dueDate: m.dueDate, progress: m.progress || 0 }));
//     const teamMembers = project.team.map((member) => ({
//       user: { _id: member.user?._id, name: member.user?.name, email: member.user?.email, avatar: member.user?.avatar },
//       role: member.role,
//       permissions: member.permissions || [],
//     }));

//     const projectTasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).select('_id title dueDate status milestone checklist').sort({ createdAt: -1 });

//     res.json({ success: true, data: { project: { name: project.name, startDate: project.startDate, endDate: project.endDate }, milestones, teamMembers, projectTasks } });
//   } catch (error) {
//     res.status(500).json({ success: false, message: 'Failed to load task creation data.', error: error.message });
//   }
// };

// export const getUserTaskStats = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

//     const assignedTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, isDeleted: { $ne: true } });
//     const watchingTasks = await Task.countDocuments({ project: projectId, watchers: req.user.id, isDeleted: { $ne: true } });
//     const completedTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, status: 'completed', isDeleted: { $ne: true } });
//     const overdueTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, status: { $ne: 'completed' }, dueDate: { $lt: new Date() }, isDeleted: { $ne: true } });
//     const statusBreakdown = await Task.aggregate([{ $match: { project: projectId, assignees: req.user.id, isDeleted: { $ne: true } } }, { $group: { _id: '$status', count: { $sum: 1 } } }]);

//     res.json({
//       success: true,
//       data: {
//         assignedTasks, watchingTasks, completedTasks, overdueTasks,
//         statusBreakdown: statusBreakdown.reduce((acc, item) => { acc[item._id] = item.count; return acc; }, {}),
//       },
//     });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const remove = async (req, res) => {
//   const session = await mongoose.startSession();
//   session.startTransaction();
//   try {
//     const { id } = req.params;
//     const task = await Task.findById(id).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar').session(session);
//     if (!task) {
//       await session.abortTransaction();
//       return res.status(404).json({ success: false, message: 'Task not found.' });
//     }

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_DELETE);
//     if (!allowed) {
//       await session.abortTransaction();
//       return res.status(403).json({ success: false, message: 'You do not have permission to delete this task.' });
//     }

//     task.isDeleted = true;
//     task.deletedAt = new Date();
//     task.deletedBy = req.user.id;
//     await task.save({ session });

//     const attachments = await File.find({ task: task._id }).session(session);
//     for (const file of attachments) {
//       if (file.url) {
//         const filePath = path.join(process.cwd(), 'uploads', path.basename(file.url));
//         try { await fs.unlink(filePath); } catch { }
//       }
//     }
//     await File.updateMany({ task: task._id }, { deleted: true, deletedAt: new Date() }).session(session);

//     if (task.assignees?.length) await recalcWorkloadForUsers(task.project, task.assignees.map((a) => a._id || a));
//     if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
//     else await syncProjectProgressFromTasks(task.project);

//     await Activity.create([{
//       organization: project.organization,
//       project: task.project,
//       level: 'task',
//       task: task._id,
//       user: req.user.id,
//       type: 'task_deleted',
//       entity: 'Task',
//       entityId: task._id,
//       description: `Task "${task.title}" deleted`,
//     }], { session });

//     await session.commitTransaction();

//     if (project) {
//       const orgSlug = await getOrgSlug(project.organization);
//       await notifyTaskParticipants(task, project, {
//         type: 'task_deleted',
//         title: 'Task Deleted',
//         message: `Task "${task.title}" was deleted from "${project.name}".`,
//         excludeUserId: req.user.id,
//         link: projectLink(orgSlug, project._id),
//       });
//     }

//     res.json({ success: true, message: 'Task deleted successfully.' });
//   } catch (error) {
//     await session.abortTransaction();
//     res.status(500).json({ success: false, error: error.message });
//   } finally {
//     session.endSession();
//   }
// };

// export const addWatcher = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { userId } = req.body;
//     const task = await Task.findById(id);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

//     if (!task.watchers.includes(userId)) {
//       task.watchers.push(userId);
//       await task.save();
//     }

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'watcher_added', entity: 'Task', entityId: task._id, description: `Watcher added to task "${task.title}"`,
//     });

//     const orgSlug = await getOrgSlug(project.organization);
//     const updatedTask = await Task.findById(id).populate('watchers', 'name email avatar');

//     await sendNotification({
//       userId, type: 'watcher_added', title: 'Added as Watcher',
//       message: `You're now watching task "${task.title}".`,
//       relatedTask: task._id, relatedProject: task.project,
//       link: taskLink(orgSlug, task.project, task._id),
//     });

//     res.json({ success: true, message: 'Watcher added successfully.', data: updatedTask });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const removeWatcher = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { userId } = req.body;
//     const task = await Task.findById(id);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

//     task.watchers = task.watchers.filter((wid) => wid.toString() !== userId);
//     await task.save();

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'watcher_removed', entity: 'Task', entityId: task._id, description: `Watcher removed from task "${task.title}"`,
//     });

//     const updatedTask = await Task.findById(id).populate('watchers', 'name email avatar');
//     res.json({ success: true, message: 'Watcher removed successfully.', data: updatedTask });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const addWorkLog = async (req, res) => {
//   try {
//     const { projectId, taskId } = req.params;
//     const { hours, date, description } = req.body;
//     const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to add work logs.' });

//     const durationSeconds = Math.floor(hours * 3600);
//     task.workLogs.push({ user: req.user.id, seconds: durationSeconds, date: date || new Date(), description, approved: false });
//     task.actualHours = (task.actualHours || 0) + hours;
//     await task.save();

//     const orgSlug = await getOrgSlug(project.organization);
//     const link = taskLink(orgSlug, projectId, task._id);

//     await sendNotification({
//       userId: task.assignees?.[0]?._id || task.assignees?.[0] || req.user.id,
//       type: 'work_log_approved', title: 'Work Log Added',
//       message: `Work log added for task "${task.title}"`,
//       relatedTask: task._id, relatedProject: task.project, link,
//     });

//     await notifyTaskParticipants(task, project, {
//       type: 'work_log_added', title: 'Work Log Added',
//       message: `${hours}h logged on task "${task.title}".`,
//       excludeUserId: req.user.id, link,
//     });

//     await Activity.create({
//       organization: project.organization, project: projectId, level: 'task', task: taskId,
//       user: req.user.id, type: 'work_log_added', entity: 'Task', entityId: taskId,
//       newValue: { hours, description }, description: `Work log added: ${hours} hours`,
//     });

//     const updatedTask = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('workLogs.user', 'name email');
//     res.json({ success: true, message: 'Work log added successfully.', data: updatedTask });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const addAttachment = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { filename, originalName, url, size, mimeType } = req.body;
//     const task = await Task.findById(id).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

//     const fileRecord = new File({ task: task._id, filename, originalName, url, size, mimeType, uploadedBy: req.user.id });
//     await fileRecord.save();
//     task.attachments.push(fileRecord._id);
//     await task.save();

//     const orgSlug = await getOrgSlug(project.organization);
//     const link = taskLink(orgSlug, task.project, task._id);

//     await sendNotification({
//       userId: task.assignees?.[0]?._id || task.assignees?.[0] || req.user.id,
//       type: 'file_uploaded', title: 'File Uploaded',
//       message: `File "${filename}" added to task "${task.title}"`,
//       relatedTask: task._id, relatedProject: task.project, link,
//     });

//     await notifyTaskParticipants(task, project, {
//       type: 'attachment_added', title: 'Attachment Added',
//       message: `"${filename}" was added to task "${task.title}".`,
//       excludeUserId: req.user.id, link,
//     });

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'attachment_added', entity: 'Task', entityId: task._id, description: `Attachment "${filename}" added to task`,
//     });

//     const updatedTask = await Task.findById(id).populate('assignees', 'name email avatar').populate({ path: 'attachments', populate: { path: 'uploadedBy', select: 'name email' } });
//     res.json({ success: true, message: 'Attachment added successfully.', data: updatedTask });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const removeAttachment = async (req, res) => {
//   try {
//     const { id, attachmentId } = req.params;
//     const task = await Task.findById(id);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

//     task.attachments = task.attachments.filter((att) => att.toString() !== attachmentId);
//     await task.save();

//     const file = await File.findById(attachmentId);
//     if (file && file.url) {
//       const filePath = path.join(process.cwd(), 'uploads', path.basename(file.url));
//       try { await fs.unlink(filePath); } catch { }
//     }
//     await File.updateOne({ _id: attachmentId, deleted: false }, { deleted: true, deletedAt: new Date() });

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'attachment_removed', entity: 'Task', entityId: task._id, description: 'Attachment removed from task',
//     });

//     const updatedTask = await Task.findById(id).populate('assignees', 'name email avatar').populate({ path: 'attachments', populate: { path: 'uploadedBy', select: 'name email' } });
//     res.json({ success: true, message: 'Attachment removed successfully.', data: updatedTask });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const getGanttData = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

//     const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).populate('assignees', 'name').select('title startDate dueDate status priority checklist');

//     const ganttData = tasks.map((task) => ({
//       id: task._id, name: task.title, start: task.startDate, end: task.dueDate,
//       progress: computeTaskProgress(task), type: 'task', assignee: task.assignees[0]?.name,
//     }));
//     res.json({ success: true, data: ganttData });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// // Timer actions are assignee-only. Having task.edit is not enough — the
// // permission gates *whether the project role can touch timers at all*,
// // but starting/stopping/resuming a specific task's timer is restricted
// // to the people actually assigned to that task, regardless of role.
// const requireAssignee = (task, userId) => isTaskAssignee(task, userId);

// export const startTimer = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const task = await Task.findById(taskId);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

//     const { allowed } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
//     if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can start the timer on this task.' });

//     const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
//     if (activeTimer) return res.status(400).json({ success: false, message: 'No active timer can be started because another timer is already running.' });

//     task.workLogs.push({ user: req.user.id, seconds: 0, date: new Date(), description: 'Timer started', isTimer: true, stopped: false });
//     if (task.status === 'todo') task.status = 'in-progress';
//     task.updatedAt = new Date();
//     await task.save();

//     if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
//     else await syncProjectProgressFromTasks(task.project);

//     const updatedTask = await Task.findById(taskId)
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('workLogs.user', 'name email');

//     res.json({ success: true, data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const stopTimer = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const task = await Task.findById(taskId);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

//     const { allowed } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
//     if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can stop the timer on this task.' });

//     const lastTimerLog = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
//     if (!lastTimerLog) return res.status(400).json({ success: false, message: 'No active timer' });

//     const durationSeconds = Math.floor((Date.now() - new Date(lastTimerLog.date).getTime()) / 1000);
//     lastTimerLog.seconds = durationSeconds;
//     lastTimerLog.stopped = true;
//     lastTimerLog.description = `Timer stopped (${durationSeconds}s)`;
//     task.timeSpent = task.workLogs.reduce((sum, log) => sum + (log.seconds || 0), 0);
//     await task.save();

//     const updatedTask = await Task.findById(taskId)
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('workLogs.user', 'name email');

//     res.json({ success: true, data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const resumeTimer = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const task = await Task.findById(taskId);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

//     const { allowed } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
//     if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can resume the timer on this task.' });

//     const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
//     if (activeTimer) return res.status(400).json({ success: false, message: 'No active timer can be started because another timer is already running.' });

//     task.workLogs.push({ user: req.user.id, seconds: 0, date: new Date(), description: 'Timer resumed', isTimer: true, stopped: false });
//     await task.save();

//     const updatedTask = await Task.findById(taskId)
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('workLogs.user', 'name email');

//     res.json({ success: true, data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const finishTask = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
//     if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can mark this task as finished.' });

//     const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
//     if (activeTimer) {
//       activeTimer.seconds = Math.floor((Date.now() - new Date(activeTimer.date).getTime()) / 1000);
//       activeTimer.stopped = true;
//       activeTimer.description = `Timer stopped (${activeTimer.seconds}s)`;
//     }

//     task.checklist.forEach((c) => { c.completed = true; });
//     task.status = 'completed';
//     task.timeSpent = task.workLogs.reduce((sum, log) => sum + (log.seconds || 0), 0);
//     task.updatedAt = new Date();
//     await task.save();

//     if (task.assignees?.length) await recalcWorkloadForUsers(task.project, task.assignees.map((a) => a._id || a));
//     if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
//     else await syncProjectProgressFromTasks(task.project);

//     const orgSlug = await getOrgSlug(project.organization);

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'task_status_changed', entity: 'Task', entityId: task._id,
//       previousValue: 'in-progress', newValue: 'completed', description: `Task "${task.title}" marked as completed`,
//     });

//     await notifyTaskParticipants(task, project, {
//       type: 'task_status_changed', title: 'Task Completed',
//       message: `Task "${task.title}" was marked completed.`,
//       excludeUserId: req.user.id, link: taskLink(orgSlug, project._id, task._id),
//     });

//     const updatedTask = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
//     res.json({ success: true, message: 'Task marked as completed', data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const getTimerStatus = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const task = await Task.findById(taskId);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

//     const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
//     const lastLogTime = activeTimer ? new Date(activeTimer.date) : null;

//     res.json({
//       success: true,
//       data: {
//         isRunning: !!activeTimer,
//         elapsedSeconds: activeTimer ? Math.floor((Date.now() - lastLogTime.getTime()) / 1000) : 0,
//         timeSpent: task.timeSpent,
//         canControl: requireAssignee(task, req.user.id),
//       },
//     });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const addChecklistItem = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { item } = req.body;
//     if (!item || !item.trim()) return res.status(400).json({ success: false, message: 'Checklist item text is required.' });

//     const task = await Task.findById(id);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

//     task.checklist.push({ item: item.trim(), completed: false });
//     await task.save();

//     if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
//     else await syncProjectProgressFromTasks(task.project);

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id, description: `Checklist item "${item.trim()}" added`,
//     });

//     res.status(201).json({ success: true, message: 'Checklist item added.', data: task.checklist });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const toggleChecklistItem = async (req, res) => {
//   try {
//     const { id, itemId } = req.params;
//     const { completed } = req.body;

//     const task = await Task.findById(id);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

//     const checklistItem = task.checklist.id(itemId);
//     if (!checklistItem) return res.status(404).json({ success: false, message: 'Checklist item not found.' });

//     checklistItem.completed = typeof completed === 'boolean' ? completed : !checklistItem.completed;
//     task.updatedAt = new Date();
//     await task.save();

//     if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
//     else await syncProjectProgressFromTasks(task.project);

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id,
//       description: `Checklist item "${checklistItem.item}" marked ${checklistItem.completed ? 'complete' : 'incomplete'}`,
//     });

//     res.json({ success: true, message: 'Checklist item updated.', data: task.checklist });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const removeChecklistItem = async (req, res) => {
//   try {
//     const { id, itemId } = req.params;
//     const task = await Task.findById(id);
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

//     task.checklist = task.checklist.filter((c) => c._id.toString() !== itemId);
//     await task.save();

//     if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
//     else await syncProjectProgressFromTasks(task.project);

//     await Activity.create({
//       organization: project.organization, project: task.project, level: 'task', task: task._id,
//       user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id, description: 'Checklist item removed',
//     });

//     res.json({ success: true, message: 'Checklist item removed.', data: task.checklist });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const getKanbanBoards = async (req, res) => {
//   try {
//     const { projectId } = req.params;
//     const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
//     if (!allowed) return res.status(403).json({ success: false, message: 'Access denied.' });

//     const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } })
//       .populate('assignees', 'name email avatar')
//       .populate('watchers', 'name email avatar')
//       .populate('createdBy', 'name email')
//       .populate('dependencies')
//       .sort({ order: 1 });

//     const columns = getKanbanColumns();

//     const tasksWithOverdue = tasks.map((task) => {
//       const taskObj = task.toObject ? task.toObject() : task._doc || task;
//       let isOverdue = false;
//       if (taskObj.dueDate && taskObj.status !== 'completed') {
//         const dueDate = new Date(taskObj.dueDate);
//         const today = new Date();
//         today.setHours(0, 0, 0, 0);
//         isOverdue = dueDate < today;
//       }

//       const checklist = taskObj.checklist || [];
//       const checklistTotal = checklist.length;
//       const checklistCompleted = checklist.filter((i) => i.completed).length;
//       const checklistPct = checklistTotal > 0 ? Math.round((checklistCompleted / checklistTotal) * 100) : 0;

//       return attachTaskUserFlags({
//         ...taskObj, isOverdue, checklistTotal, checklistCompleted, checklistPct, progress: computeTaskProgress(taskObj),
//       }, req.user.id);
//     });

//     const data = {
//       columns,
//       tasks: groupTasksByStatus(tasksWithOverdue),
//       unassigned: tasksWithOverdue.filter((t) => !t.milestone),
//     };

//     res.json({ success: true, data });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// export const moveTask = async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const { targetColumn, beforeTaskId } = req.body;

//     const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
//     if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

//     const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
//     if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to move tasks.' });
//     if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

//     const oldStatus = task.status;
//     task.status = targetColumn;

//     let newOrder = 0;
//     if (beforeTaskId) {
//       const before = await Task.findById(beforeTaskId);
//       newOrder = before ? before.order - 0.5 : 0;
//     } else {
//       const last = await Task.findOne({ project: task.project, status: targetColumn }).sort({ order: -1 });
//       newOrder = last ? last.order + 1 : 0;
//     }

//     task.order = newOrder;
//     await task.save();

//     await Task.updateMany(
//       { project: task.project, status: targetColumn, _id: { $ne: task._id }, order: { $gte: newOrder } },
//       { $inc: { order: 1 } }
//     );

//     const orgSlug = await getOrgSlug(project.organization);

//     await Activity.create({
//       organization: project.organization, project: project._id, level: 'task', task: task._id,
//       user: req.user.id, type: 'task_moved', entity: 'Task', entityId: task._id,
//       description: `Task "${task.title}" moved from "${oldStatus}" to "${targetColumn}"`,
//     });

//     await notifyTaskParticipants(task, project, {
//       type: 'task_moved', title: 'Task Moved',
//       message: `Task "${task.title}" moved from ${oldStatus} to ${targetColumn}.`,
//       excludeUserId: req.user.id, link: taskLink(orgSlug, project._id, task._id),
//     });

//     if (task.assignees?.length) await recalcWorkloadForUsers(project._id, task.assignees.map((a) => a._id || a));
//     if (task.milestone) await updateMilestoneProgress(project._id, task.milestone);
//     else await syncProjectProgressFromTasks(project._id);

//     res.json({ success: true, message: 'Task moved successfully.' });
//   } catch (error) {
//     res.status(500).json({ success: false, error: error.message });
//   }
// };

// const getKanbanColumns = (statuses = ['todo', 'in-progress', 'review', 'completed']) => statuses.map((status) => ({
//   _id: status,
//   name: status === 'todo' ? 'To Do' : status === 'in-progress' ? 'In Progress' : status === 'review' ? 'In Review' : 'Done',
//   status,
//   color: status === 'todo' ? '#6B7280' : status === 'in-progress' ? '#3B82F6' : status === 'review' ? '#8B5CF6' : '#10B981',
// }));

// const groupTasksByStatus = (tasks) => {
//   const groups = { todo: [], 'in-progress': [], review: [], completed: [] };
//   tasks.forEach((task) => {
//     const status = task.status || 'todo';
//     if (groups[status]) groups[status].push(task);
//   });
//   return groups;
// };


// V2


import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import Project from '../models/Project.js';
import Organization from '../models/Organization.js';
import Comment from '../models/Comment.js';
import File from '../models/File.js';
import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';
import { sendNotification, notifyTaskParticipants, sendBulkNotification, notifyProjectTeam } from '../utils/sendNotification.js';
import { computeTaskProgress, computeMilestoneStats, computeProjectProgress } from '../utils/progressEngine.js';
import { taskLink, projectLink } from '../utils/routeLinks.js';
import {
  checkProjectPermission,
  isTaskAssignee,
  attachTaskUserFlags,
  loadOrgAndCheckMembership,
  buildPermissionContext,
} from '../utils/permissions.js';

import fs from 'fs/promises';
import path from 'path';
import mongoose from 'mongoose';
import { recalcWorkloadForUsers } from './workloadController.js';

const getOrgSlug = async (organizationId) => {
  const org = await Organization.findById(organizationId).select('slug');
  return org?.slug || '';
};

// ---------------------------------------------------------------------------
// Same pattern projectController uses for `currentUserPermissions`:
// resolve orgRole for the requesting user against the project's organization,
// then build the permission context off of it. Used to attach
// `currentUserPermissions` to task responses the same way project responses do.
// ---------------------------------------------------------------------------
const getTaskPermissionContext = async (project, userId) => {
  if (!project) return null;
  const { orgRole } = await loadOrgAndCheckMembership(project.organization, userId);
  return buildPermissionContext(project, orgRole, userId);
};

// ---------------------------------------------------------------------------
// 6-digit, per-project task code. Starts at 111111 for the first task created
// in a project and increments by 1 for each subsequent task in that same
// project (independent of other projects, and independent of deletions, so
// codes never get reused).
//
// NOTE: requires a `taskCode` Number field on the Task schema, e.g.:
//   taskCode: { type: Number, index: true }
// with a compound index on { project: 1, taskCode: 1 } recommended for
// fast lookups/uniqueness per project.
// ---------------------------------------------------------------------------
const generateTaskCode = async (projectId, session) => {
  const lastTask = await Task.findOne({ project: projectId })
    .sort({ taskCode: -1 })
    .select('taskCode')
    .session(session);

  return lastTask?.taskCode ? lastTask.taskCode + 1 : 111111;
};

const validateTaskDates = ({ taskStart, taskDue, projectStart, projectEnd }) => {
  const start = taskStart ? new Date(taskStart) : null;
  const due = taskDue ? new Date(taskDue) : null;
  const pStart = projectStart ? new Date(projectStart) : null;
  const pEnd = projectEnd ? new Date(projectEnd) : null;

  if (start && due && start > due) return 'Due date cannot be before start date';
  if (pStart && start && start < pStart) return 'Task start date cannot be before project start date';
  if (pEnd && due && due > pEnd) return 'Task due date cannot be after project end date';
  return null;
};

const validateTaskAgainstMilestone = (taskStart, taskDue, milestone) => {
  if (!milestone) return null;
  const toDateOnly = (date) => {
    if (!date) return null;
    const d = new Date(date);
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  };
  const tStart = toDateOnly(taskStart);
  const tDue = toDateOnly(taskDue);
  const mStart = toDateOnly(milestone.startDate);
  const mDue = toDateOnly(milestone.dueDate);

  if (tStart && tDue && tStart > tDue) return 'Task due date must be after task start date';
  if (mStart && tStart && tStart < mStart) return `Task start date cannot be before milestone start date (${mStart.toLocaleDateString()})`;
  if (mDue && tDue && tDue > mDue) return `Task due date cannot be after milestone due date (${mDue.toLocaleDateString()})`;
  return null;
};

export const listByProject = async (req, res) => {
  try {
    const { projectId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const search = req.query.search || '';
    const status = req.query.status || '';
    const priority = req.query.priority || '';
    const filterType = req.query.filterType || 'all';
    const sortBy = req.query.sortBy || 'createdAt';
    const sortOrder = req.query.sortOrder || 'desc';

    const { allowed, project } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

    let query = { project: projectId, isDeleted: { $ne: true } };
    if (filterType === 'assigned') query.assignees = req.user.id;
    else if (filterType === 'watching') query.watchers = req.user.id;
    if (search) {
      const orConditions = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { tags: { $regex: search, $options: 'i' } },
      ];
      // Allow searching by the 6-digit task code as well (numeric match).
      if (/^\d+$/.test(search.trim())) orConditions.push({ taskCode: Number(search.trim()) });
      query.$or = orConditions;
    }
    if (status) query.status = status;
    if (priority) query.priority = priority;

    const total = await Task.countDocuments(query);
    const sortOptions = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

    const tasks = await Task.find(query)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .sort(sortOptions)
      .limit(limit)
      .skip((page - 1) * limit);

    const tasksOut = tasks.map((t) => {
      const obj = t.toObject();
      obj.progress = computeTaskProgress(t);
      return attachTaskUserFlags(obj, req.user.id);
    });

    const currentUserPermissions = await getTaskPermissionContext(project, req.user.id);

    res.json({
      success: true,
      data: tasksOut,
      pagination: { total, page, limit, pages: Math.ceil(total / limit), hasNext: page * limit < total, hasPrevious: page > 1 },
      currentUserPermissions,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getMyTasks = async (req, res) => {
  try {
    const { page = 1, limit = 10, type = 'all', projectId, search = '' } = req.query;
    const userId = req.user.id;

    let query = { isDeleted: { $ne: true } };
    if (projectId) query.project = projectId;

    switch (type) {
      case 'assigned': query.assignees = userId; break;
      case 'watching': query.watchers = userId; break;
      default: query.$or = [{ assignees: userId }, { watchers: userId }];
    }

    if (search) {
      const searchConditions = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { tags: { $regex: search, $options: 'i' } },
      ];
      if (/^\d+$/.test(String(search).trim())) searchConditions.push({ taskCode: Number(String(search).trim()) });

      // Combine with the existing assigned/watching $or (if any) using $and
      // so the search doesn't override the type filter.
      if (query.$or) {
        query = { ...query, $and: [{ $or: query.$or }, { $or: searchConditions }] };
        delete query.$or;
      } else {
        query.$or = searchConditions;
      }
    }

    const total = await Task.countDocuments(query);
    const tasks = await Task.find(query)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .sort({ createdAt: -1 })
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit));

    const tasksOut = tasks.map((t) => {
      const obj = t.toObject();
      obj.progress = computeTaskProgress(t);
      return attachTaskUserFlags(obj, userId);
    });

    res.json({
      success: true,
      data: tasksOut,
      filters: { type },
      pagination: {
        total, page: Number(page), limit: Number(limit),
        pages: Math.ceil(total / Number(limit)),
        hasNext: Number(page) < Math.ceil(total / Number(limit)),
        hasPrevious: Number(page) > 1,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getMyTaskStats = async (req, res) => {
  try {
    const { projectId } = req.query;
    const userId = new mongoose.Types.ObjectId(req.user.id);

    const assignedMatch = { assignees: userId, isDeleted: { $ne: true } };
    if (projectId) assignedMatch.project = new mongoose.Types.ObjectId(projectId);

    const stats = await Task.aggregate([
      { $match: assignedMatch },
      { $group: {
        _id: null,
        total: { $sum: 1 },
        completed: { $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] } },
        pending: { $sum: { $cond: [{ $in: ['$status', ['todo', 'in-progress', 'review']] }, 1, 0] } },
      } },
    ]);

    const result = stats[0] || { total: 0, completed: 0, pending: 0 };
    const overdue = await Task.countDocuments({ ...assignedMatch, dueDate: { $lt: new Date() }, status: { $ne: 'completed' } });

    const watchingQuery = { watchers: userId, isDeleted: { $ne: true } };
    if (projectId) watchingQuery.project = new mongoose.Types.ObjectId(projectId);
    const watching = await Task.countDocuments(watchingQuery);

    res.json({
      success: true,
      data: {
        total: result.total,
        completed: result.completed,
        pending: result.pending,
        overdue,
        watching,
        completionRate: result.total > 0 ? Math.round((result.completed / result.total) * 100) : 0,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

const updateMilestoneProgress = async (projectId, milestoneId) => {
  const project = await Project.findById(projectId);
  if (!project) return;

  if (milestoneId) {
    const milestone = project.milestones.find((m) => m._id.toString() === milestoneId.toString());
    if (milestone) {
      const tasks = await Task.find({ project: projectId, milestone: milestoneId, isDeleted: { $ne: true } }).select('status checklist dueDate');
      const stats = computeMilestoneStats(tasks);
      const wasCompleted = milestone.status === 'completed';
      const nowCompleted = stats.status === 'completed';

      await Project.updateOne(
        { _id: projectId, 'milestones._id': milestoneId },
        { $set: { 'milestones.$.status': stats.status, 'milestones.$.progress': stats.progress, 'milestones.$.completedAt': nowCompleted ? new Date() : null } }
      );

      if (!wasCompleted && nowCompleted) {
        const populated = await Project.findById(projectId).populate('owner', 'name email avatar').populate('team.user', 'name email avatar');
        const orgSlug = await getOrgSlug(populated.organization);
        await notifyProjectTeam(populated, {
          type: 'milestone_completed',
          title: 'Milestone Completed',
          message: `Milestone "${milestone.name}" in "${populated.name}" reached 100%.`,
          link: projectLink(orgSlug, populated._id),
        });
      }
    }
  }

  await syncProjectProgressFromTasks(projectId);
};

const syncProjectProgressFromTasks = async (projectId) => {
  const project = await Project.findById(projectId);
  if (!project) return;

  const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).select('status checklist milestone dueDate');
  const totalTasks = tasks.length;

  const milestoneStatsList = project.milestones.map((m) => computeMilestoneStats(tasks.filter((t) => t.milestone && t.milestone.toString() === m._id.toString())));
  const unassignedTasks = tasks.filter((t) => !t.milestone);
  const progress = computeProjectProgress({ milestoneStatsList, unassignedTasks });

  let newStatus = project.status;
  let completedAt = project.completedAt;

  if (project.status === 'planning' && totalTasks > 0) newStatus = 'active';

  const allMilestonesDone = project.milestones.length === 0 || project.milestones.every((m) => m.status === 'completed');

  if (['planning', 'active'].includes(newStatus) && totalTasks > 0 && progress === 100 && allMilestonesDone) {
    newStatus = 'completed';
    completedAt = new Date();
  } else if (newStatus === 'completed' && (progress < 100 || !allMilestonesDone)) {
    newStatus = 'active';
    completedAt = null;
  }

  const statusChanged = newStatus !== project.status;
  await Project.updateOne({ _id: projectId }, { $set: { progress, status: newStatus, completedAt, lastActivityAt: new Date() } });

  if (statusChanged && (newStatus === 'completed' || newStatus === 'active')) {
    const populated = await Project.findById(projectId).populate('owner', 'name email avatar').populate('team.user', 'name email avatar');
    const orgSlug = await getOrgSlug(populated.organization);

    await notifyProjectTeam(populated, {
      type: 'project_status_changed',
      title: newStatus === 'completed' ? 'Project Completed' : 'Project Now Active',
      message: newStatus === 'completed' ? `Project "${populated.name}" reached 100% completion.` : `Project "${populated.name}" is now active based on task activity.`,
      link: projectLink(orgSlug, populated._id),
    });

    await Activity.create({
      organization: populated.organization,
      project: projectId,
      level: 'project',
      user: project.owner,
      type: 'project_status_changed',
      entity: 'Project',
      entityId: projectId,
      description: `Project status auto-updated to "${newStatus}" based on task activity`,
    });
  }
};

export const create = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { projectId } = req.params;
    const { title, description, assignees, watchers, priority, dueDate, startDate, estimatedHours, labels, tags, estimatedEffort, dependencies = [], checklist = [], milestone } = req.body;

    const { allowed, project } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_CREATE);
    if (!allowed) {
      await session.abortTransaction();
      return res.status(403).json({ success: false, message: 'You do not have permission to create tasks in this project.' });
    }
    if (!project) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Project not found.' });
    }

    if (!milestone) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: 'Milestone is required when creating a task.' });
    }

    const milestoneDoc = project.milestones.find((m) => m._id.toString() === milestone);
    if (!milestoneDoc) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: 'Invalid milestone.' });
    }

    const dateError = validateTaskDates({ taskStart: startDate, taskDue: dueDate, projectStart: project.startDate, projectEnd: project.endDate });
    if (dateError) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: dateError });
    }

    const milestoneDateError = validateTaskAgainstMilestone(startDate, dueDate, milestoneDoc);
    if (milestoneDateError) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: milestoneDateError });
    }

    let validDependencies = [];
    if (dependencies.length > 0) {
      const depIds = dependencies.map((d) => d._id || d);
      const depTasks = await Task.find({ _id: { $in: depIds }, project: projectId, isDeleted: { $ne: true } }).session(session);
      if (depTasks.length !== depIds.length) {
        await session.abortTransaction();
        return res.status(400).json({ success: false, message: 'One or more dependencies are invalid for this project.' });
      }
      validDependencies = depIds;
    }

    // Per-project, 6-digit task code — first task in a project gets 111111,
    // and it increments by 1 for every task created after it in that project.
    const taskCode = await generateTaskCode(projectId, session);

    const task = new Task({
      title, description, project: projectId, assignees: assignees || [], watchers: watchers || [],
      priority: priority || 'medium', dueDate, startDate, estimatedHours: Number(estimatedHours || 0),
      labels: labels || [], tags: tags || [], estimatedEffort: estimatedEffort || 'medium',
      createdBy: req.user.id, dependencies: validDependencies, checklist, milestone,
      taskCode,
    });

    await task.save({ session });

    if (assignees?.length) await recalcWorkloadForUsers(projectId, assignees);
    await updateMilestoneProgress(projectId, milestone);

    const orgSlug = await getOrgSlug(project.organization);
    const link = taskLink(orgSlug, projectId, task._id);

    await sendBulkNotification(assignees, {
      type: 'task_assigned',
      title: 'New Task Assigned',
      message: `You have been assigned to task "${title}" in project "${project.name}"`,
      relatedTask: task._id,
      relatedProject: projectId,
      link,
    });

    await notifyTaskParticipants(task, project, {
      type: 'task_created',
      title: 'Task Created',
      message: `Task "${title}" (#${taskCode}) was created in "${project.name}".`,
      excludeUserId: req.user.id,
      link,
    });

    await Activity.create([{
      organization: project.organization,
      project: projectId,
      level: 'task',
      task: task._id,
      user: req.user.id,
      type: 'task_created',
      entity: 'Task',
      entityId: task._id,
      description: `Task "${title}" (#${taskCode}) created`,
    }], { session });

    await session.commitTransaction();

    const populatedTask = await Task.findById(task._id)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .populate('dependencies');

    const taskObj = populatedTask.toObject();
    taskObj.progress = computeTaskProgress(populatedTask);

    const currentUserPermissions = await getTaskPermissionContext(project, req.user.id);

    res.status(201).json({
      success: true,
      message: 'Task created successfully.',
      data: attachTaskUserFlags(taskObj, req.user.id),
      currentUserPermissions,
    });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ success: false, error: error.message });
  } finally {
    session.endSession();
  }
};

export const update = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { id } = req.params;
    const oldTask = await Task.findById(id).session(session);
    if (!oldTask) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    const { allowed, project } = await checkProjectPermission(req.user.id, oldTask.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) {
      await session.abortTransaction();
      return res.status(403).json({ success: false, message: 'You do not have permission to edit this task.' });
    }
    if (!project) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Project not found.' });
    }

    const { title, description, status, priority, dueDate, startDate, estimatedHours, assignees, watchers, labels, tags, estimatedEffort, dependencies, checklist, milestone } = req.body;

    const effectiveStart = startDate !== undefined ? startDate : oldTask.startDate;
    const effectiveDue = dueDate !== undefined ? dueDate : oldTask.dueDate;

    const dateError = validateTaskDates({ taskStart: effectiveStart, taskDue: effectiveDue, projectStart: project.startDate, projectEnd: project.endDate });
    if (dateError) {
      await session.abortTransaction();
      return res.status(400).json({ success: false, message: dateError });
    }

    const previousAssignees = (oldTask.assignees || []).map((id) => id.toString());
    const previousStatus = oldTask.status;
    const previousMilestone = oldTask.milestone;

    if (title !== undefined) oldTask.title = title;
    if (description !== undefined) oldTask.description = description;
    if (status !== undefined) oldTask.status = status;
    if (priority !== undefined) oldTask.priority = priority;
    if (dueDate !== undefined) oldTask.dueDate = dueDate;
    if (startDate !== undefined) oldTask.startDate = startDate;
    if (estimatedHours !== undefined) oldTask.estimatedHours = Number(estimatedHours);
    if (labels !== undefined) oldTask.labels = labels;
    if (tags !== undefined) oldTask.tags = tags;
    if (estimatedEffort !== undefined) oldTask.estimatedEffort = estimatedEffort;
    if (assignees !== undefined) oldTask.assignees = assignees;
    if (watchers !== undefined) oldTask.watchers = watchers;
    if (dependencies !== undefined) oldTask.dependencies = dependencies;
    if (checklist !== undefined) oldTask.checklist = checklist;
    if (milestone !== undefined) oldTask.milestone = milestone;

    // taskCode is immutable once assigned at creation — intentionally not
    // editable here so codes stay stable and never collide.

    oldTask.updatedAt = new Date();
    await oldTask.save({ session });

    const currentAssignees = (oldTask.assignees || []).map((id) => id.toString());
    const usersToRecalculate = [...new Set([...previousAssignees, ...currentAssignees])];
    if (usersToRecalculate.length > 0) await recalcWorkloadForUsers(oldTask.project, usersToRecalculate);

    const checklistChanged = checklist !== undefined;
    if (milestone !== undefined || checklistChanged || (status !== undefined && status !== previousStatus)) {
      if (oldTask.milestone) await updateMilestoneProgress(oldTask.project, oldTask.milestone);
      if (previousMilestone && String(previousMilestone) !== String(oldTask.milestone)) await updateMilestoneProgress(oldTask.project, previousMilestone);
      if (!oldTask.milestone && !previousMilestone) await syncProjectProgressFromTasks(oldTask.project);
    }

    await session.commitTransaction();

    const updatedTask = await Task.findById(oldTask._id)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .populate('dependencies');

    const orgSlug = await getOrgSlug(project.organization);
    const link = taskLink(orgSlug, project._id, updatedTask._id);

    const newlyAssigned = currentAssignees.filter((a) => !previousAssignees.includes(a));
    await sendBulkNotification(newlyAssigned, {
      type: 'task_assigned',
      title: 'New Task Assigned',
      message: `You have been assigned to task "${updatedTask.title}" in project "${project.name}"`,
      relatedTask: updatedTask._id,
      relatedProject: project._id,
      link,
    });

    if (status !== undefined && status !== previousStatus) {
      await notifyTaskParticipants(updatedTask, project, {
        type: 'task_status_changed',
        title: 'Task Status Changed',
        message: `Task "${updatedTask.title}" status changed from ${previousStatus} to ${status}.`,
        excludeUserId: req.user.id,
        link,
      });

      await Activity.create({
        organization: project.organization,
        project: oldTask.project,
        level: 'task',
        task: oldTask._id,
        user: req.user.id,
        type: 'task_status_changed',
        entity: 'Task',
        entityId: oldTask._id,
        previousValue: previousStatus,
        newValue: status,
        description: `Task status changed from "${previousStatus}" to "${status}"`,
      });
    } else {
      await notifyTaskParticipants(updatedTask, project, {
        type: 'task_updated',
        title: 'Task Updated',
        message: `Task "${updatedTask.title}" was updated.`,
        excludeUserId: req.user.id,
        link,
      });

      await Activity.create({
        organization: project.organization,
        project: oldTask.project,
        level: 'task',
        task: oldTask._id,
        user: req.user.id,
        type: 'task_updated',
        entity: 'Task',
        entityId: oldTask._id,
        description: `Task "${updatedTask.title}" updated`,
      });
    }

    const taskObj = updatedTask.toObject();
    taskObj.progress = computeTaskProgress(updatedTask);

    const currentUserPermissions = await getTaskPermissionContext(project, req.user.id);

    res.json({
      success: true,
      message: 'Task updated successfully.',
      data: attachTaskUserFlags(taskObj, req.user.id),
      currentUserPermissions,
    });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ success: false, error: error.message });
  } finally {
    session.endSession();
  }
};

export const get = async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, isDeleted: { $ne: true } })
      .populate('project', 'name organization milestones')
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .populate({ path: 'comments', populate: { path: 'author', select: 'name email avatar' } })
      .populate('workLogs.user', 'name email')
      .populate('dependencies')
      .populate('attachments');

    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed } = await checkProjectPermission(req.user.id, task.project._id, PROJECT_PERMISSIONS.TASK_DETAILS_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view this task.' });

    const taskObj = task.toObject();
    taskObj.progress = computeTaskProgress(task);

    const milestoneDoc = task.milestone
      ? task.project?.milestones?.find((m) => m._id.toString() === task.milestone.toString())
      : null;

    taskObj.milestone = milestoneDoc
      ? { _id: milestoneDoc._id, name: milestoneDoc.name, startDate: milestoneDoc.startDate, dueDate: milestoneDoc.dueDate, status: milestoneDoc.status }
      : null;

    taskObj.project = { _id: task.project._id, name: task.project.name, organization: task.project.organization };

    const currentUserPermissions = await getTaskPermissionContext(task.project, req.user.id);

    res.json({
      success: true,
      data: attachTaskUserFlags(taskObj, req.user.id),
      currentUserPermissions,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// New: look a task up by its 6-digit project-scoped code, e.g. 111111.
// Mirrors `get` above (same population, same permission check, same
// currentUserPermissions attachment) but resolves the task via
// { project, taskCode } instead of _id.
export const getByCode = async (req, res) => {
  try {
    const { projectId, taskCode } = req.params;
    if (!/^\d+$/.test(String(taskCode))) {
      return res.status(400).json({ success: false, message: 'Invalid task code.' });
    }

    const task = await Task.findOne({ project: projectId, taskCode: Number(taskCode), isDeleted: { $ne: true } })
      .populate('project', 'name organization milestones')
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .populate({ path: 'comments', populate: { path: 'author', select: 'name email avatar' } })
      .populate('workLogs.user', 'name email')
      .populate('dependencies')
      .populate('attachments');

    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed } = await checkProjectPermission(req.user.id, task.project._id, PROJECT_PERMISSIONS.TASK_DETAILS_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view this task.' });

    const taskObj = task.toObject();
    taskObj.progress = computeTaskProgress(task);

    const milestoneDoc = task.milestone
      ? task.project?.milestones?.find((m) => m._id.toString() === task.milestone.toString())
      : null;

    taskObj.milestone = milestoneDoc
      ? { _id: milestoneDoc._id, name: milestoneDoc.name, startDate: milestoneDoc.startDate, dueDate: milestoneDoc.dueDate, status: milestoneDoc.status }
      : null;

    taskObj.project = { _id: task.project._id, name: task.project.name, organization: task.project.organization };

    const currentUserPermissions = await getTaskPermissionContext(task.project, req.user.id);

    res.json({
      success: true,
      data: attachTaskUserFlags(taskObj, req.user.id),
      currentUserPermissions,
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getTaskCreationData = async (req, res) => {
  try {
    const { projectId } = req.params;
    const userId = req.user.id;
    if (!projectId) return res.status(400).json({ success: false, message: 'Project ID is required.' });

    const { allowed: canCreate } = await checkProjectPermission(userId, projectId, PROJECT_PERMISSIONS.TASK_CREATE);
    if (!canCreate) return res.status(403).json({ success: false, message: 'You do not have permission to create tasks in this project.' });

    const { allowed: canView } = await checkProjectPermission(userId, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!canView) return res.status(403).json({ success: false, message: 'You do not have permission to view this project.' });

    const project = await Project.findById(projectId).populate('team.user', 'name email avatar').select('milestones team startDate endDate name');
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const milestones = project.milestones.map((m) => ({ _id: m._id, name: m.name, startDate: m.startDate, dueDate: m.dueDate, progress: m.progress || 0 }));
    const teamMembers = project.team.map((member) => ({
      user: { _id: member.user?._id, name: member.user?.name, email: member.user?.email, avatar: member.user?.avatar },
      role: member.role,
      permissions: member.permissions || [],
    }));

    const projectTasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).select('_id title dueDate status milestone checklist taskCode').sort({ createdAt: -1 });

    // The code the next task created in this project will receive.
    const nextTaskCode = await generateTaskCode(projectId);

    res.json({ success: true, data: { project: { name: project.name, startDate: project.startDate, endDate: project.endDate }, milestones, teamMembers, projectTasks, nextTaskCode } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to load task creation data.', error: error.message });
  }
};

export const getUserTaskStats = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

    const assignedTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, isDeleted: { $ne: true } });
    const watchingTasks = await Task.countDocuments({ project: projectId, watchers: req.user.id, isDeleted: { $ne: true } });
    const completedTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, status: 'completed', isDeleted: { $ne: true } });
    const overdueTasks = await Task.countDocuments({ project: projectId, assignees: req.user.id, status: { $ne: 'completed' }, dueDate: { $lt: new Date() }, isDeleted: { $ne: true } });
    const statusBreakdown = await Task.aggregate([{ $match: { project: projectId, assignees: req.user.id, isDeleted: { $ne: true } } }, { $group: { _id: '$status', count: { $sum: 1 } } }]);

    res.json({
      success: true,
      data: {
        assignedTasks, watchingTasks, completedTasks, overdueTasks,
        statusBreakdown: statusBreakdown.reduce((acc, item) => { acc[item._id] = item.count; return acc; }, {}),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const remove = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { id } = req.params;
    const task = await Task.findById(id).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar').session(session);
    if (!task) {
      await session.abortTransaction();
      return res.status(404).json({ success: false, message: 'Task not found.' });
    }

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_DELETE);
    if (!allowed) {
      await session.abortTransaction();
      return res.status(403).json({ success: false, message: 'You do not have permission to delete this task.' });
    }

    task.isDeleted = true;
    task.deletedAt = new Date();
    task.deletedBy = req.user.id;
    await task.save({ session });

    const attachments = await File.find({ task: task._id }).session(session);
    for (const file of attachments) {
      if (file.url) {
        const filePath = path.join(process.cwd(), 'uploads', path.basename(file.url));
        try { await fs.unlink(filePath); } catch { }
      }
    }
    await File.updateMany({ task: task._id }, { deleted: true, deletedAt: new Date() }).session(session);

    if (task.assignees?.length) await recalcWorkloadForUsers(task.project, task.assignees.map((a) => a._id || a));
    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
    else await syncProjectProgressFromTasks(task.project);

    await Activity.create([{
      organization: project.organization,
      project: task.project,
      level: 'task',
      task: task._id,
      user: req.user.id,
      type: 'task_deleted',
      entity: 'Task',
      entityId: task._id,
      description: `Task "${task.title}" deleted`,
    }], { session });

    await session.commitTransaction();

    if (project) {
      const orgSlug = await getOrgSlug(project.organization);
      await notifyTaskParticipants(task, project, {
        type: 'task_deleted',
        title: 'Task Deleted',
        message: `Task "${task.title}" was deleted from "${project.name}".`,
        excludeUserId: req.user.id,
        link: projectLink(orgSlug, project._id),
      });
    }

    res.json({ success: true, message: 'Task deleted successfully.' });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ success: false, error: error.message });
  } finally {
    session.endSession();
  }
};

export const addWatcher = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    if (!task.watchers.includes(userId)) {
      task.watchers.push(userId);
      await task.save();
    }

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'watcher_added', entity: 'Task', entityId: task._id, description: `Watcher added to task "${task.title}"`,
    });

    const orgSlug = await getOrgSlug(project.organization);
    const updatedTask = await Task.findById(id).populate('watchers', 'name email avatar');

    await sendNotification({
      userId, type: 'watcher_added', title: 'Added as Watcher',
      message: `You're now watching task "${task.title}".`,
      relatedTask: task._id, relatedProject: task.project,
      link: taskLink(orgSlug, task.project, task._id),
    });

    res.json({ success: true, message: 'Watcher added successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const removeWatcher = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    task.watchers = task.watchers.filter((wid) => wid.toString() !== userId);
    await task.save();

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'watcher_removed', entity: 'Task', entityId: task._id, description: `Watcher removed from task "${task.title}"`,
    });

    const updatedTask = await Task.findById(id).populate('watchers', 'name email avatar');
    res.json({ success: true, message: 'Watcher removed successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const addWorkLog = async (req, res) => {
  try {
    const { projectId, taskId } = req.params;
    const { hours, date, description } = req.body;
    const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to add work logs.' });

    const durationSeconds = Math.floor(hours * 3600);
    task.workLogs.push({ user: req.user.id, seconds: durationSeconds, date: date || new Date(), description, approved: false });
    task.actualHours = (task.actualHours || 0) + hours;
    await task.save();

    const orgSlug = await getOrgSlug(project.organization);
    const link = taskLink(orgSlug, projectId, task._id);

    await sendNotification({
      userId: task.assignees?.[0]?._id || task.assignees?.[0] || req.user.id,
      type: 'work_log_approved', title: 'Work Log Added',
      message: `Work log added for task "${task.title}"`,
      relatedTask: task._id, relatedProject: task.project, link,
    });

    await notifyTaskParticipants(task, project, {
      type: 'work_log_added', title: 'Work Log Added',
      message: `${hours}h logged on task "${task.title}".`,
      excludeUserId: req.user.id, link,
    });

    await Activity.create({
      organization: project.organization, project: projectId, level: 'task', task: taskId,
      user: req.user.id, type: 'work_log_added', entity: 'Task', entityId: taskId,
      newValue: { hours, description }, description: `Work log added: ${hours} hours`,
    });

    const updatedTask = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('workLogs.user', 'name email');
    res.json({ success: true, message: 'Work log added successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const addAttachment = async (req, res) => {
  try {
    const { id } = req.params;
    const { filename, originalName, url, size, mimeType } = req.body;
    const task = await Task.findById(id).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    const fileRecord = new File({ task: task._id, filename, originalName, url, size, mimeType, uploadedBy: req.user.id });
    await fileRecord.save();
    task.attachments.push(fileRecord._id);
    await task.save();

    const orgSlug = await getOrgSlug(project.organization);
    const link = taskLink(orgSlug, task.project, task._id);

    await sendNotification({
      userId: task.assignees?.[0]?._id || task.assignees?.[0] || req.user.id,
      type: 'file_uploaded', title: 'File Uploaded',
      message: `File "${filename}" added to task "${task.title}"`,
      relatedTask: task._id, relatedProject: task.project, link,
    });

    await notifyTaskParticipants(task, project, {
      type: 'attachment_added', title: 'Attachment Added',
      message: `"${filename}" was added to task "${task.title}".`,
      excludeUserId: req.user.id, link,
    });

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'attachment_added', entity: 'Task', entityId: task._id, description: `Attachment "${filename}" added to task`,
    });

    const updatedTask = await Task.findById(id).populate('assignees', 'name email avatar').populate({ path: 'attachments', populate: { path: 'uploadedBy', select: 'name email' } });
    res.json({ success: true, message: 'Attachment added successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const removeAttachment = async (req, res) => {
  try {
    const { id, attachmentId } = req.params;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    task.attachments = task.attachments.filter((att) => att.toString() !== attachmentId);
    await task.save();

    const file = await File.findById(attachmentId);
    if (file && file.url) {
      const filePath = path.join(process.cwd(), 'uploads', path.basename(file.url));
      try { await fs.unlink(filePath); } catch { }
    }
    await File.updateOne({ _id: attachmentId, deleted: false }, { deleted: true, deletedAt: new Date() });

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'attachment_removed', entity: 'Task', entityId: task._id, description: 'Attachment removed from task',
    });

    const updatedTask = await Task.findById(id).populate('assignees', 'name email avatar').populate({ path: 'attachments', populate: { path: 'uploadedBy', select: 'name email' } });
    res.json({ success: true, message: 'Attachment removed successfully.', data: updatedTask });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getGanttData = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view tasks in this project.' });

    const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } }).populate('assignees', 'name').select('title startDate dueDate status priority checklist taskCode');

    const ganttData = tasks.map((task) => ({
      id: task._id, name: task.title, start: task.startDate, end: task.dueDate,
      progress: computeTaskProgress(task), type: 'task', assignee: task.assignees[0]?.name, taskCode: task.taskCode,
    }));
    res.json({ success: true, data: ganttData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

// Timer actions are assignee-only. Having task.edit is not enough — the
// permission gates *whether the project role can touch timers at all*,
// but starting/stopping/resuming a specific task's timer is restricted
// to the people actually assigned to that task, regardless of role.
const requireAssignee = (task, userId) => isTaskAssignee(task, userId);

export const startTimer = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const { allowed } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
    if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can start the timer on this task.' });

    const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (activeTimer) return res.status(400).json({ success: false, message: 'No active timer can be started because another timer is already running.' });

    task.workLogs.push({ user: req.user.id, seconds: 0, date: new Date(), description: 'Timer started', isTimer: true, stopped: false });
    if (task.status === 'todo') task.status = 'in-progress';
    task.updatedAt = new Date();
    await task.save();

    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
    else await syncProjectProgressFromTasks(task.project);

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('workLogs.user', 'name email');

    res.json({ success: true, data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const stopTimer = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const { allowed } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
    if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can stop the timer on this task.' });

    const lastTimerLog = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (!lastTimerLog) return res.status(400).json({ success: false, message: 'No active timer' });

    const durationSeconds = Math.floor((Date.now() - new Date(lastTimerLog.date).getTime()) / 1000);
    lastTimerLog.seconds = durationSeconds;
    lastTimerLog.stopped = true;
    lastTimerLog.description = `Timer stopped (${durationSeconds}s)`;
    task.timeSpent = task.workLogs.reduce((sum, log) => sum + (log.seconds || 0), 0);
    await task.save();

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('workLogs.user', 'name email');

    res.json({ success: true, data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const resumeTimer = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const { allowed } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
    if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can resume the timer on this task.' });

    const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (activeTimer) return res.status(400).json({ success: false, message: 'No active timer can be started because another timer is already running.' });

    task.workLogs.push({ user: req.user.id, seconds: 0, date: new Date(), description: 'Timer resumed', isTimer: true, stopped: false });
    await task.save();

    const updatedTask = await Task.findById(taskId)
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('workLogs.user', 'name email');

    res.json({ success: true, data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const finishTask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'Permission denied' });
    if (!requireAssignee(task, req.user.id)) return res.status(403).json({ success: false, message: 'Only assignees can mark this task as finished.' });

    const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    if (activeTimer) {
      activeTimer.seconds = Math.floor((Date.now() - new Date(activeTimer.date).getTime()) / 1000);
      activeTimer.stopped = true;
      activeTimer.description = `Timer stopped (${activeTimer.seconds}s)`;
    }

    task.checklist.forEach((c) => { c.completed = true; });
    task.status = 'completed';
    task.timeSpent = task.workLogs.reduce((sum, log) => sum + (log.seconds || 0), 0);
    task.updatedAt = new Date();
    await task.save();

    if (task.assignees?.length) await recalcWorkloadForUsers(task.project, task.assignees.map((a) => a._id || a));
    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
    else await syncProjectProgressFromTasks(task.project);

    const orgSlug = await getOrgSlug(project.organization);

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'task_status_changed', entity: 'Task', entityId: task._id,
      previousValue: 'in-progress', newValue: 'completed', description: `Task "${task.title}" marked as completed`,
    });

    await notifyTaskParticipants(task, project, {
      type: 'task_status_changed', title: 'Task Completed',
      message: `Task "${task.title}" was marked completed.`,
      excludeUserId: req.user.id, link: taskLink(orgSlug, project._id, task._id),
    });

    const updatedTask = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    res.json({ success: true, message: 'Task marked as completed', data: attachTaskUserFlags(updatedTask.toObject(), req.user.id) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getTimerStatus = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found' });

    const activeTimer = task.workLogs.find((log) => log.user.toString() === req.user.id && log.isTimer && !log.stopped);
    const lastLogTime = activeTimer ? new Date(activeTimer.date) : null;

    res.json({
      success: true,
      data: {
        isRunning: !!activeTimer,
        elapsedSeconds: activeTimer ? Math.floor((Date.now() - lastLogTime.getTime()) / 1000) : 0,
        timeSpent: task.timeSpent,
        canControl: requireAssignee(task, req.user.id),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const addChecklistItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { item } = req.body;
    if (!item || !item.trim()) return res.status(400).json({ success: false, message: 'Checklist item text is required.' });

    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    task.checklist.push({ item: item.trim(), completed: false });
    await task.save();

    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
    else await syncProjectProgressFromTasks(task.project);

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id, description: `Checklist item "${item.trim()}" added`,
    });

    res.status(201).json({ success: true, message: 'Checklist item added.', data: task.checklist });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const toggleChecklistItem = async (req, res) => {
  try {
    const { id, itemId } = req.params;
    const { completed } = req.body;

    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    const checklistItem = task.checklist.id(itemId);
    if (!checklistItem) return res.status(404).json({ success: false, message: 'Checklist item not found.' });

    checklistItem.completed = typeof completed === 'boolean' ? completed : !checklistItem.completed;
    task.updatedAt = new Date();
    await task.save();

    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
    else await syncProjectProgressFromTasks(task.project);

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id,
      description: `Checklist item "${checklistItem.item}" marked ${checklistItem.completed ? 'complete' : 'incomplete'}`,
    });

    res.json({ success: true, message: 'Checklist item updated.', data: task.checklist });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const removeChecklistItem = async (req, res) => {
  try {
    const { id, itemId } = req.params;
    const task = await Task.findById(id);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to update this task.' });

    task.checklist = task.checklist.filter((c) => c._id.toString() !== itemId);
    await task.save();

    if (task.milestone) await updateMilestoneProgress(task.project, task.milestone);
    else await syncProjectProgressFromTasks(task.project);

    await Activity.create({
      organization: project.organization, project: task.project, level: 'task', task: task._id,
      user: req.user.id, type: 'checklist_updated', entity: 'Task', entityId: task._id, description: 'Checklist item removed',
    });

    res.json({ success: true, message: 'Checklist item removed.', data: task.checklist });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const getKanbanBoards = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.TASK_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'Access denied.' });

    const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } })
      .populate('assignees', 'name email avatar')
      .populate('watchers', 'name email avatar')
      .populate('createdBy', 'name email')
      .populate('dependencies')
      .sort({ order: 1 });

    const columns = getKanbanColumns();

    const tasksWithOverdue = tasks.map((task) => {
      const taskObj = task.toObject ? task.toObject() : task._doc || task;
      let isOverdue = false;
      if (taskObj.dueDate && taskObj.status !== 'completed') {
        const dueDate = new Date(taskObj.dueDate);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        isOverdue = dueDate < today;
      }

      const checklist = taskObj.checklist || [];
      const checklistTotal = checklist.length;
      const checklistCompleted = checklist.filter((i) => i.completed).length;
      const checklistPct = checklistTotal > 0 ? Math.round((checklistCompleted / checklistTotal) * 100) : 0;

      return attachTaskUserFlags({
        ...taskObj, isOverdue, checklistTotal, checklistCompleted, checklistPct, progress: computeTaskProgress(taskObj),
      }, req.user.id);
    });

    const data = {
      columns,
      tasks: groupTasksByStatus(tasksWithOverdue),
      unassigned: tasksWithOverdue.filter((t) => !t.milestone),
    };

    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const moveTask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const { targetColumn, beforeTaskId } = req.body;

    const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.TASK_EDIT);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to move tasks.' });
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const oldStatus = task.status;
    task.status = targetColumn;

    let newOrder = 0;
    if (beforeTaskId) {
      const before = await Task.findById(beforeTaskId);
      newOrder = before ? before.order - 0.5 : 0;
    } else {
      const last = await Task.findOne({ project: task.project, status: targetColumn }).sort({ order: -1 });
      newOrder = last ? last.order + 1 : 0;
    }

    task.order = newOrder;
    await task.save();

    await Task.updateMany(
      { project: task.project, status: targetColumn, _id: { $ne: task._id }, order: { $gte: newOrder } },
      { $inc: { order: 1 } }
    );

    const orgSlug = await getOrgSlug(project.organization);

    await Activity.create({
      organization: project.organization, project: project._id, level: 'task', task: task._id,
      user: req.user.id, type: 'task_moved', entity: 'Task', entityId: task._id,
      description: `Task "${task.title}" moved from "${oldStatus}" to "${targetColumn}"`,
    });

    await notifyTaskParticipants(task, project, {
      type: 'task_moved', title: 'Task Moved',
      message: `Task "${task.title}" moved from ${oldStatus} to ${targetColumn}.`,
      excludeUserId: req.user.id, link: taskLink(orgSlug, project._id, task._id),
    });

    if (task.assignees?.length) await recalcWorkloadForUsers(project._id, task.assignees.map((a) => a._id || a));
    if (task.milestone) await updateMilestoneProgress(project._id, task.milestone);
    else await syncProjectProgressFromTasks(project._id);

    res.json({ success: true, message: 'Task moved successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

const getKanbanColumns = (statuses = ['todo', 'in-progress', 'review', 'completed']) => statuses.map((status) => ({
  _id: status,
  name: status === 'todo' ? 'To Do' : status === 'in-progress' ? 'In Progress' : status === 'review' ? 'In Review' : 'Done',
  status,
  color: status === 'todo' ? '#6B7280' : status === 'in-progress' ? '#3B82F6' : status === 'review' ? '#8B5CF6' : '#10B981',
}));

const groupTasksByStatus = (tasks) => {
  const groups = { todo: [], 'in-progress': [], review: [], completed: [] };
  tasks.forEach((task) => {
    const status = task.status || 'todo';
    if (groups[status]) groups[status].push(task);
  });
  return groups;
};