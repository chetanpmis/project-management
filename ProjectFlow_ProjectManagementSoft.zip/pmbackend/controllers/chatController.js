import Message from '../models/Message.js';
import Project from '../models/Project.js';
import Organization from '../models/Organization.js';
import { emitToProject } from '../utils/socket.js';
import { sendBulkNotification } from '../utils/sendNotification.js';
import { toUserIds } from '../utils/userIdHelpers.js';
import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';
import { checkProjectPermission, hasProjectPermission, resolveAccess, loadOrgAndCheckMembership } from '../utils/permissions.js';
import { projectChatLink } from '../utils/routeLinks.js';

const getOrgSlug = async (organizationId) => {
  const org = await Organization.findById(organizationId).select('slug');
  return org?.slug || '';
};

const populateMessage = (query) =>
  query
    .populate('author', 'name email avatar')
    .populate('mentions', 'name email avatar')
    .populate('reactions.users', 'name')
    .populate('readBy.user', 'name')
    .populate({ path: 'replyTo', select: 'content author isDeleted', populate: { path: 'author', select: 'name' } });

const handleError = (res, err) => {
  console.error('[ChatController]', err);
  const status = err.status || 500;
  return res.status(status).json({ success: false, message: err.message || 'Something went wrong.' });
};

export const list = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { page = 1, limit = 30 } = req.query;

    const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.CHAT_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view this chat.' });

    const pageNum = Math.max(parseInt(page), 1);
    const limitNum = Math.max(parseInt(limit), 1);

    const query = { project: projectId };
    const total = await Message.countDocuments(query);

    const messagesQuery = Message.find(query)
      .sort({ createdAt: -1 })
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum);

    const messages = await populateMessage(messagesQuery);

    const shaped = messages.reverse().map((m) => {
      const obj = m.toObject();
      if (obj.isDeleted) {
        obj.content = null;
        obj.mentions = [];
        obj.reactions = [];
      }
      return obj;
    });

    return res.json({
      success: true,
      data: shaped,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum),
        hasMore: pageNum * limitNum < total,
      },
    });
  } catch (error) {
    return handleError(res, error);
  }
};

export const create = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { content, mentions = [], replyTo = null } = req.body;

    if (!content?.trim()) return res.status(400).json({ success: false, message: 'Message content is required.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.CHAT_SEND);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to send messages in this chat.' });

    const validTeamIds = new Set([project.owner.toString(), ...project.team.map((t) => t.user.toString())]);
    const validMentions = toUserIds(mentions).filter((id) => validTeamIds.has(id));

    const message = await Message.create({
      project: projectId,
      author: req.user.id,
      content: content.trim(),
      mentions: validMentions,
      replyTo: replyTo || null,
      readBy: [{ user: req.user.id, readAt: new Date() }],
    });

    const populated = await populateMessage(Message.findById(message._id));

    emitToProject(projectId, 'chat:message', populated);

    if (validMentions.length > 0) {
      const orgSlug = await getOrgSlug(project.organization);
      await sendBulkNotification(validMentions, {
        type: 'task_mentioned',
        title: `Mentioned by ${req.user.name || req.user.email || 'a teammate'}`,
        message: content.length > 140 ? `${content.slice(0, 140)}…` : content,
        relatedProject: projectId,
        excludeUserId: req.user.id,
        link: projectChatLink(orgSlug, projectId),
      });
    }

    return res.status(201).json({ success: true, message: 'Message sent.', data: populated });
  } catch (error) {
    return handleError(res, error);
  }
};

export const update = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { content, mentions } = req.body;

    const message = await Message.findById(messageId);
    if (!message || message.isDeleted) return res.status(404).json({ success: false, message: 'Message not found.' });

    const project = await Project.findById(message.project);
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const { allowed: accessAllowed, orgRole } = await resolveAccess(project, req.user.id);
    if (!accessAllowed) return res.status(403).json({ success: false, message: 'Access denied.' });

    const isAuthor = message.author.toString() === req.user.id.toString();
    const canEditAny = hasProjectPermission(project, orgRole, req.user.id, PROJECT_PERMISSIONS.CHAT_EDIT);

    if (!isAuthor && !canEditAny) {
      return res.status(403).json({ success: false, message: 'You cannot edit this message.' });
    }

    if (content !== undefined) message.content = content.trim();
    if (mentions !== undefined) message.mentions = toUserIds(mentions);
    message.edited = true;
    message.editedAt = new Date();
    await message.save();

    const populated = await populateMessage(Message.findById(message._id));
    emitToProject(message.project.toString(), 'chat:message:updated', populated);

    return res.json({ success: true, message: 'Message updated.', data: populated });
  } catch (error) {
    return handleError(res, error);
  }
};

export const remove = async (req, res) => {
  try {
    const { messageId } = req.params;

    const message = await Message.findById(messageId);
    if (!message || message.isDeleted) return res.status(404).json({ success: false, message: 'Message not found.' });

    const project = await Project.findById(message.project);
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const { allowed: accessAllowed, orgRole } = await resolveAccess(project, req.user.id);
    if (!accessAllowed) return res.status(403).json({ success: false, message: 'Access denied.' });

    const isAuthor = message.author.toString() === req.user.id.toString();
    const canDeleteAny = hasProjectPermission(project, orgRole, req.user.id, PROJECT_PERMISSIONS.CHAT_DELETE);

    if (!isAuthor && !canDeleteAny) {
      return res.status(403).json({ success: false, message: 'You do not have permission to delete this message.' });
    }

    message.isDeleted = true;
    message.deletedAt = new Date();
    message.content = 'This message was deleted';
    message.mentions = [];
    message.reactions = [];
    message.replyTo = null;
    message.edited = false;
    message.editedAt = null;

    await message.save();

    const populated = await populateMessage(Message.findById(message._id));
    emitToProject(message.project.toString(), 'chat:message:updated', populated);

    return res.json({ success: true, message: 'Message deleted.', data: populated });
  } catch (error) {
    return handleError(res, error);
  }
};

export const react = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { emoji } = req.body;
    if (!emoji) return res.status(400).json({ success: false, message: 'Emoji is required.' });

    const message = await Message.findById(messageId);
    if (!message || message.isDeleted) return res.status(404).json({ success: false, message: 'Message not found.' });

    const project = await Project.findById(message.project);
    if (!project) return res.status(404).json({ success: false, message: 'Project not found.' });

    const { allowed: accessAllowed, orgRole } = await resolveAccess(project, req.user.id);
    if (!accessAllowed) return res.status(403).json({ success: false, message: 'Access denied.' });

    if (!hasProjectPermission(project, orgRole, req.user.id, PROJECT_PERMISSIONS.CHAT_SEND)) {
      return res.status(403).json({ success: false, message: 'You do not have permission to react to messages.' });
    }

    let group = message.reactions.find((r) => r.emoji === emoji);
    if (!group) {
      group = { emoji, users: [req.user.id] };
      message.reactions.push(group);
    } else {
      const idx = group.users.findIndex((u) => u.toString() === req.user.id);
      if (idx >= 0) group.users.splice(idx, 1);
      else group.users.push(req.user.id);
    }

    message.reactions = message.reactions.filter((r) => r.users.length > 0);
    await message.save();

    const populated = await populateMessage(Message.findById(message._id));
    emitToProject(message.project.toString(), 'chat:message:updated', populated);

    return res.json({ success: true, data: populated });
  } catch (error) {
    return handleError(res, error);
  }
};

export const markRead = async (req, res) => {
  try {
    const { projectId } = req.params;

    const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.CHAT_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'Access denied.' });

    const unread = await Message.find({
      project: projectId,
      isDeleted: { $ne: true },
      'readBy.user': { $ne: req.user.id },
    });

    if (unread.length > 0) {
      await Message.updateMany(
        { _id: { $in: unread.map((m) => m._id) } },
        { $push: { readBy: { user: req.user.id, readAt: new Date() } } }
      );
      emitToProject(projectId, 'chat:read', { userId: req.user.id, messageIds: unread.map((m) => m._id) });
    }

    return res.json({ success: true, message: 'Chat marked as read.' });
  } catch (error) {
    return handleError(res, error);
  }
};

export const getUnreadCount = async (req, res) => {
  try {
    const { projectId } = req.params;

    const { allowed } = await checkProjectPermission(req.user.id, projectId, PROJECT_PERMISSIONS.CHAT_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'Access denied.' });

    const unreadCount = await Message.countDocuments({
      project: projectId,
      isDeleted: { $ne: true },
      author: { $ne: req.user.id },
      'readBy.user': { $ne: req.user.id },
    });

    return res.json({ success: true, data: { unreadCount } });
  } catch (error) {
    return handleError(res, error);
  }
};