
import mongoose from 'mongoose';
import fs from 'fs';
import path from 'path';
import File, { Folder } from '../models/File.js';
import Project from '../models/Project.js';
import { createActivity } from '../utils/activity.js';
import { 
  PROJECT_PERMISSIONS, 
  DEFAULT_ROLE_PERMISSIONS 
} from '../constants/projectPermissions.js';
// import { hasPermission } from '../utils/permissions.js';
import { 
  sendBulkNotification, 
  sendNotification 
} from '../utils/sendNotification.js';
import { toUserIds } from '../utils/userIdHelpers.js';

const checkResourcePermission = (role, permission) => {
  const rolePerms = DEFAULT_ROLE_PERMISSIONS[role] || [];
  // return hasPermission(rolePerms, permission) || rolePerms.includes('*');
};

const notifyProjectTeam = async (project, { type, title, message, relatedTask = null, link = null, excludeUserId = null }) => {
  const recipients = toUserIds([
    project.owner,
    ...(project.team || []).map((t) => t.user),
  ]);
  return sendBulkNotification(recipients, { 
    type, title, message, 
    relatedProject: project._id, 
    link, 
    excludeUserId 
  });
};

/* ============================================================
   Shared helpers (updated)
============================================================ */

const getProjectRole = (project, userId) => {
  const uid = userId.toString();
  if (project.owner.toString() === uid) return 'owner';
  const member = project.team.find((t) => t.user.toString() === uid);
  return member ? member.role || 'member' : null;
};

const requireProjectAccess = async (projectId, userId) => {
  if (!mongoose.Types.ObjectId.isValid(projectId)) {
    const err = new Error('Invalid project ID.');
    err.status = 400;
    throw err;
  }
  const project = await Project.findById(projectId);
  if (!project) {
    const err = new Error('Project not found.');
    err.status = 404;
    throw err;
  }
  const role = getProjectRole(project, userId);
  if (!role) {
    const err = new Error('You are not a member of this project.');
    err.status = 403;
    throw err;
  }
  // if (!checkResourcePermission(role, PROJECT_PERMISSIONS.PROJECT_VIEW)) {
  //   const err = new Error('You do not have permission to view this project.');
  //   err.status = 403;
  //   throw err;
  // }
  return { project, role };
};

const deleteFileFromDisk = (filePath) => {
  fs.access(filePath, fs.constants.F_OK, (accessErr) => {
    if (accessErr) return;
    fs.unlink(filePath, () => {});
  });
};

const ok = (res, message, data, status = 200) =>
  res.status(status).json({ success: true, message, data });

const fail = (res, status, message) =>
  res.status(status).json({ success: false, message });

const handleError = (res, err) => {
  console.error('[ResourceController]', err);
  const status = err.status || 500;
  return fail(res, status, err.message || 'Something went wrong.');
};

/* ============================================================
   FOLDERS (updated)
============================================================ */

export const createFolder = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { role } = await requireProjectAccess(projectId, req.user.id);

    const name = (req.body.name || '').trim();
    if (!name) return fail(res, 400, 'Folder name is required.');
    if (name.length > 100) return fail(res, 400, 'Folder name cannot exceed 100 characters.');

    const existing = await Folder.findOne({
      project: projectId,
      isDeleted: false,
      name: { $regex: `^${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, $options: 'i' },
    }).lean();
    if (existing) return fail(res, 409, 'A folder with this name already exists in this project.');

    const folder = await Folder.create({ project: projectId, name, createdBy: req.user.id });

    await createActivity({
      project: projectId,
      user: req.user.id,
      type: 'folder_created',
      entity: 'Folder',
      entityId: folder._id,
      description: `Created folder "${folder.name}"`,
    });

    return ok(res, 'Folder created successfully.', folder, 201);
  } catch (err) {
    return handleError(res, err);
  }
};

export const listFolders = async (req, res) => {
  try {
    const { projectId } = req.params;
    await requireProjectAccess(projectId, req.user.id);

    const folders = await Folder.find({ project: projectId, isDeleted: false })
      .sort({ name: 1 })
      .select('name project createdBy createdAt')
      .lean();

    return ok(res, 'Folders fetched successfully.', folders);
  } catch (err) {
    return handleError(res, err);
  }
};

export const renameFolder = async (req, res) => {
  try {
    const { folderId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(folderId)) return fail(res, 400, 'Invalid folder ID.');

    const folder = await Folder.findOne({ _id: folderId, isDeleted: false });
    if (!folder) return fail(res, 404, 'Folder not found.');

    const { role } = await requireProjectAccess(folder.project, req.user.id);
    // if (!checkResourcePermission(role, PROJECT_PERMISSIONS.FILE_EDIT)) {
    //   return fail(res, 403, 'Only owners and managers can rename folders.');
    // }

    const name = (req.body.name || '').trim();
    if (!name) return fail(res, 400, 'Folder name is required.');

    const duplicate = await Folder.findOne({
      _id: { $ne: folder._id },
      project: folder.project,
      isDeleted: false,
      name: { $regex: `^${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, $options: 'i' },
    }).lean();
    if (duplicate) return fail(res, 409, 'A folder with this name already exists in this project.');

    const oldName = folder.name;
    folder.name = name;
    await folder.save();

    await createActivity({
      project: folder.project,
      user: req.user.id,
      type: 'folder_renamed',
      entity: 'Folder',
      entityId: folder._id,
      description: `Renamed folder "${oldName}" to "${folder.name}"`,
    });

    return ok(res, 'Folder renamed successfully.', folder);
  } catch (err) {
    return handleError(res, err);
  }
};

export const deleteFolder = async (req, res) => {
  try {
    const { folderId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(folderId)) return fail(res, 400, 'Invalid folder ID.');

    const folder = await Folder.findOne({ _id: folderId, isDeleted: false });
    if (!folder) return fail(res, 404, 'Folder not found.');

    const { role } = await requireProjectAccess(folder.project, req.user.id);
    // if (!checkResourcePermission(role, PROJECT_PERMISSIONS.FILE_DELETE)) {
    //   return fail(res, 403, 'Only owners and managers can delete folders.');
    // }

    const fileCount = await File.countDocuments({ folder: folder._id, isDeleted: false });
    if (fileCount > 0) {
      return fail(res, 400, 'Cannot delete a folder that still contains files. Move or delete the files first.');
    }

    folder.isDeleted = true;
    folder.deletedAt = new Date();
    await folder.save();

    await createActivity({
      project: folder.project,
      user: req.user.id,
      type: 'folder_deleted',
      entity: 'Folder',
      entityId: folder._id,
      description: `Deleted folder "${folder.name}"`,
    });

    return ok(res, 'Folder deleted successfully.', null);
  } catch (err) {
    return handleError(res, err);
  }
};

/* ============================================================
   FILES — Upload / Get / List (updated)
============================================================ */

export const uploadFile = async (req, res) => {
  const uploadedPath = req.file ? req.file.path : null;

  try {
    const { projectId } = req.params;
    await requireProjectAccess(projectId, req.user.id);

    if (!req.file) return fail(res, 400, 'A file is required.');

    const { folder = null, visibility = 'team', task = null } = req.body;

    if (folder) {
      if (!mongoose.Types.ObjectId.isValid(folder)) throw Object.assign(new Error('Invalid folder ID.'), { status: 400 });
      const folderDoc = await Folder.findOne({ _id: folder, project: projectId, isDeleted: false }).lean();
      if (!folderDoc) throw Object.assign(new Error('Folder not found in this project.'), { status: 404 });
    }
    if (!['team', 'private'].includes(visibility)) {
      throw Object.assign(new Error('Visibility must be either "team" or "private".'), { status: 400 });
    }

    const relativeUrl = `/uploads/resources/${projectId}/${req.file.filename}`;

    const session = await mongoose.startSession();
    let created;
    try {
      session.startTransaction();
      created = await File.create(
        [
          {
            project: projectId,
            task: task || null,
            folder: folder || null,
            filename: req.file.filename,
            originalName: req.file.originalname,
            url: relativeUrl,
            size: req.file.size,
            mimeType: req.file.mimetype,
            uploadedBy: req.user.id,
            visibility,
            currentVersion: 1,
            versions: [
              {
                version: 1,
                filename: req.file.filename,
                originalName: req.file.originalname,
                url: relativeUrl,
                size: req.file.size,
                mimeType: req.file.mimetype,
                uploadedBy: req.user.id,
                uploadedAt: new Date(),
              },
            ],
          },
        ],
        { session }
      );
      await session.commitTransaction();
    } catch (txErr) {
      await session.abortTransaction();
      throw txErr;
    } finally {
      session.endSession();
    }

    const fileDoc = created[0];

    await createActivity({
      project: projectId,
      user: req.user.id,
      type: 'file_uploaded',
      entity: 'File',
      entityId: fileDoc._id,
      description: `Uploaded file "${fileDoc.originalName}"`,
    });

    const project = await Project.findById(projectId).select('owner team').lean();
    const recipients = [project.owner, ...project.team.map((t) => t.user)].filter(
      (u) => u.toString() !== req.user.id.toString()
    );
    if (recipients.length) {
      await sendBulkNotification(recipients, {
        type: 'file_uploaded',
        title: 'New file uploaded',
        message: `${fileDoc.originalName} was uploaded to the project.`,
        relatedProject: projectId,
        excludeUserId: req.user.id,
      });
    }

    return ok(res, 'File uploaded successfully.', fileDoc, 201);
  } catch (err) {
    if (uploadedPath) deleteFileFromDisk(uploadedPath);
    return handleError(res, err);
  }
};

export const getFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false })
      .populate('uploadedBy', 'name email avatar')
      .populate('folder', 'name');
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.isAccessibleBy(req.user.id, role)) return fail(res, 403, 'You do not have access to this file.');

    return ok(res, 'File fetched successfully.', file);
  } catch (err) {
    return handleError(res, err);
  }
};

export const listFiles = async (req, res) => {
  try {
    const { projectId } = req.params;
    const { role } = await requireProjectAccess(projectId, req.user.id);

    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit) || 20, 1), 100);
    const { search, folder, mimeType, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;

    const query = { project: projectId, isDeleted: false };

    if (folder) {
      if (folder === 'root') query.folder = null;
      else if (mongoose.Types.ObjectId.isValid(folder)) query.folder = folder;
      else return fail(res, 400, 'Invalid folder filter.');
    }
    if (mimeType) query.mimeType = mimeType;
    if (search && search.trim()) query.$text = { $search: search.trim() };

    if (role === 'member') {
      query.$or = [
        { visibility: 'team' },
        { uploadedBy: req.user.id },
        { 'sharedWith.user': req.user.id },
      ];
    }

    const allowedSortFields = new Set(['createdAt', 'originalName', 'size']);
    const sortField = allowedSortFields.has(sortBy) ? sortBy : 'createdAt';
    const sortDir = sortOrder === 'asc' ? 1 : -1;

    const [files, total] = await Promise.all([
      File.find(query)
        .sort({ [sortField]: sortDir })
        .skip((page - 1) * limit)
        .limit(limit)
        .select('-versions -sharedWith')
        .populate('uploadedBy', 'name email avatar')
        .populate('folder', 'name')
        .lean(),
      File.countDocuments(query),
    ]);

    return ok(res, 'Files fetched successfully.', {
      files,
      pagination: { total, page, limit, totalPages: Math.ceil(total / limit), hasMore: page * limit < total },
    });
  } catch (err) {
    return handleError(res, err);
  }
};

/* ============================================================
   FILES — Rename / Move / Delete / Download (updated)
============================================================ */

export const renameFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.editPermissionFor(req.user.id, role)) return fail(res, 403, 'You cannot rename this file.');

    const originalName = (req.body.originalName || '').trim();
    if (!originalName) return fail(res, 400, 'File name is required.');

    file.originalName = originalName;
    await file.save();

    await createActivity({
      project: file.project,
      user: req.user.id,
      type: 'file_renamed',
      entity: 'File',
      entityId: file._id,
      description: `Renamed file to "${originalName}"`,
    });

    return ok(res, 'File renamed successfully.', file);
  } catch (err) {
    return handleError(res, err);
  }
};

export const moveFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.editPermissionFor(req.user.id, role)) return fail(res, 403, 'You cannot move this file.');

    const { folder = null } = req.body;
    if (folder) {
      if (!mongoose.Types.ObjectId.isValid(folder)) return fail(res, 400, 'Invalid folder ID.');
      const folderDoc = await Folder.findOne({ _id: folder, project: file.project, isDeleted: false }).lean();
      if (!folderDoc) return fail(res, 404, 'Target folder not found in this project.');
    }

    file.folder = folder || null;
    await file.save();

    await createActivity({
      project: file.project,
      user: req.user.id,
      type: 'file_moved',
      entity: 'File',
      entityId: file._id,
      description: `Moved file "${file.originalName}"`,
    });

    return ok(res, 'File moved successfully.', file);
  } catch (err) {
    return handleError(res, err);
  }
};

export const deleteFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    const isOwnFile = file.uploadedBy.toString() === req.user.id.toString();
    if (role === 'member' && !isOwnFile) return fail(res, 403, 'You can only delete your own files.');

    const session = await mongoose.startSession();
    try {
      session.startTransaction();
      file.isDeleted = true;
      file.deletedAt = new Date();
      await file.save({ session });
      await session.commitTransaction();
    } catch (txErr) {
      await session.abortTransaction();
      throw txErr;
    } finally {
      session.endSession();
    }

    await createActivity({
      project: file.project,
      user: req.user.id,
      type: 'file_deleted',
      entity: 'File',
      entityId: file._id,
      description: `Deleted file "${file.originalName}"`,
    });

    return ok(res, 'File deleted successfully.', null);
  } catch (err) {
    return handleError(res, err);
  }
};

export const downloadFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.isAccessibleBy(req.user.id, role)) return fail(res, 403, 'You do not have access to this file.');

    const absolutePath = path.resolve('.' + file.url);
    if (!fs.existsSync(absolutePath)) return fail(res, 404, 'File is missing from storage.');

    return res.download(absolutePath, file.originalName);
  } catch (err) {
    return handleError(res, err);
  }
};

/* ============================================================
   VERSIONING — Replace / List / Download / Restore (updated)
============================================================ */

export const replaceFile = async (req, res) => {
  const uploadedPath = req.file ? req.file.path : null;

  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');
    if (!req.file) return fail(res, 400, 'A replacement file is required.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.editPermissionFor(req.user.id, role)) return fail(res, 403, 'You cannot replace this file.');

    const oldPhysicalPath = path.resolve('.' + file.url);
    const newRelativeUrl = `/uploads/resources/${file.project}/${req.file.filename}`;

    const session = await mongoose.startSession();
    try {
      session.startTransaction();

      file.versions.push({
        version: file.currentVersion,
        filename: file.filename,
        originalName: file.originalName,
        url: file.url,
        size: file.size,
        mimeType: file.mimeType,
        uploadedBy: file.uploadedBy,
        uploadedAt: file.updatedAt,
      });

      const nextVersion = file.currentVersion + 1;
      file.filename = req.file.filename;
      file.originalName = req.body.originalName || req.file.originalname;
      file.url = newRelativeUrl;
      file.size = req.file.size;
      file.mimeType = req.file.mimetype;
      file.currentVersion = nextVersion;

      await file.save({ session });
      await session.commitTransaction();
    } catch (txErr) {
      await session.abortTransaction();
      throw txErr;
    } finally {
      session.endSession();
    }

    deleteFileFromDisk(oldPhysicalPath);

    await createActivity({
      project: file.project,
      user: req.user.id,
      type: 'file_replaced',
      entity: 'File',
      entityId: file._id,
      description: `Uploaded a new version of "${file.originalName}" (v${file.currentVersion})`,
    });

    const project = await Project.findById(file.project).select('owner team').lean();
    const recipients = [project.owner, ...project.team.map((t) => t.user)].filter(
      (u) => u.toString() !== req.user.id.toString()
    );
    if (recipients.length) {
      await sendBulkNotification(recipients, {
        type: 'file_version_uploaded',
        title: 'New file version',
        message: `A new version of "${file.originalName}" was uploaded.`,
        relatedProject: file.project,
        excludeUserId: req.user.id,
      });
    }

    return ok(res, 'File replaced successfully.', file);
  } catch (err) {
    if (uploadedPath) deleteFileFromDisk(uploadedPath);
    return handleError(res, err);
  }
};

export const listVersions = async (req, res) => {
  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false }).select('project versions currentVersion');
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);

    return ok(res, 'Versions fetched successfully.', {
      currentVersion: file.currentVersion,
      versions: file.versions.sort((a, b) => b.version - a.version),
    });
  } catch (err) {
    return handleError(res, err);
  }
};

export const downloadVersion = async (req, res) => {
  try {
    const { fileId, version } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.isAccessibleBy(req.user.id, role)) return fail(res, 403, 'You do not have access to this file.');

    const versionNum = parseInt(version, 10);
    const versionDoc = file.versions.find((v) => v.version === versionNum);
    if (!versionDoc) return fail(res, 404, 'Version not found.');

    const absolutePath = path.resolve('.' + versionDoc.url);
    if (!fs.existsSync(absolutePath)) return fail(res, 404, 'This version is missing from storage.');

    return res.download(absolutePath, versionDoc.originalName);
  } catch (err) {
    return handleError(res, err);
  }
};

export const restoreVersion = async (req, res) => {
  try {
    const { fileId, version } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.editPermissionFor(req.user.id, role)) return fail(res, 403, 'You cannot restore versions of this file.');

    const versionNum = parseInt(version, 10);
    const target = file.versions.find((v) => v.version === versionNum);
    if (!target) return fail(res, 404, 'Version not found.');

    const session = await mongoose.startSession();
    try {
      session.startTransaction();

      file.versions.push({
        version: file.currentVersion,
        filename: file.filename,
        originalName: file.originalName,
        url: file.url,
        size: file.size,
        mimeType: file.mimeType,
        uploadedBy: file.uploadedBy,
        uploadedAt: file.updatedAt,
      });

      const nextVersion = file.currentVersion + 1;
      file.filename = target.filename;
      file.originalName = target.originalName;
      file.url = target.url;
      file.size = target.size;
      file.mimeType = target.mimeType;
      file.currentVersion = nextVersion;

      await file.save({ session });
      await session.commitTransaction();
    } catch (txErr) {
      await session.abortTransaction();
      throw txErr;
    } finally {
      session.endSession();
    }

    await createActivity({
      project: file.project,
      user: req.user.id,
      type: 'version_restored',
      entity: 'File',
      entityId: file._id,
      description: `Restored "${file.originalName}" to version ${versionNum}`,
    });

    return ok(res, 'Version restored successfully.', file);
  } catch (err) {
    return handleError(res, err);
  }
};

/* ============================================================
   SHARING (updated — now notifies the whole project team)
============================================================ */

export const shareFile = async (req, res) => {
  try {
    const { fileId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { project, role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.editPermissionFor(req.user.id, role)) return fail(res, 403, 'You cannot share this file.');

    const { userId, permission = 'view' } = req.body;
    if (!userId || !mongoose.Types.ObjectId.isValid(userId)) return fail(res, 400, 'A valid user ID is required.');
    if (!['view', 'edit'].includes(permission)) return fail(res, 400, 'Permission must be "view" or "edit".');

    const isMember =
      project.owner.toString() === userId || project.team.some((t) => t.user.toString() === userId);
    if (!isMember) return fail(res, 400, 'You can only share files with members of this project.');

    const existingShare = file.sharedWith.find((s) => s.user.toString() === userId);
    if (existingShare) {
      existingShare.permission = permission;
    } else {
      file.sharedWith.push({ user: userId, permission, sharedBy: req.user.id });
    }
    await file.save();

    await createActivity({
      project: file.project,
      user: req.user.id,
      type: 'file_shared',
      entity: 'File',
      entityId: file._id,
      description: `Shared "${file.originalName}"`,
    });

    // Notify the whole project team (as requested)
    await notifyProjectTeam(project, {
      type: 'file_shared',
      title: 'A file was shared with you',
      message: `${file.originalName} was shared with you (${permission} access).`,
      relatedProject: file.project,
      excludeUserId: req.user.id,
    });

    return ok(res, 'File shared successfully.', file);
  } catch (err) {
    return handleError(res, err);
  }
};

export const unshareFile = async (req, res) => {
  try {
    const { fileId, userId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(fileId)) return fail(res, 400, 'Invalid file ID.');

    const file = await File.findOne({ _id: fileId, isDeleted: false });
    if (!file) return fail(res, 404, 'File not found.');

    const { role } = await requireProjectAccess(file.project, req.user.id);
    if (!file.editPermissionFor(req.user.id, role)) return fail(res, 403, 'You cannot modify sharing for this file.');

    const before = file.sharedWith.length;
    file.sharedWith = file.sharedWith.filter((s) => s.user.toString() !== userId);
    if (file.sharedWith.length === before) return fail(res, 404, 'This file was not shared with that user.');

    await file.save();

    await createActivity({
      project: file.project,
      user: req.user.id,
      type: 'file_unshared',
      entity: 'File',
      entityId: file._id,
      description: `Unshared "${file.originalName}"`,
    });

    return ok(res, 'File unshared successfully.', file);
  } catch (err) {
    return handleError(res, err);
  }
};