import User from '../models/User.js';
import mongoose from 'mongoose';
import fs from 'fs/promises';
import path from 'path';
import bcrypt from 'bcryptjs';

export const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.json(user);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

export const updateProfile = async (req, res) => {
  try {
    const {
      name,
      bio,
      avatar,
      dailyCapacity,
      workingDaysPerWeek,
    } = req.body;

    const user = await User.findByIdAndUpdate(
      req.user.id,
      {
        name,
        bio,
        avatar,
        dailyCapacity,
        workingDaysPerWeek,
        updatedAt: new Date(),
      },
      {
        new: true,
        runValidators: true,
      }
    ).select('-password');

    res.json(user);
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};
export const updateAvatar = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload an avatar.',
      });
    }

    session.startTransaction();

    const user = await User.findById(req.user.id).session(session);

    if (!user) {
      throw new Error('User not found.');
    }

    const oldAvatar = user.avatar;

    user.avatar = `/uploads/avatars/${req.file.filename}`;
    user.updatedAt = new Date();

    await user.save({ session });

    await session.commitTransaction();

    // Delete old avatar after successful DB update
    if (
      oldAvatar &&
      oldAvatar.startsWith('/uploads/avatars/')
    ) {
      try {
        const oldFilePath = path.resolve(oldAvatar.substring(1));
        await fs.unlink(oldFilePath);
      } catch {
        // Ignore if file doesn't exist
      }
    }

    return res.json({
      success: true,
      message: 'Avatar updated successfully.',
      data: user,
    });
  } catch (error) {
    await session.abortTransaction();

    // Remove newly uploaded file if transaction failed
    if (req.file?.path) {
      try {
        await fs.unlink(req.file.path);
      } catch {
        // Ignore cleanup errors
      }
    }

    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to update avatar.',
    });
  } finally {
    session.endSession();
  }
};
export const listUsers = async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 10, 1);
    const search = (req.query.search || '').trim();

    const query = {
      _id: { $ne: new mongoose.Types.ObjectId(req.user.id) },
    };

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const total = await User.countDocuments(query);

    const users = await User.find(query)
      .select('-password')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.json({
      success: true,
      data: users,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('listUsers Error:', error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};
export const getUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const deleteAvatar = async (req, res) => {
  const session = await mongoose.startSession();

  try {
    session.startTransaction();

    const user = await User.findById(req.user.id).session(session);

    if (!user) {
      throw new Error('User not found.');
    }

    const oldAvatar = user.avatar;

    if (!oldAvatar) {
      await session.abortTransaction();

      return res.status(400).json({
        success: false,
        message: 'No avatar to delete.',
      });
    }

    user.avatar = null;
    user.updatedAt = new Date();

    await user.save({ session });

    await session.commitTransaction();

    // Delete the file only after a successful commit
    if (oldAvatar.startsWith('/uploads/avatars/')) {
      try {
        const filePath = path.resolve(oldAvatar.substring(1));
        await fs.unlink(filePath);
      } catch {
        // Ignore if file is already missing
      }
    }

    return res.json({
      success: true,
      message: 'Avatar removed successfully.',
      data: user,
    });
  } catch (error) {
    await session.abortTransaction();

    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to remove avatar.',
    });
  } finally {
    session.endSession();
  }
};

export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Current password and new password are required.',
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 8 characters.',
      });
    }

    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found.',
      });
    }

    const isMatch = await bcrypt.compare(
      currentPassword,
      user.password
    );

    if (!isMatch) {
      return res.status(400).json({
        success: false,
        message: 'Current password is incorrect.',
      });
    }

    const isSamePassword = await bcrypt.compare(
      newPassword,
      user.password
    );

    if (isSamePassword) {
      return res.status(400).json({
        success: false,
        message: 'New password must be different from the current password.',
      });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 12);

    user.password = hashedPassword;
    user.updatedAt = new Date();

    await user.save();

    return res.json({
      success: true,
      message: 'Password changed successfully.',
    });
  } catch (error) {
    console.error('Change Password:', error);

    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to change password.',
    });
  }
};