import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import User from '../models/User.js';
import Organization from '../models/Organization.js';
import Invitation from '../models/Invitation.js';
import { logOrgActivity } from '../utils/activityLogger.js';
import { sendNotification } from '../utils/sendNotification.js';
import { sendEmail } from '../services/email/emailService.js';
import { buildAppUrl } from '../services/email/base.js';
import { invitationAcceptedTemplate } from '../services/email/templates/organizationMailTemplates.js';

const safeSendEmail = async (args) => {
  try {
    await sendEmail(args);
  } catch (err) {
    console.error('[email] failed:', args?.subject, err.message);
  }
};

const addAcceptedMember = (org, { userId, role, permissions, invitedBy, invitedAt }) => {
  const already = org.members.find((m) => m.user.toString() === userId.toString());
  if (already) {
    already.status = 'accepted';
    already.role = role;
    already.permissions = permissions;
    already.joinedAt = new Date();
    return already;
  }
  org.members.push({
    user: userId,
    role,
    permissions,
    status: 'accepted',
    invitedBy,
    invitedAt: invitedAt || new Date(),
    joinedAt: new Date(),
  });
  return org.members[org.members.length - 1];
};

export const register = async (req, res) => {
  try {
    const { name, email, password, invite, inviteCode } = req.body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    // ---- Resolve the invitation from EITHER the token OR the manual code.
    // This is the fix: previously only `invite` (token) was ever read, so
    // registering via the code fallback silently skipped org join. ----
    let invitation = null;
    if (invite) {
      invitation = await Invitation.findOne({ token: invite });
      if (!invitation) {
        return res.status(400).json({ error: 'Invalid invitation link.' });
      }
    } else if (inviteCode) {
      invitation = await Invitation.findOne({ code: inviteCode.trim().toUpperCase() });
      if (!invitation) {
        return res.status(400).json({ error: 'Invalid invitation code.' });
      }
    }

    if (invitation) {
      if (invitation.status !== 'pending') {
        return res.status(400).json({ error: `This invitation has already been ${invitation.status}.` });
      }
      if (invitation.isExpired()) {
        invitation.status = 'expired';
        await invitation.save();
        return res.status(400).json({ error: 'This invitation has expired.' });
      }
      if (invitation.email !== email.toLowerCase().trim()) {
        return res.status(400).json({ error: 'This invitation was sent to a different email address.' });
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      name,
      email,
      password: hashedPassword,
      role: 'member',
    });

    await user.save();

    let joinedOrg = null;

    if (invitation) {
      const org = await Organization.findById(invitation.organization).populate('owner', 'name email');
      if (org && !org.isDeleted) {
        addAcceptedMember(org, {
          userId: user._id,
          role: invitation.role,
          permissions: invitation.permissions,
          invitedBy: invitation.invitedBy,
          invitedAt: invitation.createdAt,
        });
        await org.save();

        invitation.status = 'accepted';
        invitation.acceptedAt = new Date();
        invitation.user = user._id;
        await invitation.save();

        await logOrgActivity(org._id, user._id, 'org_member_joined', {
          entity: 'User',
          entityId: user._id,
          description: `${user.name} joined the organization via invitation`,
        });

        await sendNotification({
          userId: org.owner,
          type: 'org_invite_accepted',
          title: 'Invitation Response',
          message: `${user.name} joined "${org.name}" (registered via invite).`,
          relatedOrganization: org._id,
          link: `/organizations/${org._id}/members`,
        });

        const welcomeTemplate = invitationAcceptedTemplate({
          organizationName: org.name,
          memberName: user.name,
          role: invitation.role,
          description: org.description,
          orgUrl: buildAppUrl(`/organizations/${org._id}`),
        });
        safeSendEmail({ to: user.email, ...welcomeTemplate });

        await User.findByIdAndUpdate(user._id, { activeOrganization: org._id });

        joinedOrg = { id: org._id, name: org.name, role: invitation.role };
      }
    }

    // ---- Auto-login: issue the token immediately so the frontend can log
    // the user straight in after registering, invite or not. ----
    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET || 'your_secret_key',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
      joinedOrganization: joinedOrg,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET || 'your_secret_key',
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};