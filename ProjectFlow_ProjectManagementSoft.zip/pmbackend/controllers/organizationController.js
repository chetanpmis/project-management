import Organization from '../models/Organization.js';
import User from '../models/User.js';
import Project from '../models/Project.js';
import Invitation from '../models/Invitation.js';

import mongoose from 'mongoose';
import { DEFAULT_ORG_ROLE_PERMISSIONS, ORG_PERMISSIONS } from '../constants/organizationPermissions.js';
import { logOrgActivity } from '../utils/activityLogger.js';
import { sendNotification, notifyOrgMembers } from '../utils/sendNotification.js';
import { expireStaleInvitations } from '../utils/invitationHelpers.js';

import {
  organizationInvitationExistingUserTemplate,
  organizationInvitationNewUserTemplate,
  organizationCreatedTemplate,
  invitationAcceptedTemplate,
  memberRemovedTemplate,
  memberRoleChangedTemplate,
} from '../services/email/templates/organizationMailTemplates.js';
import { buildAppUrl } from '../services/email/base.js';
import { sendEmail } from '../services/email/emailService.js';

const INVITE_EXPIRY_DAYS = 7;

// Organization-level roles are: owner, admin, member. ('manager' removed.)
const ASSIGNABLE_ORG_ROLES = ['admin', 'member'];

const slugify = (name) => name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const getId = (value) => (value?._id || value).toString();
const isOwner = (org, userId) => getId(org.owner) === getId(userId);
const getMember = (org, userId) => org.members.find((m) => getId(m.user) === getId(userId));

const hasOrgPermission = (org, userId, permission) => {
  if (isOwner(org, userId)) return true;
  const member = getMember(org, userId);
  if (!member || member.status !== 'accepted') return false;
  return member.permissions.includes(permission);
};

const orgLink = (slug) => `/${slug}`;
const orgMembersLink = (slug) => `/${slug}/organization`;

const safeSendEmail = async (args) => {
  try {
    await sendEmail(args);
  } catch (err) {
    console.error('[email] failed:', args?.subject, err.message);
  }
};

const buildPermissionContext = (org, userId) => {
  const owner = isOwner(org, userId);
  const member = getMember(org, userId);
  const role = owner ? 'owner' : member?.role || null;
  const status = owner ? 'accepted' : member?.status || null;
  const permissions = owner ? DEFAULT_ORG_ROLE_PERMISSIONS.owner : (member?.status === 'accepted' ? member.permissions : []);

  const permissionMap = ORG_PERMISSIONS.reduce((acc, perm) => {
    acc[perm] = owner || permissions.includes(perm);
    return acc;
  }, {});

  return { userId: userId?.toString(), isOwner: owner, role, status, permissions, can: permissionMap };
};

const withPermissionContext = (org, userId) => ({
  ...org.toObject(),
  currentUserPermissions: buildPermissionContext(org, userId),
});

// Every sub-resource route (get/update/members/invite/etc.) is now keyed
// by :slug instead of :id, to match the frontend's organization.service.js.
// This one helper does the lookup so every handler below stays a
// one-liner for it.
const loadOrgBySlug = async (slug, { populate } = {}) => {
  let query = Organization.findOne({ slug, isDeleted: false });
  if (populate) populate.forEach((p) => { query = query.populate(p); });
  return query;
};

const addAcceptedMember = (org, { userId, role, permissions, invitedBy, invitedAt }) => {
  const already = org.members.find((m) => m.user.toString() === userId.toString());
  if (already) {
    already.status = 'accepted';
    already.role = role;
    already.permissions = permissions;
    already.joinedAt = new Date();
    return already;
  }
  org.members.push({
    user: userId,
    role,
    permissions,
    status: 'accepted',
    invitedBy,
    invitedAt: invitedAt || new Date(),
    joinedAt: new Date(),
  });
  return org.members[org.members.length - 1];
};

// ====================== CREATE ORG ======================
export const create = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { name, description } = req.body;
    if (!name || !name.trim()) return res.status(400).json({ success: false, message: 'Organization name is required.' });
    if (name.trim().length < 2 || name.trim().length > 100) {
      return res.status(400).json({ success: false, message: 'Organization name must be 2–100 characters.' });
    }

    let baseSlug = slugify(name);
    if (!baseSlug) return res.status(400).json({ success: false, message: 'Organization name must contain letters or numbers.' });
    let slug = baseSlug;
    let counter = 1;
    while (await Organization.findOne({ slug })) {
      slug = `${baseSlug}-${counter++}`;
    }

    let org;
    await session.withTransaction(async () => {
      const created = await Organization.create(
        [
          {
            name: name.trim(),
            description,
            slug,
            owner: req.user.id,
            members: [
              {
                user: req.user.id,
                role: 'owner',
                permissions: DEFAULT_ORG_ROLE_PERMISSIONS.owner,
                status: 'accepted',
                invitedBy: req.user.id,
                joinedAt: new Date(),
              },
            ],
          },
        ],
        { session },
      );
      org = created[0];

      await User.findByIdAndUpdate(req.user.id, { activeOrganization: org._id }, { session });

      await logOrgActivity(org._id, req.user.id, 'org_created', {
        entity: 'Organization',
        entityId: org._id,
        description: `Organization "${org.name}" created`,
        newValue: { name: org.name, slug: org.slug, role: 'owner', permissions: DEFAULT_ORG_ROLE_PERMISSIONS.owner },
      });
    });

    if (req.user.email) {
      const template = organizationCreatedTemplate({
        organizationName: org.name,
        ownerName: req.user.name || 'there',
        slug: org.slug,
        description: org.description,
        orgUrl: buildAppUrl(orgLink(org.slug)),
      });
      safeSendEmail({ to: req.user.email, ...template });
    }

    return res.status(201).json({ success: true, message: 'Organization created successfully.', data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== LIST MY ORGS ======================
export const list = async (req, res) => {
  try {
    const orgs = await Organization.find({
      isDeleted: false,
      members: { $elemMatch: { user: req.user.id, status: 'accepted' } },
    })
      .populate('owner', 'name email avatar')
      .sort({ createdAt: -1 });

    return res.json({ success: true, data: orgs.map((org) => withPermissionContext(org, req.user.id)) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== GET ONE (by slug) ======================
export const get = async (req, res) => {
  try {
    const { slug } = req.params;

    const org = await loadOrgBySlug(slug, {
      populate: [
        { path: 'owner', select: 'name email avatar' },
        { path: 'members.user', select: 'name email avatar' },
        { path: 'members.invitedBy', select: 'name email' },
      ],
    });

    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'org.view')) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    return res.json({ success: true, data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== UPDATE ORG SETTINGS (by slug) ======================
export const update = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { slug } = req.params;
    const org = await loadOrgBySlug(slug);
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'org.settings.edit')) {
      return res.status(403).json({ success: false, message: 'No permission to update organization settings.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }

    const { name, description, logo, settings } = req.body;
    if (name !== undefined) {
      if (!name.trim() || name.trim().length < 2 || name.trim().length > 100) {
        return res.status(400).json({ success: false, message: 'Organization name must be 2–100 characters.' });
      }
      org.name = name.trim();
      // Name changes intentionally do NOT change the slug — the URL stays
      // stable even if the display name changes later.
    }
    if (description !== undefined) org.description = description;
    if (logo !== undefined) org.logo = logo;
    if (settings) {
      if (settings.defaultDailyCapacity !== undefined && settings.defaultDailyCapacity <= 0) {
        return res.status(400).json({ success: false, message: 'defaultDailyCapacity must be greater than 0.' });
      }
      org.settings = { ...org.settings.toObject(), ...settings };
    }

    await session.withTransaction(async () => {
      await org.save({ session });
      await logOrgActivity(org._id, req.user.id, 'org_updated', {
        entity: 'Organization',
        entityId: org._id,
        description: `Organization "${org.name}" settings updated`,
        newValue: { name: org.name, description: org.description, settings: org.settings },
      });
    });

    await notifyOrgMembers(org, {
      type: 'org_updated',
      title: 'Organization Updated',
      message: `"${org.name}" settings were updated.`,
      link: orgLink(org.slug),
      excludeUserId: req.user.id,
    });

    return res.json({ success: true, message: 'Organization updated.', data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== DELETE ORG (owner only, by slug) ======================
export const remove = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { slug } = req.params;
    const org = await loadOrgBySlug(slug);
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!isOwner(org, req.user.id)) {
      return res.status(403).json({ success: false, message: 'Only the organization owner can delete the organization.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }

    await session.withTransaction(async () => {
      org.isDeleted = true;
      org.deletedAt = new Date();
      await org.save({ session });

      await logOrgActivity(org._id, req.user.id, 'org_deleted', {
        entity: 'Organization',
        entityId: org._id,
        description: `Organization "${org.name}" deleted`,
      });
    });

    await notifyOrgMembers(org, {
      type: 'org_deleted',
      title: 'Organization Deleted',
      message: `"${org.name}" has been deleted.`,
      excludeUserId: req.user.id,
    });

    return res.json({ success: true, message: 'Organization deleted successfully.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== INVITE MEMBER (by slug) ======================
export const inviteMember = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { slug } = req.params;
    const { email, role = 'member', permissions } = req.body;

    if (!email || !email.trim()) return res.status(400).json({ success: false, message: 'Email is required.' });
    const normalizedEmail = email.toLowerCase().trim();
    if (!ASSIGNABLE_ORG_ROLES.includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role.' });
    }

    const org = await loadOrgBySlug(slug);
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'team.invite')) {
      return res.status(403).json({ success: false, message: 'No permission to invite members.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }
    if (role === 'admin' && !isOwner(org, req.user.id)) {
      return res.status(403).json({ success: false, message: 'Only the organization owner can add another admin.' });
    }

    const existingUser = await User.findOne({ email: normalizedEmail });
    if (existingUser && isOwner(org, existingUser._id)) {
      return res.status(400).json({ success: false, message: 'This user already owns the organization.' });
    }
    if (existingUser) {
      const existingMember = getMember(org, existingUser._id);
      if (existingMember?.status === 'accepted') {
        return res.status(400).json({ success: false, message: 'User is already a member.' });
      }
    }

    await expireStaleInvitations({ organization: org._id, email: normalizedEmail });
    const existingInvite = await Invitation.findOne({ organization: org._id, email: normalizedEmail, status: 'pending' });
    if (existingInvite) {
      return res.status(400).json({ success: false, message: 'Invitation already pending for this email.' });
    }

    let grantedPermissions = DEFAULT_ORG_ROLE_PERMISSIONS[role] || [];
    if (permissions?.length) {
      const invalid = permissions.filter((p) => !ORG_PERMISSIONS.includes(p));
      if (invalid.length) return res.status(400).json({ success: false, message: `Invalid permissions: ${invalid.join(', ')}` });
      if (!isOwner(org, req.user.id)) return res.status(403).json({ success: false, message: 'Only the owner can assign custom permissions.' });
      grantedPermissions = permissions;
    }

    const token = Invitation.generateToken();
    const code = await Invitation.generateUniqueCode();
    const expiresAt = new Date(Date.now() + INVITE_EXPIRY_DAYS * 24 * 60 * 60 * 1000);

    let invitation;
    await session.withTransaction(async () => {
      const created = await Invitation.create(
        [{
          organization: org._id,
          email: normalizedEmail,
          user: existingUser?._id || null,
          role,
          permissions: grantedPermissions,
          invitedBy: req.user.id,
          token,
          code,
          status: 'pending',
          expiresAt,
        }],
        { session }
      );
      invitation = created[0];

      await logOrgActivity(org._id, req.user.id, 'org_member_invited', {
        entity: 'Invitation',
        entityId: invitation._id,
        description: `${normalizedEmail} invited as ${role}`,
        newValue: { email: normalizedEmail, role, permissions: grantedPermissions, existingUser: !!existingUser },
      });
    });

    if (existingUser) {
      await sendNotification({
        userId: existingUser._id,
        type: 'org_invitation',
        title: 'Organization Invitation',
        message: `You were invited to join "${org.name}" as ${role}. Code: ${invitation.code}`,
        relatedOrganization: org._id,
        link: `/organizations/invites`,
      });
      const template = organizationInvitationExistingUserTemplate({
        organizationName: org.name,
        inviterName: req.user.name || 'A team member',
        role,
        inviteUrl: buildAppUrl(`/organizations/invites`),
        code: invitation.code,
        rejectUrl: buildAppUrl(`/invitations/reject/${invitation.token}`),
      });
      safeSendEmail({ to: existingUser.email, ...template });
    } else {
      const registerUrl = buildAppUrl(`/register?invite=${invitation.token}`);
      const template = organizationInvitationNewUserTemplate({
        organizationName: org.name,
        inviterName: req.user.name || 'A team member',
        role,
        registerUrl,
        code: invitation.code,
        rejectUrl: buildAppUrl(`/invitations/reject/${invitation.token}`),
      });
      safeSendEmail({ to: normalizedEmail, ...template });
    }

    return res.status(200).json({
      success: true,
      message: existingUser ? 'Invitation sent.' : 'Invitation sent — recipient will be prompted to create an account.',
      data: {
        invitationId: invitation._id,
        email: normalizedEmail,
        role,
        status: invitation.status,
        expiresAt: invitation.expiresAt,
        code: invitation.code,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== RESEND INVITE (still by invitation id) ======================
export const resendInvitation = async (req, res) => {
  try {
    const { id } = req.params;
    const invitation = await Invitation.findById(id);
    if (!invitation) return res.status(404).json({ success: false, message: 'Invitation not found.' });
    if (invitation.status !== 'pending' && invitation.status !== 'expired') {
      return res.status(400).json({ success: false, message: `Cannot resend a ${invitation.status} invitation.` });
    }

    const org = await Organization.findById(invitation.organization);
    if (!org || org.isDeleted) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'team.invite.manage')) {
      return res.status(403).json({ success: false, message: 'No permission to resend invitations.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }

    invitation.status = 'pending';
    invitation.token = Invitation.generateToken();
    invitation.code = await Invitation.generateUniqueCode();
    invitation.expiresAt = new Date(Date.now() + INVITE_EXPIRY_DAYS * 24 * 60 * 60 * 1000);
    invitation.resendCount += 1;
    invitation.lastResentAt = new Date();
    await invitation.save();

    const existingUser = await User.findOne({ email: invitation.email });
    if (existingUser) {
      await sendNotification({
        userId: existingUser._id,
        type: 'org_invitation',
        title: 'Organization Invitation (Reminder)',
        message: `Reminder: you were invited to join "${org.name}" as ${invitation.role}. Code: ${invitation.code}`,
        relatedOrganization: org._id,
        link: `/organizations/invites`,
      });
      const template = organizationInvitationExistingUserTemplate({
        organizationName: org.name,
        inviterName: req.user.name || 'A team member',
        role: invitation.role,
        inviteUrl: buildAppUrl(`/organizations/invites`),
        code: invitation.code,
        rejectUrl: buildAppUrl(`/invitations/reject/${invitation.token}`),
      });
      safeSendEmail({ to: existingUser.email, ...template });
    } else {
      const registerUrl = buildAppUrl(`/register?invite=${invitation.token}`);
      const template = organizationInvitationNewUserTemplate({
        organizationName: org.name,
        inviterName: req.user.name || 'A team member',
        role: invitation.role,
        registerUrl,
        code: invitation.code,
        rejectUrl: buildAppUrl(`/invitations/reject/${invitation.token}`),
      });
      safeSendEmail({ to: invitation.email, ...template });
    }

    return res.json({ success: true, message: 'Invitation resent.', data: { code: invitation.code, expiresAt: invitation.expiresAt } });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== VALIDATE INVITATION CODE (public, by code) ======================
export const validateInvitationCode = async (req, res) => {
  try {
    const { code } = req.params;
    const normalized = code.trim().toUpperCase();
    const invitation = await Invitation.findOne({ code: normalized }).populate('organization', 'name slug description');
    if (!invitation) return res.status(404).json({ success: false, message: 'Invalid invitation code.' });

    if (invitation.status !== 'pending') {
      return res.status(400).json({ success: false, message: `This invitation has already been ${invitation.status}.` });
    }
    if (invitation.isExpired()) {
      invitation.status = 'expired';
      await invitation.save();
      return res.status(400).json({ success: false, message: 'This invitation code has expired.' });
    }

    return res.json({
      success: true,
      data: { email: invitation.email, role: invitation.role, organization: invitation.organization },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== JOIN BY CODE (logged-in existing user) ======================
export const joinByCode = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { code } = req.body;
    if (!code || !code.trim()) return res.status(400).json({ success: false, message: 'Invitation code is required.' });

    const normalized = code.trim().toUpperCase();
    const invitation = await Invitation.findOne({ code: normalized });
    if (!invitation) return res.status(404).json({ success: false, message: 'Invalid invitation code.' });


    if (invitation.email !== req.user.email?.toLowerCase()) {
      return res.status(403).json({ success: false, message: 'Invalid invitation code.' });
    }
    if (invitation.status !== 'pending') {
      return res.status(400).json({ success: false, message: `This invitation has already been ${invitation.status}.` });
    }
    if (invitation.isExpired()) {
      invitation.status = 'expired';
      await invitation.save();
      return res.status(400).json({ success: false, message: 'This invitation code has expired. Ask an admin to resend it.' });
    }

    const org = await Organization.findById(invitation.organization).populate('owner', 'name email');
    if (!org || org.isDeleted) return res.status(404).json({ success: false, message: 'Organization not found.' });

    await session.withTransaction(async () => {
      addAcceptedMember(org, {
        userId: req.user.id,
        role: invitation.role,
        permissions: invitation.permissions,
        invitedBy: invitation.invitedBy,
      });
      await org.save({ session });

      invitation.status = 'accepted';
      invitation.acceptedAt = new Date();
      invitation.user = req.user.id;
      await invitation.save({ session });

      await logOrgActivity(org._id, req.user.id, 'org_member_joined', {
        entity: 'User',
        entityId: req.user.id,
        description: `${req.user.name || req.user.email} joined the organization via invitation code`,
      });
    });

    await sendNotification({
      userId: org.owner,
      type: 'org_invite_accepted',
      title: 'Invitation Response',
      message: `${req.user.name || req.user.email} joined "${org.name}" using an invitation code.`,
      relatedOrganization: org._id,
      link: orgMembersLink(org.slug),
    });

    return res.json({ success: true, message: 'You joined the organization.', data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== VALIDATE INVITATION TOKEN (public) ======================
export const validateInvitationToken = async (req, res) => {
  try {
    const { token } = req.params;
    const invitation = await Invitation.findOne({ token }).populate('organization', 'name slug description');
    if (!invitation) return res.status(404).json({ success: false, message: 'Invitation not found.' });

    if (invitation.status !== 'pending') {
      return res.status(400).json({ success: false, message: `This invitation has already been ${invitation.status}.` });
    }
    if (invitation.isExpired()) {
      invitation.status = 'expired';
      await invitation.save();
      return res.status(400).json({ success: false, message: 'This invitation has expired.' });
    }

    return res.json({
      success: true,
      data: {
        email: invitation.email,
        role: invitation.role,
        organization: invitation.organization,
      },
    });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== LIST ORG'S INVITATIONS (by slug) ======================
export const listOrgInvitations = async (req, res) => {
  try {
    const { slug } = req.params;
    const org = await loadOrgBySlug(slug);
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'team.invite')) {
      return res.status(403).json({ success: false, message: 'No permission to view invitations.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }

    await expireStaleInvitations({ organization: org._id });

    const invitations = await Invitation.find({ organization: org._id })
      .populate('invitedBy', 'name email')
      .populate('user', 'name email')
      .sort({ createdAt: -1 });

    return res.json({ success: true, data: invitations, currentUserPermissions: buildPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== REVOKE INVITATION (still by invitation id) ======================
export const revokeInvitation = async (req, res) => {
  try {
    const { id } = req.params;
    const invitation = await Invitation.findById(id);
    if (!invitation) return res.status(404).json({ success: false, message: 'Invitation not found.' });

    const org = await Organization.findById(invitation.organization);
    if (!org || org.isDeleted) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'team.invite.manage')) {
      return res.status(403).json({ success: false, message: 'No permission to revoke invitations.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }
    if (invitation.status !== 'pending') {
      return res.status(400).json({ success: false, message: `Cannot revoke a ${invitation.status} invitation.` });
    }

    invitation.status = 'revoked';
    await invitation.save();

    await logOrgActivity(org._id, req.user.id, 'org_member_removed', {
      entity: 'Invitation',
      entityId: invitation._id,
      description: `Invitation to ${invitation.email} revoked`,
    });

    return res.json({ success: true, message: 'Invitation revoked.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== ACCEPT INVITATION (still by invitation id) ======================
export const acceptInvitation = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { id } = req.params;
    const invitation = await Invitation.findById(id);
    if (!invitation) return res.status(404).json({ success: false, message: 'Invitation not found.' });

    if (invitation.email !== req.user.email?.toLowerCase()) {
      return res.status(403).json({ success: false, message: 'This invitation was not sent to your account.' });
    }
    if (invitation.status !== 'pending') {
      return res.status(400).json({ success: false, message: `This invitation has already been ${invitation.status}.` });
    }
    if (invitation.isExpired()) {
      invitation.status = 'expired';
      await invitation.save();
      return res.status(400).json({ success: false, message: 'This invitation has expired.' });
    }

    const org = await Organization.findById(invitation.organization).populate('owner', 'name email');
    if (!org || org.isDeleted) return res.status(404).json({ success: false, message: 'Organization not found.' });

    await session.withTransaction(async () => {
      addAcceptedMember(org, {
        userId: req.user.id,
        role: invitation.role,
        permissions: invitation.permissions,
        invitedBy: invitation.invitedBy,
      });
      await org.save({ session });

      invitation.status = 'accepted';
      invitation.acceptedAt = new Date();
      invitation.user = req.user.id;
      await invitation.save({ session });

      await logOrgActivity(org._id, req.user.id, 'org_member_joined', {
        entity: 'User',
        entityId: req.user.id,
        description: `${req.user.name || req.user.email} joined the organization`,
      });
    });

    await sendNotification({
      userId: org.owner,
      type: 'org_invite_accepted',
      title: 'Invitation Response',
      message: `${req.user.name || req.user.email} joined "${org.name}".`,
      relatedOrganization: org._id,
      link: orgMembersLink(org.slug),
    });

    if (req.user.email) {
      const template = invitationAcceptedTemplate({
        organizationName: org.name,
        memberName: req.user.name || 'there',
        role: invitation.role,
        description: org.description,
        orgUrl: buildAppUrl(orgLink(org.slug)),
      });
      safeSendEmail({ to: req.user.email, ...template });
    }

    return res.json({ success: true, message: 'Invitation accepted.', data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== DECLINE INVITATION (still by invitation id) ======================
export const declineInvitation = async (req, res) => {
  try {
    const { id } = req.params;
    const invitation = await Invitation.findById(id);
    if (!invitation) return res.status(404).json({ success: false, message: 'Invitation not found.' });

    if (invitation.email !== req.user.email?.toLowerCase()) {
      return res.status(403).json({ success: false, message: 'This invitation was not sent to your account.' });
    }
    if (invitation.status !== 'pending') {
      return res.status(400).json({ success: false, message: `This invitation has already been ${invitation.status}.` });
    }

    invitation.status = 'declined';
    invitation.declinedAt = new Date();
    invitation.user = req.user.id;
    await invitation.save();

    const org = await Organization.findById(invitation.organization);
    if (org) {
      await logOrgActivity(org._id, req.user.id, 'org_member_declined', {
        entity: 'Invitation',
        entityId: invitation._id,
        description: `${req.user.name || req.user.email} declined to join the organization`,
      });
      await sendNotification({
        userId: org.owner,
        type: 'org_invite_declined',
        title: 'Invitation Response',
        message: `${req.user.name || req.user.email} declined to join "${org.name}".`,
        relatedOrganization: org._id,
        link: orgMembersLink(org.slug),
      });
    }

    return res.json({ success: true, message: 'Invitation declined.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== DECLINE VIA EMAIL LINK (public, no auth) ======================
export const declineInvitationByToken = async (req, res) => {
  try {
    const { token } = req.params;
    const invitation = await Invitation.findOne({ token }).populate('organization', 'name owner slug');
    if (!invitation) return res.status(404).json({ success: false, message: 'Invitation not found.' });

    if (invitation.status !== 'pending') {
      return res.status(400).json({ success: false, message: `This invitation has already been ${invitation.status}.` });
    }

    invitation.status = 'declined';
    invitation.declinedAt = new Date();
    await invitation.save();

    const org = invitation.organization;
    if (org) {
      await logOrgActivity(org._id, invitation.invitedBy, 'org_member_declined', {
        entity: 'Invitation',
        entityId: invitation._id,
        description: `${invitation.email} declined the invitation (via email link)`,
      });
      await sendNotification({
        userId: org.owner,
        type: 'org_invite_declined',
        title: 'Invitation Response',
        message: `${invitation.email} declined to join "${org.name}".`,
        relatedOrganization: org._id,
        link: orgMembersLink(org.slug),
      });
    }

    return res.json({ success: true, message: 'Invitation declined.' });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== RESPOND TO INVITE (legacy member-array path, by slug) ======================
export const respondToInvite = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { slug } = req.params;
    const { action } = req.body;
    if (!['accept', 'decline'].includes(action)) return res.status(400).json({ success: false, message: "Action must be 'accept' or 'decline'." });

    const org = await loadOrgBySlug(slug, { populate: [{ path: 'owner', select: 'name email' }] });
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    const member = getMember(org, req.user.id);
    if (!member || member.status !== 'pending') return res.status(400).json({ success: false, message: 'No pending invitation found.' });

    member.status = action === 'accept' ? 'accepted' : 'declined';
    if (action === 'accept') member.joinedAt = new Date();

    await session.withTransaction(async () => {
      await org.save({ session });
      await logOrgActivity(org._id, req.user.id, action === 'accept' ? 'org_member_joined' : 'org_member_declined', {
        entity: 'User',
        entityId: req.user.id,
        description: `${req.user.name || req.user.email} ${action === 'accept' ? 'joined' : 'declined to join'} the organization`,
      });
    });

    await sendNotification({
      userId: org.owner,
      type: action === 'accept' ? 'org_invite_accepted' : 'org_invite_declined',
      title: 'Invitation Response',
      message: `${req.user.name || req.user.email} ${action === 'accept' ? 'joined' : 'declined to join'} "${org.name}".`,
      relatedOrganization: org._id,
      link: orgMembersLink(org.slug),
    });

    if (action === 'accept' && req.user.email) {
      const template = invitationAcceptedTemplate({
        organizationName: org.name,
        memberName: req.user.name || 'there',
        role: member.role,
        description: org.description,
        orgUrl: buildAppUrl(orgLink(org.slug)),
      });
      safeSendEmail({ to: req.user.email, ...template });
    }

    return res.json({ success: true, message: `Invitation ${action}ed.`, data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== LIST MY PENDING INVITES (legacy member-array path) ======================
export const listMyInvites = async (req, res) => {
  try {
    const { status } = req.query;

    const query = {
      isDeleted: false,
      members: {
        $elemMatch: {
          user: req.user.id,
          ...(status ? { status } : {}),
        },
      },
    };

    const orgs = await Organization.find(query)
      .populate("owner", "name email")
      .select("name slug description owner members.$");

    return res.json({
      success: true,
      data: orgs,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ====================== LIST MEMBERS (by slug) ======================
export const listMembers = async (req, res) => {
  try {
    const org = await loadOrgBySlug(req.params.slug, { populate: [{ path: 'members.user', select: 'name email avatar' }] });
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'org.view')) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const search = (req.query.search || '').trim().toLowerCase();
    let members = org.members;

    if (search) {
      members = members.filter((m) => {
        const name = m.user?.name?.toLowerCase() || '';
        const email = m.user?.email?.toLowerCase() || '';
        return name.includes(search) || email.includes(search);
      });
    }

    const limit = parseInt(req.query.limit, 10);
    if (Number.isFinite(limit) && limit > 0) {
      members = members.slice(0, limit);
    }

    return res.json({ success: true, data: members, currentUserPermissions: buildPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};

// ====================== UPDATE MEMBER ROLE (by slug) ======================
export const updateMemberRole = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { slug, userId } = req.params;
    const { role } = req.body;
    if (!ASSIGNABLE_ORG_ROLES.includes(role)) return res.status(400).json({ success: false, message: 'Invalid role.' });

    const org = await loadOrgBySlug(slug, { populate: [{ path: 'members.user', select: 'name email' }] });
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'team.role.edit')) {
      return res.status(403).json({ success: false, message: 'No permission to change member roles.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }
    if (role === 'admin' && !isOwner(org, req.user.id)) return res.status(403).json({ success: false, message: 'Only the owner can promote a member to admin.' });
    if (isOwner(org, userId)) return res.status(400).json({ success: false, message: "Cannot change the owner's role." });

    const target = getMember(org, userId);
    if (!target) return res.status(404).json({ success: false, message: 'Member not found.' });
    if (target.role === 'owner') return res.status(400).json({ success: false, message: "Cannot change the owner's role." });
    if (target.status !== 'accepted') return res.status(400).json({ success: false, message: 'Member has not accepted the invitation yet.' });
    if (target.role === 'admin' && !isOwner(org, req.user.id)) return res.status(403).json({ success: false, message: "Only the owner can change an admin's role." });

    const previousRole = target.role;
    const previousPermissions = [...target.permissions];
    target.role = role;
    target.permissions = DEFAULT_ORG_ROLE_PERMISSIONS[role] || [];

    await session.withTransaction(async () => {
      await org.save({ session });
      await logOrgActivity(org._id, req.user.id, 'org_member_role_changed', {
        entity: 'User',
        entityId: userId,
        description: `Role changed from "${previousRole}" to "${role}"`,
        previousValue: { role: previousRole, permissions: previousPermissions },
        newValue: { role: target.role, permissions: target.permissions },
      });
    });

    await sendNotification({
      userId,
      type: 'org_role_changed',
      title: 'Your Role Was Updated',
      message: `Your role in "${org.name}" changed from ${previousRole} to ${role}.`,
      relatedOrganization: org._id,
      link: orgLink(org.slug),
    });

    if (target.user?.email) {
      const template = memberRoleChangedTemplate({
        organizationName: org.name,
        memberName: target.user.name || 'there',
        previousRole,
        newRole: role,
        orgUrl: buildAppUrl(orgLink(org.slug)),
      });
      safeSendEmail({ to: target.user.email, ...template });
    }

    return res.json({ success: true, message: 'Member role updated.', data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== UPDATE MEMBER PERMISSIONS (by slug) ======================
export const updateMemberPermissions = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { slug, userId } = req.params;
    const { permissions } = req.body;
    if (!Array.isArray(permissions)) return res.status(400).json({ success: false, message: 'permissions must be an array.' });

    const invalid = permissions.filter((p) => !ORG_PERMISSIONS.includes(p));
    if (invalid.length) return res.status(400).json({ success: false, message: `Invalid permissions: ${invalid.join(', ')}` });

    const org = await loadOrgBySlug(slug);
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'team.permissions.edit')) {
      return res.status(403).json({ success: false, message: 'No permission to edit member permissions.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }
    if (isOwner(org, userId)) return res.status(400).json({ success: false, message: "Cannot change the owner's permissions." });

    const target = getMember(org, userId);
    if (!target) return res.status(404).json({ success: false, message: 'Member not found.' });
    if (target.role === 'owner') return res.status(400).json({ success: false, message: "Cannot change the owner's permissions." });
    if (target.status !== 'accepted') return res.status(400).json({ success: false, message: 'Member has not accepted the invitation yet.' });
    if (target.role === 'admin' && !isOwner(org, req.user.id)) {
      return res.status(403).json({ success: false, message: "Only the owner can edit an admin's permissions." });
    }

    const previousPermissions = [...target.permissions];
    target.permissions = permissions;

    await session.withTransaction(async () => {
      await org.save({ session });
      await logOrgActivity(org._id, req.user.id, 'org_member_permissions_changed', {
        entity: 'User',
        entityId: userId,
        description: `Permissions updated for ${target.role} member`,
        previousValue: { permissions: previousPermissions },
        newValue: { permissions: target.permissions },
      });
    });

    await sendNotification({
      userId,
      type: 'org_permissions_changed',
      title: 'Your Permissions Were Updated',
      message: `Your permissions in "${org.name}" were updated.`,
      relatedOrganization: org._id,
      link: orgLink(org.slug),
    });

    return res.json({ success: true, message: 'Member permissions updated.', data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== REMOVE MEMBER (by slug) ======================
export const removeMember = async (req, res) => {
  const session = await mongoose.startSession();
  try {
    const { slug, userId } = req.params;
    const org = await loadOrgBySlug(slug, { populate: [{ path: 'members.user', select: 'name email' }] });
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (isOwner(org, userId)) return res.status(400).json({ success: false, message: 'Cannot remove the organization owner.' });

    const isSelf = req.user.id === userId;
    const canRemove = isSelf || hasOrgPermission(org, req.user.id, 'team.remove');
    if (!canRemove) {
      return res.status(403).json({ success: false, message: 'No permission to remove this member.', currentUserPermissions: buildPermissionContext(org, req.user.id) });
    }

    const target = getMember(org, userId);
    if (!target) return res.status(404).json({ success: false, message: 'Member not found.' });
    if (target.role === 'owner') return res.status(400).json({ success: false, message: 'Cannot remove the organization owner.' });
    if (target.role === 'admin' && !isSelf && !isOwner(org, req.user.id)) {
      return res.status(403).json({ success: false, message: 'Only the owner can remove an admin.' });
    }

    const targetUser = target.user;

    await session.withTransaction(async () => {
      org.members = org.members.filter((m) => m.user._id.toString() !== userId);
      await org.save({ session });
      await logOrgActivity(org._id, req.user.id, isSelf ? 'org_member_left' : 'org_member_removed', {
        entity: 'User',
        entityId: userId,
        description: isSelf ? 'Member left the organization' : 'Member removed from the organization',
      });
    });

    if (!isSelf) {
      await sendNotification({
        userId,
        type: 'org_member_removed',
        title: 'Removed from Organization',
        message: `You were removed from "${org.name}".`,
        relatedOrganization: org._id,
      });

      if (targetUser?.email) {
        const template = memberRemovedTemplate({
          organizationName: org.name,
          memberName: targetUser.name || 'there',
          removedByName: req.user.name,
        });
        safeSendEmail({ to: targetUser.email, ...template });
      }
    } else {
      await sendNotification({
        userId: org.owner,
        type: 'org_member_left',
        title: 'Member Left',
        message: `${req.user.name || req.user.email} left "${org.name}".`,
        relatedOrganization: org._id,
        link: orgMembersLink(org.slug),
      });
    }

    return res.json({ success: true, message: 'Member removed.', data: withPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  } finally {
    session.endSession();
  }
};

// ====================== ORG WORKLOAD OVERVIEW (by slug) ======================
export const getOrgWorkload = async (req, res) => {
  try {
    const org = await loadOrgBySlug(req.params.slug, { populate: [{ path: 'members.user', select: 'name email dailyCapacity' }] });
    if (!org) return res.status(404).json({ success: false, message: 'Organization not found.' });

    if (!hasOrgPermission(org, req.user.id, 'org.view')) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const acceptedMembers = org.members.filter((m) => m.status === 'accepted');
    const memberIds = acceptedMembers.map((m) => m.user._id);

    const projects = await Project.find({ organization: org._id, isDeleted: false }).select('_id');
    const projectIds = projects.map((p) => p._id);

    const Task = mongoose.model('Task');
    const workload = await Task.aggregate([
      { $match: { project: { $in: projectIds }, isDeleted: { $ne: true }, status: { $ne: 'completed' } } },
      { $unwind: '$assignees' },
      { $match: { assignees: { $in: memberIds } } },
      { $group: { _id: '$assignees', activeTasks: { $sum: 1 }, estimatedHours: { $sum: { $ifNull: ['$estimatedHours', 0] } } } },
    ]);

    const workloadMap = new Map(workload.map((w) => [w._id.toString(), w]));

    const data = acceptedMembers.map((m) => {
      const w = workloadMap.get(m.user._id.toString());
      const capacity = m.user.dailyCapacity || org.settings.defaultDailyCapacity;
      const estimatedHours = w?.estimatedHours || 0;
      return {
        user: m.user,
        role: m.role,
        activeTasks: w?.activeTasks || 0,
        estimatedHours,
        dailyCapacity: capacity,
        overloaded: estimatedHours > capacity * org.settings.workingDaysPerWeek,
      };
    });

    return res.json({ success: true, data, currentUserPermissions: buildPermissionContext(org, req.user.id) });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
};