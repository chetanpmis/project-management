import Project from "../models/Project.js";
import Task from "../models/Task.js";
import * as reportService from "../services/reportService.js";
import { computeTaskProgress, isTaskOverdue } from "../utils/progressEngine.js";

/**
 * Aggregates already-computed task progress (via computeTaskProgress) into
 * a milestone-level progress/status pair for the Gantt view. Kept local
 * (rather than reusing progressEngine.computeMilestoneStats) because the
 * Gantt tasks are already reshaped with `.progress` attached — no need to
 * recompute checklist math twice.
 */
const aggregateGanttMilestone = (mTasks) => {
  if (!mTasks.length) {
    return { progress: 0, status: "pending" };
  }
  const progress = Math.round(mTasks.reduce((sum, t) => sum + t.progress, 0) / mTasks.length);
  let status;
  if (progress === 100) status = "completed";
  else if (progress > 0 || mTasks.some((t) => t.status !== "todo")) status = "in-progress";
  else status = "pending";
  return { progress, status };
};

// NOTE: route/export name kept exactly as-is. Only the query (soft-delete
// exclusion) and the progress math (dynamic, checklist-aware) were fixed —
// the old version selected a `progress` field that Task doesn't even define,
// so every task silently reported 0% before this fix.
export const getProjectGantt = async (req, res) => {
  try {
    const { projectId } = req.params;
    const userId = req.user.id;

    const project = await Project.findOne({
      _id: projectId,
      isDeleted: false,
    }).lean();

    if (!project) {
      return res.status(404).json({ success: false, message: "Project not found" });
    }

    const tasks = await Task.find({ project: projectId, isDeleted: { $ne: true } })
      .select(
        "_id title status priority checklist startDate dueDate assignees watchers milestone dependencies"
      )
      .populate("assignees", "name avatar")
      .populate("watchers", "name avatar")
      .lean();

    const taskMap = new Map(tasks.map((t) => [t._id.toString(), t]));

    const ganttTasks = tasks.map((task) => {
      const assignees = task.assignees || [];
      const watchers = task.watchers || [];
      const isAssignedToMe = assignees.some((u) => u?._id?.toString() === userId.toString());
      const isWatcher = watchers.some((u) => u?._id?.toString() === userId.toString());
      const overdue = isTaskOverdue(task);

      return {
        _id: task._id.toString(),
        title: task.title,
        startDate: task.startDate,
        dueDate: task.dueDate,
        status: overdue ? "overdue" : task.status, // computed, not stored
        priority: task.priority,
        progress: computeTaskProgress(task), // dynamic: checklist-aware, falls back to status
        milestone: task.milestone ? task.milestone.toString() : null,
        assignees,
        watchers,
        isAssignedToMe,
        isWatcher,
        // gantt-task-react draws dependency arrows natively from this list
        dependencies: (task.dependencies || [])
          .map((d) => d.toString())
          .filter((id) => taskMap.has(id)), // drop refs to deleted tasks
      };
    });

    // group tasks by milestone id (task.milestone is the source of truth)
    const tasksByMilestone = new Map();
    const unassignedTasks = [];
    ganttTasks.forEach((t) => {
      if (!t.milestone) {
        unassignedTasks.push(t);
        return;
      }
      if (!tasksByMilestone.has(t.milestone)) tasksByMilestone.set(t.milestone, []);
      tasksByMilestone.get(t.milestone).push(t);
    });

    const milestones = (project.milestones || []).map((m) => {
      const mTasks = (tasksByMilestone.get(m._id.toString()) || []).sort(
        (a, b) => new Date(a.startDate || 0) - new Date(b.startDate || 0)
      );

      const derivedStart =
        m.startDate ||
        mTasks.reduce(
          (min, t) =>
            t.startDate && (!min || new Date(t.startDate) < min) ? new Date(t.startDate) : min,
          null
        );

      const { progress, status } = aggregateGanttMilestone(mTasks);

      return {
        _id: m._id,
        name: m.name,
        description: m.description,
        startDate: derivedStart,
        dueDate: m.dueDate,
        priority: m.priority,
        status, // computed
        progress, // computed — never m.progress
        taskCount: mTasks.length,
        tasks: mTasks,
      };
    });

    const dependencies = [];
    ganttTasks.forEach((t) => {
      t.dependencies.forEach((depId) => {
        const dep = taskMap.get(depId);
        dependencies.push({
          from: depId,
          to: t._id,
          crossMilestone: !!(
            (dep?.milestone?.toString() || null) !== t.milestone &&
            (dep?.milestone || t.milestone)
          ),
        });
      });
    });

    return res.json({
      success: true,
      data: {
        project: {
          _id: project._id,
          name: project.name,
          startDate: project.startDate,
          endDate: project.endDate,
        },
        milestones,
        unassignedTasks,
        dependencies,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: "Failed to load gantt data" });
  }
};

export const getProjectReportsDashboard = async (req, res) => {
  try {
    const { projectId } = req.params;

    const [
      overview,
      taskStatus,
      milestones,
      teamPerformance,
      estimatedVsActual,
      overdue,
      completionTrend,
    ] = await Promise.all([
      reportService.getProjectOverview(projectId),
      reportService.getProjectTaskStatus(projectId),
      reportService.getProjectMilestones(projectId),
      reportService.getProjectTeamPerformance(projectId),
      reportService.getProjectEstimatedVsActual(projectId),
      reportService.getProjectOverdueTasks(projectId),
      reportService.getProjectCompletionTrend(projectId),
    ]);

    return res.json({
      success: true,
      data: { overview, taskStatus, milestones, teamPerformance, estimatedVsActual, overdue, completionTrend },
    });
  } catch (error) {
    console.error("Dashboard Report Error:", error);
    return res.status(error.status || 500).json({
      success: false,
      message: error.status === 404 ? error.message : "Failed to generate dashboard report.",
    });
  }
};

export const getProjectOverview = async (req, res) => {
  try {
    const report = await reportService.getProjectOverview(req.params.projectId);
    return res.status(200).json({ success: true, data: report });
  } catch (error) {
    console.error("Project Overview Report Error:", error);
    return res
      .status(error.status || 500)
      .json({ success: false, message: error.status === 404 ? error.message : "Failed to generate project overview report." });
  }
};

export const getProjectTaskStatus = async (req, res) => {
  try {
    const report = await reportService.getProjectTaskStatus(req.params.projectId);
    return res.status(200).json({ success: true, data: report });
  } catch (error) {
    console.error("Task Status Report Error:", error);
    return res
      .status(error.status || 500)
      .json({ success: false, message: error.status === 404 ? error.message : "Failed to generate task status report." });
  }
};

export const getProjectMilestones = async (req, res) => {
  try {
    const report = await reportService.getProjectMilestones(req.params.projectId);
    return res.status(200).json({ success: true, data: report });
  } catch (error) {
    console.error("Milestone Report Error:", error);
    return res
      .status(error.status || 500)
      .json({ success: false, message: error.status === 404 ? error.message : "Failed to generate milestone report." });
  }
};

export const getProjectTeamPerformance = async (req, res) => {
  try {
    const report = await reportService.getProjectTeamPerformance(req.params.projectId);
    return res.json({ success: true, data: report });
  } catch (error) {
    console.error(error);
    return res
      .status(error.status || 500)
      .json({ success: false, message: error.status === 404 ? error.message : "Failed to generate team performance report." });
  }
};

export const getProjectEstimatedVsActual = async (req, res) => {
  try {
    const report = await reportService.getProjectEstimatedVsActual(req.params.projectId);
    return res.json({ success: true, data: report });
  } catch (error) {
    console.error(error);
    return res
      .status(error.status || 500)
      .json({ success: false, message: error.status === 404 ? error.message : "Failed to generate estimated vs actual report." });
  }
};

export const getProjectOverdueTasks = async (req, res) => {
  try {
    const report = await reportService.getProjectOverdueTasks(req.params.projectId);
    return res.json({ success: true, data: report });
  } catch (error) {
    console.error("Overdue Report Error:", error);
    return res
      .status(error.status || 500)
      .json({ success: false, message: error.status === 404 ? error.message : "Failed to generate overdue tasks report." });
  }
};

export const getProjectCompletionTrend = async (req, res) => {
  try {
    const report = await reportService.getProjectCompletionTrend(req.params.projectId, req.query.period);
    return res.json({ success: true, data: report });
  } catch (error) {
    console.error(error);
    return res
      .status(error.status || 500)
      .json({ success: false, message: error.status === 404 ? error.message : "Failed to generate completion trend report." });
  }
};