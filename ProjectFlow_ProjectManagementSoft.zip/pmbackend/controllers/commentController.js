import Comment from '../models/Comment.js';
import Task from '../models/Task.js';
import Activity from '../models/Activity.js';
import Project from '../models/Project.js';
import Organization from '../models/Organization.js';
import { PROJECT_PERMISSIONS } from '../constants/projectPermissions.js';
import { notifyTaskParticipants, sendNotification } from '../utils/sendNotification.js';
import { taskLink } from '../utils/routeLinks.js';
import { checkProjectPermission } from '../utils/permissions.js';

const getOrgSlug = async (organizationId) => {
  const org = await Organization.findById(organizationId).select('slug');
  return org?.slug || '';
};

export const listByTask = async (req, res) => {
  try {
    const { taskId } = req.params;
    const task = await Task.findById(taskId);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.COMMENT_VIEW);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to view comments on this task.' });

    const comments = await Comment.find({ task: taskId })
      .populate('author', 'name email avatar')
      .populate('mentions', 'name email')
      .populate('replies.author', 'name email avatar')
      .sort({ createdAt: 1 });

    res.json({ success: true, data: comments });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const create = async (req, res) => {
  try {
    const { taskId } = req.params;
    const { content, mentions = [], attachments = [] } = req.body;

    if (!content || !content.trim()) return res.status(400).json({ success: false, message: 'Comment content is required.' });

    const task = await Task.findById(taskId).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.COMMENT_CREATE);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to comment on this task.' });

    const comment = await Comment.create({ task: taskId, author: req.user.id, content: content.trim(), mentions, attachments });

    task.comments.push(comment._id);
    await task.save();

    await Activity.create({
      organization: project.organization,
      project: task.project,
      level: 'task',
      task: task._id,
      user: req.user.id,
      type: 'comment_added',
      entity: 'Task',
      entityId: task._id,
      description: `Comment added on task "${task.title}"`,
    });

    const orgSlug = await getOrgSlug(project.organization);
    const link = taskLink(orgSlug, project._id, task._id);

    await notifyTaskParticipants(task, project, {
      type: 'task_commented',
      title: 'New Comment',
      message: `New comment on task "${task.title}".`,
      excludeUserId: req.user.id,
      link,
    });

    if (mentions.length) {
      await Promise.all(mentions.map((userId) => sendNotification({
        userId,
        type: 'task_mentioned',
        title: 'You Were Mentioned',
        message: `You were mentioned in a comment on task "${task.title}".`,
        relatedTask: task._id,
        relatedProject: project._id,
        link,
      })));
    }

    const populated = await Comment.findById(comment._id).populate('author', 'name email avatar').populate('mentions', 'name email');

    res.status(201).json({ success: true, message: 'Comment added successfully.', data: populated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const update = async (req, res) => {
  try {
    const { commentId } = req.params;
    const { content } = req.body;

    const comment = await Comment.findById(commentId);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });

    const task = await Task.findById(comment.task);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const isAuthor = comment.author.toString() === req.user.id;
    const { allowed: canEditAny } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.COMMENT_EDIT);

    if (!isAuthor && !canEditAny) return res.status(403).json({ success: false, message: 'You do not have permission to edit this comment.' });

    comment.content = content;
    comment.edited = true;
    comment.editedAt = new Date();
    comment.updatedAt = new Date();
    await comment.save();

    const populated = await Comment.findById(comment._id).populate('author', 'name email avatar').populate('mentions', 'name email');

    res.json({ success: true, message: 'Comment updated successfully.', data: populated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const remove = async (req, res) => {
  try {
    const { commentId } = req.params;
    const comment = await Comment.findById(commentId);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });

    const task = await Task.findById(comment.task);
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const isAuthor = comment.author.toString() === req.user.id;
    const { allowed: canDeleteAny, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.COMMENT_DELETE);

    if (!isAuthor && !canDeleteAny) return res.status(403).json({ success: false, message: 'You do not have permission to delete this comment.' });

    await Task.findByIdAndUpdate(comment.task, { $pull: { comments: comment._id } });
    await Comment.findByIdAndDelete(commentId);

    if (project) {
      await Activity.create({
        organization: project.organization,
        project: task.project,
        level: 'task',
        task: task._id,
        user: req.user.id,
        type: 'comment_deleted',
        entity: 'Task',
        entityId: task._id,
        description: `Comment deleted on task "${task.title}"`,
      });
    }

    res.json({ success: true, message: 'Comment deleted successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};

export const addReply = async (req, res) => {
  try {
    const { commentId } = req.params;
    const { content, mentions = [] } = req.body;

    if (!content || !content.trim()) return res.status(400).json({ success: false, message: 'Reply content is required.' });

    const comment = await Comment.findById(commentId);
    if (!comment) return res.status(404).json({ success: false, message: 'Comment not found.' });

    const task = await Task.findById(comment.task).populate('assignees', 'name email avatar').populate('watchers', 'name email avatar');
    if (!task) return res.status(404).json({ success: false, message: 'Task not found.' });

    const { allowed, project } = await checkProjectPermission(req.user.id, task.project, PROJECT_PERMISSIONS.COMMENT_CREATE);
    if (!allowed) return res.status(403).json({ success: false, message: 'You do not have permission to reply on this task.' });

    comment.replies.push({ author: req.user.id, content: content.trim(), mentions });
    comment.updatedAt = new Date();
    await comment.save();

    const orgSlug = await getOrgSlug(project.organization);
    const link = taskLink(orgSlug, project._id, task._id);

    await notifyTaskParticipants(task, project, {
      type: 'task_commented',
      title: 'New Reply',
      message: `New reply on task "${task.title}".`,
      excludeUserId: req.user.id,
      link,
    });

    if (mentions.length) {
      await Promise.all(mentions.map((userId) => sendNotification({
        userId,
        type: 'task_mentioned',
        title: 'You Were Mentioned',
        message: `You were mentioned in a reply on task "${task.title}".`,
        relatedTask: task._id,
        relatedProject: project._id,
        link,
      })));
    }

    const populated = await Comment.findById(comment._id).populate('author', 'name email avatar').populate('replies.author', 'name email avatar');

    res.status(201).json({ success: true, message: 'Reply added successfully.', data: populated });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};