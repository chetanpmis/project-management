'use client';

import { useMemo, useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Loader2,
  CalendarClock,
  Check,
  X,
  ChevronDown,
  Users,
  Eye,
  Link2,
  ListChecks,
  Tag as TagIcon,
  Pencil,
  AlertTriangle,
  Info,
} from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import taskService from '@/services/task.service';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { CardListSkeleton } from '@/components/common/Skeletons';
import { PriorityBadge, PriorityDot } from '@/components/common/StatusBadges';
import { PRIORITY_CONFIG } from '@/lib/statusConfig';
import { cn } from '@/lib/utils';

const MIN_LEAD_MINUTES = 15;
const priorityOptions = Object.keys(PRIORITY_CONFIG);

// ---------- helpers ----------
const toDatetimeLocal = (value) => {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

const addMinutes = (date, minutes) => new Date(date.getTime() + minutes * 60000);

const formatDisplayDate = (value) => {
  if (!value) return 'Not set';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return 'Not set';
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
};

const initials = (name = '') => name.slice(0, 2).toUpperCase();

const schema = z
  .object({
    title: z.string().min(1, 'Title is required').min(3, 'At least 3 characters'),
    description: z.string().optional(),
    priority: z.enum(priorityOptions),
    startDate: z.string().optional(),
    dueDate: z.string().optional(),
    milestone: z.string().min(1, 'Milestone is required'),
  })
  .refine((data) => !(data.startDate && data.dueDate && new Date(data.startDate) > new Date(data.dueDate)), {
    message: 'Due date must be after start date',
    path: ['dueDate'],
  });

const findCycle = (taskId, candidateId, projectTasks) => {
  if (!taskId) return false;
  const graph = new Map(projectTasks.map((t) => [t._id, (t.dependencies || []).map((d) => d._id || d)]));
  const visited = new Set();
  const dfs = (currentId) => {
    if (currentId === taskId) return true;
    if (visited.has(currentId)) return false;
    visited.add(currentId);
    return (graph.get(currentId) || []).some(dfs);
  };
  return dfs(candidateId);
};

function SectionLabel({ icon: Icon, children, hint }) {
  return (
    <Label className="flex items-center gap-2 text-base font-medium">
      <Icon className="h-4 w-4 text-muted-foreground" />
      {children}
      {hint && <span className="text-sm font-normal text-muted-foreground">{hint}</span>}
    </Label>
  );
}

function PickerTrigger({ placeholder, preview, disabled }) {
  return (
    <button
      type="button"
      disabled={disabled}
      className="w-full flex items-center justify-between gap-3 rounded-lg border border-input bg-background px-4 py-2.5 text-base text-left hover:bg-accent/40 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
    >
      <span className="flex-1 min-w-0">{preview || <span className="text-muted-foreground">{placeholder}</span>}</span>
      <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0" />
    </button>
  );
}

function PeopleMultiSelect({ label, icon: Icon, people, selectedIds, onToggle, placeholder }) {
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return people;
    return people.filter((p) => p.name?.toLowerCase().includes(q) || p.email?.toLowerCase().includes(q));
  }, [people, query]);

  const selected = people.filter((p) => selectedIds.includes(p.id));

  const preview = selected.length > 0 ? (
    <span className="flex items-center gap-2">
      <span className="flex -space-x-2">
        {selected.slice(0, 4).map((p) => (
          <Avatar key={p.id} className="h-6 w-6 border-2 border-background">
            <AvatarFallback className="text-[10px]">{initials(p.name)}</AvatarFallback>
          </Avatar>
        ))}
      </span>
      <span className="truncate">
        {selected.length <= 2 ? selected.map((p) => p.name).join(', ') : `${selected.length} selected`}
      </span>
    </span>
  ) : null;

  return (
    <div className="space-y-2.5">
      <SectionLabel icon={Icon}>{label}</SectionLabel>
      <Popover>
        <PopoverTrigger asChild>
          <div><PickerTrigger placeholder={placeholder} preview={preview} /></div>
        </PopoverTrigger>
        <PopoverContent className="w-96 p-0" align="start">
          <div className="p-2.5 border-b">
            <Input autoFocus placeholder="Search by name or email..." value={query} onChange={(e) => setQuery(e.target.value)} className="h-9 text-base" />
          </div>
          <div className="max-h-72 overflow-y-auto p-1">
            {filtered.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No matches</p>}
            {filtered.map((person) => {
              const isSelected = selectedIds.includes(person.id);
              return (
                <button
                  type="button"
                  key={person.id}
                  onClick={() => onToggle(person.id)}
                  className={cn('w-full flex items-center gap-3 rounded-md px-2.5 py-2.5 text-sm hover:bg-accent transition-colors', isSelected && 'bg-accent')}
                >
                  <Avatar className="h-7 w-7 shrink-0">
                    <AvatarFallback className="text-xs">{initials(person.name)}</AvatarFallback>
                  </Avatar>
                  <span className="flex-1 text-left truncate">
                    <span className="font-medium">{person.name}</span>
                    <span className="block text-xs text-muted-foreground truncate">{person.email}</span>
                  </span>
                  {isSelected && <Check className="h-4 w-4 text-primary shrink-0" />}
                </button>
              );
            })}
          </div>
        </PopoverContent>
      </Popover>

      {selected.length > 0 && (
        <div className="flex flex-wrap gap-2 pt-0.5">
          {selected.map((p) => (
            <span key={p.id} className="inline-flex items-center gap-2 rounded-full bg-secondary pl-1.5 pr-3 py-1 text-sm">
              <Avatar className="h-5 w-5">
                <AvatarFallback className="text-[9px]">{initials(p.name)}</AvatarFallback>
              </Avatar>
              {p.name}
              <button type="button" onClick={() => onToggle(p.id)} className="text-muted-foreground hover:text-foreground">
                <X className="h-3.5 w-3.5" />
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

export default function TaskFormDialog({
  open,
  onOpenChange,
  projectId,
  onCreated,
  initialData = null,
  isEditing = false,
}) {
  const [assigneeIds, setAssigneeIds] = useState([]);
  const [watcherIds, setWatcherIds] = useState([]);
  const [dependencyIds, setDependencyIds] = useState([]);
  const [tags, setTags] = useState([]);
  const [checklist, setChecklist] = useState([]);
  const [newTag, setNewTag] = useState('');
  const [newChecklistItem, setNewChecklistItem] = useState('');
  const [dateError, setDateError] = useState('');
  const [depError, setDepError] = useState('');
  const [serverError, setServerError] = useState('');

  const { data: creationData, isLoading: isLoadingCreationData } = useQuery({
    queryKey: ['taskCreationData', projectId],
    queryFn: () => taskService.getTaskCreationData(projectId),
    enabled: open && !!projectId,
  });

  const milestones = creationData?.data?.milestones || [];
  console.log("Milestone Data : ",milestones)
  const teamMembers = creationData?.data?.teamMembers || [];
  const projectTasks = creationData?.data?.projectTasks || [];
  const project = creationData?.data?.project || {};

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      title: initialData?.title || '',
      description: initialData?.description || '',
      priority: initialData?.priority || 'medium',
      startDate: toDatetimeLocal(initialData?.startDate),
      dueDate: toDatetimeLocal(initialData?.dueDate),
      milestone: initialData?.milestone?._id || initialData?.milestone || '',
    },
  });

  const startDate = watch('startDate');
  const dueDate = watch('dueDate');
  const priority = watch('priority');
  const selectedMilestoneId = watch('milestone');

  const selectedMilestone = milestones.find((m) => m._id === selectedMilestoneId);

  useEffect(() => {
    if (!isEditing && !getValues('milestone') && milestones.length > 0) {
      setValue('milestone', milestones[0]._id);
    }
  }, [milestones, isEditing]);

  const minStart = toDatetimeLocal(addMinutes(new Date(), MIN_LEAD_MINUTES));
  const minDue = startDate ? toDatetimeLocal(addMinutes(new Date(startDate), MIN_LEAD_MINUTES)) : minStart;

  const people = useMemo(() =>
    teamMembers.map((m) => ({ id: m.user?._id, name: m.user?.name, email: m.user?.email })).filter((p) => p.id),
  [teamMembers]);

  const toggleAssignee = (userId) => setAssigneeIds(prev => prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]);
  const toggleWatcher = (userId) => setWatcherIds(prev => prev.includes(userId) ? prev.filter(id => id !== userId) : [...prev, userId]);

  const toggleDependency = (taskId) => {
    setDepError('');
    if (dependencyIds.includes(taskId)) {
      setDependencyIds((prev) => prev.filter((id) => id !== taskId));
      return;
    }
    if (initialData?._id && taskId === initialData._id) {
      setDepError("A task can't depend on itself.");
      return;
    }
    if (findCycle(initialData?._id, taskId, projectTasks)) {
      const depTitle = projectTasks.find((t) => t._id === taskId)?.title || 'That task';
      setDepError(`${depTitle} already depends on this task (directly or indirectly)`);
      return;
    }
    setDependencyIds((prev) => [...prev, taskId]);
  };

  const addTag = () => {
    const trimmed = newTag.trim();
    if (trimmed && !tags.includes(trimmed) && tags.length < 5) {
      setTags([...tags, trimmed]);
      setNewTag('');
    }
  };
  const removeTag = (tag) => setTags(tags.filter((t) => t !== tag));

  const addChecklist = () => {
    const trimmed = newChecklistItem.trim();
    if (trimmed) setChecklist([...checklist, { item: trimmed, completed: false }]);
    setNewChecklistItem('');
  };
  const toggleChecklist = (index) => {
    const updated = [...checklist];
    updated[index].completed = !updated[index].completed;
    setChecklist(updated);
  };
  const removeChecklist = (index) => setChecklist(checklist.filter((_, i) => i !== index));

  const createTaskMutation = useMutation({
    mutationFn: (data) => {
      console.log('🚀 Creating task with payload:', data);
      return taskService.createTask(projectId, data);
    },
    onSuccess: (response) => {
      console.log('✅ Task created successfully:', response);
      handleClose();
      onCreated?.();
    },
    onError: (error) => {
      console.error('❌ Create task failed:', error.response?.data || error);
      let message = 'Failed to create task. Please try again.';
      if (error?.response?.data?.message) message = error.response.data.message;
      else if (error?.response?.data?.error) message = error.response.data.error;
      setServerError(message);
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: (data) => taskService.updateTask(initialData?._id, data),
    onSuccess: () => { handleClose(); onCreated?.(); },
    onError: (error) => {
      console.error('❌ Update failed:', error);
      setServerError('Failed to update task. Please try again.');
    },
  });

  const mutation = isEditing ? updateTaskMutation : createTaskMutation;

  const validateDates = (data) => {
    const start = data.startDate ? new Date(data.startDate) : null;
    const due = data.dueDate ? new Date(data.dueDate) : null;
    const now = new Date();

    if (start && start < addMinutes(now, MIN_LEAD_MINUTES)) return `Start time must be at least ${MIN_LEAD_MINUTES} minutes from now.`;
    if (start && due && due < addMinutes(start, MIN_LEAD_MINUTES)) return `Due time must be at least ${MIN_LEAD_MINUTES} minutes after start.`;
    if (!start && due && due < addMinutes(now, MIN_LEAD_MINUTES)) return `Due time must be at least ${MIN_LEAD_MINUTES} minutes from now.`;
    if (project?.startDate && start && start < new Date(project.startDate)) return `Task start cannot be before project start.`;
    if (project?.endDate && due && due > new Date(project.endDate)) return `Task due date cannot be after project end.`;
    return '';
  };

  const onSubmit = (data) => {
    console.log('📤 Submit triggered');
    setServerError('');

    if (assigneeIds.length === 0) {
      setServerError('At least one assignee is required.');
      return;
    }

    const err = validateDates(data);
    if (err) {
      setDateError(err);
      return;
    }

    const payload = {
      ...data,
      assignees: assigneeIds,
      watchers: watcherIds,
      tags,
      checklist,
      dependencies: dependencyIds,
    };

    mutation.mutate(payload);
  };

  const handleClose = () => {
    reset();
    setAssigneeIds([]);
    setWatcherIds([]);
    setDependencyIds([]);
    setTags([]);
    setChecklist([]);
    setNewTag('');
    setNewChecklistItem('');
    setDateError('');
    setDepError('');
    setServerError('');
    onOpenChange(false);
  };

  useEffect(() => {
    if (open && initialData) {
      setAssigneeIds(initialData.assignees?.map(a => a._id || a) || []);
      setWatcherIds(initialData.watchers?.map(w => w._id || w) || []);
      setDependencyIds(initialData.dependencies?.map(d => d._id || d) || []);
      setTags(initialData.tags || []);
      setChecklist(initialData.checklist || []);
    }
  }, [open, initialData]);

  const selectedDependencies = projectTasks.filter((t) => dependencyIds.includes(t._id));
  const dependencyOptions = projectTasks.filter((t) => t._id !== initialData?._id);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-3xl lg:max-w-4xl max-h-[92vh] overflow-y-auto p-8">
        <DialogHeader className="flex flex-row items-center justify-between">
          <div>
            <DialogTitle className="text-2xl">
              {isEditing ? 'Edit task' : 'New task'}
            </DialogTitle>
            {project?.name && <p className="text-sm text-muted-foreground mt-1">{project.name}</p>}
          </div>
          <Button type="button" variant="ghost" size="icon" onClick={handleClose} className="h-8 w-8">
            <X className="h-5 w-5" />
          </Button>
        </DialogHeader>

        {isLoadingCreationData ? (
          <CardListSkeleton count={3} height="h-14" />
        ) : (
          <>
            {serverError && (
              <div className="rounded-lg bg-red-50 border border-red-200 p-4 text-red-700 flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium">Error</p>
                  <p className="text-sm">{serverError}</p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-7 text-base">
              <div className="space-y-7">
                {/* Basic Info */}
                <div className="space-y-5">
                  <div className="space-y-2">
                    <Label className="text-base font-medium">Title <span className="text-red-500">*</span></Label>
                    <Input placeholder="Task title..." className="h-11 text-base" {...register('title')} />
                    {errors.title && <p className="text-red-500 text-sm">{errors.title.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-medium">Description</Label>
                    <Textarea placeholder="What's this task about?" rows={3} className="text-base" {...register('description')} />
                  </div>

                  <div className="space-y-2.5">
                    <Label className="text-base font-medium">Priority</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {priorityOptions.map((p) => {
                        const entry = PRIORITY_CONFIG[p];
                        const isSelected = priority === p;
                        return (
                          <button
                            key={p}
                            type="button"
                            onClick={() => setValue('priority', p, { shouldValidate: true })}
                            className={cn(
                              'flex items-center gap-2 rounded-lg border-2 px-3 py-2.5 text-sm font-semibold transition-colors',
                              isSelected ? 'border-primary bg-primary/5 text-foreground' : 'border-border text-muted-foreground hover:bg-muted/50'
                            )}
                          >
                            <PriorityDot priority={p} />
                            {entry.label}
                            {isSelected && <Check className="h-3.5 w-3.5 ml-auto text-primary" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {!isEditing && (
                    <div className="space-y-2">
                      <Label className="text-base font-medium">Milestone <span className="text-red-500">*</span></Label>
                      <Select value={selectedMilestoneId || undefined} onValueChange={(v) => setValue('milestone', v, { shouldValidate: true })}>
                        <SelectTrigger className="h-11 text-base w-full">
                          <SelectValue placeholder="Select a milestone" />
                        </SelectTrigger>
                        <SelectContent>
                          {milestones.map((m) => (
                            <SelectItem key={m._id} value={m._id}>
                              {m.name} ({formatDisplayDate(m.startDate)} – {formatDisplayDate(m.dueDate)})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.milestone && <p className="text-red-500 text-sm">{errors.milestone.message}</p>}
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <SectionLabel icon={CalendarClock}>Start date &amp; time</SectionLabel>
                      <Input type="datetime-local" className="h-11 text-base" min={minStart} {...register('startDate')} />
                    </div>
                    <div className="space-y-2">
                      <SectionLabel icon={CalendarClock}>Due date &amp; time</SectionLabel>
                      <Input type="datetime-local" className="h-11 text-base" min={minDue} {...register('dueDate')} />
                      {errors.dueDate && <p className="text-red-500 text-sm">{errors.dueDate.message}</p>}
                    </div>
                  </div>

                  {dateError && (
                    <p className="flex items-center gap-1.5 text-red-500 text-sm">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" /> {dateError}
                    </p>
                  )}
                </div>

                {/* People */}
                <div className="border-t pt-6 space-y-6">
                  <PeopleMultiSelect label="Assignees *" icon={Users} people={people} selectedIds={assigneeIds} onToggle={toggleAssignee} placeholder="Select at least one assignee..." />
                  {assigneeIds.length === 0 && <p className="text-red-500 text-sm">At least one assignee is required</p>}

                  <PeopleMultiSelect label="Watchers" icon={Eye} people={people} selectedIds={watcherIds} onToggle={toggleWatcher} placeholder="Select watchers..." />
                </div>

                {/* Dependencies */}
                <div className="border-t pt-6 space-y-2.5">
                  <SectionLabel icon={Link2} hint="(optional)">Dependencies</SectionLabel>
                  <Popover>
                    <PopoverTrigger asChild disabled={dependencyOptions.length === 0}>
                      <div>
                        <PickerTrigger
                          placeholder={dependencyOptions.length === 0 ? 'No other tasks in this project yet' : 'This task depends on...'}
                          preview={selectedDependencies.length > 0 ? (
                            <span className="truncate block">
                              {selectedDependencies.length <= 2 ? selectedDependencies.map(t => t.title).join(', ') : `${selectedDependencies.length} tasks selected`}
                            </span>
                          ) : null}
                          disabled={dependencyOptions.length === 0}
                        />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-96 p-1 max-h-72 overflow-y-auto" align="start">
                      {dependencyOptions.map((t) => {
                        const isSelected = dependencyIds.includes(t._id);
                        return (
                          <button
                            type="button"
                            key={t._id}
                            onClick={() => toggleDependency(t._id)}
                            className={cn(
                              'w-full flex items-center justify-between rounded-md px-2.5 py-2.5 text-sm hover:bg-accent transition-colors',
                              isSelected && 'bg-accent'
                            )}
                          >
                            <span className="truncate text-left">{t.title}</span>
                            {isSelected && <Check className="h-4 w-4 text-primary shrink-0" />}
                          </button>
                        );
                      })}
                    </PopoverContent>
                  </Popover>

                  {selectedDependencies.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-0.5">
                      {selectedDependencies.map((t) => (
                        <span key={t._id} className="inline-flex items-center gap-2 rounded-full bg-secondary pl-3 pr-2 py-1 text-sm">
                          {t.title}
                          <button type="button" onClick={() => toggleDependency(t._id)} className="text-muted-foreground hover:text-foreground">
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}

                  {depError && (
                    <p className="flex items-center gap-1.5 text-red-500 text-sm">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" /> {depError}
                    </p>
                  )}
                </div>

                {/* Tags & Checklist */}
                <div className="border-t pt-6 space-y-6">
                  <div>
                    <SectionLabel icon={TagIcon} hint="(max 5)">Tags</SectionLabel>
                    <div className="flex gap-2 mt-2.5">
                      <Input placeholder="Add tag..." className="h-10 text-base" value={newTag} onChange={(e) => setNewTag(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }} />
                      <Button type="button" variant="outline" onClick={addTag} disabled={tags.length >= 5}>Add</Button>
                    </div>
                    {tags.length > 0 && (
                      <div className="flex flex-wrap gap-2 mt-3">
                        {tags.map((tag, i) => (
                          <span key={i} className="bg-blue-100 text-blue-700 px-3 py-1.5 rounded-full text-sm flex items-center gap-1.5">
                            {tag}
                            <X className="h-3.5 w-3.5 cursor-pointer" onClick={() => removeTag(tag)} />
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <SectionLabel icon={ListChecks}>Checklist</SectionLabel>
                    <div className="flex gap-2 mt-2.5">
                      <Input placeholder="New checklist item..." className="h-10 text-base" value={newChecklistItem} onChange={(e) => setNewChecklistItem(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addChecklist(); } }} />
                      <Button type="button" variant="outline" onClick={addChecklist}>Add</Button>
                    </div>
                    {checklist.length > 0 && (
                      <div className="mt-3 space-y-1.5">
                        {checklist.map((item, index) => (
                          <div key={index} className="flex items-center gap-3 rounded-md px-2.5 py-2 hover:bg-accent/40">
                            <input type="checkbox" checked={item.completed} onChange={() => toggleChecklist(index)} className="h-4 w-4 shrink-0" />
                            <span className={cn('flex-1 text-base', item.completed && 'line-through text-muted-foreground')}>{item.item}</span>
                            <button type="button" onClick={() => removeChecklist(index)} className="text-muted-foreground hover:text-foreground">
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Submit Buttons */}
                <div className="flex justify-between border-t pt-5 gap-3">
                  <Button type="button" variant="outline" size="lg" onClick={handleClose} className="flex-1">
                    Cancel
                  </Button>
                  <Button type="submit" size="lg" className="flex-1" disabled={isSubmitting || mutation.isPending}>
                    {isSubmitting || mutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Check className="mr-2 h-4 w-4" />
                        {isEditing ? 'Update Task' : 'Create Task'}
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}