'use client';

import { Card } from '@/components/ui/card';

export default function ProfileSkeleton() {
  return (
    <div className="space-y-6 animate-pulse">

      {/* Profile Header */}
      <Card className="p-8">
        <div className="flex flex-col items-center gap-4">

          <div className="h-28 w-28 rounded-full bg-muted" />

          <div className="space-y-2 text-center">
            <div className="h-7 w-48 rounded bg-muted mx-auto" />
            <div className="h-4 w-64 rounded bg-muted mx-auto" />
          </div>

          <div className="flex gap-2">
            <div className="h-9 w-28 rounded bg-muted" />
            <div className="h-9 w-28 rounded bg-muted" />
          </div>

        </div>
      </Card>

      {/* Basic Information */}
      <Card className="p-6">

        <div className="mb-6 h-6 w-48 rounded bg-muted" />

        <div className="grid gap-5 md:grid-cols-2">

          {[...Array(8)].map((_, i) => (
            <div key={i} className="space-y-2">
              <div className="h-4 w-28 rounded bg-muted" />
              <div className="h-10 rounded-md bg-muted" />
            </div>
          ))}

        </div>

      </Card>

      {/* Change Password */}
      <Card className="p-6">

        <div className="mb-6 h-6 w-48 rounded bg-muted" />

        <div className="space-y-5">

          {[...Array(3)].map((_, i) => (
            <div key={i} className="space-y-2">
              <div className="h-4 w-40 rounded bg-muted" />
              <div className="h-10 rounded-md bg-muted" />
            </div>
          ))}

          <div className="h-10 w-40 rounded bg-muted" />

        </div>

      </Card>

    </div>
  );
}