"use client";

import { useCallback, useRef, useState } from "react";
import {
  UploadCloud,
  File as FileIcon,
  FileText,
  FileSpreadsheet,
  FileImage,
  FileArchive,
  X,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import resourceService from "@/services/resource.service";


const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB
const ALLOWED_MIME_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/gif",
  "image/webp",
  "image/svg+xml",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "text/plain",
  "text/csv",
  "application/zip",
  "application/json",
]);

const formatBytes = (bytes) => {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
};

const iconForMime = (mime = "") => {
  if (mime.startsWith("image/")) return FileImage;
  if (mime.includes("pdf") || mime.includes("word") || mime === "text/plain") return FileText;
  if (mime.includes("sheet") || mime.includes("excel") || mime === "text/csv") return FileSpreadsheet;
  if (mime.includes("zip")) return FileArchive;
  return FileIcon;
};

const validateFile = (file) => {
  if (!ALLOWED_MIME_TYPES.has(file.type)) {
    return `"${file.type || "unknown type"}" is not an allowed file type.`;
  }
  if (file.size > MAX_FILE_SIZE) {
    return `File exceeds the ${formatBytes(MAX_FILE_SIZE)} limit.`;
  }
  if (file.size === 0) {
    return "File is empty.";
  }
  return null;
};

/**
 * Drag-and-drop / click-to-browse uploader with a live per-file progress bar.
 *
 * Usage:
 *   <FileUploader projectId={id} folder={currentFolderId} onUploaded={refetchFiles} />
 */
export default function FileUploader({ projectId, folder = null, visibility = "team", onUploaded }) {
  const [items, setItems] = useState([]); // { id, file, status, progress, error }
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef(null);
  const dragCounter = useRef(0);

  const updateItem = (id, patch) =>
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)));

  const uploadOne = useCallback(
    async (item) => {
      updateItem(item.id, { status: "uploading", progress: 0, error: null });
      try {
        const res = await resourceService.uploadFile(
          projectId,
          item.file,
          { folder, visibility },
          (progress) => updateItem(item.id, { progress })
        );
        updateItem(item.id, { status: "done", progress: 100 });
        onUploaded?.(res.data?.data);
      } catch (err) {
        updateItem(item.id, {
          status: "error",
          error: err?.response?.data?.message || err.message || "Upload failed.",
        });
      }
    },
    [projectId, folder, visibility, onUploaded]
  );

  const addFiles = useCallback(
    (fileList) => {
      const incoming = Array.from(fileList).map((file) => {
        const error = validateFile(file);
        return {
          id: `${file.name}-${file.size}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          file,
          status: error ? "invalid" : "queued",
          progress: 0,
          error,
        };
      });

      setItems((prev) => [...prev, ...incoming]);

      incoming
        .filter((it) => it.status === "queued")
        .forEach((it) => uploadOne(it));
    },
    [uploadOne]
  );

  const onDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    dragCounter.current = 0;
    if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
  };

  const onDragEnter = (e) => {
    e.preventDefault();
    dragCounter.current += 1;
    setIsDragging(true);
  };

  const onDragLeave = (e) => {
    e.preventDefault();
    dragCounter.current -= 1;
    if (dragCounter.current <= 0) setIsDragging(false);
  };

  const removeItem = (id) => setItems((prev) => prev.filter((it) => it.id !== id));

  const retryItem = (id) => {
    const item = items.find((it) => it.id === id);
    if (item) uploadOne(item);
  };

  return (
    <div className="space-y-3">
      {/* Dropzone */}
      <div
        onDrop={onDrop}
        onDragOver={(e) => e.preventDefault()}
        onDragEnter={onDragEnter}
        onDragLeave={onDragLeave}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && inputRef.current?.click()}
        className={`flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-6 py-10 text-center cursor-pointer transition-colors
          ${isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/40"}`}
      >
        <UploadCloud className={`h-8 w-8 ${isDragging ? "text-primary" : "text-muted-foreground"}`} />
        <p className="text-sm font-medium">
          {isDragging ? "Drop files to upload" : "Drag & drop files, or click to browse"}
        </p>
        <p className="text-xs text-muted-foreground">
          Up to {formatBytes(MAX_FILE_SIZE)} per file · PDF, Office, images, text, zip
        </p>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.length) addFiles(e.target.files);
            e.target.value = ""; // allow re-selecting the same file
          }}
        />
      </div>

      {/* Upload queue */}
      {items.length > 0 && (
        <ul className="space-y-2">
          {items.map((item) => {
            const Icon = iconForMime(item.file.type);
            return (
              <li
                key={item.id}
                className="flex items-center gap-3 rounded-md border bg-card px-3 py-2.5"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-muted">
                  <Icon className="h-4.5 w-4.5 text-muted-foreground" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-sm font-medium">{item.file.name}</p>
                    <span className="shrink-0 text-xs text-muted-foreground">
                      {formatBytes(item.file.size)}
                    </span>
                  </div>

                  {item.status === "uploading" && (
                    <div className="mt-1.5 flex items-center gap-2">
                      <Progress value={item.progress} className="h-1.5" />
                      <span className="w-9 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
                        {item.progress}%
                      </span>
                    </div>
                  )}

                  {(item.status === "invalid" || item.status === "error") && (
                    <p className="mt-1 flex items-center gap-1 text-xs text-red-600">
                      <AlertCircle className="h-3 w-3" />
                      {item.error}
                    </p>
                  )}

                  {item.status === "done" && (
                    <p className="mt-1 flex items-center gap-1 text-xs text-emerald-600">
                      <CheckCircle2 className="h-3 w-3" />
                      Uploaded
                    </p>
                  )}
                </div>

                <div className="flex shrink-0 items-center gap-1">
                  {item.status === "error" && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => retryItem(item.id)}
                      title="Retry upload"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => removeItem(item.id)}
                    title="Remove"
                  >
                    <X className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}