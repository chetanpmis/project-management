'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { Eye, EyeOff, LockKeyhole, Loader2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

import userService from '@/services/user.service';
import { changePasswordSchema } from '@/schema/profileSchema';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const inputClass =
  'flex h-11 w-full rounded-lg border border-input bg-background px-3.5 py-2 pr-11 text-base shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 disabled:cursor-not-allowed disabled:opacity-60';

/** Plain label + error helper, no shadcn Form/FormField wrapper */
function Field({ label, htmlFor, error, children }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={htmlFor} className="text-sm font-medium text-foreground">
        {label}
      </label>
      {children}
      {error && (
        <p className="flex items-center gap-1.5 text-sm text-destructive">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" /> {error}
        </p>
      )}
    </div>
  );
}

function PasswordInput({ id, show, onToggle, error, registration }) {
  return (
    <div className="relative">
      <input
        id={id}
        type={show ? 'text' : 'password'}
        autoComplete="new-password"
        className={cn(inputClass, error && 'border-destructive focus-visible:ring-destructive')}
        {...registration}
      />
      <button
        type="button"
        onClick={onToggle}
        className="absolute right-1 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
        aria-label={show ? 'Hide password' : 'Show password'}
      >
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  );
}

/**
 * Controlled dialog — the parent (ProfilePage) owns `open`/`onOpenChange`,
 * exactly like TaskDetailPage owns `editOpen` for TaskFormDialog.
 * Nothing password-related renders until the user opens this.
 */
export default function ChangePasswordCard({ open, onOpenChange }) {
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(changePasswordSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    },
  });

  const mutation = useMutation({
    mutationFn: userService.changePassword,
    onSuccess: (res) => {
      toast.success(res.message || 'Password changed successfully.');
      reset();
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'Failed to change password.');
    },
  });

  const onSubmit = (values) => {
    mutation.mutate({
      currentPassword: values.currentPassword,
      newPassword: values.newPassword,
    });
  };

  const handleOpenChange = (next) => {
    if (!next) reset();
    onOpenChange(next);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LockKeyhole className="h-5 w-5" />
            Change Password
          </DialogTitle>
          <DialogDescription>Update your account password.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
          <Field label="Current Password" htmlFor="currentPassword" error={errors.currentPassword?.message}>
            <PasswordInput
              id="currentPassword"
              show={showCurrent}
              onToggle={() => setShowCurrent((prev) => !prev)}
              error={errors.currentPassword}
              registration={register('currentPassword')}
            />
          </Field>

          <Field label="New Password" htmlFor="newPassword" error={errors.newPassword?.message}>
            <PasswordInput
              id="newPassword"
              show={showNew}
              onToggle={() => setShowNew((prev) => !prev)}
              error={errors.newPassword}
              registration={register('newPassword')}
            />
          </Field>

          <Field label="Confirm Password" htmlFor="confirmPassword" error={errors.confirmPassword?.message}>
            <PasswordInput
              id="confirmPassword"
              show={showConfirm}
              onToggle={() => setShowConfirm((prev) => !prev)}
              error={errors.confirmPassword}
              registration={register('confirmPassword')}
            />
          </Field>

          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => handleOpenChange(false)} disabled={mutation.isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Update Password
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}