'use client';

import { useRouter } from 'next/navigation';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

/**
 * The one page header every screen (Projects, Tasks, Project details, task
 * details, create/edit forms) should render with. Two sizes:
 *  - `size="page"` (default): big 3xl title, used on top-level list/detail pages
 *  - `size="form"`: smaller title, used on create/edit wizards
 *
 * <PageHeader
 *   title="Projects"
 *   description="Manage and monitor all your projects."
 *   actions={<Button>New project</Button>}
 * />
 *
 * <PageHeader
 *   showBack
 *   title={project.name}
 *   eyebrow={project.projectCode}
 *   badges={[<ProjectStatusBadge status={project.status} />]}
 *   actions={<Button variant="outline">Edit</Button>}
 * />
 */
export default function PageHeader({
  title,
  description,
  eyebrow,
  badges = [],
  actions,
  showBack = false,
  onBack,
  size = 'page',
  loading = false,
}) {
  const router = useRouter();

  if (loading) {
    return (
      <div className="flex items-center justify-between mb-8 animate-pulse">
        <div className="space-y-2">
          <div className="h-8 w-56 bg-muted rounded-md" />
          <div className="h-4 w-72 bg-muted rounded-md" />
        </div>
        <div className="h-10 w-32 bg-muted rounded-md" />
      </div>
    );
  }

  return (
    <div className="flex items-start justify-between gap-4 mb-8 flex-wrap">
      <div className="flex items-start gap-3 min-w-0">
        {showBack && (
          <Button
            variant="ghost"
            size="icon"
            className="h-10 w-10 -ml-2 mt-1 shrink-0"
            onClick={() => (onBack ? onBack() : router.back())}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
        )}
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className={cn('font-bold tracking-tight  truncate', size === 'form' ? 'text-2xl' : 'text-3xl lg:text-4xl')}>
              {title}
            </h1>
            {eyebrow && (
              <Badge variant="outline" className="font-mono text-xs shrink-0">
                {eyebrow}
              </Badge>
            )}
          </div>
          {description && (
            <p className={cn('text-muted-foreground mt-1', size === 'form' ? 'text-sm' : 'text-base lg:text-lg')}>
              {description}
            </p>
          )}
          {badges.length > 0 && (
            <div className="flex items-center gap-2 mt-2.5 flex-wrap">
              {badges.map((b, i) => (
                <span key={i}>{b}</span>
              ))}
            </div>
          )}
        </div>
      </div>

      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
}