'use client';

import { Card } from '@/components/ui/card';

export default function GanttChartSkeleton() {
  return (
    <Card className="overflow-hidden">
      <div className="animate-pulse">

        {/* Toolbar */}
        <div className="flex items-center justify-between border-b p-4">
          <div className="h-8 w-64 rounded bg-muted" />
          <div className="flex gap-2">
            <div className="h-8 w-24 rounded bg-muted" />
            <div className="h-8 w-24 rounded bg-muted" />
          </div>
        </div>

        <div className="flex h-[calc(100vh-240px)] min-h-[650px]">

          {/* Left Task List */}
          <div className="w-80 border-r p-4 space-y-4">
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="h-10 rounded-md bg-muted"
              />
            ))}
          </div>

          {/* Timeline */}
          <div className="flex-1 p-4">

            {/* Header */}
            <div className="flex gap-2 mb-6">
              {[...Array(18)].map((_, i) => (
                <div
                  key={i}
                  className="h-6 flex-1 rounded bg-muted"
                />
              ))}
            </div>

            {/* Gantt Rows */}
            <div className="space-y-5">
              {[...Array(12)].map((_, row) => (
                <div
                  key={row}
                  className="relative h-8"
                >
                  <div
                    className="absolute h-6 rounded-md bg-muted"
                    style={{
                      left: `${10 + row * 2}%`,
                      width: `${30 + (row % 4) * 8}%`,
                    }}
                  />
                </div>
              ))}
            </div>

          </div>

        </div>

      </div>
    </Card>
  );
}