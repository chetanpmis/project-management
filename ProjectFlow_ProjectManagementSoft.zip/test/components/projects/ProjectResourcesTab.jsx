'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Folder as FolderIcon,
  FolderPlus,
  Search,
  MoreVertical,
  Download,
  Pencil,
  Trash2,
  FolderInput,
  Share2,
  History,
  X,
  Loader2,
  File as FileIcon,
  FileText,
  FileSpreadsheet,
  FileImage,
  FileArchive,
  Lock,
  Globe,
  ChevronLeft,
  ChevronRight,
  UploadCloud,
  RotateCcw,
  Inbox,
} from 'lucide-react';
import resourceService from '@/services/resource.service';
import projectService from '@/services/project.service';
import useAuthStore from '@/store/auth-store';
import { usePermission } from '@/hooks/usePermission';
import { PROJECT_PERMISSIONS } from '@/constants/projectPermissions';
import FileUploader from '@/components/common/FileUploader';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import EmptyState from '@/components/feedback/EmptyState';
import { CardListSkeleton } from '@/components/common/Skeletons';
import { SuccessDialog, ErrorDialog, ConfirmDialog } from '@/components/common/AppDialogs';
import Tooltip from '@/components/common/Tooltip';
import { cn } from '@/lib/utils';

const PAGE_SIZE = 12;

const formatBytes = (bytes) => {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
};

const formatDate = (d) =>
  d ? new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '—';

const getInitials = (name) => (!name ? 'U' : name.split(' ').map((w) => w[0]).join('').toUpperCase().slice(0, 2));

const iconForMime = (mime = '') => {
  if (mime.startsWith('image/')) return FileImage;
  if (mime.includes('pdf') || mime.includes('word') || mime === 'text/plain') return FileText;
  if (mime.includes('sheet') || mime.includes('excel') || mime === 'text/csv') return FileSpreadsheet;
  if (mime.includes('zip')) return FileArchive;
  return FileIcon;
};

const triggerBlobDownload = (blob, filename) => {
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.URL.revokeObjectURL(url);
};

const SORT_OPTIONS = [
  { value: 'createdAt_desc', label: 'Newest first' },
  { value: 'createdAt_asc', label: 'Oldest first' },
  { value: 'originalName_asc', label: 'Name (A–Z)' },
  { value: 'originalName_desc', label: 'Name (Z–A)' },
  { value: 'size_desc', label: 'Largest first' },
  { value: 'size_asc', label: 'Smallest first' },
];

export default function ProjectResourcesTab({ projectId }) {
  const queryClient = useQueryClient();
  const currentUser = useAuthStore((s) => s.user);

  const { data: projectRes } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => projectService.getProjectById(projectId),
    enabled: !!projectId,
  });
  const project = projectRes?.data;

  const canView = usePermission(project, PROJECT_PERMISSIONS.RESOURCE_VIEW);
  const canUpload = usePermission(project, PROJECT_PERMISSIONS.RESOURCE_UPLOAD);
  const canEditResources = usePermission(project, PROJECT_PERMISSIONS.RESOURCE_EDIT);
  const canDeleteResources = usePermission(project, PROJECT_PERMISSIONS.RESOURCE_DELETE);
  const canManageResources = usePermission(project, PROJECT_PERMISSIONS.RESOURCE_MANAGE);

  const [activeFolder, setActiveFolder] = useState('all');
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [sortValue, setSortValue] = useState('createdAt_desc');
  const [page, setPage] = useState(1);
  const [showUploader, setShowUploader] = useState(false);
  const [feedback, setFeedback] = useState({ type: null, message: '' });

  const [folderDialog, setFolderDialog] = useState(null);
  const [folderNameInput, setFolderNameInput] = useState('');
  const [deleteFolderTarget, setDeleteFolderTarget] = useState(null);

  const [renameFileTarget, setRenameFileTarget] = useState(null);
  const [renameFileInput, setRenameFileInput] = useState('');
  const [moveFileTarget, setMoveFileTarget] = useState(null);
  const [moveFileFolder, setMoveFileFolder] = useState('root');
  const [deleteFileTarget, setDeleteFileTarget] = useState(null);
  const [shareFileTarget, setShareFileTarget] = useState(null);
  const [versionsFileTarget, setVersionsFileTarget] = useState(null);
  const [shareMemberId, setShareMemberId] = useState('');
  const [sharePermission, setSharePermission] = useState('view');

  const replaceInputRef = useRef(null);
  const [replaceTarget, setReplaceTarget] = useState(null);
  const [replaceProgress, setReplaceProgress] = useState(0);
  const [isReplacing, setIsReplacing] = useState(false);

  const [sortBy, sortOrder] = useMemo(() => {
    const idx = sortValue.lastIndexOf('_');
    return [sortValue.slice(0, idx), sortValue.slice(idx + 1)];
  }, [sortValue]);

  useEffect(() => {
    const t = setTimeout(() => {
      setSearch(searchInput.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [searchInput]);

  useEffect(() => setPage(1), [activeFolder, sortValue]);

  const teamMembers = useMemo(() => {
    if (!project) return [];
    const owner = project.owner ? [{ ...project.owner, role: 'owner' }] : [];
    const members = (project.team || []).map((t) => ({ ...t.user, role: t.role }));
    const seen = new Set();
    return [...owner, ...members].filter((u) => {
      if (!u?._id || seen.has(u._id)) return false;
      seen.add(u._id);
      return true;
    });
  }, [project]);

  const memberById = useMemo(() => {
    const map = new Map();
    teamMembers.forEach((m) => map.set(m._id, m));
    return map;
  }, [teamMembers]);

  const canActOn = (file) =>
    canDeleteResources || canEditResources || file.uploadedBy?._id === currentUser?.id;

  const { data: foldersRes, isLoading: isFoldersLoading } = useQuery({
    queryKey: ['resources', 'folders', projectId],
    queryFn: () => resourceService.listFolders(projectId),
    enabled: !!projectId && canView,
  });
  const folders = foldersRes?.data?.data || [];

  const filesQueryParams = {
    page,
    limit: PAGE_SIZE,
    sortBy,
    sortOrder,
    ...(search ? { search } : {}),
    ...(activeFolder !== 'all' ? { folder: activeFolder } : {}),
  };

  const { data: filesRes, isLoading: isFilesLoading, isFetching: isFilesFetching } = useQuery({
    queryKey: ['resources', 'files', projectId, filesQueryParams],
    queryFn: () => resourceService.listFiles(projectId, filesQueryParams),
    enabled: !!projectId && canView,
    keepPreviousData: true,
  });
  const filesPayload = filesRes?.data?.data;
  const files = filesPayload?.files || [];
  const pagination = filesPayload?.pagination || { total: 0, totalPages: 1, page: 1 };

  const invalidateFolders = () => queryClient.invalidateQueries({ queryKey: ['resources', 'folders', projectId] });
  const invalidateFiles = () => queryClient.invalidateQueries({ queryKey: ['resources', 'files', projectId] });

  const onError = (err, fallback) =>
    setFeedback({ type: 'error', message: err?.response?.data?.message || fallback });
  const onSuccess = (message) => setFeedback({ type: 'success', message });

  const createFolderMutation = useMutation({
    mutationFn: (name) => resourceService.createFolder(projectId, name),
    onSuccess: () => {
      invalidateFolders();
      setFolderDialog(null);
      onSuccess('Folder created.');
    },
    onError: (err) => onError(err, 'Could not create this folder.'),
  });

  const renameFolderMutation = useMutation({
    mutationFn: ({ folderId, name }) => resourceService.renameFolder(folderId, name),
    onSuccess: () => {
      invalidateFolders();
      setFolderDialog(null);
      onSuccess('Folder renamed.');
    },
    onError: (err) => onError(err, 'Could not rename this folder.'),
  });

  const deleteFolderMutation = useMutation({
    mutationFn: (folderId) => resourceService.deleteFolder(folderId),
    onSuccess: () => {
      invalidateFolders();
      if (activeFolder === deleteFolderTarget?._id) setActiveFolder('all');
      setDeleteFolderTarget(null);
      onSuccess('Folder deleted.');
    },
    onError: (err) => {
      setDeleteFolderTarget(null);
      onError(err, 'Could not delete this folder.');
    },
  });

  const renameFileMutation = useMutation({
    mutationFn: ({ fileId, originalName }) => resourceService.renameFile(fileId, originalName),
    onSuccess: () => {
      invalidateFiles();
      setRenameFileTarget(null);
      onSuccess('File renamed.');
    },
    onError: (err) => onError(err, 'Could not rename this file.'),
  });

  const moveFileMutation = useMutation({
    mutationFn: ({ fileId, folder }) => resourceService.moveFile(fileId, folder),
    onSuccess: () => {
      invalidateFiles();
      setMoveFileTarget(null);
      onSuccess('File moved.');
    },
    onError: (err) => onError(err, 'Could not move this file.'),
  });

  const deleteFileMutation = useMutation({
    mutationFn: (fileId) => resourceService.deleteFile(fileId),
    onSuccess: () => {
      invalidateFiles();
      setDeleteFileTarget(null);
      onSuccess('File deleted.');
    },
    onError: (err) => {
      setDeleteFileTarget(null);
      onError(err, 'Could not delete this file.');
    },
  });

  const shareMutation = useMutation({
    mutationFn: ({ fileId, userId, permission }) => resourceService.shareFile(fileId, userId, permission),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['resources', 'file', shareFileTarget] });
      invalidateFiles();
      setShareMemberId('');
      onSuccess('File shared.');
    },
    onError: (err) => onError(err, 'Could not share this file.'),
  });

  const unshareMutation = useMutation({
    mutationFn: ({ fileId, userId }) => resourceService.unshareFile(fileId, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['resources', 'file', shareFileTarget] });
      invalidateFiles();
      onSuccess('Access removed.');
    },
    onError: (err) => onError(err, 'Could not update sharing.'),
  });

  const restoreVersionMutation = useMutation({
    mutationFn: ({ fileId, version }) => resourceService.restoreVersion(fileId, version),
    onSuccess: (_res, vars) => {
      queryClient.invalidateQueries({ queryKey: ['resources', 'versions', vars.fileId] });
      invalidateFiles();
      onSuccess('Version restored.');
    },
    onError: (err) => onError(err, 'Could not restore this version.'),
  });

  const { data: shareFileRes } = useQuery({
    queryKey: ['resources', 'file', shareFileTarget],
    queryFn: () => resourceService.getFile(shareFileTarget),
    enabled: !!shareFileTarget,
  });
  const shareFileData = shareFileRes?.data?.data;

  const { data: versionsRes, isLoading: isVersionsLoading } = useQuery({
    queryKey: ['resources', 'versions', versionsFileTarget],
    queryFn: () => resourceService.listVersions(versionsFileTarget),
    enabled: !!versionsFileTarget,
  });
  const versionsData = versionsRes?.data?.data;
  const versionsFile = files.find((f) => f._id === versionsFileTarget);

  const handleDownload = async (file) => {
    try {
      const res = await resourceService.downloadFile(file._id);
      triggerBlobDownload(res.data, file.originalName);
    } catch (err) {
      onError(err, 'Could not download this file.');
    }
  };

  const handleDownloadVersion = async (fileId, version) => {
    try {
      const res = await resourceService.downloadVersion(fileId, version.version);
      triggerBlobDownload(res.data, version.originalName);
    } catch (err) {
      onError(err, 'Could not download this version.');
    }
  };

  const triggerReplace = (file) => {
    if (!canEditResources && file.uploadedBy?._id !== currentUser?.id) return;
    setReplaceTarget(file);
    requestAnimationFrame(() => replaceInputRef.current?.click());
  };

  const onReplaceFileSelected = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !replaceTarget) return;
    setIsReplacing(true);
    setReplaceProgress(0);
    try {
      await resourceService.replaceFile(replaceTarget._id, file, undefined, setReplaceProgress);
      invalidateFiles();
      onSuccess(`Uploaded a new version of "${replaceTarget.originalName}".`);
    } catch (err) {
      onError(err, 'Could not upload the new version.');
    } finally {
      setIsReplacing(false);
      setReplaceTarget(null);
      setReplaceProgress(0);
    }
  };

  const activeFolderLabel =
    activeFolder === 'all'
      ? 'All files'
      : activeFolder === 'root'
      ? 'Unfiled files'
      : folders.find((f) => f._id === activeFolder)?.name || 'Folder';

  const uploadTargetFolder = activeFolder !== 'all' && activeFolder !== 'root' ? activeFolder : undefined;

  const isInitialLoading = (isFoldersLoading || isFilesLoading) && !filesPayload;

  if (!canView) {
    return (
      <div className="flex min-h-[300px] items-center justify-center rounded-lg border bg-white">
        <EmptyState
          compact
          icon={<Lock className="h-6 w-6" />}
          title="You don't have access to files"
          description="Ask a project owner or manager to grant you resource access."
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <input ref={replaceInputRef} type="file" className="hidden" onChange={onReplaceFileSelected} />

      <div className="flex flex-wrap items-center gap-2 justify-between">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search files…"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="pl-8"
          />
        </div>

        <div className="flex items-center gap-2">
          <Select value={sortValue} onValueChange={setSortValue}>
            <SelectTrigger className="w-[160px] h-9">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SORT_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {canManageResources && (
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5"
              onClick={() => {
                setFolderNameInput('');
                setFolderDialog({ mode: 'create' });
              }}
            >
              <FolderPlus className="h-3.5 w-3.5" />
              New folder
            </Button>
          )}

          {canUpload && (
            <Button size="sm" className="gap-1.5" onClick={() => setShowUploader((v) => !v)}>
              <UploadCloud className="h-3.5 w-3.5" />
              {showUploader ? 'Close upload' : 'Upload'}
            </Button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <FolderChip
          label="All files"
          icon={Inbox}
          active={activeFolder === 'all'}
          onClick={() => setActiveFolder('all')}
        />
        <FolderChip
          label="Unfiled"
          icon={FileIcon}
          active={activeFolder === 'root'}
          onClick={() => setActiveFolder('root')}
        />
        {folders.map((folder) => (
          <FolderChip
            key={folder._id}
            label={folder.name}
            icon={FolderIcon}
            active={activeFolder === folder._id}
            onClick={() => setActiveFolder(folder._id)}
            menu={
              canManageResources && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      onClick={(e) => e.stopPropagation()}
                      className="ml-1 rounded p-0.5 hover:bg-black/10 shrink-0"
                    >
                      <MoreVertical className="h-3 w-3" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem
                      onClick={() => {
                        setFolderNameInput(folder.name);
                        setFolderDialog({ mode: 'rename', folder });
                      }}
                    >
                      <Pencil className="h-3.5 w-3.5 mr-2" />
                      Rename
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      className="text-red-600 focus:text-red-600"
                      onClick={() => setDeleteFolderTarget(folder)}
                    >
                      <Trash2 className="h-3.5 w-3.5 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )
            }
          />
        ))}
      </div>

      {isReplacing && (
        <div className="flex items-center gap-3 rounded-md border bg-muted/40 px-3 py-2 text-sm">
          <Loader2 className="h-4 w-4 shrink-0 animate-spin text-muted-foreground" />
          <span className="truncate">{`Uploading new version of ${replaceTarget?.originalName}…`}</span>
          <Progress value={replaceProgress} className="h-1.5 flex-1 max-w-[160px]" />
          <span className="w-9 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
            {replaceProgress}%
          </span>
        </div>
      )}

      {canUpload && showUploader && (
        <div className="rounded-lg border p-3 bg-muted/20">
          <p className="text-xs text-muted-foreground mb-2">
            Uploading to: <span className="font-medium text-foreground">{activeFolderLabel === 'All files' ? 'Unfiled' : activeFolderLabel}</span>
          </p>
          <FileUploader
            projectId={projectId}
            folder={uploadTargetFolder}
            onUploaded={() => invalidateFiles()}
          />
        </div>
      )}

      {isInitialLoading ? (
        <CardListSkeleton count={4} height="h-16" />
      ) : files.length === 0 ? (
        <EmptyState
          compact
          icon={<FolderIcon className="h-6 w-6" />}
          title={search ? 'No files match your search' : 'No files here yet'}
          description={
            search
              ? 'Try a different search term.'
              : canUpload
              ? 'Upload a file to get started, or pick a different folder.'
              : 'No files have been shared here yet.'
          }
        />
      ) : (
        <div className="rounded-lg border divide-y relative">
          {isFilesFetching && (
            <div className="absolute right-3 top-2">
              <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
            </div>
          )}
          {files.map((file) => {
            const Icon = iconForMime(file.mimeType);
            const canRenameOrMove = canEditResources || file.uploadedBy?._id === currentUser?.id;
            const canDeleteThis = canDeleteResources || file.uploadedBy?._id === currentUser?.id;
            const canReplace = canEditResources || file.uploadedBy?._id === currentUser?.id;
            const canShare = canManageResources;
            const canAct = canRenameOrMove || canDeleteThis || canReplace || canShare;
            return (
              <div key={file._id} className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-muted">
                  <Icon className="h-4.5 w-4.5 text-muted-foreground" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="truncate text-sm font-medium max-w-[280px]">{file.originalName}</p>
                    {file.currentVersion > 1 && (
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                        v{file.currentVersion}
                      </Badge>
                    )}
                    <Tooltip content={file.visibility === 'private' ? 'Private' : 'Visible to the whole team'}>
                      {file.visibility === 'private' ? (
                        <Lock className="h-3 w-3 text-muted-foreground" />
                      ) : (
                        <Globe className="h-3 w-3 text-muted-foreground" />
                      )}
                    </Tooltip>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5 text-xs text-muted-foreground">
                    <span>{formatBytes(file.size)}</span>
                    <span>·</span>
                    <span>{formatDate(file.createdAt)}</span>
                    {file.folder?.name && (
                      <>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <FolderIcon className="h-3 w-3" />
                          {file.folder.name}
                        </span>
                      </>
                    )}
                  </div>
                </div>

                <Tooltip content={file.uploadedBy?.name || 'Unknown'}>
                  <Avatar className="h-7 w-7 border shrink-0">
                    <AvatarFallback className="text-[10px] font-semibold">
                      {getInitials(file.uploadedBy?.name)}
                    </AvatarFallback>
                  </Avatar>
                </Tooltip>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleDownload(file)}>
                      <Download className="h-3.5 w-3.5 mr-2" />
                      Download
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setVersionsFileTarget(file._id)}>
                      <History className="h-3.5 w-3.5 mr-2" />
                      Version history
                    </DropdownMenuItem>
                    {canAct && <DropdownMenuSeparator />}
                    {canRenameOrMove && (
                      <DropdownMenuItem
                        onClick={() => {
                          setRenameFileInput(file.originalName);
                          setRenameFileTarget(file);
                        }}
                      >
                        <Pencil className="h-3.5 w-3.5 mr-2" />
                        Rename
                      </DropdownMenuItem>
                    )}
                    {canRenameOrMove && (
                      <DropdownMenuItem
                        onClick={() => {
                          setMoveFileFolder(file.folder?._id || file.folder || 'root');
                          setMoveFileTarget(file);
                        }}
                      >
                        <FolderInput className="h-3.5 w-3.5 mr-2" />
                        Move
                      </DropdownMenuItem>
                    )}
                    {canReplace && (
                      <DropdownMenuItem onClick={() => triggerReplace(file)}>
                        <UploadCloud className="h-3.5 w-3.5 mr-2" />
                        Upload new version
                      </DropdownMenuItem>
                    )}
                    {canShare && (
                      <DropdownMenuItem
                        onClick={() => {
                          setShareMemberId('');
                          setSharePermission('view');
                          setShareFileTarget(file._id);
                        }}
                      >
                        <Share2 className="h-3.5 w-3.5 mr-2" />
                        Share
                      </DropdownMenuItem>
                    )}
                    {canDeleteThis && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-red-600 focus:text-red-600"
                          onClick={() => setDeleteFileTarget(file)}
                        >
                          <Trash2 className="h-3.5 w-3.5 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            );
          })}
        </div>
      )}

      {pagination.total > 0 && (
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>
            {pagination.total} file{pagination.total === 1 ? '' : 's'} · Page {pagination.page} of{' '}
            {pagination.totalPages}
          </span>
          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="h-8 w-8"
              disabled={page >= pagination.totalPages}
              onClick={() => setPage((p) => Math.min(pagination.totalPages, p + 1))}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      <Dialog open={!!folderDialog} onOpenChange={(v) => !v && setFolderDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{folderDialog?.mode === 'rename' ? 'Rename folder' : 'New folder'}</DialogTitle>
            <DialogDescription>Folder names must be unique within this project.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="folder-name">Folder name</Label>
            <Input
              id="folder-name"
              value={folderNameInput}
              onChange={(e) => setFolderNameInput(e.target.value)}
              placeholder="e.g. Design assets"
              maxLength={100}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFolderDialog(null)}>
              Cancel
            </Button>
            <Button
              disabled={
                !canManageResources ||
                !folderNameInput.trim() ||
                createFolderMutation.isPending ||
                renameFolderMutation.isPending
              }
              onClick={() => {
                if (folderDialog?.mode === 'rename') {
                  renameFolderMutation.mutate({ folderId: folderDialog.folder._id, name: folderNameInput.trim() });
                } else {
                  createFolderMutation.mutate(folderNameInput.trim());
                }
              }}
            >
              {(createFolderMutation.isPending || renameFolderMutation.isPending) && (
                <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
              )}
              {folderDialog?.mode === 'rename' ? 'Save' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteFolderTarget}
        onOpenChange={(v) => !v && setDeleteFolderTarget(null)}
        title="Delete folder?"
        description={`"${deleteFolderTarget?.name}" must be empty before it can be deleted. Move or delete its files first.`}
        confirmLabel="Delete"
        loading={deleteFolderMutation.isPending}
        onConfirm={() => canManageResources && deleteFolderMutation.mutate(deleteFolderTarget._id)}
      />

      <Dialog open={!!renameFileTarget} onOpenChange={(v) => !v && setRenameFileTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename file</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="file-name">File name</Label>
            <Input
              id="file-name"
              value={renameFileInput}
              onChange={(e) => setRenameFileInput(e.target.value)}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRenameFileTarget(null)}>
              Cancel
            </Button>
            <Button
              disabled={!renameFileInput.trim() || renameFileMutation.isPending}
              onClick={() =>
                renameFileMutation.mutate({ fileId: renameFileTarget._id, originalName: renameFileInput.trim() })
              }
            >
              {renameFileMutation.isPending && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!moveFileTarget} onOpenChange={(v) => !v && setMoveFileTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Move file</DialogTitle>
            <DialogDescription>{`Choose a destination folder for ${moveFileTarget?.originalName}.`}</DialogDescription>
          </DialogHeader>
          <Select value={moveFileFolder} onValueChange={setMoveFileFolder}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="root">No folder (unfiled)</SelectItem>
              {folders.map((f) => (
                <SelectItem key={f._id} value={f._id}>
                  {f.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMoveFileTarget(null)}>
              Cancel
            </Button>
            <Button
              disabled={moveFileMutation.isPending}
              onClick={() =>
                moveFileMutation.mutate({
                  fileId: moveFileTarget._id,
                  folder: moveFileFolder === 'root' ? null : moveFileFolder,
                })
              }
            >
              {moveFileMutation.isPending && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}
              Move
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteFileTarget}
        onOpenChange={(v) => !v && setDeleteFileTarget(null)}
        title="Delete file?"
        description={`"${deleteFileTarget?.originalName}" will be removed from the project.`}
        confirmLabel="Delete"
        loading={deleteFileMutation.isPending}
        onConfirm={() => deleteFileMutation.mutate(deleteFileTarget._id)}
      />

      <Dialog open={!!shareFileTarget} onOpenChange={(v) => !v && setShareFileTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share file</DialogTitle>
            <DialogDescription>Only members of this project can be shared files.</DialogDescription>
          </DialogHeader>

          <div className="flex items-end gap-2">
            <div className="flex-1 space-y-1.5">
              <Label>Member</Label>
              <Select value={shareMemberId} onValueChange={setShareMemberId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a member" />
                </SelectTrigger>
                <SelectContent>
                  {teamMembers
                    .filter((m) => m._id !== currentUser?.id)
                    .map((m) => (
                      <SelectItem key={m._id} value={m._id}>
                        {m.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="w-28 space-y-1.5">
              <Label>Access</Label>
              <Select value={sharePermission} onValueChange={setSharePermission}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="view">View</SelectItem>
                  <SelectItem value="edit">Edit</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button
              disabled={!canManageResources || !shareMemberId || shareMutation.isPending}
              onClick={() =>
                shareMutation.mutate({ fileId: shareFileTarget, userId: shareMemberId, permission: sharePermission })
              }
            >
              {shareMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Share'}
            </Button>
          </div>

          <div className="pt-2 border-t space-y-1.5">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Shared with</p>
            {!shareFileData?.sharedWith?.length ? (
              <p className="text-sm text-muted-foreground py-2">Not shared with anyone yet.</p>
            ) : (
              <ul className="space-y-1.5 max-h-48 overflow-y-auto">
                {shareFileData.sharedWith.map((s) => {
                  const member = memberById.get(s.user?._id || s.user);
                  return (
                    <li key={s.user?._id || s.user} className="flex items-center justify-between text-sm">
                      <span className="flex items-center gap-2">
                        <Avatar className="h-6 w-6 border">
                          <AvatarFallback className="text-[10px]">{getInitials(member?.name)}</AvatarFallback>
                        </Avatar>
                        {member?.name || 'Unknown member'}
                        <Badge variant="outline" className="text-[10px] capitalize">
                          {s.permission}
                        </Badge>
                      </span>
                      {canManageResources && (
                        <button
                          className="text-muted-foreground hover:text-red-600"
                          onClick={() =>
                            unshareMutation.mutate({ fileId: shareFileTarget, userId: s.user?._id || s.user })
                          }
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShareFileTarget(null)}>
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!versionsFileTarget} onOpenChange={(v) => !v && setVersionsFileTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Version history</DialogTitle>
            <DialogDescription>
              {versionsFile?.originalName}
              {versionsData ? ` · current v${versionsData.currentVersion}` : ''}
            </DialogDescription>
          </DialogHeader>

          {isVersionsLoading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : !versionsData?.versions?.length ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              {`No previous versions — this file hasn't been replaced yet.`}
            </p>
          ) : (
            <ul className="space-y-2 max-h-72 overflow-y-auto">
              {versionsData.versions.map((v) => {
                const uploader = memberById.get(v.uploadedBy?._id || v.uploadedBy);
                return (
                  <li key={v.version} className="flex items-center gap-3 rounded-md border px-3 py-2">
                    <Badge variant="outline" className="shrink-0">
                      v{v.version}
                    </Badge>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{v.originalName}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatBytes(v.size)} · {formatDate(v.uploadedAt)}
                        {uploader?.name ? ` · ${uploader.name}` : ''}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleDownloadVersion(versionsFileTarget, v)}
                      title="Download this version"
                    >
                      <Download className="h-3.5 w-3.5" />
                    </Button>
                    {versionsFile && canActOn(versionsFile) && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        title="Restore this version"
                        disabled={restoreVersionMutation.isPending}
                        onClick={() =>
                          restoreVersionMutation.mutate({ fileId: versionsFileTarget, version: v.version })
                        }
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </li>
                );
              })}
            </ul>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setVersionsFileTarget(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SuccessDialog
        open={feedback.type === 'success'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        description={feedback.message}
      />
      <ErrorDialog
        open={feedback.type === 'error'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        description={feedback.message}
      />
    </div>
  );
}

function FolderChip({ label, icon: Icon, active, onClick, menu }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'group flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm transition-colors',
        active ? 'bg-black text-white border-black' : 'bg-white text-foreground hover:bg-muted/60'
      )}
    >
      <Icon className="h-3.5 w-3.5" />
      <span className="max-w-[140px] truncate">{label}</span>
      {menu}
    </button>
  );
}