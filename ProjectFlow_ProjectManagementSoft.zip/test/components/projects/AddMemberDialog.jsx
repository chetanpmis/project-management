'use client';

import { useState } from 'react';
import { UserPlus, Search, AlertCircle, Loader2 } from 'lucide-react';
import { useMutation, useQuery } from '@tanstack/react-query';
import organizationService from '@/services/organization.service';
import projectService from '@/services/project.service';
import { useDebounce } from '@/hooks/useDebounce';
import { ROLE_OPTIONS, ROLE_META } from '@/constants/projectPermissions';
import { SuccessDialog, ErrorDialog } from '@/components/common/AppDialogs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';

export default function AddMemberDialog({ open, onOpenChange, projectId, orgSlug, existingMemberIds = [], onAdded }) {
  console.log("ORG SLUG ",orgSlug)
  const [query, setQuery] = useState('');
  const [role, setRole] = useState('member');
  const [feedback, setFeedback] = useState({ type: null, message: '' });
  const debouncedQuery = useDebounce(query, 400);

  const { data: membersRes, isFetching, isError } = useQuery({
    queryKey: ['organizationMembers', orgSlug, debouncedQuery],
    queryFn: () => organizationService.listMembers(orgSlug, { search: debouncedQuery, limit: 8 }),
    enabled: open && !!orgSlug,
  });

  const results = membersRes?.data || [];

  const addMemberMutation = useMutation({
    mutationFn: (user) => projectService.addTeamMember(projectId, { userId: user._id, role }),
    onSuccess: (_res, user) => {
      onAdded?.();
      setFeedback({ type: 'success', message: `${user.name} was added to the project.` });
    },
    onError: (err) => setFeedback({ type: 'error', message: err?.message || 'Could not add this member.' }),
  });

  const resetAndClose = (next) => {
    if (!next) {
      setQuery('');
      setRole('member');
    }
    onOpenChange(next);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={resetAndClose}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add team member</DialogTitle>
            <DialogDescription>
              Search for an organization member and give them a role on this project.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Role for new member</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLE_OPTIONS.map((r) => (
                    <SelectItem key={r} value={r} className="capitalize">
                      {ROLE_META[r].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">{ROLE_META[role].description}</p>
            </div>

            <div className="space-y-2">
              <Label>Search by name or email</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or email…"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="pl-9"
                  autoFocus
                />
              </div>
            </div>

            <div className="rounded-lg border border-border divide-y divide-border max-h-64 overflow-y-auto">
              {debouncedQuery.trim().length === 0 ? (
                <p className="px-4 py-6 text-sm text-muted-foreground text-center">Start typing a name or email to search.</p>
              ) : isFetching ? (
                <p className="px-4 py-6 text-sm text-muted-foreground flex items-center justify-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Searching…
                </p>
              ) : isError ? (
                <p className="px-4 py-6 text-sm text-red-500 flex items-center justify-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Could not search members.
                </p>
              ) : results.length > 0 ? (
                results.map((member) => {
                  const alreadyMember = existingMemberIds.includes(member.user?._id);
                  const isAddingThis =
                    addMemberMutation.isPending && addMemberMutation.variables?._id === member.user?._id;
                  return (
                    <button
                      type="button"
                      key={member.user?._id || member._id}
                      disabled={alreadyMember || addMemberMutation.isPending}
                      onClick={() => addMemberMutation.mutate(member.user)}
                      className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-muted/50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar className="h-9 w-9 shrink-0 border">
                          {member.user?.avatar && <AvatarImage src={member.user.avatar} alt={member.user?.name} />}
                          <AvatarFallback className="text-xs font-semibold">
                            {member.user?.name?.slice(0, 2)?.toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{member.user?.name}</p>
                          <p className="text-xs text-muted-foreground truncate">{member.user?.email}</p>
                        </div>
                      </div>
                      {alreadyMember ? (
                        <Badge variant="outline" className="shrink-0 text-xs">Already added</Badge>
                      ) : isAddingThis ? (
                        <Loader2 className="h-4 w-4 text-muted-foreground animate-spin shrink-0" />
                      ) : (
                        <UserPlus className="h-4 w-4 text-muted-foreground shrink-0" />
                      )}
                    </button>
                  );
                })
              ) : (
                <p className="px-4 py-6 text-sm text-muted-foreground text-center">No matching people</p>
              )}
            </div>

            {addMemberMutation.isError && (
              <p className="text-red-500 text-sm flex items-center gap-1">
                <AlertCircle className="h-3.5 w-3.5" />
                {addMemberMutation.error?.message || 'Could not add member'}
              </p>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => resetAndClose(false)}>
              Done
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SuccessDialog
        open={feedback.type === 'success'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        title="Member added"
        description={feedback.message}
      />
      <ErrorDialog
        open={feedback.type === 'error'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        description={feedback.message}
      />
    </>
  );
}