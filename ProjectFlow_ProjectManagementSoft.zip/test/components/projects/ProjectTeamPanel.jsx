'use client';

import { useMemo, useState } from 'react';
import { useParams } from 'next/navigation';
import { useQueryClient } from '@tanstack/react-query';
import { UserPlus, Users2, ShieldCheck, Crown, Wrench, User, Eye } from 'lucide-react';

import AddMemberDialog from '@/components/projects/AddMemberDialog';
import TeamPermissionsPanel from '@/components/projects/TeamPermissionsPanel';
import PermissionGate from '@/lib/permissionGate';
import { usePermission } from '@/hooks/usePermission';
import { PROJECT_PERMISSIONS, ROLE_META } from '@/constants/projectPermissions';
import StatCard, { StatCardGrid } from '@/components/common/StatCard';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const ROLE_ICONS = { owner: Crown, manager: Wrench, member: User, viewer: Eye };

export default function ProjectTeamPanel({ project, isLoading, onChanged }) {
  const { orgSlug } = useParams();
  const queryClient = useQueryClient();
  const canInvite = usePermission(project, PROJECT_PERMISSIONS.TEAM_INVITE);

  const [addMemberOpen, setAddMemberOpen] = useState(false);
  const team = project?.team || [];

  const roleCounts = useMemo(() => {
    const counts = { owner: 0, manager: 0, member: 0, viewer: 0 };
    team.forEach((m) => {
      if (counts[m.role] !== undefined) counts[m.role]++;
    });
    return counts;
  }, [team]);

  const existingMemberIds = useMemo(() => team.map((m) => m.user?._id).filter(Boolean), [team]);

  const handleAdded = () => {
    queryClient.invalidateQueries({ queryKey: ['project', project?._id] });
    onChanged?.();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Users2 className="h-4.5 w-4.5 text-primary" />
            Team Overview
          </CardTitle>
        </CardHeader>

        <CardContent>
          <StatCardGrid columns={4}>
            {['owner', 'manager', 'member', 'viewer'].map((role) => {
              const Icon = ROLE_ICONS[role];
              return (
                <StatCard
                  key={role}
                  title={ROLE_META[role]?.label || role}
                  value={roleCounts[role]}
                  icon={Icon}
                  color={
                    role === 'owner' ? 'text-violet-600' : role === 'manager' ? 'text-blue-600' : role === 'member' ? 'text-emerald-600' : 'text-slate-600'
                  }
                  loading={isLoading}
                />
              );
            })}
          </StatCardGrid>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <ShieldCheck className="h-4 w-4" />
          Manage roles and fine tune member permissions.
        </div>

        <PermissionGate project={project} permission={PROJECT_PERMISSIONS.TEAM_INVITE} inline>
          <Button onClick={() => setAddMemberOpen(true)}>
            <UserPlus className="mr-2 h-4 w-4" />
            Add Member
          </Button>
        </PermissionGate>
      </div>

      <TeamPermissionsPanel project={project} isLoading={isLoading} onChanged={onChanged} />

      {canInvite && (
        <AddMemberDialog
          open={addMemberOpen}
          onOpenChange={setAddMemberOpen}
          projectId={project?._id}
          orgSlug={orgSlug}
          existingMemberIds={existingMemberIds}
          onAdded={handleAdded}
        />
      )}
    </div>
  );
}