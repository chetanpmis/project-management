'use client';

import { useState, useRef, useEffect, useMemo, useLayoutEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import EmojiPicker from 'emoji-picker-react';
import { Send, X, Pencil, Trash2, CornerUpLeft, Smile, ChevronDown, Loader2, Lock } from 'lucide-react';
import chatService from '@/services/chat.service';
import { useChatMessages } from '@/hooks/useChatMessages';
import { usePermission } from '@/hooks/usePermission';
import { PROJECT_PERMISSIONS } from '@/constants/projectPermissions';
import { Button } from '@/components/ui/button';
import { ChatMessageSkeleton } from '@/components/common/ChatSkeleton';
import EmptyState from '@/components/feedback/EmptyState';
import Tooltip from '@/components/common/Tooltip';
import { useProjectChatSocket } from '@/hooks/useProjectChatSocket';
import useAuthStore from '@/store/auth-store';
import { formatChatTime, formatDateDivider, isSameDay } from '@/lib/formatChatTime';

const getInitials = (name) => (!name ? 'U' : name.split(' ').map((w) => w[0]).join('').toUpperCase().slice(0, 2));

const EDIT_WINDOW_MS = 10 * 60 * 1000;
const withinEditWindow = (msg) => Date.now() - new Date(msg.createdAt).getTime() < EDIT_WINDOW_MS;

export default function ProjectChatTab({ project }) {
  const queryClient = useQueryClient();
  const currentUser = useAuthStore((s) => s.user);

  const canView = usePermission(project, PROJECT_PERMISSIONS.CHAT_VIEW);
  const canSend = usePermission(project, PROJECT_PERMISSIONS.CHAT_SEND);
  const canEdit = usePermission(project, PROJECT_PERMISSIONS.CHAT_EDIT);
  const canDelete = usePermission(project, PROJECT_PERMISSIONS.CHAT_DELETE);

  const { emitTyping, typingUsers } = useProjectChatSocket(canView ? project._id : null);

  const [input, setInput] = useState('');
  const [mentionQuery, setMentionQuery] = useState(null);
  const [mentionedUsers, setMentionedUsers] = useState([]);
  const [replyTo, setReplyTo] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [openEmojiFor, setOpenEmojiFor] = useState(null);
  const [showJumpButton, setShowJumpButton] = useState(false);
  const [newSinceScroll, setNewSinceScroll] = useState(0);
  const [, forceTick] = useState(0);

  const textareaRef = useRef(null);
  const scrollRef = useRef(null);
  const bottomRef = useRef(null);
  const topSentinelRef = useRef(null);
  const emojiPanelRef = useRef(null);
  const isNearBottomRef = useRef(true);
  const prevScrollHeightRef = useRef(0);
  const hasDoneInitialScroll = useRef(false);
  const justSentRef = useRef(false);
  const lastMessageIdRef = useRef(null);

  const { messages, isLoading, isFetchingOlder, hasOlder, loadOlder } = useChatMessages(canView ? project._id : null);

  useEffect(() => {
    const t = setInterval(() => forceTick((n) => n + 1), 30000);
    return () => clearInterval(t);
  }, []);

  const teamMembers = useMemo(() => {
    const owner = project.owner ? [{ ...project.owner, role: 'owner' }] : [];
    const members = (project.team || []).map((t) => ({ ...t.user, role: t.role }));
    const seen = new Set();
    return [...owner, ...members].filter((u) => {
      if (!u?._id || seen.has(u._id)) return false;
      seen.add(u._id);
      return true;
    });
  }, [project]);

  const firstUnreadIndex = useMemo(() => {
    return messages.findIndex(
      (m) => m.author?._id !== currentUser?.id && !m.readBy?.some((r) => r.user?._id === currentUser?.id)
    );
  }, [messages, currentUser?.id]);

  const scrollToBottom = (behavior = 'smooth') => {
    bottomRef.current?.scrollIntoView({ behavior });
    setShowJumpButton(false);
    setNewSinceScroll(0);
  };

  useEffect(() => {
    if (isLoading || messages.length === 0) return;
    const currentLastId = messages[messages.length - 1]._id;

    if (!hasDoneInitialScroll.current) {
      scrollToBottom('auto');
      hasDoneInitialScroll.current = true;
      lastMessageIdRef.current = currentLastId;
      return;
    }

    if (currentLastId === lastMessageIdRef.current) return;
    lastMessageIdRef.current = currentLastId;

    if (justSentRef.current) {
      justSentRef.current = false;
      scrollToBottom();
    } else if (isNearBottomRef.current) {
      scrollToBottom();
    } else {
      setShowJumpButton(true);
      setNewSinceScroll((n) => n + 1);
    }
  }, [messages, isLoading]);

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el || !isFetchingOlder) return;
    prevScrollHeightRef.current = el.scrollHeight;
  }, [isFetchingOlder]);

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el || prevScrollHeightRef.current === 0) return;
    el.scrollTop = el.scrollHeight - prevScrollHeightRef.current;
    prevScrollHeightRef.current = 0;
  }, [messages.length]);

  useEffect(() => {
    if (!canView) return;
    chatService.markRead(project._id).then(() => {
      queryClient.invalidateQueries({ queryKey: ['chat', project._id, 'unreadCount'] });
    }).catch(() => {});
  }, [project._id, canView]);

  useEffect(() => {
    const el = scrollRef.current;
    const sentinel = topSentinelRef.current;
    if (!el || !sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasOlder && !isFetchingOlder) loadOlder();
      },
      { root: el, threshold: 0 }
    );
    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasOlder, isFetchingOlder, loadOlder]);

  useEffect(() => {
    if (!openEmojiFor) return;
    const handleClickOutside = (e) => {
      if (emojiPanelRef.current && !emojiPanelRef.current.contains(e.target)) setOpenEmojiFor(null);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [openEmojiFor]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const nearBottom = distanceFromBottom < 120;
    isNearBottomRef.current = nearBottom;
    if (nearBottom) {
      setShowJumpButton(false);
      setNewSinceScroll(0);
    }
  };

  const filteredMentionCandidates = useMemo(() => {
    if (mentionQuery === null) return [];
    const q = mentionQuery.toLowerCase();
    return teamMembers.filter((u) => u.name?.toLowerCase().includes(q)).slice(0, 6);
  }, [mentionQuery, teamMembers]);

  const handleInputChange = (e) => {
    const value = e.target.value;
    setInput(value);
    emitTyping();
    const caret = e.target.selectionStart;
    const match = value.slice(0, caret).match(/@([a-zA-Z0-9._ ]*)$/);
    setMentionQuery(match ? match[1] : null);
  };

  const insertMention = (user) => {
    const caret = textareaRef.current.selectionStart;
    const replaced = input.slice(0, caret).replace(/@([a-zA-Z0-9._ ]*)$/, `@${user.name} `);
    setInput(replaced + input.slice(caret));
    setMentionedUsers((prev) => (prev.some((u) => u._id === user._id) ? prev : [...prev, user]));
    setMentionQuery(null);
    textareaRef.current?.focus();
  };

  const handleEmojiClick = (emojiData) => {
    if (openEmojiFor === 'composer') {
      setInput((prev) => prev + emojiData.emoji);
      textareaRef.current?.focus();
    } else if (openEmojiFor) {
      handleToggleReaction(openEmojiFor, emojiData.emoji, { keepOpen: true });
    }
  };

  const resetComposer = () => {
    setInput('');
    setMentionedUsers([]);
    setReplyTo(null);
    setEditingId(null);
    setMentionQuery(null);
  };

  const handleSend = async () => {
    if (!canSend || !input.trim()) return;
    const activeMentions = mentionedUsers.filter((u) => input.includes(`@${u.name}`));
    justSentRef.current = true;

    if (editingId) {
      if (!canEdit) return;
      await chatService.editMessage(editingId, { content: input.trim(), mentions: activeMentions.map((u) => u._id) });
    } else {
      await chatService.sendMessage(project._id, {
        content: input.trim(),
        mentions: activeMentions.map((u) => u._id),
        replyTo: replyTo?._id || null,
      });
    }
    resetComposer();
  };

  const handleKeyDown = (e) => {
    if (!canSend) return;
    if (e.key === 'Enter' && !e.shiftKey && mentionQuery === null) {
      e.preventDefault();
      handleSend();
    }
    if (e.key === 'Escape') {
      setMentionQuery(null);
      setOpenEmojiFor(null);
    }
  };

  const startEdit = (msg) => {
    if (!canEdit || !withinEditWindow(msg)) return;
    setEditingId(msg._id);
    setInput(msg.content);
    setMentionedUsers(msg.mentions || []);
    textareaRef.current?.focus();
  };

  const handleDelete = async (messageId) => {
    if (!canDelete) return;
    await chatService.deleteMessage(messageId);
  };

  const handleToggleReaction = async (messageId, emoji, { keepOpen = false } = {}) => {
    if (!canSend) return;
    await chatService.reactToMessage(messageId, emoji);
    if (!keepOpen) setOpenEmojiFor(null);
  };

  const renderContent = (msg, isOwn) => {
    if (!msg.mentions?.length) return msg.content;
    const mentionClass = isOwn
      ? 'text-blue-400 font-semibold'
      : 'text-blue-600 font-semibold bg-blue-50 rounded px-1';

    let parts = [msg.content];
    msg.mentions.forEach((user) => {
      const token = `@${user.name}`;
      parts = parts.flatMap((part) =>
        typeof part !== 'string'
          ? [part]
          : part.split(token).flatMap((chunk, i, arr) =>
              i < arr.length - 1
                ? [chunk, <span key={`${user._id}-${i}`} className={mentionClass}>{token}</span>]
                : [chunk]
            )
      );
    });
    return parts;
  };

  const lastMessage = messages[messages.length - 1];

  if (!canView) {
    return (
     
        <EmptyState
          compact
          icon={<Lock className="h-6 w-6" />}
          title="You don't have access to this chat"
          description="Ask a project owner or manager to grant you chat access."
        />
   
    );
  }

  return (
    <div className="flex flex-col border rounded-lg bg-white relative overflow-hidden">
      <div ref={scrollRef} onScroll={handleScroll} className="flex-1 overflow-y-auto">
        {isLoading ? (
          <ChatMessageSkeleton count={6} />
        ) : messages.length === 0 ? (
          <EmptyState
            compact
            title="No messages yet"
            description={canSend ? 'Start the conversation — tag a teammate with @ to notify them.' : 'No messages have been posted yet.'}
          />
        ) : (
          <div className="p-4 space-y-1">
            <div ref={topSentinelRef} className="h-1" />

            {isFetchingOlder && (
              <div className="flex justify-center py-2">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              </div>
            )}

            {!hasOlder && messages.length > 0 && (
              <div className="text-center text-[11px] text-muted-foreground py-2">Start of conversation</div>
            )}

            {messages.map((msg, idx) => {
              const isOwn = msg.author?._id === currentUser?.id;
              const isLast = msg._id === lastMessage?._id;
              const showUnreadDivider = idx === firstUnreadIndex && firstUnreadIndex > 0;
              const showAvatar = idx === 0 || messages[idx - 1].author?._id !== msg.author?._id;
              const showDateDivider = idx === 0 || !isSameDay(messages[idx - 1].createdAt, msg.createdAt);
              const viewers = (msg.readBy || []).filter((r) => r.user?._id !== msg.author?._id);
              const canEditThis = canEdit && isOwn && !msg.isDeleted && withinEditWindow(msg);
              const canDeleteThis = canDelete && !msg.isDeleted;
              const showHoverActions = canSend || canEdit || canDelete;

              return (
                <div key={msg._id}>
                  {showDateDivider && (
                    <div className="flex items-center justify-center my-4">
                      <span className="text-[11px] font-medium text-zinc-500 bg-zinc-100 rounded-full px-3 py-1">
                        {formatDateDivider(msg.createdAt)}
                      </span>
                    </div>
                  )}

                  {showUnreadDivider && (
                    <div className="flex items-center gap-2 my-3">
                      <div className="flex-1 h-px bg-red-200" />
                      <span className="text-[11px] font-medium text-red-500 uppercase tracking-wide">New messages</span>
                      <div className="flex-1 h-px bg-red-200" />
                    </div>
                  )}

                  <div className={`flex gap-3 group ${isOwn ? 'flex-row-reverse' : ''} ${showAvatar ? 'mt-3' : 'mt-0.5'}`}>
                    <div className="w-8 shrink-0">
                      {showAvatar && (
                        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white text-xs font-semibold">
                          {getInitials(msg.author?.name)}
                        </div>
                      )}
                    </div>

                    <div className={`max-w-[70%] flex flex-col ${isOwn ? 'items-end' : 'items-start'}`}>
                      {showAvatar && (
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-xs font-medium text-zinc-700">{isOwn ? 'You' : msg.author?.name}</span>
                          <Tooltip content={new Date(msg.createdAt).toLocaleString()}>
                            <span className="text-[11px] text-muted-foreground cursor-default">{formatChatTime(msg.createdAt)}</span>
                          </Tooltip>
                          {msg.edited && !msg.isDeleted && <span className="text-[11px] text-muted-foreground">· edited</span>}
                        </div>
                      )}

                      {msg.replyTo && !msg.isDeleted && (
                        <div className="text-xs bg-zinc-50 border-l-2 border-zinc-300 px-2 py-1 rounded mb-1 max-w-full truncate text-muted-foreground">
                          Replying to {msg.replyTo.author?.name}: {msg.replyTo.isDeleted ? 'deleted message' : msg.replyTo.content}
                        </div>
                      )}

                      {msg.isDeleted ? (
                        <div className="rounded-2xl px-3.5 py-2 text-sm italic text-muted-foreground bg-zinc-50 border border-dashed border-zinc-200">
                          This message was deleted
                        </div>
                      ) : (
                        <div className="relative">
                          <div
                            className={`rounded-2xl px-3.5 py-2 text-sm ${
                              isOwn ? 'bg-black text-white' : 'bg-zinc-100 text-zinc-900'
                            }`}
                          >
                            {renderContent(msg, isOwn)}
                          </div>

                          {msg.reactions?.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1">
                              {msg.reactions.map((r) => {
                                const iReacted = r.users.some((u) => u._id === currentUser?.id);
                                return (
                                  <button
                                    key={r.emoji}
                                    disabled={!canSend}
                                    onClick={() => handleToggleReaction(msg._id, r.emoji)}
                                    className={`text-xs rounded-full px-2 py-0.5 border flex items-center gap-1 transition ${
                                      iReacted ? 'bg-blue-50 border-blue-300' : 'bg-white border-zinc-200 hover:border-zinc-300'
                                    } ${!canSend ? 'cursor-default opacity-70' : ''}`}
                                  >
                                    <span>{r.emoji}</span>
                                    <span className="text-[10px] text-muted-foreground">{r.users.length}</span>
                                  </button>
                                );
                              })}
                            </div>
                          )}

                          {showHoverActions && (
                            <div className={`hidden group-hover:flex gap-1 mt-1 items-center ${isOwn ? 'justify-end' : ''}`}>
                              {canSend && (
                                <div className="relative">
                                  <button
                                    onClick={() => setOpenEmojiFor(openEmojiFor === msg._id ? null : msg._id)}
                                    className="text-muted-foreground hover:text-foreground"
                                  >
                                    <Smile className="h-3.5 w-3.5" />
                                  </button>

                                  {openEmojiFor === msg._id && (
                                    <div ref={emojiPanelRef} className="absolute bottom-full mb-1 left-0 z-30 shadow-xl rounded-xl overflow-hidden">
                                      <div className="flex justify-end bg-white border-b px-1.5 py-1">
                                        <button onClick={() => setOpenEmojiFor(null)} className="text-zinc-400 hover:text-zinc-600">
                                          <X className="h-3.5 w-3.5" />
                                        </button>
                                      </div>
                                      <EmojiPicker onEmojiClick={handleEmojiClick} width={300} height={360} lazyLoadEmojis previewConfig={{ showPreview: false }} />
                                    </div>
                                  )}
                                </div>
                              )}
                              {canSend && (
                                <button onClick={() => setReplyTo(msg)} className="text-[11px] text-muted-foreground hover:text-foreground flex items-center gap-1">
                                  <CornerUpLeft className="h-3 w-3" /> Reply
                                </button>
                              )}
                              {canEditThis && (
                                <button onClick={() => startEdit(msg)} className="text-[11px] text-muted-foreground hover:text-foreground flex items-center gap-1">
                                  <Pencil className="h-3 w-3" /> Edit
                                </button>
                              )}
                              {canDeleteThis && (
                                <button onClick={() => handleDelete(msg._id)} className="text-[11px] text-red-500 hover:text-red-600 flex items-center gap-1">
                                  <Trash2 className="h-3 w-3" /> Delete
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      )}

                      {isLast && !msg.isDeleted && viewers.length > 0 && (
                        <Tooltip
                          content={
                            <div className="space-y-0.5">
                              {viewers.map((v) => (
                                <div key={v.user._id}>{v.user.name} · {formatChatTime(v.readAt)}</div>
                              ))}
                            </div>
                          }
                        >
                          <div className="flex items-center mt-1 cursor-default">
                            <div className="flex -space-x-1.5">
                              {viewers.slice(0, 2).map((v) => (
                                <div key={v.user._id} className="h-4 w-4 rounded-full bg-zinc-300 border border-white flex items-center justify-center text-[8px] font-semibold text-white">
                                  {getInitials(v.user.name)}
                                </div>
                              ))}
                            </div>
                            {viewers.length > 2 && <span className="text-[10px] text-muted-foreground ml-1">+{viewers.length - 2}</span>}
                            <span className="text-[10px] text-muted-foreground ml-1">Seen</span>
                          </div>
                        </Tooltip>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>
        )}

        {canSend && typingUsers.length > 0 && (
          <div className="px-4 pb-2 text-xs text-muted-foreground italic flex items-center gap-1.5">
            <span className="flex gap-0.5">
              <span className="h-1.5 w-1.5 rounded-full bg-zinc-400 animate-bounce [animation-delay:-0.3s]" />
              <span className="h-1.5 w-1.5 rounded-full bg-zinc-400 animate-bounce [animation-delay:-0.15s]" />
              <span className="h-1.5 w-1.5 rounded-full bg-zinc-400 animate-bounce" />
            </span>
            {typingUsers.map((u) => u.userName).join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing…
          </div>
        )}
      </div>

      {canSend && showJumpButton && (
        <button
          onClick={() => scrollToBottom()}
          className="absolute bottom-24 right-4 flex items-center gap-1.5 bg-zinc-900 text-white text-xs px-3 py-1.5 rounded-full shadow-lg hover:bg-zinc-800 transition"
        >
          <ChevronDown className="h-3.5 w-3.5" />
          {newSinceScroll > 0 ? `${newSinceScroll} new` : 'Jump to latest'}
        </button>
      )}

      {canSend && (replyTo || editingId) && (
        <div className="flex items-center justify-between px-4 py-1.5 bg-zinc-50 border-t text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            {editingId ? <Pencil className="h-3 w-3" /> : <CornerUpLeft className="h-3 w-3" />}
            {editingId ? 'Editing message' : `Replying to ${replyTo.author?.name}`}
          </span>
          <button onClick={resetComposer}><X className="h-3.5 w-3.5" /></button>
        </div>
      )}

      {canSend ? (
        <div className="relative border-t p-3">
          {filteredMentionCandidates.length > 0 && (
            <div className="absolute bottom-full left-3 mb-1 w-64 rounded-lg border bg-white shadow-lg overflow-hidden z-10">
              {filteredMentionCandidates.map((user) => (
                <button key={user._id} onClick={() => insertMention(user)} className="w-full flex items-center gap-2 px-3 py-2 text-sm hover:bg-zinc-50 text-left">
                  <div className="h-6 w-6 rounded-full bg-linear-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white text-[10px] font-semibold shrink-0">
                    {getInitials(user.name)}
                  </div>
                  <span>{user.name}</span>
                  <span className="text-xs text-muted-foreground capitalize ml-auto">{user.role}</span>
                </button>
              ))}
            </div>
          )}

          {openEmojiFor === 'composer' && (
            <div ref={emojiPanelRef} className="absolute bottom-full left-3 mb-1 z-10 shadow-xl rounded-xl overflow-hidden">
              <div className="flex justify-end bg-white border-b px-1.5 py-1">
                <button onClick={() => setOpenEmojiFor(null)} className="text-zinc-400 hover:text-zinc-600">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              <EmojiPicker onEmojiClick={handleEmojiClick} width={320} height={380} lazyLoadEmojis previewConfig={{ showPreview: false }} />
            </div>
          )}

          <div className="flex items-end gap-2">
            <button
              onClick={() => setOpenEmojiFor(openEmojiFor === 'composer' ? null : 'composer')}
              className="h-9 w-9 shrink-0 rounded-full flex items-center justify-center text-zinc-400 hover:text-zinc-600 hover:bg-zinc-50"
            >
              <Smile className="h-5 w-5" />
            </button>
            <textarea
              ref={textareaRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Message the team — use @ to tag someone"
              rows={1}
              className="flex-1 resize-none rounded-xl border border-zinc-200 px-3.5 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-black max-h-32"
            />
            <Button size="icon" onClick={handleSend} disabled={!input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 border-t px-4 py-3 text-xs text-muted-foreground">
          <Lock className="h-3.5 w-3.5" />
          You have read-only access to this chat.
        </div>
      )}
    </div>
  );
}