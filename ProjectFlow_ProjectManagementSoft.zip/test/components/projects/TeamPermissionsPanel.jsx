'use client';

import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { ShieldCheck, ChevronDown, Loader2, Settings2, UserMinus } from 'lucide-react';
import projectService from '@/services/project.service';
import { usePermission, useIsOwner } from '@/hooks/usePermission';
import { PROJECT_PERMISSIONS, ROLE_OPTIONS, ROLE_META, PERMISSION_GROUPS } from '@/constants/projectPermissions';
import PermissionGate from '@/lib/permissionGate';
import EmptyState from '@/components/feedback/EmptyState';
import { CardListSkeleton } from '@/components/common/Skeletons';
import { SuccessDialog, ErrorDialog, ConfirmDialog } from '@/components/common/AppDialogs';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Users2 } from 'lucide-react';
import { cn } from '@/lib/utils';

function MemberPermissionCard({ project, member, isProjectOwner, canEditRole, canEditPermissions, onSaved, onError, onChanged }) {
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState(false);
  const [role, setRole] = useState(member.role);
  // Effective permissions are always exactly what the server stored for
  // this member — never a client-guessed role default.
  const [permissions, setPermissions] = useState(member.permissions || []);
  const [removeOpen, setRemoveOpen] = useState(false);

  const updateMutation = useMutation({
    mutationFn: (payload) => projectService.updateTeamMember(project._id, member.user._id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project', project._id] });
      onSaved?.(`Updated permissions for ${member.user?.name}.`);
      onChanged?.();
    },
    onError: (err) => onError?.(err?.message || 'Could not update this member.'),
  });

  const removeMutation = useMutation({
    mutationFn: () => projectService.removeTeamMember(project._id, member.user._id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project', project._id] });
      setRemoveOpen(false);
      onSaved?.(`${member.user?.name} was removed from the project.`);
      onChanged?.();
    },
    onError: (err) => {
      setRemoveOpen(false);
      onError?.(err?.message || 'Could not remove this member.');
    },
  });

  const togglePermission = (key) => {
    setPermissions((prev) => (prev.includes(key) ? prev.filter((p) => p !== key) : [...prev, key]));
  };

  const handleRoleChange = (nextRole) => setRole(nextRole);

  const hasChanges =
    role !== member.role ||
    JSON.stringify([...permissions].sort()) !== JSON.stringify([...(member.permissions || [])].sort());

  const handleSave = () => {
    const payload = {};
    if (role !== member.role) payload.role = role;
    if (JSON.stringify([...permissions].sort()) !== JSON.stringify([...(member.permissions || [])].sort())) {
      payload.permissions = permissions;
    }
    updateMutation.mutate(payload);
  };

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-center gap-4 flex-wrap sm:flex-nowrap">
          <Avatar className="h-12 w-12 shrink-0 border">
            <AvatarFallback className="text-sm font-semibold">{member.user?.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
          </Avatar>

          <div className="min-w-0 flex-1">
            <p className="font-semibold truncate">{member.user?.name}</p>
            <p className="text-sm text-muted-foreground truncate">{member.user?.email}</p>
          </div>

          <div className="flex items-center gap-2 shrink-0 ml-auto">
            {member.role === 'owner' ? (
              <Badge variant="outline" className={ROLE_META.owner.badgeClass}>
                {ROLE_META.owner.label}
              </Badge>
            ) : canEditRole ? (
              <Select value={role} onValueChange={handleRoleChange}>
                <SelectTrigger className="w-[130px] h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROLE_OPTIONS.map((r) => (
                    <SelectItem key={r} value={r} className="capitalize">
                      {ROLE_META[r].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Badge variant="outline" className={ROLE_META[member.role]?.badgeClass}>
                {ROLE_META[member.role]?.label || member.role}
              </Badge>
            )}

            {member.role !== 'owner' && (
              <Button
                variant="outline"
                size="sm"
                className="gap-1.5"
                onClick={() => setExpanded((v) => !v)}
              >
                <Settings2 className="h-3.5 w-3.5" />
                Permissions
                <ChevronDown className={cn('h-3.5 w-3.5 transition-transform', expanded && 'rotate-180')} />
              </Button>
            )}
          </div>
        </div>

        {member.role === 'owner' && (
          <p className="text-sm text-muted-foreground mt-3 pl-16">{`Full access to every permission. This can't be changed.`}</p>
        )}

        {member.role !== 'owner' && expanded && (
          <div className="mt-5 pl-0 sm:pl-16 space-y-4 border-t pt-4">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Permissions</p>

            <div className="grid sm:grid-cols-2 gap-x-8 gap-y-4">
              {PERMISSION_GROUPS.map((group) => (
                <div key={group.id} className="space-y-1.5">
                  <p className="text-xs font-semibold text-muted-foreground">{group.label}</p>
                  {group.permissions.map((perm) => (
                    <label key={perm.key} className={cn('flex items-center gap-2 text-sm py-0.5', canEditPermissions ? 'cursor-pointer' : 'cursor-not-allowed opacity-70')}>
                      <Checkbox
                        checked={permissions.includes(perm.key)}
                        disabled={!canEditPermissions}
                        onCheckedChange={() => togglePermission(perm.key)}
                      />
                      {perm.label}
                    </label>
                  ))}
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-2 border-t flex-wrap gap-2">
              <PermissionGate project={project} permission={PROJECT_PERMISSIONS.TEAM_REMOVE} inline>
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-1.5 text-red-600 hover:text-red-700 hover:bg-red-50"
                  onClick={() => setRemoveOpen(true)}
                >
                  <UserMinus className="h-3.5 w-3.5" />
                  Remove from project
                </Button>
              </PermissionGate>

              {(canEditRole || canEditPermissions) && (
                <Button
                  size="sm"
                  disabled={!hasChanges || updateMutation.isPending}
                  onClick={handleSave}
                >
                  {updateMutation.isPending && <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />}
                  Save changes
                </Button>
              )}
            </div>
          </div>
        )}
      </CardContent>

      <ConfirmDialog
        open={removeOpen}
        onOpenChange={setRemoveOpen}
        title="Remove team member?"
        description={`${member.user?.name} will lose access to this project immediately.`}
        confirmLabel="Remove"
        loading={removeMutation.isPending}
        onConfirm={() => removeMutation.mutate()}
      />
    </Card>
  );
}

/**
 * <TeamPermissionsPanel project={project} isLoading={isLoading} onChanged={invalidateProject} />
 */
export default function TeamPermissionsPanel({ project, isLoading, onChanged }) {
  const isOwner = useIsOwner(project);
  const canEditRole = usePermission(project, PROJECT_PERMISSIONS.TEAM_ROLE_EDIT);
  const canEditPermissions = usePermission(project, PROJECT_PERMISSIONS.TEAM_PERMISSIONS_EDIT);
  const [feedback, setFeedback] = useState({ type: null, message: '' });

  if (isLoading) {
    return <CardListSkeleton count={4} height="h-24" />;
  }

  const members = project?.team || [];

  return (
    <PermissionGate
      project={project}
      permission={PROJECT_PERMISSIONS.TEAM_VIEW}
      title="You can't view the team for this project"
      description="Ask a project owner or manager to grant you team access."
    >
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <ShieldCheck className="h-4 w-4" />
          {canEditRole || canEditPermissions
            ? 'Change roles or fine-tune individual permissions per member.'
            : 'Viewing roles only — you need team edit access to change permissions.'}
        </div>

        {members.length === 0 ? (
          <EmptyState
            compact
            icon={<Users2 className="h-6 w-6" />}
            title="No team members yet"
            description="Add people to this project from the team tab to manage their permissions here."
          />
        ) : (
          <div className="space-y-3">
            {members.map((m) => (
              <MemberPermissionCard
                key={m.user?._id || m._id}
                project={project}
                member={m}
                isProjectOwner={isOwner}
                canEditRole={canEditRole}
                canEditPermissions={canEditPermissions}
                onSaved={(msg) => setFeedback({ type: 'success', message: msg })}
                onError={(msg) => setFeedback({ type: 'error', message: msg })}
                onChanged={onChanged}
              />
            ))}
          </div>
        )}
      </div>

      <SuccessDialog
        open={feedback.type === 'success'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        title="Team updated"
        description={feedback.message}
      />
      <ErrorDialog
        open={feedback.type === 'error'}
        onOpenChange={(v) => !v && setFeedback({ type: null, message: '' })}
        description={feedback.message}
      />
    </PermissionGate>
  );
}