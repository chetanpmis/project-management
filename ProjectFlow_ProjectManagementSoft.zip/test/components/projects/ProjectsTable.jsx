'use client';

import { useState, useMemo } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQueryClient } from '@tanstack/react-query';
import { ChevronUp, ChevronDown, Eye, Trash2, Edit2, Users2, AlertCircle } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import Tooltip from '@/components/common/Tooltip';
import projectService from '@/services/project.service';
import { ProjectStatusBadge, PriorityBadge } from '@/components/common/StatusBadges';
import { TableSkeleton } from '@/components/common/Skeletons';
import EmptyState from '@/components/feedback/EmptyState';
import { SuccessDialog, ErrorDialog, ConfirmDialog, useMutationFeedback } from '@/components/common/AppDialogs';
import Pagination, { usePagedList } from '@/components/common/Pagination';
import { PROJECT_PERMISSIONS } from '@/constants/projectPermissions';
import { FolderKanban } from 'lucide-react';
import { formatDate } from '../../lib/date';

const COLUMNS = 8;

const isOverdue = (project) =>
  !!(project.endDate && new Date(project.endDate) < new Date() && project.status !== 'completed' && project.status !== 'cancelled');

const can = (project, permission) => !!project?.currentUserPermissions?.can?.[permission];

export default function ProjectsTable({ projects = [], isLoading = false, onDeleted, onCreateProject }) {
  const { orgSlug } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const feedback = useMutationFeedback();

  const projectPath = (projectId, suffix = '') => `/${orgSlug}/projects/${projectId}${suffix}`;

  const [sortField, setSortField] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const visibleProjects = useMemo(
    () => projects.filter((p) => can(p, PROJECT_PERMISSIONS.PROJECT_VIEW)),
    [projects]
  );

  const toggleSort = (field) => {
    if (sortField === field) {
      setSortOrder((o) => (o === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const sortedProjects = useMemo(() => {
    const list = [...visibleProjects];
    list.sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];
      if (sortField === 'name') {
        aVal = a.name?.toLowerCase() || '';
        bVal = b.name?.toLowerCase() || '';
      }
      if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
    return list;
  }, [visibleProjects, sortField, sortOrder]);

  const { paged, total, safePage } = usePagedList(sortedProjects, page, pageSize);

  const handleConfirmDelete = async () => {
    if (!deleteTarget) return;
    const name = deleteTarget.name;
    setIsDeleting(true);
    try {
      await feedback.run(projectService.deleteProject(deleteTarget._id), `${name} was deleted.`);
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      onDeleted?.();
    } catch {
    } finally {
      setIsDeleting(false);
      setDeleteTarget(null);
    }
  };

  const SortHead = ({ field, children, className }) => (
    <TableHead className={className}>
      <button type="button" onClick={() => toggleSort(field)} className="flex items-center gap-1 hover:text-foreground">
        {children}
        {sortField === field && (sortOrder === 'asc' ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />)}
      </button>
    </TableHead>
  );

  if (isLoading) {
    return <TableSkeleton rows={8} columns={COLUMNS} />;
  }

  if (visibleProjects.length === 0) {
    return (
      <EmptyState
        icon={<FolderKanban className="h-10 w-10" />}
        title="No projects yet"
        description="Get started by creating your first project."
        action={onCreateProject && <Button size="lg" onClick={onCreateProject}>New project</Button>}
      />
    );
  }

  return (
    <>
      <div className="rounded-2xl border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-35">Project Code</TableHead>
              <SortHead field="name">Name</SortHead>
              <TableHead>Type</TableHead>
              <SortHead field="status">Status</SortHead>
              <SortHead field="priority">Priority</SortHead>
              <SortHead field="endDate">Due Date</SortHead>
              <TableHead>Progress</TableHead>
              <TableHead className="w-25">Team</TableHead>
              <TableHead className="w-30 text-center">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paged.map((project) => {
              const canViewDetails = can(project, PROJECT_PERMISSIONS.PROJECT_DETAILS_VIEW);
              const canEdit = can(project, PROJECT_PERMISSIONS.PROJECT_EDIT);
              const canInvite = can(project, PROJECT_PERMISSIONS.TEAM_INVITE);
              const canDelete = can(project, PROJECT_PERMISSIONS.PROJECT_DELETE);

              return (
                <TableRow key={project._id} className="hover:bg-muted/50">
                  <TableCell className="font-mono text-xs">{project.projectCode}</TableCell>
                  <TableCell className="font-medium">
                    {canViewDetails ? (
                      <button onClick={() => router.push(projectPath(project._id))} className="hover:underline text-left">
                        {project.name}
                      </button>
                    ) : (
                      <span>{project.name}</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="capitalize">{project.projectType}</Badge>
                  </TableCell>
                  <TableCell><ProjectStatusBadge status={project.status} /></TableCell>
                  <TableCell><PriorityBadge priority={project.priority} /></TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5">
                      {formatDate(project.endDate)}
                      {isOverdue(project) && (
                        <Tooltip content="Past the due date">
                          <AlertCircle className="h-3.5 w-3.5 text-red-500" />
                        </Tooltip>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="h-2 w-20 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary" style={{ width: `${project.progress || 0}%` }} />
                      </div>
                      <span className="text-sm font-medium">{project.progress || 0}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center font-medium">{project.team?.length || 0}</TableCell>
                  <TableCell className="text-center">
                    <div className="flex items-center justify-center gap-1">
                      {canViewDetails && (
                        <Button variant="ghost" size="icon" onClick={() => router.push(projectPath(project._id))} title="View">
                          <Eye className="h-4 w-4 text-blue-600" />
                        </Button>
                      )}
                      {canEdit && (
                        <Button variant="ghost" size="icon" onClick={() => router.push(projectPath(project._id, '/edit'))} title="Edit">
                          <Edit2 className="h-4 w-4 text-amber-600" />
                        </Button>
                      )}
                      {/* {canInvite && (
                        <Button variant="ghost" size="icon" onClick={() => router.push(projectPath(project._id, '?tab=team'))} title="Manage team">
                          <Users2 className="h-4 w-4 text-purple-600" />
                        </Button>
                      )} */}
                      {canDelete && (
                        <Button variant="ghost" size="icon" onClick={() => setDeleteTarget(project)} title="Delete">
                          <Trash2 className="h-4 w-4 text-red-600" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>

        <Pagination page={safePage} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={(n) => { setPageSize(n); setPage(1); }} />
      </div>

      <ConfirmDialog
        open={!!deleteTarget}
        onOpenChange={(v) => !v && setDeleteTarget(null)}
        title="Delete project?"
        description={`"${deleteTarget?.name}" will be moved to trash and can be restored later.`}
        confirmLabel={isDeleting ? undefined : 'Delete'}
        loading={isDeleting}
        onConfirm={handleConfirmDelete}
      />

      <SuccessDialog {...feedback.successProps} title="Project deleted" />
      <ErrorDialog {...feedback.errorProps} title="Couldn't delete project" />
    </>
  );
}