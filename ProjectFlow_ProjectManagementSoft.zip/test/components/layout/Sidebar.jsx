// // components/Layout/Sidebar.jsx
// "use client";

// import { useState } from "react";
// import Link from "next/link";
// import { useParams, usePathname, useRouter } from "next/navigation";
// import { useQuery } from "@tanstack/react-query";
// import { motion, AnimatePresence } from "framer-motion";
// import {
//   LayoutDashboard,
//   FolderKanban,
//   CheckSquare,
//   Users,
//   Bell,
//   Settings,
//   Building2,
//   BarChart3,
//   ChevronDown,
//   ChevronRight,
//   Plus,
//   Check,
// } from "lucide-react";

// import useAuthStore from "@/store/auth-store";
// import useOrganizationStore from "@/store/organization-store";
// import organizationService from "@/services/organization.service";
// import { useOrgPermission } from "@/hooks/useOrgPermission";

// import Logo from "@/components/Layout/Logo";
// import { getInitials } from "../../lib/helpers/avatar";
// import useSidebarStore from "../../store/sidebar.store";

// export default function Sidebar() {
//   const pathname = usePathname();
//   const router = useRouter();
//   const { orgSlug } = useParams();
//   const [openMenu, setOpenMenu] = useState("Projects");
//   const [switcherOpen, setSwitcherOpen] = useState(false);
//   const { collapsed } = useSidebarStore();
//   const user = useAuthStore((state) => state.user);
//   const organization = useOrganizationStore((s) => s.organization);

//   const canCreateProject = useOrgPermission(organization, "project.create");

//   const { data: orgsRes } = useQuery({
//     queryKey: ["organizations"],
//     queryFn: organizationService.listOrganizations,
//   });
//   const orgs = orgsRes?.data || [];

//   const base = orgSlug ? `/${orgSlug}` : "";

//   // Same menu shape as before — only hrefs are now org-scoped, and
//   // "Create Project" is gated behind project.create permission.
//   const menus = [
//     { title: "Dashboard", icon: LayoutDashboard, href: `${base}/dashboard` },
//     { title: "Organization", icon: Building2, href: `${base}/organization` },
//     {
//       title: "Projects",
//       icon: FolderKanban,
//       children: [
//         { title: "All Projects", href: `${base}/projects` },
//         ...(canCreateProject ? [{ title: "Create Project", href: `${base}/projects/create` }] : []),
//       ],
//     },
//     {
//       title: "Tasks",
//       icon: CheckSquare,
//       children: [
//         { title: "My Tasks", href: `${base}/tasks` },
//         { title: "Calendar", href: `${base}/tasks/calendar` },
//       ],
//     },
//     { title: "Notifications", icon: Bell, href: `${base}/notifications` },
//   ];

//   const switchOrg = (slug) => {
//     setSwitcherOpen(false);
//     const rest = pathname.split("/").slice(2).join("/") || "dashboard";
//     router.push(`/${slug}/${rest}`);
//   };

//   return (
//     <aside
//       className={`hidden flex-col border-r border-zinc-200 bg-white transition-all duration-300 lg:flex ${
//         collapsed ? "w-20" : "w-72"
//       }`}
//     >
//       {/* Logo */}
//       <div className="flex h-20 items-center border-b border-zinc-200 px-6">
//         <Logo collapsed={collapsed} />
//       </div>

//       {/* Navigation */}
//       <div className="flex-1 overflow-y-auto p-4 space-y-1">
//         {menus.map((menu) => {
//           const Icon = menu.icon;
//           const isActive = pathname === menu.href;

//           if (!menu.children) {
//             return (
//               <Link
//                 key={menu.title}
//                 href={menu.href}
//                 className={`flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition-all ${
//                   isActive
//                     ? "bg-zinc-100 text-black font-semibold"
//                     : "text-zinc-700 hover:bg-zinc-100 hover:text-black"
//                 } ${collapsed ? "justify-center" : ""}`}
//                 title={collapsed ? menu.title : undefined}
//               >
//                 <Icon size={20} />
//                 {!collapsed && <span>{menu.title}</span>}
//               </Link>
//             );
//           }

//           const isOpen = openMenu === menu.title && !collapsed;

//           return (
//             <div key={menu.title}>
//               <button
//                 onClick={() => setOpenMenu(isOpen ? "" : menu.title)}
//                 className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium text-zinc-700 transition hover:bg-zinc-100 hover:text-black ${
//                   collapsed ? "justify-center" : "justify-between"
//                 }`}
//                 title={collapsed ? menu.title : undefined}
//               >
//                 <div className="flex items-center gap-3">
//                   <Icon size={20} />
//                   {!collapsed && <span>{menu.title}</span>}
//                 </div>
//                 {!collapsed && (isOpen ? <ChevronDown size={18} /> : <ChevronRight size={18} />)}
//               </button>

//               <AnimatePresence>
//                 {isOpen && !collapsed && (
//                   <motion.div
//                     initial={{ height: 0, opacity: 0 }}
//                     animate={{ height: "auto", opacity: 1 }}
//                     exit={{ height: 0, opacity: 0 }}
//                     className="overflow-hidden"
//                   >
//                     <div className="ml-9 mt-1 space-y-1 border-l border-zinc-200 pl-5">
//                       {menu.children.map((item) => (
//                         <Link
//                           key={item.href}
//                           href={item.href}
//                           className={`block rounded-xl px-4 py-2.5 text-sm transition ${
//                             pathname === item.href
//                               ? "bg-zinc-100 text-black font-medium"
//                               : "text-zinc-600 hover:bg-zinc-100 hover:text-black"
//                           }`}
//                         >
//                           {item.title}
//                         </Link>
//                       ))}
//                     </div>
//                   </motion.div>
//                 )}
//               </AnimatePresence>
//             </div>
//           );
//         })}
//       </div>

//       {/* Org switcher — Jira-style workspace picker */}
//       <div className="relative border-t border-zinc-200 p-4">
//         <button
//           onClick={() => setSwitcherOpen((v) => !v)}
//           className={`flex w-full items-center gap-3 rounded-2xl bg-zinc-100 p-3 hover:bg-zinc-200 transition ${
//             collapsed ? "justify-center" : "justify-between"
//           }`}
//           title={collapsed ? organization?.name : undefined}
//         >
//           <div className="flex items-center gap-2.5 min-w-0">
//             <div className="h-8 w-8 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
//               <Building2 size={16} />
//             </div>
//             {!collapsed && (
//               <div className="min-w-0 text-left">
//                 <p className="text-sm font-semibold text-black truncate">{organization?.name || "Select org"}</p>
//                 <p className="text-xs text-zinc-500 truncate">/{orgSlug}</p>
//               </div>
//             )}
//           </div>
//           {!collapsed && <ChevronDown size={16} className="shrink-0 text-zinc-500" />}
//         </button>

//         <AnimatePresence>
//           {switcherOpen && !collapsed && (
//             <motion.div
//               initial={{ opacity: 0, y: 6 }}
//               animate={{ opacity: 1, y: 0 }}
//               exit={{ opacity: 0, y: 6 }}
//               className="absolute bottom-full left-4 right-4 mb-2 rounded-2xl border border-zinc-200 bg-white shadow-lg overflow-hidden z-50"
//             >
//               <div className="max-h-56 overflow-y-auto p-1.5">
//                 {orgs.map((o) => (
//                   <button
//                     key={o._id}
//                     onClick={() => switchOrg(o.slug)}
//                     className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm hover:bg-zinc-100 transition"
//                   >
//                     <div className="h-7 w-7 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold">
//                       {o.logo ? <img src={o.logo} className="h-7 w-7 rounded-lg object-cover" /> : o.name?.[0]?.toUpperCase()}
//                     </div>
//                     <span className="flex-1 text-left truncate">{o.name}</span>
//                     {o.slug === orgSlug && <Check size={15} className="text-primary shrink-0" />}
//                   </button>
//                 ))}
//               </div>
//               <div className="border-t border-zinc-200 p-1.5">
//                 <button
//                   onClick={() => {
//                     setSwitcherOpen(false);
//                     router.push("/organizations/create");
//                   }}
//                   className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-zinc-700 hover:bg-zinc-100 transition"
//                 >
//                   <Plus size={16} className="shrink-0" />
//                   Create organization
//                 </button>
//               </div>
//             </motion.div>
//           )}
//         </AnimatePresence>
//       </div>

//       {/* User Footer */}
//       <div className="border-t border-zinc-200 p-4">
//         <div className={`rounded-3xl bg-zinc-100 p-4 ${collapsed ? "text-center" : ""}`}>
//           <div className="flex items-center gap-3">
//             <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-semibold text-lg flex-shrink-0">
//               {user?.name ? getInitials(user.name) : "U"}
//             </div>
//             {!collapsed && (
//               <div className="min-w-0">
//                 <p className="font-semibold text-black truncate">{user?.name || "User"}</p>
//                 <p className="text-xs text-zinc-500 capitalize">{user?.role || "Member"}</p>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </aside>
//   );
// }


// "use client";

// import { useState, useEffect } from "react";
// import Link from "next/link";
// import { useParams, usePathname, useRouter } from "next/navigation";
// import { useQuery } from "@tanstack/react-query";
// import { motion, AnimatePresence } from "framer-motion";
// import {
//   LayoutDashboard,
//   FolderKanban,
//   CheckSquare,
//   Building2,
//   ChevronDown,
//   ChevronRight,
//   Plus,
//   Check,
// } from "lucide-react";

// import useAuthStore from "@/store/auth-store";
// import useOrganizationStore from "@/store/organization-store";
// import organizationService from "@/services/organization.service";
// import { useOrgPermission } from "@/hooks/useOrgPermission";

// import Logo from "@/components/Layout/Logo";
// import { getInitials } from "../../lib/helpers/avatar";
// import useSidebarStore from "../../store/sidebar.store";

// export default function Sidebar() {
//   const pathname = usePathname();
//   const router = useRouter();
//   const { orgSlug } = useParams();
//   const [openMenu, setOpenMenu] = useState("");
//   const [switcherOpen, setSwitcherOpen] = useState(false);
//   const { collapsed } = useSidebarStore();
//   const user = useAuthStore((state) => state.user);
//   const organization = useOrganizationStore((s) => s.organization);

//   const { data: orgsRes } = useQuery({
//     queryKey: ["organizations"],
//     queryFn: organizationService.listOrganizations,
//   });
//   const orgs = orgsRes?.data || [];

//   const base = orgSlug ? `/${orgSlug}` : "";

//   const switchOrg = (slug) => {
//     setSwitcherOpen(false);
//     router.push(`/${slug}/dashboard`);
//   };

//   // ── Permissions ──────────────────────────────────────────────────────────
//   const canViewOrg = useOrgPermission(organization, "org.view");
//   const canInvite = useOrgPermission(organization, "team.invite");
//   const canManageInvites = useOrgPermission(organization, "team.invite.manage");
//   const canCreateProject = useOrgPermission(organization, "project.create");

//   // ── Menu structure ───────────────────────────────────────────────────────
//   // `href` on a parent = where clicking the parent label itself navigates.
//   // `children` = sub-items shown when expanded. A parent with no visible
//   // children just behaves like a plain link (no chevron, no expand).
//   const orgChildren = [
//     { title: "Members", href: `${base}/organization?tab=members`, show: canViewOrg },
//     { title: "Invitations", href: `${base}/organization?tab=invitations`, show: canInvite || canManageInvites },
//   ].filter((c) => c.show);

//   const menus = [
//     {
//       title: "Organization",
//       icon: Building2,
//       href: `${base}/organization`, // clicking "Organization" goes straight to org dashboard
//       children: orgChildren,
//       show: canViewOrg,
//     },
//     {
//       title: "Projects",
//       icon: FolderKanban,
//       href: `${base}/projects`, // clicking "Projects" goes to the project list/dashboard
//       children: [
//         ...(canCreateProject ? [{ title: "Create Project", href: `${base}/projects/create` }] : []),
//         { title: "Reports", href: `${base}/projects/reports` },
//       ],
//     },
//     {
//       title: "Tasks",
//       icon: CheckSquare,
//       href: `${base}/tasks`, // clicking "Tasks" goes to task dashboard
//       children: [
//         { title: "My Tasks", href: `${base}/tasks/my` },
//         { title: "Calendar", href: `${base}/tasks/calendar` },
//       ],
//     },
//   ].filter((m) => m.show !== false);

//   const isChildActive = (href) => pathname === href.split("?")[0];
//   const isParentActive = (menu) =>
//     pathname === menu.href || menu.children?.some((c) => isChildActive(c.href));

//   // Auto-expand whichever section contains the active route
//   useEffect(() => {
//     const active = menus.find((m) => isParentActive(m));
//     if (active) setOpenMenu(active.title);
//   }, [pathname]);

//   const handleParentClick = (menu) => {
//     const isOpen = openMenu === menu.title;
//     setOpenMenu(isOpen ? "" : menu.title);
//     router.push(menu.href); // always navigate to the section's home page
//   };

//   return (
//     <aside
//       className={`hidden flex-col border-r border-zinc-200 bg-white transition-all duration-300 lg:flex ${
//         collapsed ? "w-20" : "w-72"
//       }`}
//     >
//       {/* Logo */}
//       <div className="flex h-20 items-center border-b border-zinc-200 px-6">
//         <Logo collapsed={collapsed} />
//       </div>

//       {/* Navigation */}
//       <div className="flex-1 overflow-y-auto p-4 space-y-1">
//         {menus.map((menu) => {
//           const Icon = menu.icon;
//           const isOpen = openMenu === menu.title && !collapsed;
//           const parentActive = isParentActive(menu);
//           const hasChildren = menu.children?.length > 0;

//           return (
//             <div key={menu.title}>
//               <button
//                 onClick={() => handleParentClick(menu)}
//                 className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition ${
//                   collapsed ? "justify-center" : "justify-between"
//                 } ${
//                   parentActive
//                     ? "bg-zinc-100 text-black font-semibold"
//                     : "text-zinc-700 hover:bg-zinc-100 hover:text-black"
//                 }`}
//                 title={collapsed ? menu.title : undefined}
//               >
//                 <div className="flex items-center gap-3">
//                   <Icon size={20} />
//                   {!collapsed && <span>{menu.title}</span>}
//                 </div>
//                 {!collapsed && hasChildren && (
//                   <span
//                     onClick={(e) => {
//                       e.stopPropagation(); // chevron only toggles expand, doesn't navigate
//                       setOpenMenu(isOpen ? "" : menu.title);
//                     }}
//                   >
//                     {isOpen ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
//                   </span>
//                 )}
//               </button>

//               <AnimatePresence>
//                 {isOpen && hasChildren && (
//                   <motion.div
//                     initial={{ height: 0, opacity: 0 }}
//                     animate={{ height: "auto", opacity: 1 }}
//                     exit={{ height: 0, opacity: 0 }}
//                     className="overflow-hidden"
//                   >
//                     <div className="ml-9 mt-1 space-y-1 border-l border-zinc-200 pl-5">
//                       {menu.children.map((item) => (
//                         <Link
//                           key={item.href}
//                           href={item.href}
//                           className={`block rounded-xl px-4 py-2.5 text-sm transition ${
//                             isChildActive(item.href)
//                               ? "bg-zinc-100 text-black font-medium"
//                               : "text-zinc-600 hover:bg-zinc-100 hover:text-black"
//                           }`}
//                         >
//                           {item.title}
//                         </Link>
//                       ))}
//                     </div>
//                   </motion.div>
//                 )}
//               </AnimatePresence>
//             </div>
//           );
//         })}
//       </div>

//       {/* Org switcher */}
//       <div className="relative border-t border-zinc-200 p-4">
//         <button
//           onClick={() => setSwitcherOpen((v) => !v)}
//           className={`flex w-full items-center gap-3 rounded-2xl bg-zinc-100 p-3 hover:bg-zinc-200 transition ${
//             collapsed ? "justify-center" : "justify-between"
//           }`}
//           title={collapsed ? organization?.name : undefined}
//         >
//           <div className="flex items-center gap-2.5 min-w-0">
//             <div className="h-8 w-8 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
//               <Building2 size={16} />
//             </div>
//             {!collapsed && (
//               <div className="min-w-0 text-left">
//                 <p className="text-sm font-semibold text-black truncate">{organization?.name || "Select org"}</p>
//                 <p className="text-xs text-zinc-500 truncate">/{orgSlug}</p>
//               </div>
//             )}
//           </div>
//           {!collapsed && <ChevronDown size={16} className="shrink-0 text-zinc-500" />}
//         </button>

//         <AnimatePresence>
//           {switcherOpen && !collapsed && (
//             <motion.div
//               initial={{ opacity: 0, y: 6 }}
//               animate={{ opacity: 1, y: 0 }}
//               exit={{ opacity: 0, y: 6 }}
//               className="absolute bottom-full left-4 right-4 mb-2 rounded-2xl border border-zinc-200 bg-white shadow-lg overflow-hidden z-50"
//             >
//               <div className="max-h-56 overflow-y-auto p-1.5">
//                 {orgs.map((o) => (
//                   <button
//                     key={o._id}
//                     onClick={() => switchOrg(o.slug)}
//                     className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm hover:bg-zinc-100 transition"
//                   >
//                     <div className="h-7 w-7 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold">
//                       {o.logo ? <img src={o.logo} className="h-7 w-7 rounded-lg object-cover" /> : o.name?.[0]?.toUpperCase()}
//                     </div>
//                     <span className="flex-1 text-left truncate">{o.name}</span>
//                     {o.slug === orgSlug && <Check size={15} className="text-primary shrink-0" />}
//                   </button>
//                 ))}
//               </div>
//               <div className="border-t border-zinc-200 p-1.5">
//                 <button
//                   onClick={() => {
//                     setSwitcherOpen(false);
//                     router.push("/organizations/create");
//                   }}
//                   className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-zinc-700 hover:bg-zinc-100 transition"
//                 >
//                   <Plus size={16} className="shrink-0" />
//                   Create organization
//                 </button>
//               </div>
//             </motion.div>
//           )}
//         </AnimatePresence>
//       </div>

//       {/* User Footer */}
//       <div className="border-t border-zinc-200 p-4">
//         <div className={`rounded-3xl bg-zinc-100 p-4 ${collapsed ? "text-center" : ""}`}>
//           <div className="flex items-center gap-3">
//             <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-semibold text-lg flex-shrink-0">
//               {user?.name ? getInitials(user.name) : "U"}
//             </div>
//             {!collapsed && (
//               <div className="min-w-0">
//                 <p className="font-semibold text-black truncate">{user?.name || "User"}</p>
//                 <p className="text-xs text-zinc-500 capitalize">{user?.role || "Member"}</p>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </aside>
//   );
// }



// components/Layout/Sidebar.jsx
"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import { useParams, usePathname, useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  FolderKanban,
  CheckSquare,
  Building2,
  ChevronDown,
  ChevronRight,
  Plus,
  Check,
} from "lucide-react";
import useAuthStore from "@/store/auth-store";
import useOrganizationStore from "@/store/organization-store";
import organizationService from "@/services/organization.service";
import { useOrgPermission } from "@/hooks/useOrgPermission";
import Logo from "@/components/Layout/Logo";
import { getInitials } from "../../lib/helpers/avatar";
import useSidebarStore from "../../store/sidebar.store";

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { orgSlug } = useParams();
  const [openMenu, setOpenMenu] = useState("");
  const [switcherOpen, setSwitcherOpen] = useState(false);
  const { collapsed } = useSidebarStore();
  const user = useAuthStore((state) => state.user);
  const organization = useOrganizationStore((s) => s.organization);
  const { data: orgsRes } = useQuery({
    queryKey: ["organizations"],
    queryFn: organizationService.listOrganizations,
  });
  const orgs = orgsRes?.data || [];
  const base = orgSlug ? `/${orgSlug}` : "";
  const switchOrg = (slug) => {
    setSwitcherOpen(false);
    router.push(`/${slug}/dashboard`);
  };

  // ── Permissions ──────────────────────────────────────────────────────────
  const canViewOrg = useOrgPermission(organization, "org.view");
  const canInvite = useOrgPermission(organization, "team.invite");
  const canManageInvites = useOrgPermission(organization, "team.invite.manage");
  const canCreateProject = useOrgPermission(organization, "project.create");

  // ── Menu structure ───────────────────────────────────────────────────────
  // "All Projects" always first. Organization & Tasks children unchanged.
  const orgChildren = [
    { title: "Members", href: `${base}/organization?tab=members`, show: canViewOrg },
    { title: "Invitations", href: `${base}/organization?tab=invitations`, show: canInvite || canManageInvites },
  ].filter((c) => c.show);

  const menus = [
    {
      title: "Organization",
      icon: Building2,
      href: `${base}/organization`,
      children: orgChildren,
      show: canViewOrg,
    },
    {
      title: "Projects",
      icon: FolderKanban,
      href: `${base}/projects`,
      children: [
        { title: "All Projects", href: `${base}/projects` },
        ...(canCreateProject ? [{ title: "Create Project", href: `${base}/projects/create` }] : []),
        { title: "Reports", href: `${base}/projects/reports` },
      ],
    },
    {
      title: "Tasks",
      icon: CheckSquare,
      href: `${base}/tasks`,
      children: [
        { title: "My Tasks", href: `${base}/tasks/my` },
        { title: "Calendar", href: `${base}/tasks/calendar` },
      ],
    },
  ].filter((m) => m.show !== false);

  // ── Simple active state (no conditional highlight for children) ─────────
  // This keeps it very simple:
  // - Only the main parent button gets highlighted (bg-zinc-100 / font-semibold)
  // - Clicking any child still navigates to its separate page
  // - No extra highlight for children
  const isChildActive = (href) => {
    if (!href) return false;
    const cleanHref = href.split("?")[0];
    return pathname === cleanHref;
  };

  const isParentActive = (menu) => {
    if (!menu.href) return false;
    const cleanHref = menu.href.split("?")[0];
    return pathname === cleanHref;
  };

  // ── Auto-expand only for Organization (kept simple) ─────────────────────
  useEffect(() => {
    const active = menus.find((m) => isParentActive(m));
    if (active) setOpenMenu(active.title);
  }, [pathname]);

  const handleParentClick = (menu) => {
    const isOpen = openMenu === menu.title;
    setOpenMenu(isOpen ? "" : menu.title);
    router.push(menu.href);
  };

  return (
    <aside
      className={`hidden flex-col border-r border-zinc-200 bg-white transition-all duration-300 lg:flex ${
        collapsed ? "w-20" : "w-72"
      }`}
    >
      {/* Logo */}
      <div className="flex h-20 items-center border-b border-zinc-200 px-6">
        <Logo collapsed={collapsed} />
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto p-4 space-y-1">
        {menus.map((menu) => {
          const Icon = menu.icon;
          const isOpen = openMenu === menu.title && !collapsed;
          const parentActive = isParentActive(menu);
          const hasChildren = menu.children?.length > 0;

          return (
            <div key={menu.title}>
              <button
                onClick={() => handleParentClick(menu)}
                className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-medium transition ${
                  collapsed ? "justify-center" : "justify-between"
                } ${
                  parentActive
                    ? "bg-zinc-100 text-black font-semibold"
                    : "text-zinc-700 hover:bg-zinc-100 hover:text-black"
                }`}
                title={collapsed ? menu.title : undefined}
              >
                <div className="flex items-center gap-3">
                  <Icon size={20} />
                  {!collapsed && <span>{menu.title}</span>}
                </div>
                {!collapsed && hasChildren && (
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      setOpenMenu(isOpen ? "" : menu.title);
                    }}
                  >
                    {isOpen ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                  </span>
                )}
              </button>

              <AnimatePresence>
                {isOpen && hasChildren && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="ml-9 mt-1 space-y-1 border-l border-zinc-200 pl-5">
                      {menu.children.map((item) => (
                        <Link
                          key={item.href}
                          href={item.href}
                          className="block rounded-xl px-4 py-2.5 text-sm text-zinc-600 hover:bg-zinc-100 hover:text-black"
                        >
                          {item.title}
                        </Link>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* Org switcher */}
      <div className="relative border-t border-zinc-200 p-4">
        <button
          onClick={() => setSwitcherOpen((v) => !v)}
          className={`flex w-full items-center gap-3 rounded-2xl bg-zinc-100 p-3 hover:bg-zinc-200 transition ${
            collapsed ? "justify-center" : "justify-between"
          }`}
          title={collapsed ? organization?.name : undefined}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-8 w-8 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <Building2 size={16} />
            </div>
            {!collapsed && (
              <div className="min-w-0 text-left">
                <p className="text-sm font-semibold text-black truncate">{organization?.name || "Select org"}</p>
                <p className="text-xs text-zinc-500 truncate">/{orgSlug}</p>
              </div>
            )}
          </div>
          {!collapsed && <ChevronDown size={16} className="shrink-0 text-zinc-500" />}
        </button>
        <AnimatePresence>
          {switcherOpen && !collapsed && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              className="absolute bottom-full left-4 right-4 mb-2 rounded-2xl border border-zinc-200 bg-white shadow-lg overflow-hidden z-50"
            >
              <div className="max-h-56 overflow-y-auto p-1.5">
                {orgs.map((o) => (
                  <button
                    key={o._id}
                    onClick={() => switchOrg(o.slug)}
                    className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm hover:bg-zinc-100 transition"
                  >
                    <div className="h-7 w-7 shrink-0 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold">
                      {o.logo ? <img src={o.logo} className="h-7 w-7 rounded-lg object-cover" /> : o.name?.[0]?.toUpperCase()}
                    </div>
                    <span className="flex-1 text-left truncate">{o.name}</span>
                    {o.slug === orgSlug && <Check size={15} className="text-primary shrink-0" />}
                  </button>
                ))}
              </div>
              <div className="border-t border-zinc-200 p-1.5">
                <button
                  onClick={() => {
                    setSwitcherOpen(false);
                    router.push("/organizations/create");
                  }}
                  className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm text-zinc-700 hover:bg-zinc-100 transition"
                >
                  <Plus size={16} className="shrink-0" />
                  Create organization
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* User Footer */}
      <div className="border-t border-zinc-200 p-4">
        <div className={`rounded-3xl bg-zinc-100 p-4 ${collapsed ? "text-center" : ""}`}>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white font-semibold text-lg flex-shrink-0">
              {user?.name ? getInitials(user.name) : "U"}
            </div>
            {!collapsed && (
              <div className="min-w-0">
                <p className="font-semibold text-black truncate">{user?.name || "User"}</p>
                <p className="text-xs text-zinc-500 capitalize">{user?.role || "Member"}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}