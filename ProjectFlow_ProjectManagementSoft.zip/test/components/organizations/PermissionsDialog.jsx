

"use client";

import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Shield, Loader2, Info } from "lucide-react";
import { toast } from "sonner";

import organizationService from "@/services/organization.service";
import { ORG_PERMISSION_GROUPS, ORG_ROLE_META } from "@/constants/organizationPermissions";
import { useIsOrgOwner } from "@/hooks/useOrgPermission";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";

export default function PermissionsDialog({ open, onOpenChange, orgId, org, member }) {
  const queryClient = useQueryClient();
  const isOwner = useIsOrgOwner(org);

  const [selected, setSelected] = useState(member?.permissions || []);

  useEffect(() => {
    setSelected(member?.permissions || []);
  }, [member]);

  const meta = member ? ORG_ROLE_META[member.role] || ORG_ROLE_META.member : null;

  // If `org` wasn't passed in for some reason, isOwner resolves to false —
  // that would incorrectly lock the dialog even for the real owner. Guard
  // against that: only apply the admin-lock when we actually know isOwner
  // is false from a loaded org, not from a missing prop.
  const orgLoaded = !!org?.currentUserPermissions;
  const isLockedAdmin = orgLoaded && member?.role === "admin" && !isOwner;

  const toggle = (perm) => {
    if (isLockedAdmin) return;
    setSelected((prev) => (prev.includes(perm) ? prev.filter((p) => p !== perm) : [...prev, perm]));
  };

  const hasChanges =
    member &&
    JSON.stringify([...selected].sort()) !== JSON.stringify([...(member.permissions || [])].sort());

  const saveMutation = useMutation({
    mutationFn: () => organizationService.updateMemberPermissions(orgId, member.user._id, selected),
    onSuccess: () => {
      toast.success("Permissions updated.");
      queryClient.invalidateQueries({ queryKey: ["organization", orgId] });
      onOpenChange(false);
    },
    onError: (err) => toast.error(err.message || "Failed to update permissions."),
  });

  if (!member) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" /> Permissions — {member.user?.name}
          </DialogTitle>
        </DialogHeader>

        <div className="flex items-center gap-2 -mt-2">
          <span className="text-xs text-muted-foreground">Current role:</span>
          {meta && (
            <Badge variant="outline" className={meta.badgeClass}>
              {meta.label}
            </Badge>
          )}
        </div>

        {isLockedAdmin && (
          <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-sm text-amber-800">
            <Info className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{`Only the organization owner can edit an admin's permissions.`}</span>
          </div>
        )}

        <div className="space-y-5 max-h-96 overflow-y-auto py-1">
          {ORG_PERMISSION_GROUPS.map((group) => (
            <div key={group.group} className="space-y-1.5">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{group.group}</p>
              {group.permissions.map((perm) => (
                <label
                  key={perm.value}
                  className={`flex items-center gap-3 rounded-lg border px-3.5 py-2.5 text-sm transition-colors ${
                    isLockedAdmin ? "cursor-not-allowed opacity-60" : "cursor-pointer hover:bg-slate-50"
                  }`}
                >
                  <Checkbox
                    checked={selected.includes(perm.value)}
                    onCheckedChange={() => toggle(perm.value)}
                    disabled={isLockedAdmin}
                  />
                  {perm.label}
                </label>
              ))}
            </div>
          ))}
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            type="button"
            onClick={() => saveMutation.mutate()}
            disabled={isLockedAdmin || !hasChanges || saveMutation.isPending}
            className="inline-flex items-center gap-2"
          >
            {saveMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Save permissions
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}