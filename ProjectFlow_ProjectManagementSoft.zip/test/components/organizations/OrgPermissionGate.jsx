
'use client';

import { useOrgPermission } from '@/hooks/useOrgPermission';
import NoPermissionState from '@/components/feedback/NoPermissionState';

/**
 * <OrgPermissionGate org={org} permission="team.invite">
 *   <InviteButton />
 * </OrgPermissionGate>
 *
 * Same contract as the project-level PermissionGate: NoPermissionState by
 * default when denied, `fallback` if given, nothing at all when `inline`.
 */
export default function OrgPermissionGate({
  org,
  permission,
  children,
  fallback,
  compact = true,
  inline = false,
  title,
  description,
}) {
  const allowed = useOrgPermission(org, permission);

  if (allowed) return children;
  if (inline) return null;
  if (fallback) return fallback;

  return <NoPermissionState compact={compact} title={title} description={description} />;
}