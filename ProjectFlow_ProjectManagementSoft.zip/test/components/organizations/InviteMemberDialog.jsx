// components/organizations/InviteMemberDialog.jsx
"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { UserPlus, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

import organizationService from "@/services/organization.service";
import { ORG_ROLE_OPTIONS } from "@/constants/organizationPermissions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const inviteSchema = z.object({
  email: z.string().email("Enter a valid email"),
  role: z.enum(ORG_ROLE_OPTIONS),
});

function FieldError({ message }) {
  if (!message) return null;
  return (
    <p className="text-red-500 text-sm flex items-center gap-1 mt-1">
      <AlertCircle className="h-3.5 w-3.5" /> {message}
    </p>
  );
}

export default function InviteMemberDialog({ open, onOpenChange, orgId, isOwner }) {
  const queryClient = useQueryClient();
  const {
    register, handleSubmit, reset, setValue, watch,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(inviteSchema),
    defaultValues: { email: "", role: "member" },
  });

  const inviteMutation = useMutation({
    mutationFn: (payload) => organizationService.inviteMember(orgId, payload),
    onSuccess: () => {
      toast.success("Invitation sent.");
      queryClient.invalidateQueries({ queryKey: ["organization", orgId] });
      reset();
      onOpenChange(false);
    },
    onError: (err) => toast.error(err.message || "Failed to send invitation."),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5" /> Invite a member
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit((data) => inviteMutation.mutate(data))} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="invite-email">Email address</Label>
            <Input id="invite-email" placeholder="teammate@company.com" {...register("email")} />
            <FieldError message={errors.email?.message} />
          </div>

          <div className="space-y-1.5">
            <Label>Role</Label>
            <Select value={watch("role")} onValueChange={(v) => setValue("role", v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ORG_ROLE_OPTIONS.filter((r) => r !== "admin" || isOwner).map((r) => (
                  <SelectItem key={r} value={r} className="capitalize">{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {!isOwner && <p className="text-xs text-muted-foreground">Only the owner can invite admins.</p>}
          </div>

          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={isSubmitting || inviteMutation.isPending} className="inline-flex items-center gap-2">
              {inviteMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Send invite
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}