"use client";

import { useState, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { RefreshCw, Trash2, Search, Copy, Check, Mail } from "lucide-react";
import { toast } from "sonner";

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import organizationService from "@/services/organization.service";
import { useOrgPermission } from "@/hooks/useOrgPermission";
import { TableSkeleton } from "@/components/common/Skeletons";
import EmptyState from "@/components/feedback/EmptyState";
import { ConfirmDialog } from "@/components/common/AppDialogs";
import { formatDate } from "@/lib/date";

const statusMeta = {
  pending: { label: "Pending", className: "bg-amber-100 text-amber-700 border-amber-200" },
  accepted: { label: "Accepted", className: "bg-emerald-100 text-emerald-700 border-emerald-200" },
  declined: { label: "Declined", className: "bg-zinc-100 text-zinc-700 border-zinc-200" },
  expired: { label: "Expired", className: "bg-red-100 text-red-700 border-red-200" },
  revoked: { label: "Revoked", className: "bg-zinc-100 text-zinc-500 border-zinc-200" },
};

function CopyableCode({ code }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      toast.success("Code copied.");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Could not copy code.");
    }
  };
  return (
    <button
      type="button"
      onClick={copy}
      className="inline-flex items-center gap-1.5 rounded-md border px-2 py-1 font-mono text-xs hover:bg-muted/50 transition-colors"
      title="Copy code"
    >
      {code}
      {copied ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3 text-muted-foreground" />}
    </button>
  );
}

export default function InvitationsTable({ org, orgId }) {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [revokeTarget, setRevokeTarget] = useState(null);
  const [isRevoking, setIsRevoking] = useState(false);
  const [resendingId, setResendingId] = useState(null);

  // Two distinct permissions: viewing the list vs. managing (resend/revoke) it.
  const canViewInvitations = useOrgPermission(org, "team.invite");
  const canManageInvitations = useOrgPermission(org, "team.invite.manage");

  const { data: invitesRes, isLoading } = useQuery({
    queryKey: ["organizationInvitations", orgId],
    queryFn: () => organizationService.listOrgInvitations(orgId),
    enabled: !!orgId && canViewInvitations,
  });

  const invitations = invitesRes?.data || [];

  const resendMutation = useMutation({
    mutationFn: (id) => organizationService.resendInvitation(id),
    onSuccess: (res) => {
      toast.success(`Invitation resent. New code: ${res.data?.code}`);
      queryClient.invalidateQueries({ queryKey: ["organizationInvitations", orgId] });
    },
    onError: (err) => toast.error(err.message || "Could not resend invitation."),
    onSettled: () => setResendingId(null),
  });

  const revokeMutation = useMutation({
    mutationFn: (id) => organizationService.revokeInvitation(id),
    onSuccess: () => {
      toast.success("Invitation revoked.");
      queryClient.invalidateQueries({ queryKey: ["organizationInvitations", orgId] });
      setRevokeTarget(null);
      setIsRevoking(false);
    },
    onError: (err) => {
      toast.error(err.message || "Could not revoke invitation.");
      setIsRevoking(false);
    },
  });

  const filtered = useMemo(() => {
    let result = [...invitations];
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter((inv) => inv.email?.toLowerCase().includes(q) || inv.code?.toLowerCase().includes(q));
    }
    if (statusFilter) result = result.filter((inv) => inv.status === statusFilter);
    return result;
  }, [invitations, searchQuery, statusFilter]);

  const handleConfirmRevoke = () => {
    setIsRevoking(true);
    revokeMutation.mutate(revokeTarget._id);
  };

  if (!canViewInvitations) {
    return (
      <EmptyState
        compact
        icon={<Mail className="h-8 w-8" />}
        title="No permission"
        description="You don't have permission to view invitations for this organization."
      />
    );
  }

  if (isLoading) return <TableSkeleton rows={5} columns={6} />;

  const hasActiveFilters = !!(searchQuery || statusFilter);

  return (
    <>
      <div className="space-y-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by email or code…"
              className="pl-9 h-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[160px] h-10">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All status</SelectItem>
              {Object.entries(statusMeta).map(([value, meta]) => (
                <SelectItem key={value} value={value}>{meta.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={() => { setSearchQuery(""); setStatusFilter(""); }}>
              Clear filters
            </Button>
          )}
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          compact={invitations.length > 0}
          icon={<Mail className="h-8 w-8" />}
          title={invitations.length === 0 ? "No invitations yet" : "No matching invitations"}
          description={invitations.length === 0 ? "Invite people using the button above." : "Try adjusting your search or filters."}
        />
      ) : (
        <div className="rounded-2xl border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead className="w-[100px]">Role</TableHead>
                <TableHead className="w-[110px]">Status</TableHead>
                <TableHead className="w-[130px]">Code</TableHead>
                <TableHead className="w-[130px]">Invited by</TableHead>
                <TableHead className="w-[130px]">Expires</TableHead>
                {canManageInvitations && <TableHead className="w-[110px] text-center">Actions</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((inv) => {
                const meta = statusMeta[inv.status] || statusMeta.pending;
                const canResend = inv.status === "pending" || inv.status === "expired";
                return (
                  <TableRow key={inv._id} className="hover:bg-muted/50">
                    <TableCell className="font-medium">{inv.email}</TableCell>
                    <TableCell><Badge variant="outline" className="capitalize">{inv.role}</Badge></TableCell>
                    <TableCell><Badge variant="outline" className={meta.className}>{meta.label}</Badge></TableCell>
                    <TableCell>
                      {inv.status === "pending" ? <CopyableCode code={inv.code} /> : <span className="text-xs text-muted-foreground font-mono">{inv.code}</span>}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{inv.invitedBy?.name || "—"}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {inv.status === "pending" ? formatDate(inv.expiresAt) : "—"}
                    </TableCell>
                    {canManageInvitations && (
                      <TableCell className="text-center">
                        <div className="flex items-center justify-center gap-1">
                          {canResend && (
                            <Button
                              variant="ghost"
                              size="icon"
                              title="Resend invitation"
                              disabled={resendMutation.isPending && resendingId === inv._id}
                              onClick={() => {
                                setResendingId(inv._id);
                                resendMutation.mutate(inv._id);
                              }}
                            >
                              <RefreshCw className={`h-4 w-4 text-blue-600 ${resendingId === inv._id && resendMutation.isPending ? "animate-spin" : ""}`} />
                            </Button>
                          )}
                          {inv.status === "pending" && (
                            <Button variant="ghost" size="icon" title="Revoke invitation" onClick={() => setRevokeTarget(inv)}>
                              <Trash2 className="h-4 w-4 text-red-600" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}

      <ConfirmDialog
        open={!!revokeTarget}
        onOpenChange={(v) => !v && setRevokeTarget(null)}
        title="Revoke invitation?"
        description={`The invitation to "${revokeTarget?.email}" will no longer be usable.`}
        confirmLabel="Revoke"
        loading={isRevoking}
        onConfirm={handleConfirmRevoke}
      />
    </>
  );
}