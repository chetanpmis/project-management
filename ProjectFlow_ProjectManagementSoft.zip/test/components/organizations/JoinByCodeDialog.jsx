"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { KeyRound, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

import organizationService from "@/services/organization.service";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export default function JoinByCodeDialog({ open, onOpenChange }) {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [code, setCode] = useState("");
  const [error, setError] = useState("");

  const joinMutation = useMutation({
    mutationFn: () => organizationService.joinByCode(code.trim()),
    onSuccess: (res) => {
      toast.success("You joined the organization.");
      queryClient.invalidateQueries({ queryKey: ["organizations"] });
      queryClient.invalidateQueries({ queryKey: ["organizationInvites"] });
      onOpenChange(false);
      setCode("");
      const orgId = res?.data?._id;
      if (orgId) router.push(`/organizations/${orgId}`);
    },
    onError: (err) => setError(err.message || "Could not join with this code."),
  });

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) { setCode(""); setError(""); } }}>
      <DialogContent className="sm:max-w-sm bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="h-5 w-5" /> Join with a code
          </DialogTitle>
        </DialogHeader>

        <p className="text-sm text-muted-foreground">
          Didn't get an invitation email or notification? Enter the invitation code an admin shared with you.
        </p>

        <div className="space-y-1.5">
          <Label htmlFor="join-code">Invitation code</Label>
          <Input
            id="join-code"
            placeholder="AB3D-9F2K"
            value={code}
            onChange={(e) => { setCode(e.target.value.toUpperCase()); setError(""); }}
            className="font-mono tracking-wider"
            autoComplete="off"
          />
          {error && (
            <p className="text-red-500 text-sm flex items-center gap-1 mt-1">
              <AlertCircle className="h-3.5 w-3.5" /> {error}
            </p>
          )}
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            type="button"
            disabled={!code.trim() || joinMutation.isPending}
            onClick={() => joinMutation.mutate()}
            className="inline-flex items-center gap-2"
          >
            {joinMutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Join
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}