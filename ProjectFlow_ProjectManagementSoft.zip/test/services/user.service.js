import api from "../lib/axios";

const userService = {
  getUsers: async (params = {}) => {
    const response = await api.get("/users", { params });
    return response.data;
  },

  getUserById: async (userId) => {
    const response = await api.get(`/users/${userId}`);
    return response.data;
  },

  getProfile: async () => {
    const response = await api.get("/users/profile");
     console.log('Profile API Response:', response.data);

    return response.data;
  },

  updateProfile: async (data) => {
    const response = await api.put("/users/profile", data);
    return response.data;
  },

  uploadAvatar: async (file) => {
    const formData = new FormData();
    formData.append("avatar", file);

    const response = await api.put("/users/profile/avatar", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });

    return response.data;
  },

  deleteAvatar: async () => {
    const response = await api.delete("/users/profile/avatar");
    return response.data;
  },

  changePassword: async (data) => {
    const response = await api.put("/users/profile/change-password", data);
    return response.data;
  },
};

export default userService;