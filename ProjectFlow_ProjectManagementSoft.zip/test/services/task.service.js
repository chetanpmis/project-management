import api from "../lib/axios";

const taskService = {
  // Task CRUD
  getTasksByProject: async (projectId, params = {}) => {
    const response = await api.get(`/tasks/project/${projectId}`, { params });
    return response.data;
  },


getMyTasks: async ({
    projectId,
    type = 'all',
    page = 1,
    limit = 100,      
  }) => {
    try {
      const response = await api.get('/tasks/me', {
        params: {
          projectId,
          type,
          page,
          limit,
        },
      });

      console.log(`✅ getMyTasks(${type}) response:`, response.data); // ← Add this for debugging
      return response.data;
    } catch (error) {
      console.error(`❌ getMyTasks(${type}) failed:`, error.response?.data || error.message);
      throw error;
    }
  },
getMyTaskStats: async ({ projectId } = {}) => {
    try {
      const params = {};
      if (projectId) params.projectId = projectId;

      const response = await api.get('/tasks/me/stats', { params });
      console.log('✅ getMyTaskStats success:', response.data);
      c
      return response.data;
    } catch (error) {
      console.error('❌ getMyTaskStats failed:', error.response?.data || error.message);
      throw error;
    }
  },
  getUserTaskStats: async (projectId) => {
    const response = await api.get(`/tasks/project/${projectId}/stats`);
    return response.data;
  },

  getTaskById: async (taskId) => {
    const response = await api.get(`/tasks/${taskId}`);

    console.log("Task By Id Response : ",response.data)
    return response.data;
  },

  createTask: async (projectId, data) => {
    const response = await api.post(`/tasks/project/${projectId}`, data);
    console.log("Task Response : ",response.data)
    return response.data;
  },

  updateTask: async (taskId, data) => {
    const response = await api.put(`/tasks/${taskId}`, data);
    return response.data;
  },

  deleteTask: async (taskId) => {
    const response = await api.delete(`/tasks/${taskId}`);
    return response.data;
  },

  // Watcher management
  addWatcher: async (taskId, userId) => {
    const response = await api.post(`/tasks/${taskId}/watchers`, { userId });
    return response.data;
  },

  removeWatcher: async (taskId, userId) => {
    const response = await api.delete(`/tasks/${taskId}/watchers`, {
      data: { userId },
    });
    return response.data;
  },

  // Attachment management
  addAttachment: async (taskId, filename, url) => {
    const response = await api.post(`/tasks/${taskId}/attachments`, {
      filename,
      url,
    });
    return response.data;
  },

  removeAttachment: async (taskId, attachmentId) => {
    const response = await api.delete(
      `/tasks/${taskId}/attachments/${attachmentId}`
    );
    return response.data;
  },

  // Work logs
  addWorkLog: async (projectId, taskId, data) => {
    const response = await api.post(
      `/tasks/${taskId}/worklog/project/${projectId}`,
      data
    );
    return response.data;
  },

  // Gantt data
  getGanttData: async (projectId) => {
    const response = await api.get(`/tasks/project/${projectId}/gantt`);
    return response.data;
  },

  // NEW: Create task with dependencies + optional checklist
  createTaskWithDependencies: async (projectId, data) => {
    const response = await api.post(`/tasks/project/${projectId}/dependencies`, data);
    return response.data;
  },

  // NEW: Update task (now also supports updating dependencies)
  updateTaskWithDependencies: async (taskId, data) => {
    const response = await api.put(`/tasks/${taskId}/dependencies`, data);
    return response.data;
  },

  // Start timer (creates timer log)
  startTimer: async (taskId) => {
    const response = await api.post(`/tasks/${taskId}/start-timer`);
    return response.data;
  },

  // Stop timer (calculates duration + updates timeSpent)
  stopTimer: async (taskId) => {
    const response = await api.post(`/tasks/${taskId}/stop-timer`);
    return response.data;
  },

  // Resume timer (manual hours add)
  resumeTimer: async (taskId, hours, description = "Timer resumed") => {
    const response = await api.post(`/tasks/${taskId}/resume-timer`, {
      hours,
      description,
    });
    return response.data;
  },

  // Finish task + mark as completed
  finishTask: async (taskId) => {
    const response = await api.post(`/tasks/${taskId}/finish`);
    return response.data;
  },

  // Get current timer status (isLogging, elapsedSeconds, timeSpent)
  getTimerStatus: async (taskId) => {
    const response = await api.get(`/tasks/${taskId}/timer`);
    return response.data;
  },

   addChecklistItem: async (taskId, item) => {
    const response = await api.post(`/tasks/${taskId}/checklist`, { item });
    return response.data;
  },
 
  toggleChecklistItem: async (taskId, itemId, completed) => {
    const response = await api.patch(`/tasks/${taskId}/checklist/${itemId}`, { completed });
    return response.data;
  },
 
  removeChecklistItem: async (taskId, itemId) => {
    const response = await api.delete(`/tasks/${taskId}/checklist/${itemId}`);
    return response.data;
  },
  getTaskCreationData: async (projectId) => {
    try {
      const response = await api.get(`/tasks/${projectId}/creation-data`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
 getKanbanBoards: async (projectId) => {
  const response = await api.get(`/tasks/project/${projectId}/kanban`);
  console.log("Kanban Board Response:", response.data);
  return response.data;
},

moveTask: async (taskId, data) => {
  const response = await api.patch(`/tasks/${taskId}/move`, data);
  console.log("Move Task Response:", response.data);
  return response.data;
},
};


export default taskService;