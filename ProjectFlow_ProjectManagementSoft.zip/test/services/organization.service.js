import api from "../lib/axios";

const organizationService = {
  listOrganizations: () => api.get("/organizations").then((r) => r.data),
  getOrganization: (slug) =>
    api.get(`/organizations/${slug}`).then((r) => r.data),
  createOrganization: (payload) =>
    api.post("/organizations", payload).then((r) => r.data),
  updateOrganization: (slug, payload) =>
    api.put(`/organizations/${slug}`, payload).then((r) => r.data),
  deleteOrganization: (slug) =>
    api.delete(`/organizations/${slug}`).then((r) => r.data),

  listMyInvites: () =>
    api.get("/organizations/invitations/me").then((r) => r.data),
  respondToInvite: (slug, action) =>
    api
      .patch(`/organizations/${slug}/invite/respond`, { action })
      .then((r) => r.data),

        joinByCode: () =>
    api.post("/invitations/join-by-code").then((r) => r.data),

  listMembers: (slug, params = {}) =>
    api.get(`/organizations/${slug}/members`, { params }).then((r) => r.data),

  listOrgInvitations: (slug) =>
    api.get(`/organizations/${slug}/invitations`).then((r) => r.data),
  inviteMember: (slug, payload) =>
    api.post(`/organizations/${slug}/invite`, payload).then((r) => r.data),

  updateMemberRole: (slug, userId, role) =>
    api
      .patch(`/organizations/${slug}/members/${userId}/role`, { role })
      .then((r) => r.data),
  updateMemberPermissions: (slug, userId, permissions) =>
    api
      .patch(`/organizations/${slug}/members/${userId}/permissions`, {
        permissions,
      })
      .then((r) => r.data),
  removeMember: (slug, userId) =>
    api.delete(`/organizations/${slug}/members/${userId}`).then((r) => r.data),

  resendInvitation: (invitationId) =>
    api.post(`/invitations/${invitationId}/resend`).then((r) => r.data), // id still works here
};

export default organizationService;
