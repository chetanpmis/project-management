import api from "../lib/axios";

const unwrapError = (err) => {
  const status = err?.response?.status;
  const message = err?.response?.data?.message || err.message;
  const currentUserPermissions = err?.response?.data?.currentUserPermissions;

  const wrapped = new Error(message);
  wrapped.status = status;
  wrapped.currentUserPermissions = currentUserPermissions;

  throw wrapped;
};

const organizationService = {
  listOrganizations: async () => {
    try {
      const response = await api.get("/organizations");
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  getOrganization: async (id) => {
    try {
      const response = await api.get(`/organizations/${id}`);
      console.log("Organization Data : ",response.data)
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  createOrganization: async (payload) => {
    try {
      const response = await api.post("/organizations", payload);
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  updateOrganization: async (id, payload) => {
    try {
      const response = await api.put(`/organizations/${id}`, payload);
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  deleteOrganization: async (id) => {
    try {
      const response = await api.delete(`/organizations/${id}`);
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  listMyInvites: async () => {
    try {
      const response = await api.get("/organizations/invites/me");
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  respondToInvite: async (id, action) => {
    try {
      const response = await api.patch(
        `/organizations/${id}/invite/respond`,
        { action }
      );
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  listMembers: async (id) => {
    try {
      const response = await api.get(`/organizations/${id}/members`);
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  inviteMember: async (id, payload) => {
    try {
      const response = await api.post(
        `/organizations/${id}/invite`,
        payload
      );
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  updateMemberRole: async (id, userId, role) => {
    try {
      const response = await api.patch(
        `/organizations/${id}/members/${userId}/role`,
        { role }
      );
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  updateMemberPermissions: async (id, userId, permissions) => {
    try {
      const response = await api.patch(
        `/organizations/${id}/members/${userId}/permissions`,
        { permissions }
      );
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  removeMember: async (id, userId) => {
    try {
      const response = await api.delete(
        `/organizations/${id}/members/${userId}`
      );
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },

  getOrgWorkload: async (id) => {
    try {
      const response = await api.get(`/organizations/${id}/workload`);
      return response.data;
    } catch (err) {
      unwrapError(err);
    }
  },
};

export default organizationService;