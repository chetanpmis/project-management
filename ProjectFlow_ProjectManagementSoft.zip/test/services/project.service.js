import api from "../lib/axios";

const projectService = {
  getProjects: async (organizationId, params = {}) => {
    const response = await api.get("/projects", {
      params: { organization: organizationId, ...params },
    });
    return response.data;
  },

  getProjectById: async (projectId) => {
     console.log("GET PROEJECt BY ID  : ",projectId)
    const response = await api.get(`/projects/${projectId}`);

    console.log("GET PROEJECt BY ID REPONSE : ",response.data)
    return response.data;
  },

  createProject: async (organizationId, data) => {
    const response = await api.post("/projects", { organization: organizationId, ...data });
    return response.data;
  },

  updateProject: async (projectId, data) => {
    const response = await api.put(`/projects/${projectId}`, data);
    return response.data;
  },

  deleteProject: async (projectId) => {
    const response = await api.delete(`/projects/${projectId}`);
    return response.data;
  },

  restoreProject: async (projectId) => {
    const response = await api.patch(`/projects/${projectId}/restore`);
    return response.data;
  },

  updateProjectStatus: async (projectId, status) => {
    const response = await api.patch(`/projects/${projectId}/status`, { status });
    return response.data;
  },

  getProjectStats: async (projectId) => {
    const response = await api.get(`/projects/${projectId}/stats`);
    return response.data;
  },

  // ==========================
  // Team — permissions/role are always resolved server-side
  // ==========================

  addTeamMember: async (projectId, data) => {
    const response = await api.post(`/projects/${projectId}/team`, data);
    return response.data;
  },

  updateTeamMember: async (projectId, userId, data) => {
    const response = await api.patch(`/projects/${projectId}/team/${userId}`, data);
    return response.data;
  },

  removeTeamMember: async (projectId, userId) => {
    const response = await api.delete(`/projects/${projectId}/team/${userId}`);
    return response.data;
  },
};

export default projectService;