
import api from "../lib/axios";

const resourceService = {
  // ---- Folders ----
  listFolders: (projectId) => api.get(`/projects/${projectId}/folders`),
  createFolder: (projectId, name) => api.post(`/projects/${projectId}/folders`, { name }),
  renameFolder: (folderId, name) => api.patch(`/folders/${folderId}`, { name }),
  deleteFolder: (folderId) => api.delete(`/folders/${folderId}`),

  // ---- Files ----
  listFiles: (projectId, params = {}) => api.get(`/projects/${projectId}/files`, { params }),
  getFile: (fileId) => api.get(`/files/${fileId}`),
  renameFile: (fileId, originalName) => api.patch(`/files/${fileId}/rename`, { originalName }),
  moveFile: (fileId, folder) => api.patch(`/files/${fileId}/move`, { folder }),
  deleteFile: (fileId) => api.delete(`/files/${fileId}`),
  downloadFile: (fileId) => api.get(`/files/${fileId}/download`, { responseType: "blob" }),

  /**
   * Upload a file with live progress reporting.
   * onProgress receives an integer 0-100.
   */
  uploadFile: (projectId, file, { folder, visibility = "team", task } = {}, onProgress) => {
    const formData = new FormData();
    formData.append("file", file);
    if (folder) formData.append("folder", folder);
    if (task) formData.append("task", task);
    formData.append("visibility", visibility);

    return api.post(`/projects/${projectId}/files`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
      onUploadProgress: (evt) => {
        if (!onProgress || !evt.total) return;
        onProgress(Math.round((evt.loaded * 100) / evt.total));
      },
    });
  },

  replaceFile: (fileId, file, originalName, onProgress) => {
    const formData = new FormData();
    formData.append("file", file);
    if (originalName) formData.append("originalName", originalName);

    return api.put(`/files/${fileId}/replace`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
      onUploadProgress: (evt) => {
        if (!onProgress || !evt.total) return;
        onProgress(Math.round((evt.loaded * 100) / evt.total));
      },
    });
  },

  // ---- Versions ----
  listVersions: (fileId) => api.get(`/files/${fileId}/versions`),
  downloadVersion: (fileId, version) =>
    api.get(`/files/${fileId}/versions/${version}/download`, { responseType: "blob" }),
  restoreVersion: (fileId, version) => api.post(`/files/${fileId}/versions/${version}/restore`),

  // ---- Sharing ----
  shareFile: (fileId, userId, permission = "view") =>
    api.post(`/files/${fileId}/share`, { userId, permission }),
  unshareFile: (fileId, userId) => api.delete(`/files/${fileId}/share/${userId}`),
};

export default resourceService;