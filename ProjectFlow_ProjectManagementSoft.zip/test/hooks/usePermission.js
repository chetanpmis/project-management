'use client';


export function usePermission(resource, permissionKey) {
  if (!resource || !permissionKey) return false;
  const ctx = resource.currentUserPermissions;
  if (!ctx) return false;
  return !!ctx.can?.[permissionKey];
}

export function useAnyPermission(resource, permissionKeys = []) {
  if (!resource) return false;
  const ctx = resource.currentUserPermissions;
  if (!ctx) return false;
  return permissionKeys.some((key) => !!ctx.can?.[key]);
}

export function useIsOwner(resource) {
  return !!resource?.currentUserPermissions?.isOwner;
}

export function useIsOrgLevel(resource) {
  return !!resource?.currentUserPermissions?.isOrgLevel;
}

export function useRole(resource) {
  return resource?.currentUserPermissions?.role ?? null;
}

export function usePermissionContext(resource) {
  return resource?.currentUserPermissions ?? null;
}