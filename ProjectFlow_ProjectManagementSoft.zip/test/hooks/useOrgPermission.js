'use client';

import { useMemo } from 'react';

export function useOrgPermission(org, permission) {
  return useMemo(() => !!org?.currentUserPermissions?.can?.[permission], [org, permission]);
}

export function useIsOrgOwner(org) {
  return !!org?.currentUserPermissions?.isOwner;
}

export function useOrgMembership(org) {
  return useMemo(() => {
    const ctx = org?.currentUserPermissions;
    if (!ctx) return null;
    return { role: ctx.role, status: ctx.status, permissions: ctx.permissions, isOwner: ctx.isOwner };
  }, [org]);
}