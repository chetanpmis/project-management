import { z } from 'zod';

export const updateProfileSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, 'Name must be at least 2 characters.')
    .max(100, 'Name cannot exceed 100 characters.'),

  bio: z
    .string()
    .max(500, 'Bio cannot exceed 500 characters.')
    .optional()
    .or(z.literal('')),

  // Working hours per day — capped at 12, not 24. A "day" beyond 12 working
  // hours isn't a realistic capacity value for this app's scheduling math.
  dailyCapacity: z.coerce
    .number()
    .min(1, 'Minimum is 1 hour.')
    .max(12, 'Maximum is 12 hours per day.'),

  // A calendar week only has 7 days — this was already correct, kept as-is.
  workingDaysPerWeek: z.coerce
    .number()
    .min(1, 'Minimum is 1 day.')
    .max(7, 'Maximum is 7 days.'),
});

export const changePasswordSchema = z
  .object({
    currentPassword: z
      .string()
      .min(1, 'Current password is required.'),

    newPassword: z
      .string()
      .min(8, 'Password must be at least 8 characters.')
      .max(100, 'Password cannot exceed 100 characters.'),

    confirmPassword: z
      .string()
      .min(1, 'Please confirm your password.'),
  })
  .refine(
    (data) => data.newPassword === data.confirmPassword,
    {
      path: ['confirmPassword'],
      message: 'Passwords do not match.',
    }
  )
  .refine(
    (data) => data.currentPassword !== data.newPassword,
    {
      path: ['newPassword'],
      message: 'New password must be different from the current password.',
    }
  );