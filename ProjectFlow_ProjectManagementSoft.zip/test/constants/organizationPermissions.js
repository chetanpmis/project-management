

export const ORG_PERMISSIONS = [
  { value: "org.view", label: "View organization", group: "Organization" },
  { value: "org.settings.edit", label: "Edit organization settings", group: "Organization" },
  { value: "org.delete", label: "Delete organization", group: "Organization" },
  { value: "team.invite", label: "Invite members", group: "Team" },
  { value: "team.invite.manage", label: "Resend / revoke invitations", group: "Team" },
  { value: "team.remove", label: "Remove members", group: "Team" },
  { value: "team.role.edit", label: "Change member roles", group: "Team" },
  { value: "team.permissions.edit", label: "Edit member permissions", group: "Team" },
  { value: "project.create", label: "Create projects", group: "Projects" },
  { value: "project.update", label: "Update projects", group: "Projects" },
  { value: "project.delete", label: "Delete projects", group: "Projects" },
];

export const ORG_PERMISSION_GROUPS = ["Organization", "Team", "Projects"].map((group) => ({
  group,
  permissions: ORG_PERMISSIONS.filter((p) => p.group === group),
}));


export const ORG_ROLE_STAGING_HINTS = {
  admin: [
    "org.view", "org.settings.edit",
    "team.invite", "team.invite.manage", "team.remove", "team.role.edit", "team.permissions.edit",
    "project.create", "project.update", "project.delete",
  ],
  manager: ["org.view", "team.invite", "team.invite.manage", "project.create", "project.update"],
  member: ["org.view"],
};

export const ORG_ROLE_OPTIONS = ["admin", "manager", "member"];

export const ORG_ROLE_META = {
  owner: { label: "Owner", badgeClass: "bg-amber-100 text-amber-700 border-amber-200" },
  admin: { label: "Admin", badgeClass: "bg-violet-100 text-violet-700 border-violet-200" },
  manager: { label: "Manager", badgeClass: "bg-blue-100 text-blue-700 border-blue-200" },
  member: { label: "Member", badgeClass: "bg-zinc-100 text-zinc-700 border-zinc-200" },
};