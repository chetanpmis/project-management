export const PROJECT_PERMISSIONS = {
  PROJECT_VIEW: 'project.view',
  PROJECT_DETAILS_VIEW: 'project.details.view',
  PROJECT_EDIT: 'project.edit',
  PROJECT_DELETE: 'project.delete',
  PROJECT_STATUS_EDIT: 'project.status.edit',
  PROJECT_SETTINGS_EDIT: 'project.settings.edit',

  TEAM_VIEW: 'team.view',
  TEAM_INVITE: 'team.invite',
  TEAM_REMOVE: 'team.remove',
  TEAM_ROLE_EDIT: 'team.role.edit',
  TEAM_PERMISSIONS_EDIT: 'team.permissions.edit',

  MILESTONE_VIEW: 'milestone.view',
  MILESTONE_CREATE: 'milestone.create',
  MILESTONE_EDIT: 'milestone.edit',
  MILESTONE_DELETE: 'milestone.delete',

  TASK_VIEW: 'task.view',
  TASK_DETAILS_VIEW: 'task.details.view',
  TASK_CREATE: 'task.create',
  TASK_EDIT: 'task.edit',
  TASK_DELETE: 'task.delete',
  TASK_ASSIGN: 'task.assign',

  COMMENT_VIEW: 'comment.view',
  COMMENT_CREATE: 'comment.create',
  COMMENT_EDIT: 'comment.edit',
  COMMENT_DELETE: 'comment.delete',

  CHAT_VIEW: 'chat.view',
  CHAT_EDIT: 'chat.edit',
  CHAT_SEND: 'chat.send',
  CHAT_DELETE: 'chat.delete',

  RESOURCE_VIEW: 'resource.view',
  RESOURCE_UPLOAD: 'resource.upload',
  RESOURCE_EDIT: 'resource.edit',
  RESOURCE_DELETE: 'resource.delete',
  RESOURCE_MANAGE: 'resource.manage',
};

export const ROLE_OPTIONS = ['manager', 'member', 'viewer'];

export const ROLE_META = {
  owner: {
    label: 'Owner',
    badgeClass: 'bg-violet-50 text-violet-700 border-violet-200',
    description: 'Full control over this project.',
  },
  manager: {
    label: 'Manager',
    badgeClass: 'bg-blue-50 text-blue-700 border-blue-200',
    description: 'Can manage tasks, milestones, team and settings.',
  },
  member: {
    label: 'Member',
    badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    description: 'Can work on tasks, comments and files.',
  },
  viewer: {
    label: 'Viewer',
    badgeClass: 'bg-slate-50 text-slate-600 border-slate-200',
    description: 'Read-only access to the project.',
  },
};

export const PERMISSION_GROUPS = [
  {
    id: 'project',
    label: 'Project',
    permissions: [
      { key: PROJECT_PERMISSIONS.PROJECT_DETAILS_VIEW, label: 'View project details' },
      { key: PROJECT_PERMISSIONS.PROJECT_EDIT, label: 'Edit project details' },
      { key: PROJECT_PERMISSIONS.PROJECT_STATUS_EDIT, label: 'Change project status' },
      { key: PROJECT_PERMISSIONS.PROJECT_SETTINGS_EDIT, label: 'Edit project settings' },
      { key: PROJECT_PERMISSIONS.PROJECT_DELETE, label: 'Delete project' },
    ],
  },
  {
    id: 'team',
    label: 'Team',
    permissions: [
      { key: PROJECT_PERMISSIONS.TEAM_VIEW, label: 'View team' },
      { key: PROJECT_PERMISSIONS.TEAM_INVITE, label: 'Add members' },
      { key: PROJECT_PERMISSIONS.TEAM_REMOVE, label: 'Remove members' },
      { key: PROJECT_PERMISSIONS.TEAM_ROLE_EDIT, label: 'Change member roles' },
      { key: PROJECT_PERMISSIONS.TEAM_PERMISSIONS_EDIT, label: 'Edit member permissions' },
    ],
  },
  {
    id: 'milestones',
    label: 'Milestones',
    permissions: [
      { key: PROJECT_PERMISSIONS.MILESTONE_VIEW, label: 'View milestones' },
      { key: PROJECT_PERMISSIONS.MILESTONE_CREATE, label: 'Create milestones' },
      { key: PROJECT_PERMISSIONS.MILESTONE_EDIT, label: 'Edit milestones' },
      { key: PROJECT_PERMISSIONS.MILESTONE_DELETE, label: 'Delete milestones' },
    ],
  },
  {
    id: 'tasks',
    label: 'Tasks',
    permissions: [
      { key: PROJECT_PERMISSIONS.TASK_VIEW, label: 'View task list' },
      { key: PROJECT_PERMISSIONS.TASK_DETAILS_VIEW, label: 'View task details' },
      { key: PROJECT_PERMISSIONS.TASK_CREATE, label: 'Create tasks' },
      { key: PROJECT_PERMISSIONS.TASK_EDIT, label: 'Edit tasks' },
      { key: PROJECT_PERMISSIONS.TASK_ASSIGN, label: 'Assign tasks' },
      { key: PROJECT_PERMISSIONS.TASK_DELETE, label: 'Delete tasks' },
    ],
  },
  {
    id: 'comments',
    label: 'Comments',
    permissions: [
      { key: PROJECT_PERMISSIONS.COMMENT_VIEW, label: 'View comments' },
      { key: PROJECT_PERMISSIONS.COMMENT_CREATE, label: 'Add comments' },
      { key: PROJECT_PERMISSIONS.COMMENT_EDIT, label: 'Edit comments' },
      { key: PROJECT_PERMISSIONS.COMMENT_DELETE, label: 'Delete comments' },
    ],
  },
  {
    id: 'chat',
    label: 'Chat',
    permissions: [
      { key: PROJECT_PERMISSIONS.CHAT_VIEW, label: 'View chat' },
      { key: PROJECT_PERMISSIONS.CHAT_SEND, label: 'Send messages' },
      { key: PROJECT_PERMISSIONS.CHAT_EDIT, label: 'Edit own messages' },
      { key: PROJECT_PERMISSIONS.CHAT_DELETE, label: 'Delete messages' },
    ],
  },
  {
    id: 'resources',
    label: 'Files & resources',
    permissions: [
      { key: PROJECT_PERMISSIONS.RESOURCE_VIEW, label: 'View files' },
      { key: PROJECT_PERMISSIONS.RESOURCE_UPLOAD, label: 'Upload files' },
      { key: PROJECT_PERMISSIONS.RESOURCE_EDIT, label: 'Rename / move files' },
      { key: PROJECT_PERMISSIONS.RESOURCE_DELETE, label: 'Delete files' },
      { key: PROJECT_PERMISSIONS.RESOURCE_MANAGE, label: 'Manage folders & sharing' },
    ],
  },
];