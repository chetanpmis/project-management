// "use client";

// import { useState } from "react";
// import { useRouter } from "next/navigation";
// import Link from "next/link";
// import { motion } from "framer-motion";
// import { useForm } from "react-hook-form";
// import { yupResolver } from "@hookform/resolvers/yup";
// import * as yup from "yup";
// import { Eye, EyeOff, Loader2 } from "lucide-react";
// import { toast } from "sonner";

// import AuthService from "@/services/auth.service";

// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";

// const schema = yup.object({
//   name: yup.string().required("Full name is required"),
//   email: yup.string().email("Invalid email").required("Email is required"),
//   password: yup
//     .string()
//     .min(6, "Password must be at least 6 characters")
//     .required("Password is required"),
// });

// export default function RegisterPage() {
//   const router = useRouter();
//   const [showPassword, setShowPassword] = useState(false);

//   const {
//     register,
//     handleSubmit,
//     formState: { errors, isSubmitting },
//   } = useForm({
//     resolver: yupResolver(schema),
//     mode: "onSubmit",
//   });

//   const onSubmit = async (values) => {
//     try {
//       const response = await AuthService.register(values);
//       toast.success(response.message || "Registration successful!");
//       router.push("/login");
//     } catch (error) {
//       toast.error(
//         error?.response?.data?.error ||
//         error?.message ||
//         "Registration failed"
//       );
//     }
//   };

//   return (
//     <div className="flex min-h-screen items-center justify-center bg-white px-4">
//       <motion.div
//         initial={{ opacity: 0, y: 25 }}
//         animate={{ opacity: 1, y: 0 }}
//         transition={{ duration: 0.4 }}
//         className="w-full max-w-md"
//       >
//         <Card className="border border-zinc-200 bg-white shadow-xl shadow-zinc-200/50">
//           <CardContent className="p-8">
//             <div className="mb-8 text-center">
//               <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-xl bg-zinc-900 text-xl font-bold text-white shadow-md shadow-zinc-300">
//                 PM
//               </div>
//               <h1 className="text-3xl font-bold text-zinc-900">Create Account</h1>
//               <p className="mt-2 text-zinc-500">Start managing your projects</p>
//             </div>

//             <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
//               <div>
//                 <label className="mb-2 block text-sm font-medium text-zinc-700">
//                   Full Name
//                 </label>
//                 <Input
//                   placeholder="John Doe"
//                   className="border-zinc-300 bg-white text-zinc-900 placeholder:text-zinc-400 focus-visible:ring-zinc-900"
//                   {...register("name")}
//                 />
//                 {errors.name && (
//                   <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
//                 )}
//               </div>

//               <div>
//                 <label className="mb-2 block text-sm font-medium text-zinc-700">
//                   Email
//                 </label>
//                 <Input
//                   placeholder="john@example.com"
//                   className="border-zinc-300 bg-white text-zinc-900 placeholder:text-zinc-400 focus-visible:ring-zinc-900"
//                   {...register("email")}
//                 />
//                 {errors.email && (
//                   <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>
//                 )}
//               </div>

//               <div>
//                 <label className="mb-2 block text-sm font-medium text-zinc-700">
//                   Password
//                 </label>
//                 <div className="relative">
//                   <Input
//                     type={showPassword ? "text" : "password"}
//                     placeholder="********"
//                     className="border-zinc-300 bg-white pr-10 text-zinc-900 placeholder:text-zinc-400 focus-visible:ring-zinc-900"
//                     {...register("password")}
//                   />
//                   <button
//                     type="button"
//                     className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 transition-colors hover:text-zinc-700"
//                     onClick={() => setShowPassword(!showPassword)}
//                   >
//                     {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
//                   </button>
//                 </div>
//                 {errors.password && (
//                   <p className="mt-1 text-sm text-red-600">{errors.password.message}</p>
//                 )}
//               </div>

//               <Button
//                 type="submit"
//                 disabled={isSubmitting}
//                 className="h-11 w-full bg-zinc-900 text-white shadow-md shadow-zinc-300 transition-colors hover:bg-zinc-800"
//               >
//                 {isSubmitting ? (
//                   <>
//                     <Loader2 className="mr-2 h-4 w-4 animate-spin" />
//                     Creating Account...
//                   </>
//                 ) : (
//                   "Create Account"
//                 )}
//               </Button>
//             </form>

//             <div className="mt-6 text-center text-sm text-zinc-500">
//               Already have an account?{" "}
//               <Link href="/login" className="font-medium text-zinc-900 hover:underline">
//                 Login
//               </Link>
//             </div>
//           </CardContent>
//         </Card>
//       </motion.div>
//     </div>
//   );
// }


"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useQuery } from "@tanstack/react-query";
import { Eye, EyeOff, Loader2, Building2, KeyRound, AlertCircle } from "lucide-react";
import { toast } from "sonner";

import AuthService from "@/services/auth.service";
import organizationService from "@/services/organization.service";
import useAuthStore from "@/store/auth-store"; // NEW

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const schema = yup.object({
  name: yup.string().required("Full name is required"),
  email: yup.string().email("Invalid email").required("Email is required"),
  password: yup.string().min(6, "Password must be at least 6 characters").required("Password is required"),
  inviteCode: yup.string().optional(),
});

export default function RegisterPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const inviteToken = searchParams.get("invite");
  const login = useAuthStore((state) => state.login); // NEW

  const [showPassword, setShowPassword] = useState(false);
  const [useManualCode, setUseManualCode] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: yupResolver(schema),
    mode: "onSubmit",
    defaultValues: { inviteCode: "" },
  });

  const {
    data: inviteRes,
    isLoading: isValidatingInvite,
    isError: inviteTokenFailed,
  } = useQuery({
    queryKey: ["invitationToken", inviteToken],
    queryFn: () => organizationService.validateInvitationToken(inviteToken),
    enabled: !!inviteToken,
    retry: false,
  });

  const invite = inviteRes?.data;

  useEffect(() => {
    if (invite?.email) setValue("email", invite.email);
  }, [invite, setValue]);

  useEffect(() => {
    if (inviteToken && !isValidatingInvite && inviteTokenFailed) {
      setUseManualCode(true);
    }
  }, [inviteToken, isValidatingInvite, inviteTokenFailed]);

  const onSubmit = async (values) => {
    try {
      const payload = {
        name: values.name,
        email: values.email,
        password: values.password,
      };

      if (inviteToken && invite) {
        payload.invite = inviteToken;
      } else if (useManualCode && values.inviteCode) {
        payload.inviteCode = values.inviteCode.trim().toUpperCase();
      }

      const response = await AuthService.register(payload);

      // ---- Auto-login: backend now returns a token on register, so log
      // the user straight in instead of bouncing them to /login. ----
      login(response.user, response.token);

      if (response.joinedOrganization) {
        toast.success(`Welcome! You've joined ${response.joinedOrganization.name}.`);
        router.push(`/organizations/${response.joinedOrganization.id}`);
      } else {
        toast.success(response.message || "Registration successful!");
        router.push("/dashboard");
      }
    } catch (error) {
      toast.error(error?.response?.data?.error || error?.message || "Registration failed");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-white px-4">
      <motion.div
        initial={{ opacity: 0, y: 25 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md"
      >
        <Card className="border border-zinc-200 bg-white shadow-xl shadow-zinc-200/50">
          <CardContent className="p-8">
            <div className="mb-8 text-center">
              <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-xl bg-zinc-900 text-xl font-bold text-white shadow-md shadow-zinc-300">
                PM
              </div>
              <h1 className="text-3xl font-bold text-zinc-900">Create Account</h1>
              <p className="mt-2 text-zinc-500">Start managing your projects</p>
            </div>

            {inviteToken && (
              <div className="mb-6 rounded-xl border border-zinc-200 bg-zinc-50 p-4">
                {isValidatingInvite ? (
                  <p className="text-sm text-zinc-500 flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Checking your invitation…
                  </p>
                ) : invite ? (
                  <div className="flex items-start gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-zinc-900 text-white">
                      <Building2 className="h-4.5 w-4.5" />
                    </div>
                    <p className="text-sm text-zinc-700">
                      {`You're joining`} <strong className="text-zinc-900">{invite.organization?.name}</strong> as{" "}
                      <span className="capitalize font-medium">{invite.role}</span> once you create your account.
                    </p>
                  </div>
                ) : (
                  <p className="text-sm text-red-600 flex items-center gap-2">
                    <AlertCircle className="h-4 w-4 shrink-0" />
                    This invitation link is invalid or has expired. Enter your invitation code below instead.
                  </p>
                )}
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <div>
                <label className="mb-2 block text-sm font-medium text-zinc-700">Full Name</label>
                <Input
                  placeholder="John Doe"
                  className="border-zinc-300 bg-white text-zinc-900 placeholder:text-zinc-400 focus-visible:ring-zinc-900"
                  {...register("name")}
                />
                {errors.name && <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>}
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-zinc-700">Email</label>
                <Input
                  placeholder="john@example.com"
                  disabled={!!invite?.email}
                  className="border-zinc-300 bg-white text-zinc-900 placeholder:text-zinc-400 focus-visible:ring-zinc-900 disabled:bg-zinc-50 disabled:text-zinc-500"
                  {...register("email")}
                />
                {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email.message}</p>}
                {invite?.email && <p className="mt-1 text-xs text-zinc-500">Locked to the invited email address.</p>}
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-zinc-700">Password</label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="********"
                    className="border-zinc-300 bg-white pr-10 text-zinc-900 placeholder:text-zinc-400 focus-visible:ring-zinc-900"
                    {...register("password")}
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 transition-colors hover:text-zinc-700"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password.message}</p>}
              </div>

              {useManualCode ? (
                <div>
                  <label className="mb-2 block text-sm font-medium text-zinc-700 flex items-center gap-1.5">
                    <KeyRound className="h-3.5 w-3.5" />
                    Invitation code
                  </label>
                  <Input
                    placeholder="AB3D-9F2K"
                    className="border-zinc-300 bg-white text-zinc-900 placeholder:text-zinc-400 focus-visible:ring-zinc-900 font-mono tracking-wider uppercase"
                    {...register("inviteCode")}
                    onChange={(e) => setValue("inviteCode", e.target.value.toUpperCase())}
                  />
                  <p className="mt-1 text-xs text-zinc-500">
                    {`Ask the person who invited you for this code if you didn't receive an email.`}
                  </p>
                </div>
              ) : (
                !inviteToken && (
                  <button
                    type="button"
                    onClick={() => setUseManualCode(true)}
                    className="text-xs font-medium text-zinc-600 hover:text-zinc-900 hover:underline"
                  >
                    Have an invitation code?
                  </button>
                )
              )}

              <Button
                type="submit"
                disabled={isSubmitting || isValidatingInvite}
                className="h-11 w-full bg-zinc-900 text-white shadow-md shadow-zinc-300 transition-colors hover:bg-zinc-800"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating Account...
                  </>
                ) : (
                  "Create Account"
                )}
              </Button>
            </form>

            <div className="mt-6 text-center text-sm text-zinc-500">
              Already have an account?{" "}
              <Link href="/login" className="font-medium text-zinc-900 hover:underline">
                Login
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}