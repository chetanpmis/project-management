"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { XCircle, CheckCircle2, Loader2 } from "lucide-react";
import api from "@/lib/axios";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function RejectInvitationPage() {
  const { token } = useParams();
  const router = useRouter();
  const [status, setStatus] = useState("loading"); // loading | success | error
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!token) return;
    api
      .get(`/invitations/reject/${token}`)
      .then((res) => {
        setStatus("success");
        setMessage(res.data?.message || "Invitation declined.");
      })
      .catch((err) => {
        setStatus("error");
        setMessage(err?.response?.data?.message || "Could not decline this invitation.");
      });
  }, [token]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-white px-4">
      <Card className="w-full max-w-sm border border-zinc-200 shadow-lg">
        <CardContent className="p-8 text-center">
          {status === "loading" && (
            <>
              <Loader2 className="mx-auto mb-4 h-8 w-8 animate-spin text-zinc-400" />
              <p className="text-zinc-600">Processing…</p>
            </>
          )}
          {status === "success" && (
            <>
              <CheckCircle2 className="mx-auto mb-4 h-10 w-10 text-emerald-600" />
              <h1 className="text-lg font-semibold text-zinc-900">Invitation declined</h1>
              <p className="mt-2 text-sm text-zinc-500">{message}</p>
            </>
          )}
          {status === "error" && (
            <>
              <XCircle className="mx-auto mb-4 h-10 w-10 text-red-600" />
              <h1 className="text-lg font-semibold text-zinc-900">Something went wrong</h1>
              <p className="mt-2 text-sm text-zinc-500">{message}</p>
            </>
          )}
          <Button className="mt-6 w-full" onClick={() => router.push("/login")}>
            Go to login
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}