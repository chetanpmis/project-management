"use client";
// import "./globals.css";
// import { useEffect } from "react";
// import { Toaster } from "sonner";
// import useAuthStore from "@/store/auth-store";

// export default function RootLayout({ children }) {
//   const initialize = useAuthStore((state) => state.initialize);

//   useEffect(() => {
//     initialize();
//   }, []);

//   return (
//     <html lang="en">
//       <body className="bg-zinc-950 text-white">
//         {children}
//         <Toaster richColors position="top-right" />
//       </body>
//     </html>
//   );
// }

import "./globals.css";
import { Geist, Geist_Mono } from "next/font/google";

import { useEffect } from "react";
import { Toaster } from "sonner";
import useAuthStore from "@/store/auth-store";
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';

const geist = Geist({
  variable: "--font-geist",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

export default function RootLayout({ children }) {
  const initialize = useAuthStore((state) => state.initialize);

  useEffect(() => {
    initialize();
  }, []);
  return (
    <html
      lang="en"
      className={`${geist.variable} ${geistMono.variable}`}
      suppressHydrationWarning
    >
      <body className="">
        <QueryClientProvider client={queryClient}>
          {children}
          <Toaster richColors position="top-right" />

          <ReactQueryDevtools initialIsOpen={false} />
        </QueryClientProvider>
      </body>
    </html>
  );
}
