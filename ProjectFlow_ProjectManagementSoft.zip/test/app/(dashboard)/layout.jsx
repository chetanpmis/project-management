// app/(dashboard)/layout.jsx
"use client";

import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import organizationService from "@/services/organization.service";
import useOrganizationStore from "@/store/organization-store";
import { Loader2 } from "lucide-react";

export default function DashboardLayout({ children }) {
  const router = useRouter();
  const pathname = usePathname();
  const { activeOrganizationSlug } = useOrganizationStore();

  const { data: orgsRes, isLoading } = useQuery({
    queryKey: ["organizations"],
    queryFn: organizationService.listOrganizations,
  });

  useEffect(() => {
    if (isLoading) return;
    const orgs = orgsRes?.data || [];

    // Unscoped routes — never touched by this layout's redirect logic
    const isUnscoped = pathname.startsWith("/organizations") || pathname === "/onboarding";
    if (isUnscoped) return;

    // Zero orgs at all → onboarding
    if (orgs.length === 0) {
      router.replace("/onboarding");
      return;
    }

    // ⭐ If the first path segment is already a real org slug, we're
    // legitimately inside that org's routes — do NOT redirect.
    // This is what was missing before, causing every navigation inside
    // an org (projects, tasks, organization, etc.) to bounce back to
    // /${slug}/dashboard.
    const firstSegment = pathname.split("/")[1];
    const isAlreadyInValidOrg = orgs.some((o) => o.slug === firstSegment);
    if (isAlreadyInValidOrg) return;

    // Only reached for something like bare "/dashboard" (no slug) or a
    // stale/invalid slug — pick last active org, or fall back to the first.
    const target = orgs.find((o) => o.slug === activeOrganizationSlug) || orgs[0];
    router.replace(`/${target.slug}/dashboard`);
  }, [isLoading, orgsRes, pathname]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return children;
}