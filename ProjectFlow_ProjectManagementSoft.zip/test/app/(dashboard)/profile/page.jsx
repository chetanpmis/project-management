'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import Cropper from 'react-easy-crop';
import {
  Camera,
  Trash2,
  Mail,
  Calendar,
  Shield,
  Loader2,
  AlertCircle,
  Clock3,
  CalendarDays,
  UserCircle2,
  LockKeyhole,
  ImagePlus,
  ChevronRight,
} from 'lucide-react';
import { toast } from 'sonner';

import userService from '@/services/user.service';
import { updateProfileSchema } from '@/schema/profileSchema';

import ChangePasswordCard from '@/components/common/ChangePasswordCard';
import ProfileSkeleton from '@/components/common/ProfileSkeleton';

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const DAILY_CAPACITY_MAX = 12;
const WORKING_DAYS_MAX = 7;

/** Same multi-word initials logic used in Header.jsx, kept consistent app-wide. */
const getInitials = (name) => {
  if (!name) return 'U';
  return name
    .split(' ')
    .filter(Boolean)
    .map((word) => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
};

/** Plain label + error helper used instead of the shadcn Form/FormField wrappers */
function Field({ label, htmlFor, error, children, className }) {
  return (
    <div className={cn('space-y-1.5', className)}>
      <label htmlFor={htmlFor} className="text-sm font-medium text-foreground">
        {label}
      </label>
      {children}
      {error && (
        <p className="flex items-center gap-1.5 text-sm text-destructive">
          <AlertCircle className="h-3.5 w-3.5 shrink-0" /> {error}
        </p>
      )}
    </div>
  );
}

const inputClass =
  'flex h-11 w-full rounded-lg border border-input bg-white px-3.5 py-2 text-base shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 disabled:cursor-not-allowed disabled:opacity-60';

const textareaClass =
  'flex w-full rounded-lg border border-input bg-white px-3.5 py-2.5 text-base shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 resize-y';

// ---------- avatar crop helpers ----------
function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener('load', () => resolve(reader.result));
    reader.addEventListener('error', reject);
    reader.readAsDataURL(file);
  });
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.addEventListener('load', () => resolve(img));
    img.addEventListener('error', reject);
    img.crossOrigin = 'anonymous';
    img.src = src;
  });
}

/** Crops the source image to the given pixel area and returns a square JPEG File. */
async function getCroppedAvatarFile(imageSrc, cropPixels, fileName = 'avatar.jpg') {
  const image = await loadImage(imageSrc);
  const size = Math.round(Math.max(cropPixels.width, cropPixels.height));
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(
    image,
    cropPixels.x,
    cropPixels.y,
    cropPixels.width,
    cropPixels.height,
    0,
    0,
    size,
    size
  );

  return new Promise((resolve) => {
    canvas.toBlob(
      (blob) => resolve(blob ? new File([blob], fileName, { type: 'image/jpeg' }) : null),
      'image/jpeg',
      0.92
    );
  });
}

/** Dialog that lets the user zoom/pan a freshly selected image into a circular crop before upload. */
function AvatarCropDialog({ open, onOpenChange, imageSrc, onConfirm, isSaving }) {
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [cropPixels, setCropPixels] = useState(null);

  useEffect(() => {
    if (open) {
      setCrop({ x: 0, y: 0 });
      setZoom(1);
      setCropPixels(null);
    }
  }, [open]);

  const handleCropComplete = useCallback((_, areaPixels) => {
    setCropPixels(areaPixels);
  }, []);

  return (
    <Dialog open={open} onOpenChange={(next) => !isSaving && onOpenChange(next)}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ImagePlus className="h-5 w-5" />
            Adjust your photo
          </DialogTitle>
        </DialogHeader>

        <div className="relative h-72 w-full overflow-hidden rounded-lg bg-slate-100">
          {imageSrc && (
            <Cropper
              image={imageSrc}
              crop={crop}
              zoom={zoom}
              aspect={1}
              cropShape="round"
              showGrid={false}
              onCropChange={setCrop}
              onZoomChange={setZoom}
              onCropComplete={handleCropComplete}
            />
          )}
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground w-10 shrink-0">Zoom</span>
          <input
            type="range"
            min={1}
            max={3}
            step={0.05}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="flex-1 accent-primary"
          />
        </div>

        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSaving}>
            Cancel
          </Button>
          <Button type="button" onClick={() => onConfirm(cropPixels)} disabled={!cropPixels || isSaving}>
            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save photo
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Left-hand identity summary card. */
function IdentitySummary({ profile, onChangePhoto, onRemovePhoto, isUploading, isRemoving }) {
  return (
    <div className="bg-white rounded-xl border border-border shadow-sm p-6 text-center">
      <div className="relative inline-block">
        <Avatar className="h-24 w-24 border mx-auto">
         
          <AvatarImage src={profile?.avatar || ''} alt={profile?.name} />
          <AvatarFallback className="text-2xl">{getInitials(profile?.name)}</AvatarFallback>
        </Avatar>
        <button
          type="button"
          onClick={onChangePhoto}
          disabled={isUploading}
          className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full border bg-white shadow-sm hover:bg-slate-50 transition-colors disabled:opacity-60"
          aria-label="Change avatar"
        >
          {isUploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
        </button>
      </div>

      <h3 className="text-lg font-semibold mt-4 truncate">{profile?.name}</h3>
      <div className="flex items-center justify-center gap-1.5 text-muted-foreground text-sm mt-1">
        <Mail className="h-3.5 w-3.5 shrink-0" />
        <span className="truncate">{profile?.email}</span>
      </div>

      <div className="flex flex-wrap justify-center gap-2 mt-4">
        <Badge variant="secondary" className="gap-1">
          <Shield className="h-3 w-3" />
          {profile?.role}
        </Badge>
        <Badge variant={profile?.status === 'active' ? 'default' : 'destructive'} className="capitalize">
          {profile?.status}
        </Badge>
      </div>

      <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground mt-3">
        <Calendar className="h-3.5 w-3.5" />
        Joined {profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : '—'}
      </div>

      <div className="flex flex-col gap-2 mt-5">
        <Button variant="outline" size="sm" onClick={onChangePhoto} disabled={isUploading}>
          <Camera className="mr-2 h-3.5 w-3.5" /> Change photo
        </Button>
        {profile?.avatar && (
          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={onRemovePhoto} disabled={isRemoving}>
            {isRemoving ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : <Trash2 className="mr-2 h-3.5 w-3.5" />}
            Remove photo
          </Button>
        )}
      </div>
    </div>
  );
}

/** Left-hand section nav. */
function SectionNav({ active, onChange }) {
  const items = [
    { id: 'profile', label: 'Profile Info', icon: UserCircle2 },
    { id: 'security', label: 'Security', icon: LockKeyhole },
  ];

  return (
    <div className="bg-white rounded-xl border border-border shadow-sm p-2">
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = active === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onChange(item.id)}
            className={cn(
              'w-full flex items-center gap-2.5 rounded-lg px-3.5 py-2.5 text-sm font-medium transition-colors',
              isActive ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-slate-50 hover:text-foreground'
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            <span className="flex-1 text-left">{item.label}</span>
            {isActive && <ChevronRight className="h-4 w-4 shrink-0" />}
          </button>
        );
      })}
    </div>
  );
}

export default function ProfilePage() {
  const queryClient = useQueryClient();
  const fileInputRef = useRef(null);

  const [activeSection, setActiveSection] = useState('profile');
  const [cropDialogOpen, setCropDialogOpen] = useState(false);
  const [rawImageSrc, setRawImageSrc] = useState(null);
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);

  const { data: profile, isLoading } = useQuery({
    queryKey: ['profile'],
    queryFn: userService.getProfile,
  });

  

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isDirty },
  } = useForm({
    resolver: zodResolver(updateProfileSchema),
    defaultValues: {
      name: '',
      bio: '',
      dailyCapacity: 8,
      workingDaysPerWeek: 5,
    },
  });

  useEffect(() => {
    if (!profile) return;
    reset({
      name: profile.name || '',
      bio: profile.bio || '',
      dailyCapacity: profile.dailyCapacity,
      workingDaysPerWeek: profile.workingDaysPerWeek,
    });
  }, [profile, reset]);

  const updateProfileMutation = useMutation({
    mutationFn: userService.updateProfile,
    onSuccess: () => {
      toast.success('Profile updated successfully.');
      queryClient.invalidateQueries({ queryKey: ['profile'] });
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'Failed to update profile.');
    },
  });

  const uploadAvatarMutation = useMutation({
    mutationFn: userService.uploadAvatar,
    onSuccess: () => {
      toast.success('Avatar updated successfully.');
      queryClient.invalidateQueries({ queryKey: ['profile'] });
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'Failed to upload avatar.');
    },
  });

  const deleteAvatarMutation = useMutation({
    mutationFn: userService.deleteAvatar,
    onSuccess: () => {
      toast.success('Avatar removed.');
      queryClient.invalidateQueries({ queryKey: ['profile'] });
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || 'Failed to remove avatar.');
    },
  });

  const onSubmit = (values) => {
    updateProfileMutation.mutate(values);
  };

  const handleAvatarClick = () => fileInputRef.current?.click();

  const handleAvatarChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const dataUrl = await readFileAsDataURL(file);
    setRawImageSrc(dataUrl);
    setCropDialogOpen(true);
    e.target.value = '';
  };

  const handleCropConfirm = async (cropPixels) => {
    if (!cropPixels || !rawImageSrc) return;
    const file = await getCroppedAvatarFile(rawImageSrc, cropPixels);
    if (!file) {
      toast.error('Could not process that image. Please try another.');
      return;
    }
    uploadAvatarMutation.mutate(file, {
      onSuccess: () => {
        setCropDialogOpen(false);
        setRawImageSrc(null);
      },
    });
  };

  const handleDeleteAvatar = () => {
    if (!profile?.avatar) return;
    if (!confirm('Remove your profile picture?')) return;
    deleteAvatarMutation.mutate();
  };

  if (isLoading) {
    return <ProfileSkeleton />;
  }

  return (
    <div className="min-h-screen">
      <div className="">
        <div className="mb-6">
          <h1 className="text-2xl font-bold tracking-tight">My Profile</h1>
          <p className="text-muted-foreground mt-1">Manage your account information and security.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6 items-start">
          {/* ================= LEFT COLUMN ================= */}
          <div className="space-y-6">
            <IdentitySummary
              profile={profile}
              onChangePhoto={handleAvatarClick}
              onRemovePhoto={handleDeleteAvatar}
              isUploading={uploadAvatarMutation.isPending}
              isRemoving={deleteAvatarMutation.isPending}
            />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleAvatarChange}
            />
            <SectionNav active={activeSection} onChange={setActiveSection} />
          </div>

          {/* ================= RIGHT COLUMN ================= */}
          <div className="bg-white rounded-xl border border-border shadow-sm p-6 lg:p-8">
            {activeSection === 'profile' ? (
              <>
                <div className="mb-6">
                  <h2 className="text-lg font-semibold">Basic Information</h2>
                  <p className="text-sm text-muted-foreground mt-1">Your name and working preferences.</p>
                </div>

                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6" noValidate>
                  <div className="grid gap-6 md:grid-cols-2">
                    <Field label="Full Name" htmlFor="name" error={errors.name?.message}>
                      <input
                        id="name"
                        placeholder="Enter your full name"
                        className={cn(inputClass, errors.name && 'border-destructive focus-visible:ring-destructive')}
                        {...register('name')}
                      />
                    </Field>

                    <Field label="Email">
                      <input
                        value={profile?.email || ''}
                        disabled
                        className={cn(inputClass, 'bg-slate-50 text-muted-foreground')}
                      />
                    </Field>

                    <Field
                      label={`Daily Capacity (Hours) — max ${DAILY_CAPACITY_MAX}`}
                      htmlFor="dailyCapacity"
                      error={errors.dailyCapacity?.message}
                    >
                      <div className="relative">
                        <Clock3 className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                        <input
                          id="dailyCapacity"
                          type="number"
                          min={1}
                          max={DAILY_CAPACITY_MAX}
                          className={cn(inputClass, 'pl-10', errors.dailyCapacity && 'border-destructive focus-visible:ring-destructive')}
                          {...register('dailyCapacity', { valueAsNumber: true })}
                        />
                      </div>
                    </Field>

                    <Field
                      label={`Working Days Per Week — max ${WORKING_DAYS_MAX}`}
                      htmlFor="workingDaysPerWeek"
                      error={errors.workingDaysPerWeek?.message}
                    >
                      <div className="relative">
                        <CalendarDays className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                        <input
                          id="workingDaysPerWeek"
                          type="number"
                          min={1}
                          max={WORKING_DAYS_MAX}
                          className={cn(inputClass, 'pl-10', errors.workingDaysPerWeek && 'border-destructive focus-visible:ring-destructive')}
                          {...register('workingDaysPerWeek', { valueAsNumber: true })}
                        />
                      </div>
                    </Field>
                  </div>

                  <Field label="Bio" htmlFor="bio" error={errors.bio?.message}>
                    <textarea
                      id="bio"
                      rows={5}
                      placeholder="Tell us something about yourself..."
                      className={cn(textareaClass, errors.bio && 'border-destructive focus-visible:ring-destructive')}
                      {...register('bio')}
                    />
                  </Field>

                  <div className="flex justify-end pt-4 border-t">
                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending || !isDirty}
                      className="min-w-[150px]"
                    >
                      {updateProfileMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        'Save Changes'
                      )}
                    </Button>
                  </div>
                </form>
              </>
            ) : (
              <>
                <div className="mb-6">
                  <h2 className="text-lg font-semibold">Security</h2>
                  <p className="text-sm text-muted-foreground mt-1">Change the password used to sign in.</p>
                </div>

                <div className="flex items-center justify-between rounded-lg border border-border px-5 py-4">
                  <div>
                    <p className="text-sm font-medium">Password</p>
                    <p className="text-sm text-muted-foreground">Update your account password.</p>
                  </div>
                  <Button variant="outline" onClick={() => setChangePasswordOpen(true)}>
                    <LockKeyhole className="mr-2 h-4 w-4" />
                    Change Password
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      <AvatarCropDialog
        open={cropDialogOpen}
        onOpenChange={(next) => {
          setCropDialogOpen(next);
          if (!next) setRawImageSrc(null);
        }}
        imageSrc={rawImageSrc}
        onConfirm={handleCropConfirm}
        isSaving={uploadAvatarMutation.isPending}
      />

      <ChangePasswordCard open={changePasswordOpen} onOpenChange={setChangePasswordOpen} />
    </div>
  );
}