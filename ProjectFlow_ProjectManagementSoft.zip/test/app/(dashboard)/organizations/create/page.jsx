"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Building2, Loader2, AlertCircle } from "lucide-react";

import organizationService from "@/services/organization.service";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import PageHeader from "@/components/common/PageHeader";
import { SuccessDialog, ErrorDialog } from "@/components/common/AppDialogs";

const schema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100, "Name is too long"),
  description: z.string().max(500, "Description is too long").optional(),
});

function FieldError({ message }) {
  if (!message) return null;
  return (
    <p className="text-red-500 text-sm flex items-center gap-1 mt-1.5">
      <AlertCircle className="h-3.5 w-3.5" /> {message}
    </p>
  );
}

export default function CreateOrganizationPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [createdSlug, setCreatedSlug] = useState(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: { name: "", description: "" },
  });

  const createMutation = useMutation({
    mutationFn: organizationService.createOrganization,
    onSuccess: (res) => {
      queryClient.invalidateQueries({ queryKey: ["organizations"] });
      // Slug-based routing — this used to store res.data._id.
      setCreatedSlug(res.data?.slug);
      setShowSuccess(true);
    },
    onError: (err) => {
      setErrorMessage(err.message || "Failed to create organization");
      setShowError(true);
    },
  });

  const onSubmit = (data) => createMutation.mutate(data);

 const handleSuccessClose = () => {
  setShowSuccess(false);
  router.push(createdSlug ? `/${createdSlug}/dashboard` : "/organizations");
};

  return (
    <div className="min-h-screen bg-background p-6 lg:p-8">
      <div className="max-w-2xl mx-auto">
        <PageHeader showBack title="New organization" description="You'll automatically become the owner." />

        <form onSubmit={handleSubmit(onSubmit)}>
          <Card>
            <CardHeader className="pb-5">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
                  <Building2 className="h-4.5 w-4.5" />
                </span>
                <div>
                  <CardTitle className="text-xl font-semibold">Organization details</CardTitle>
                  <CardDescription className="text-base">Basic info to get your workspace started.</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-base font-medium">
                  Organization name<span className="text-red-500 ml-0.5">*</span>
                </Label>
                <Input id="name" placeholder="e.g. Acme Corp" className="h-12 text-base" {...register("name")} />
                <FieldError message={errors.name?.message} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-base font-medium">
                  Description
                </Label>
                <Textarea
                  id="description"
                  placeholder="What does your team work on?"
                  className="min-h-[100px] resize-y text-base"
                  {...register("description")}
                />
                <FieldError message={errors.description?.message} />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-3 mt-6">
            <Button type="button" variant="outline" onClick={() => router.back()} className="h-12 px-6 text-base">
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting || createMutation.isPending} className="h-12 px-8 text-base min-w-[180px]">
              {isSubmitting || createMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Creating…
                </>
              ) : (
                "Create organization"
              )}
            </Button>
          </div>
        </form>

        <SuccessDialog
          open={showSuccess}
          onOpenChange={setShowSuccess}
          title="Organization created"
          description="Your organization is ready. Invite your team to get started."
          actionLabel="Go to organization"
          onAction={handleSuccessClose}
        />
        <ErrorDialog open={showError} onOpenChange={setShowError} title="Creation failed" description={errorMessage} />
      </div>
    </div>
  );
}