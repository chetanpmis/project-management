// app/(dashboard)/organizations/page.jsx
"use client";

import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import organizationService from "@/services/organization.service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Plus } from "lucide-react";

export default function OrganizationsPage() {
  const router = useRouter();
  const { data: orgsRes } = useQuery({ queryKey: ["organizations"], queryFn: organizationService.listOrganizations });
  const orgs = orgsRes?.data || [];

  const goCreate = () => router.push("/organizations/create");

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">Organizations</h1>
        <Button size="lg" onClick={goCreate}>
          <Plus className="mr-2 h-5 w-5" /> New Organization
        </Button>
      </div>

      {orgs.length === 0 ? (
        <div className="text-center py-20">
          <Building2 className="h-16 w-16 mx-auto text-zinc-600" />
          <h3 className="text-2xl font-medium">No organizations yet</h3>
          <Button onClick={goCreate} className="mt-6">Create your first organization</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {orgs.map((org) => (
            // ⭐ was /organizations/${org.slug} — now goes straight into the scoped shell
            <Card key={org._id} className="cursor-pointer hover:shadow-xl" onClick={() => router.push(`/${org.slug}/dashboard`)}>
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 bg-primary/10 rounded-2xl flex items-center justify-center text-3xl">
                    {org.logo ? <img src={org.logo} className="h-10 w-10 object-cover" /> : "🏢"}
                  </div>
                  <div>
                    <h3 className="font-semibold text-xl truncate">{org.name}</h3>
                    <p className="text-zinc-400">/{org.slug}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}