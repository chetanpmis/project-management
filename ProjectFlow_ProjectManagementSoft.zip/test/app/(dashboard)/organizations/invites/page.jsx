"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, X, Loader2, KeyRound, Mail } from "lucide-react";
import { toast } from "sonner";

import JoinByCodeDialog from "@/components/organizations/JoinByCodeDialog";

import organizationService from "@/services/organization.service";
import { Button } from "@/components/ui/button";
import PageHeader from "@/components/common/PageHeader";
import EmptyState from "@/components/feedback/EmptyState";
import { CardListSkeleton } from "@/components/common/Skeletons";

function getInitials(name = "") {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("");
}

// deterministic accent so the same org always gets the same color
const AVATAR_COLORS = [
  "bg-violet-500/15 text-violet-600",
  "bg-blue-500/15 text-blue-600",
  "bg-emerald-500/15 text-emerald-600",
  "bg-amber-500/15 text-amber-600",
  "bg-rose-500/15 text-rose-600",
  "bg-cyan-500/15 text-cyan-600",
];
function getAvatarColor(seed = "") {
  const idx = seed.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0) % AVATAR_COLORS.length;
  return AVATAR_COLORS[idx];
}

export default function OrganizationInvitesPage() {
  const router = useRouter();
  const queryClient = useQueryClient();
  const [respondingId, setRespondingId] = useState(null);
  const [joinByCodeOpen, setJoinByCodeOpen] = useState(false);

  const { data: invitesRes, isLoading } = useQuery({
    queryKey: ["organizationInvites"],
    queryFn: organizationService.listMyInvites,
  });

  const invites = invitesRes?.data || [];

  const respondMutation = useMutation({
    mutationFn: ({ slug, action }) => organizationService.respondToInvite(slug, action),
    onSuccess: (_res, { action, slug }) => {
      queryClient.invalidateQueries({ queryKey: ["organizationInvites"] });
      queryClient.invalidateQueries({ queryKey: ["organizations"] });
      toast.success(action === "accept" ? "Invitation accepted." : "Invitation declined.");
      if (action === "accept") router.push(`/organizations/${slug}`);
    },
    onError: (err) => toast.error(err.message || "Could not respond to invitation."),
    onSettled: () => setRespondingId(null),
  });

  const respond = (slug, action) => {
    setRespondingId(`${slug}-${action}`);
    respondMutation.mutate({ slug, action });
  };

  return (
    <div className="min-h-screen bg-background p-6 lg:p-8">
      <div className="max-w-3xl mx-auto">
        <PageHeader
          showBack
          title="Organization invitations"
          description="Organizations that have invited you to join."
          actions={
            <Button variant="outline" onClick={() => setJoinByCodeOpen(true)} className="inline-flex items-center gap-2">
              <KeyRound className="h-4 w-4" />
              Join with a code
            </Button>
          }
        />

        {isLoading ? (
          <CardListSkeleton count={2} height="h-24" />
        ) : invites.length === 0 ? (
          <EmptyState
            icon={Mail}
            title="No pending invitations"
            description="You're all caught up. New invitations will show up here."
          />
        ) : (
          <div className="space-y-3">
            {invites.map((org) => {
              const invite = org.members?.[0];
              const isDeclining = respondingId === `${org.slug}-decline`;
              const isAccepting = respondingId === `${org.slug}-accept`;
              const initials = getInitials(org.name) || "?";
              const avatarColor = getAvatarColor(org._id || org.name);

              return (
                <div
                  key={org._id}
                  className="group relative flex flex-col gap-4 rounded-2xl border border-border/60 bg-card p-5 shadow-sm transition-all hover:border-border hover:shadow-md sm:flex-row sm:items-center sm:justify-between"
                >
                  {/* left accent bar */}
                  <span className="absolute inset-y-0 left-0 w-1 rounded-l-2xl bg-primary/70 opacity-0 transition-opacity group-hover:opacity-100" />

                  <div className="flex min-w-0 items-center gap-4">
                    <div
                      className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-sm font-semibold ${avatarColor}`}
                    >
                      {initials}
                    </div>
                    <div className="min-w-0 space-y-1">
                      <p className="truncate text-[15px] font-semibold leading-tight text-foreground">
                        {org.name}
                      </p>
                      <p className="truncate text-sm text-muted-foreground">
                        Invited by{" "}
                        <span className="font-medium text-foreground/80">{org.owner?.name}</span>
                      </p>
                      <span className="inline-flex items-center rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium capitalize text-muted-foreground">
                        {invite?.role || "member"}
                      </span>
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-2 self-stretch sm:self-auto">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="flex-1 text-muted-foreground hover:bg-red-500/10 hover:text-red-600 sm:flex-none"
                      disabled={respondMutation.isPending}
                      onClick={() => respond(org.slug, "decline")}
                    >
                      {isDeclining ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <X className="h-4 w-4" />
                      )}
                      <span className="ml-1.5">Decline</span>
                    </Button>
                    <Button
                      size="sm"
                      className="flex-1 shadow-sm sm:flex-none"
                      disabled={respondMutation.isPending}
                      onClick={() => respond(org.slug, "accept")}
                    >
                      {isAccepting ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4" />
                      )}
                      <span className="ml-1.5">Accept</span>
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      <JoinByCodeDialog open={joinByCodeOpen} onOpenChange={setJoinByCodeOpen} />
    </div>
  );
}