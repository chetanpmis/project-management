// app/(dashboard)/onboarding/page.jsx
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { Building2, Plus, KeyRound, Mail, ArrowRight, Sparkles } from "lucide-react";

import organizationService from "@/services/organization.service";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import JoinByCodeDialog from "@/components/organizations/JoinByCodeDialog";

export default function OnboardingPage() {
  const router = useRouter();
  const [joinByCodeOpen, setJoinByCodeOpen] = useState(false);

  // Check for pending invites so we can nudge the user toward them
  const { data: invitesRes } = useQuery({
    queryKey: ["organizationInvites"],
    queryFn: organizationService.listMyInvites,
  });
  const pendingInvites = invitesRes?.data || [];

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-b from-background to-muted/30">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-10">
          <div className="h-14 w-14 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mx-auto mb-4">
            <Sparkles className="h-7 w-7" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Welcome 👋</h1>
          <p className="text-muted-foreground text-base">
            Let's get you set up. Create a new workspace or join an existing one.
          </p>
        </div>

        {pendingInvites.length > 0 && (
          <Card
            className="mb-4 cursor-pointer border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors"
            onClick={() => router.push("/organizations/invites")}
          >
            <CardContent className="p-5 flex items-center gap-4">
              <div className="h-11 w-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
                <Mail className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold">
                  You have {pendingInvites.length} pending invitation{pendingInvites.length > 1 ? "s" : ""}
                </p>
                <p className="text-sm text-muted-foreground">
                  Join {pendingInvites[0]?.name}
                  {pendingInvites.length > 1 ? ` and ${pendingInvites.length - 1} more` : ""}
                </p>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card
            className="cursor-pointer hover:shadow-lg hover:border-primary/40 transition-all"
            onClick={() => router.push("/organizations/create")}
          >
            <CardContent className="p-6 flex flex-col items-start gap-3">
              <div className="h-11 w-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                <Plus className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Create a workspace</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Start fresh — you'll be the owner and can invite your team.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card
            className="cursor-pointer hover:shadow-lg hover:border-primary/40 transition-all"
            onClick={() => setJoinByCodeOpen(true)}
          >
            <CardContent className="p-6 flex flex-col items-start gap-3">
              <div className="h-11 w-11 rounded-xl bg-violet-500/10 text-violet-600 flex items-center justify-center">
                <KeyRound className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Join with a code</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Have an invitation code from a teammate? Enter it here.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-8">
          <Button variant="ghost" size="sm" onClick={() => router.push("/organizations/invites")}>
            <Building2 className="h-4 w-4 mr-1.5" />
            View all invitations
          </Button>
        </div>
      </div>

      <JoinByCodeDialog open={joinByCodeOpen} onOpenChange={setJoinByCodeOpen} />
    </div>
  );
}