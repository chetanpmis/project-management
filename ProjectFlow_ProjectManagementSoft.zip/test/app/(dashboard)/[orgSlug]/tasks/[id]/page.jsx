'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Loader2,
  Pencil,
  Play,
  Pause,
  CheckCircle2,
  X,
  Plus,
  UserPlus,
  Clock as ClockIcon,
  History,
  Trash2,
  Calendar,
  Flag,
  Lock,
  Activity,
  ShieldAlert,
} from 'lucide-react';
import taskService from '@/services/task.service';
import CommentSection from '@/components/tasks/CommentSection';
import TaskFormDialog from '@/components/tasks/TaskFormDialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { usePermission } from '@/hooks/usePermission';
import { PROJECT_PERMISSIONS } from '@/constants/projectPermissions';
import useAuthStore from '@/store/auth-store';
import PageHeader from '@/components/common/PageHeader';
import { TaskStatusBadge, PriorityBadge } from '@/components/common/StatusBadges';
import { ConfirmDialog } from '@/components/common/AppDialogs';
import ErrorState from '@/components/feedback/ErrorState';
import EmptyState from '@/components/feedback/EmptyState';

const CHECKLIST_DEBOUNCE_MS = 500;

function formatSeconds(totalSeconds = 0) {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = Math.floor(safe % 60);
  return [h, m, s].map((v) => String(v).padStart(2, '0')).join(':');
}

function formatDurationCompact(totalSeconds = 0) {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = Math.floor(safe % 60);
  const parts = [];
  if (h) parts.push(`${h}h`);
  if (m || h) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(' ');
}

function formatDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

function formatDateTimeWithZone(value) {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const formatted = d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  return `${formatted} · ${tz}`;
}

function getInitials(name = '') {
  return name.split(' ').map((w) => w[0]).join('').toUpperCase().slice(0, 2) || 'U';
}

function MetaRow({ icon: Icon, label, children }) {
  if (!children) return null;
  return (
    <div className="flex items-start gap-3 py-3 first:pt-0 last:pb-0 border-b last:border-0 border-slate-100">
      <Icon className="h-4 w-4 text-slate-400 mt-0.5 shrink-0" />
      <div className="min-w-0 flex-1">
        <p className="text-[11px] uppercase tracking-wide text-slate-400 font-medium mb-0.5">{label}</p>
        {children}
      </div>
    </div>
  );
}

function PersonChip({ person, onClick, removable, onRemove }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group flex items-center gap-2 rounded-full border border-slate-200 bg-white pl-1 pr-3 py-1 hover:border-slate-300 hover:shadow-sm transition-all"
    >
      <Avatar className="h-6 w-6">
        <AvatarFallback className="text-[10px] font-semibold">{getInitials(person.name)}</AvatarFallback>
      </Avatar>
      <span className="text-sm font-medium text-slate-700 group-hover:text-slate-900">{person.name}</span>
      {removable && (
        <span
          role="button"
          tabIndex={0}
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="ml-0.5 text-slate-300 hover:text-red-500"
        >
          <X className="h-3.5 w-3.5" />
        </span>
      )}
    </button>
  );
}

export default function TaskDetailPage({ teamMembers = [], project = null }) {
  const { id: taskId, orgSlug } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const { user } = useAuthStore();

  const [editOpen, setEditOpen] = useState(false);
  const [newChecklistItem, setNewChecklistItem] = useState('');
  const [watcherDialogOpen, setWatcherDialogOpen] = useState(false);
  const [removeChecklistTarget, setRemoveChecklistTarget] = useState(null);

  const checklistDebounceRef = useRef({});

  console.log('[TaskDetailPage] incoming project prop:', project);
  console.log('[TaskDetailPage] project.currentUserPermissions:', project?.currentUserPermissions);

  const canViewTaskList = usePermission(project, PROJECT_PERMISSIONS.TASK_VIEW);
  const canViewTaskDetails = usePermission(project, PROJECT_PERMISSIONS.TASK_DETAILS_VIEW);
  const canEditTask = usePermission(project, PROJECT_PERMISSIONS.TASK_EDIT);
  const canAssignTask = usePermission(project, PROJECT_PERMISSIONS.TASK_ASSIGN);

  console.log('[TaskDetailPage] canViewTaskList:', canViewTaskList, '| canViewTaskDetails:', canViewTaskDetails);
  console.log('[TaskDetailPage] canEditTask:', canEditTask, '| canAssignTask:', canAssignTask);

  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['task', taskId],
    queryFn: () => taskService.getTaskById(taskId),
    enabled: !!taskId && canViewTaskList && canViewTaskDetails,
  });

  const { data: projectTasksData } = useQuery({
    queryKey: ['tasks', data?.data?.project?._id],
    queryFn: () => taskService.getTasksByProject(data.data.project._id),
    enabled: !!data?.data?.project?._id,
  });

  const { data: timerData } = useQuery({
    queryKey: ['timer', taskId],
    queryFn: () => taskService.getTimerStatus(taskId),
    enabled: !!taskId && canViewTaskDetails,
    refetchInterval: 5000,
  });

  const task = data?.data;

  console.log('[TaskDetailPage] loaded task:', task);
  if (task) {
    console.log('[TaskDetailPage] task.isCurrentUserAssignee:', task.isCurrentUserAssignee, '| isCurrentUserWatcher:', task.isCurrentUserWatcher, '| isCurrentUserCreator:', task.isCurrentUserCreator);
  }

  const projectTasks = projectTasksData?.data || [];
  const timerRunning = timerData?.data?.isRunning;
  const isCompleted = task?.status === 'completed';

  const baseSeconds = task?.timeSpent || 0;
  const currentSessionSeconds = timerData?.data?.elapsedSeconds || 0;
  const serverTotalSeconds = timerRunning ? baseSeconds + currentSessionSeconds : baseSeconds;

  const [liveSeconds, setLiveSeconds] = useState(serverTotalSeconds);

  useEffect(() => {
    setLiveSeconds(serverTotalSeconds);
  }, [serverTotalSeconds]);

  useEffect(() => {
    if (!timerRunning) return undefined;
    const interval = setInterval(() => setLiveSeconds((prev) => prev + 1), 1000);
    return () => clearInterval(interval);
  }, [timerRunning]);

  const displaySeconds = timerRunning ? liveSeconds : baseSeconds;

  const invalidateTask = () => {
    queryClient.invalidateQueries({ queryKey: ['task', taskId] });
    queryClient.invalidateQueries({ queryKey: ['timer', taskId] });
  };

  const startTimerMutation = useMutation({ mutationFn: () => taskService.startTimer(taskId), onSuccess: invalidateTask });
  const stopTimerMutation = useMutation({ mutationFn: () => taskService.stopTimer(taskId), onSuccess: invalidateTask });
  const resumeTimerMutation = useMutation({ mutationFn: () => taskService.resumeTimer(taskId), onSuccess: invalidateTask });
  const finishTaskMutation = useMutation({ mutationFn: () => taskService.finishTask(taskId), onSuccess: invalidateTask });

  const addChecklistMutation = useMutation({
    mutationFn: (item) => taskService.addChecklistItem(taskId, item),
    onSuccess: () => {
      setNewChecklistItem('');
      invalidateTask();
    },
  });

  const toggleChecklistMutation = useMutation({
    mutationFn: ({ itemId, completed }) => taskService.toggleChecklistItem(taskId, itemId, completed),
    onError: () => invalidateTask(),
  });

  const applyOptimisticChecklist = useCallback(
    (itemId, completed) => {
      queryClient.setQueryData(['task', taskId], (old) => {
        if (!old?.data) return old;
        return {
          ...old,
          data: {
            ...old.data,
            checklist: old.data.checklist.map((c) => (c._id === itemId ? { ...c, completed } : c)),
          },
        };
      });
    },
    [queryClient, taskId]
  );

  const removeChecklistMutation = useMutation({
    mutationFn: (itemId) => taskService.removeChecklistItem(taskId, itemId),
    onSuccess: () => {
      invalidateTask();
      setRemoveChecklistTarget(null);
    },
  });

  const addWatcherMutation = useMutation({ mutationFn: (userId) => taskService.addWatcher(taskId, userId), onSuccess: invalidateTask });
  const removeWatcherMutation = useMutation({ mutationFn: (userId) => taskService.removeWatcher(taskId, userId), onSuccess: invalidateTask });

  const isAssignee = !!task?.isCurrentUserAssignee;

  const canControlTimer = isAssignee && !isCompleted;
  const canFinishTask = isAssignee && !isCompleted;
  const canManageWatchers = canAssignTask && !isCompleted;
  const canModifyChecklist = isAssignee && !isCompleted;

  const handleToggleChecklist = (itemId, completed) => {
    if (!canModifyChecklist) return;
    applyOptimisticChecklist(itemId, completed);
    if (checklistDebounceRef.current[itemId]) clearTimeout(checklistDebounceRef.current[itemId]);
    checklistDebounceRef.current[itemId] = setTimeout(() => {
      toggleChecklistMutation.mutate({ itemId, completed });
      delete checklistDebounceRef.current[itemId];
    }, CHECKLIST_DEBOUNCE_MS);
  };

  const checklistDone = task?.checklist?.filter((c) => c.completed).length || 0;
  const checklistTotal = task?.checklist?.length || 0;
  const checklistProgress = checklistTotal ? Math.round((checklistDone / checklistTotal) * 100) : 0;
  const allChecklistCompleted = checklistTotal > 0 && checklistDone === checklistTotal;

  const workLogs = task?.workLogs || [];
  const hasActiveTimerHistory = workLogs.length > 0;

  const watcherIds = new Set((task?.watchers || []).map((w) => w._id));
  const availableWatchers = teamMembers.filter((m) => !watcherIds.has(m._id));

  const isOverdue = task?.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed';
  const milestoneName = task?.milestone?.name || null;

  const goToUser = (userId) => router.push(`/${orgSlug}/users/${userId}`);

  if (!canViewTaskList || !canViewTaskDetails) {
    console.log('[TaskDetailPage] blocked: canViewTaskList =', canViewTaskList, ', canViewTaskDetails =', canViewTaskDetails);
    return (
      <div className="max-w-3xl mx-auto p-8">
        <EmptyState
          icon={<ShieldAlert className="h-8 w-8" />}
          title="You don't have access to this task"
          description="Ask a project owner or manager to grant you task view access."
          action={
            <Button variant="outline" onClick={() => router.push(`/${orgSlug}/projects`)}>
              Back to projects
            </Button>
          }
        />
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="w-full max-w-[1500px] mx-auto p-6 space-y-5">
        <div className="h-8 w-32 bg-muted rounded animate-pulse" />
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-5">
          <div className="space-y-5">
            <div className="h-40 bg-muted rounded-xl animate-pulse" />
            <div className="h-32 bg-muted rounded-xl animate-pulse" />
          </div>
          <div className="space-y-5">
            <div className="h-24 bg-muted rounded-xl animate-pulse" />
            <div className="h-24 bg-muted rounded-xl animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !task) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <ErrorState title="Couldn't load this task" description={error?.message} onRetry={refetch} />
      </div>
    );
  }

  return (
    <div className="w-full max-w-[1500px] mx-auto">
      <PageHeader
        showBack
        size="form"
        eyebrow={task.project?.name || 'No Project'}
        title={task.title}
        badges={[
          <TaskStatusBadge key="status" status={isOverdue ? 'overdue' : task.status} />,
          <PriorityBadge key="priority" priority={task.priority} />,
        ]}
        actions={
          <>
            {canFinishTask && (
              <Button
                size="sm"
                onClick={() => finishTaskMutation.mutate()}
                disabled={finishTaskMutation.isPending || (checklistTotal > 0 && !allChecklistCompleted)}
                className="gap-2"
              >
                {finishTaskMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                Finish Task
              </Button>
            )}
            {canEditTask && (
              <Button size="sm" variant="outline" onClick={() => setEditOpen(true)}>
                <Pencil className="h-4 w-4 mr-1.5" />
                Edit
              </Button>
            )}
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6 px-6 pb-10">
        <div className="space-y-6 min-w-0">
          <div className="bg-white border rounded-xl p-6 shadow-sm">
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              Description
              {isCompleted && <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded">Completed</span>}
            </h3>
            {task.description ? (
              <p className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">{task.description}</p>
            ) : (
              <p className="text-sm text-muted-foreground italic">No description provided.</p>
            )}
            {task.tags?.length > 0 && (
              <div className="flex gap-1.5 flex-wrap mt-6">
                {task.tags.map((t) => (
                  <span key={t} className="text-xs px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full font-medium">
                    #{t}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white border rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2">
                Checklist
                {checklistTotal > 0 && (
                  <span className="text-sm font-normal text-muted-foreground">
                    {checklistDone}/{checklistTotal} • {checklistProgress}%
                  </span>
                )}
              </h2>
              {checklistTotal > 0 && (
                <div className="w-24 bg-muted rounded-full h-1.5">
                  <div className="bg-emerald-600 h-1.5 rounded-full transition-all" style={{ width: `${checklistProgress}%` }} />
                </div>
              )}
            </div>

            {!isAssignee && !isCompleted && task.checklist?.length > 0 && (
              <div className="flex items-center gap-2 mb-4 text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
                <Lock className="h-3.5 w-3.5 shrink-0" />
                Only assignees can update this checklist.
              </div>
            )}

            <ul className="space-y-1 mb-5">
              {task.checklist?.length > 0 ? (
                task.checklist.map((c) => (
                  <li key={c._id} className="flex items-center gap-3 text-sm group rounded-lg px-3 py-2.5 -mx-3 hover:bg-slate-50 transition-colors">
                    <input
                      type="checkbox"
                      className="h-4 w-4 accent-emerald-600 mt-0.5 disabled:opacity-40 disabled:cursor-not-allowed"
                      checked={c.completed}
                      disabled={!canModifyChecklist}
                      onChange={(e) => handleToggleChecklist(c._id, e.target.checked)}
                    />
                    <span className={`flex-1 ${c.completed ? 'line-through text-muted-foreground' : ''}`}>{c.item}</span>
                    {canModifyChecklist && (
                      <button
                        onClick={() => setRemoveChecklistTarget(c)}
                        className="text-muted-foreground hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </li>
                ))
              ) : (
                <li className="text-sm text-muted-foreground py-4 text-center">No checklist items yet.</li>
              )}
            </ul>

            {canModifyChecklist && (
              <div className="flex gap-2">
                <Input
                  className="flex-1"
                  placeholder="Add new checklist item..."
                  value={newChecklistItem}
                  onChange={(e) => setNewChecklistItem(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newChecklistItem.trim()) addChecklistMutation.mutate(newChecklistItem.trim());
                  }}
                />
                <Button
                  size="sm"
                  onClick={() => newChecklistItem.trim() && addChecklistMutation.mutate(newChecklistItem.trim())}
                  disabled={addChecklistMutation.isPending || !newChecklistItem.trim()}
                >
                  {addChecklistMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                </Button>
              </div>
            )}
          </div>

          <div className="bg-white border rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold flex items-center gap-2">
                <History className="h-4 w-4" /> Work Log History
                {workLogs.length > 0 && (
                  <span className="text-sm font-normal text-muted-foreground">
                    {workLogs.length} session{workLogs.length !== 1 ? 's' : ''} • total {formatDurationCompact(baseSeconds)}
                  </span>
                )}
              </h2>
            </div>

            {workLogs.length > 0 ? (
              <div className="overflow-hidden rounded-xl border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-slate-50">
                      <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">User</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Time</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Description</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Duration</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[...workLogs]
                      .sort((a, b) => new Date(b.date || b.startTime || b.start) - new Date(a.date || a.startTime || a.start))
                      .map((log, idx) => {
                        const userName = log.user?.name || 'Unknown user';
                        const seconds = log.seconds || (log.duration ?? 0);
                        const date = log.date || log.startTime || log.start;
                        const description = log.description || `Timer ${log.stopped ? 'stopped' : 'started'}`;
                        return (
                          <tr key={log._id || idx} className="hover:bg-slate-50 transition-colors">
                            <td className="px-4 py-3">
                              <button onClick={() => log.user?._id && goToUser(log.user._id)} className="font-medium text-sm hover:underline text-left">
                                {userName}
                              </button>
                            </td>
                            <td className="px-4 py-3 text-xs text-muted-foreground">{formatDateTime(date)}</td>
                            <td className="px-4 py-3 text-sm">{description}</td>
                            <td className="px-4 py-3 font-mono text-sm font-medium">{formatDurationCompact(seconds)}</td>
                          </tr>
                        );
                      })}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground py-6 text-center border border-dashed rounded-xl">
                No work log entries yet — start the timer to begin tracking.
              </p>
            )}
          </div>

          <div className="bg-white border rounded-xl shadow-sm overflow-hidden">
            <CommentSection taskId={taskId} currentUserId={user?.id} disabled={isCompleted} />
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white border rounded-xl p-5 shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <div className="flex items-center gap-2 uppercase text-xs tracking-widest text-muted-foreground font-medium">
                <ClockIcon className="h-4 w-4" />
                TIME TRACKED
              </div>
              {timerRunning && (
                <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-medium">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  LIVE
                </div>
              )}
            </div>

            <div className="text-3xl font-mono font-semibold mb-1 tracking-tighter">{formatSeconds(displaySeconds)}</div>
            <p className="text-xs text-muted-foreground mb-4">
              Total across {workLogs.length} past session{workLogs.length !== 1 ? 's' : ''}{timerRunning ? ' + current session' : ''}
            </p>

            {!isCompleted && canControlTimer && (
              <div className="flex gap-2">
                {!timerRunning && (
                  <Button
                    className="flex-1"
                    onClick={() => (hasActiveTimerHistory ? resumeTimerMutation.mutate() : startTimerMutation.mutate())}
                    disabled={startTimerMutation.isPending || resumeTimerMutation.isPending}
                  >
                    {startTimerMutation.isPending || resumeTimerMutation.isPending ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Play className="mr-2 h-4 w-4" />
                    )}
                    {hasActiveTimerHistory ? 'Resume' : 'Start Timer'}
                  </Button>
                )}
                {timerRunning && (
                  <Button variant="secondary" className="flex-1" onClick={() => stopTimerMutation.mutate()} disabled={stopTimerMutation.isPending}>
                    {stopTimerMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Pause className="mr-2 h-4 w-4" />}
                    Stop
                  </Button>
                )}
              </div>
            )}

            {!isCompleted && !canControlTimer && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-slate-50 border border-slate-100 rounded-lg px-3 py-2">
                <Lock className="h-3.5 w-3.5 shrink-0" />
                Only assignees can control the timer.
              </div>
            )}
          </div>

          <div className="bg-white border rounded-xl p-5 shadow-sm">
            <div className="uppercase text-xs tracking-widest text-muted-foreground font-medium mb-3">DETAILS</div>

            <MetaRow icon={Activity} label="Status">
              <TaskStatusBadge status={isOverdue ? 'overdue' : task.status} />
            </MetaRow>

            <MetaRow icon={Flag} label="Priority">
              <PriorityBadge priority={task.priority} />
            </MetaRow>

            <MetaRow icon={CheckCircle2} label="Progress">
              <div className="flex items-center gap-2">
                <Progress value={task.progress || 0} className="h-1.5 flex-1" />
                <span className="text-sm font-medium text-slate-700 tabular-nums">{task.progress || 0}%</span>
              </div>
            </MetaRow>

            <MetaRow icon={Flag} label="Project">
              <p className="text-sm font-medium text-slate-800 truncate">{task.project?.name}</p>
            </MetaRow>

            <MetaRow icon={CheckCircle2} label="Milestone">
              <p className="text-sm font-medium text-slate-800 truncate">{milestoneName || '—'}</p>
            </MetaRow>

            <MetaRow icon={Calendar} label="Start date">
              <p className="text-sm font-medium text-slate-800">{formatDateTimeWithZone(task.startDate) || '—'}</p>
            </MetaRow>

            <MetaRow icon={Calendar} label="Due date">
              <p className={`text-sm font-medium ${isOverdue ? 'text-red-600' : 'text-slate-800'}`}>{formatDateTimeWithZone(task.dueDate) || '—'}</p>
            </MetaRow>
          </div>

          <div className="bg-white border rounded-xl p-5 shadow-sm">
            <div className="uppercase text-xs tracking-widest text-muted-foreground font-medium mb-3">ASSIGNEES</div>
            <div className="flex flex-wrap gap-2">
              {task.assignees?.length > 0 ? (
                task.assignees.map((a) => <PersonChip key={a._id} person={a} onClick={() => goToUser(a._id)} />)
              ) : (
                <p className="text-sm text-muted-foreground">No assignees</p>
              )}
            </div>
          </div>

          <div className="bg-white border rounded-xl p-5 shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <div className="uppercase text-xs tracking-widest text-muted-foreground font-medium">WATCHERS</div>
              {canManageWatchers && (
                <Button variant="ghost" size="sm" className="h-7 text-blue-600" onClick={() => setWatcherDialogOpen(true)}>
                  <UserPlus className="h-3.5 w-3.5 mr-1" /> Add
                </Button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {task.watchers?.length > 0 ? (
                task.watchers.map((w) => (
                  <PersonChip
                    key={w._id}
                    person={w}
                    onClick={() => goToUser(w._id)}
                    removable={canManageWatchers || w._id === user?.id}
                    onRemove={() => removeWatcherMutation.mutate(w._id)}
                  />
                ))
              ) : (
                <p className="text-sm text-muted-foreground">No watchers</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <TaskFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        projectId={task.project?._id}
        project={project}
        teamMembers={teamMembers}
        projectTasks={projectTasks}
        initialData={task}
        isEditing
        onCreated={invalidateTask}
      />

      <Dialog open={watcherDialogOpen} onOpenChange={setWatcherDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Watcher</DialogTitle>
          </DialogHeader>
          <div className="max-h-80 overflow-auto py-2">
            {availableWatchers.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">All team members are already watching.</p>
            ) : (
              availableWatchers.map((m) => (
                <button
                  key={m._id}
                  onClick={() => addWatcherMutation.mutate(m._id)}
                  className="w-full text-left px-4 py-3 hover:bg-slate-100 rounded-lg flex justify-between items-center"
                >
                  <div>
                    <div>{m.name}</div>
                    <div className="text-xs text-muted-foreground">{m.email}</div>
                  </div>
                </button>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!removeChecklistTarget}
        onOpenChange={(v) => !v && setRemoveChecklistTarget(null)}
        title="Remove checklist item?"
        description={`Are you sure you want to remove "${removeChecklistTarget?.item}"?`}
        confirmLabel="Remove"
        loading={removeChecklistMutation.isPending}
        onConfirm={() => removeChecklistMutation.mutate(removeChecklistTarget?._id)}
      />
    </div>
  );
}