
"use client";

import { useEffect } from "react";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import organizationService from "@/services/organization.service";
import useOrganizationStore from "@/store/organization-store";
import Sidebar from "@/components/Layout/Sidebar";
import Header from "@/components/Layout/Header"; // ⭐ your existing header, adjust path if different
import { Loader2 } from "lucide-react";
import NoPermissionState from "@/components/feedback/NoPermissionState";

export default function OrgLayout({ children }) {
  const { orgSlug } = useParams();
  const setActiveOrganization = useOrganizationStore((s) => s.setActiveOrganization);

  const { data: orgRes, isLoading, error } = useQuery({
    queryKey: ["organization", orgSlug],
    queryFn: () => organizationService.getOrganization(orgSlug),
    enabled: !!orgSlug,
    retry: (count, err) => err?.status !== 403 && err?.status !== 404 && count < 2,
  });

  const org = orgRes?.data;

  useEffect(() => {
    if (org) setActiveOrganization(org);
  }, [org, setActiveOrganization]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error?.status === 403 || error?.status === 404 || !org) {
    return (
      <div className="min-h-screen flex items-center justify-center p-8 text-zinc-950 bg-zinc-100">
        <NoPermissionState
          title="Organization not found or access denied"
          description="Check the URL, or you may need an invitation to this workspace."
        />
      </div>
    );
  }

  return (
    <div className="flex h-screen text-zinc-950 bg-zinc-100">
        <Sidebar />
        <div className="flex flex-1 flex-col overflow-hidden">
          <Header />
          <main className="flex-1 overflow-y-auto p-6">
            {children}
          </main>
        </div>
      </div>
  );
}