
'use client';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Pencil,
  Trash2,
  Plus,
  Users,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Calendar as CalendarIcon,
  Globe,
  Lock,
  MoreVertical,
  GanttChartSquare,
  KanbanSquare,
  Maximize2,
  BarChart3,
  MessageSquare,
  ShieldAlert,
} from 'lucide-react';
import projectService from '@/services/project.service';
import taskService from '@/services/task.service';
import chatService from '@/services/chat.service';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

import TasksTable from '@/components/tasks/TasksTable';
import TaskFormDialog from '@/components/tasks/TaskFormDialog';
import ProjectGanttChart from '@/components/projects/ProjectGanttChart';
import ProjectResourcesTab from '@/components/projects/ProjectResourcesTab';
import KanbanBoard from '@/components/projects/KanbanBoard';
import PageHeader from '@/components/common/PageHeader';
import { usePermission } from '@/hooks/usePermission';
import {
  ProjectStatusBadge,
  PriorityBadge,
  HealthBadge,
  MilestoneStatusBadge,
} from '@/components/common/StatusBadges';
import { CardListSkeleton, TableSkeleton } from '@/components/common/Skeletons';
import EmptyState from '@/components/feedback/EmptyState';
import {
  SuccessDialog,
  ErrorDialog,
  ConfirmDialog,
  useMutationFeedback,
} from '@/components/common/AppDialogs';
import StatCard, { StatCardGrid } from '@/components/common/StatCard';
import ProjectTeamPanel from '@/components/projects/ProjectTeamPanel';
import { PROJECT_PERMISSIONS } from '@/constants/projectPermissions';
import ProjectChatTab from '@/components/projects/ProjectChatTab';
import { formatDate } from '@/lib/date';

export default function ProjectDetailsPage() {
  const { orgSlug, id: projectId } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const feedback = useMutationFeedback();

  const base = `/${orgSlug}`;
  const projectBase = `${base}/projects/${projectId}`;

  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [deleteProjectOpen, setDeleteProjectOpen] = useState(false);
  const [isDeletingProject, setIsDeletingProject] = useState(false);

  const { data: projectRes, isLoading: isProjectLoading } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => projectService.getProjectById(projectId),
    enabled: !!projectId,
  });

  const project = projectRes?.data;

  const canViewDetails = usePermission(project, PROJECT_PERMISSIONS.PROJECT_DETAILS_VIEW);

  const { data: statsRes } = useQuery({
    queryKey: ['projectStats', projectId],
    queryFn: () => projectService.getProjectStats(projectId),
    enabled: !!projectId && canViewDetails,
  });

  const { data: tasksRes, isLoading: isTasksLoading } = useQuery({
    queryKey: ['tasks', projectId],
    queryFn: () => taskService.getTasksByProject(projectId, { limit: 50 }),
    enabled: !!projectId && canViewDetails,
  });

  const { data: chatUnreadRes } = useQuery({
    queryKey: ['chat', projectId, 'unreadCount'],
    queryFn: () => chatService.getUnreadCount(projectId),
    refetchInterval: 15000,
    enabled: !!projectId && canViewDetails,
  });

  const chatUnread = chatUnreadRes?.data?.unreadCount ?? 0;

  const stats = statsRes?.data;
  const tasks = tasksRes?.data || [];

  const canEditProject = usePermission(project, PROJECT_PERMISSIONS.PROJECT_EDIT);
  const canDeleteProject = usePermission(project, PROJECT_PERMISSIONS.PROJECT_DELETE);
  const canViewTasks = usePermission(project, PROJECT_PERMISSIONS.TASK_VIEW);
  const canCreateTask = usePermission(project, PROJECT_PERMISSIONS.TASK_CREATE);
  const canViewTeam = usePermission(project, PROJECT_PERMISSIONS.TEAM_VIEW);
  const canViewChat = usePermission(project, PROJECT_PERMISSIONS.CHAT_VIEW);
  const canSendChat = usePermission(project, PROJECT_PERMISSIONS.CHAT_SEND);
  const canViewResources = usePermission(project, PROJECT_PERMISSIONS.RESOURCE_VIEW);
  const canViewMilestones = usePermission(project, PROJECT_PERMISSIONS.MILESTONE_VIEW);

  const invalidateProject = () => {
    queryClient.invalidateQueries({ queryKey: ['project', projectId] });
    queryClient.invalidateQueries({ queryKey: ['projectStats', projectId] });
    queryClient.invalidateQueries({ queryKey: ['kanban', projectId] });
  };

  const handleConfirmDeleteProject = async () => {
    setIsDeletingProject(true);
    try {
      await projectService.deleteProject(projectId);
      router.push(`${base}/projects`);
    } catch (err) {
      setIsDeletingProject(false);
      setDeleteProjectOpen(false);
      feedback
        .run(Promise.reject(err), '', err?.message || 'Could not delete this project.')
        .catch(() => {});
    }
  };

  if (isProjectLoading) {
    return (
      <div className="max-w-6xl mx-auto p-6 lg:p-8 space-y-6">
        <PageHeader loading />
        <StatCardGrid columns={4}>
          {[...Array(4)].map((_, i) => (
            <StatCard key={i} loading />
          ))}
        </StatCardGrid>
        <CardListSkeleton count={3} height="h-16" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <EmptyState
          title="Project not found"
          description="This project may have been deleted, or you may not have access to it."
          action={
            <Button variant="outline" onClick={() => router.push(`${base}/projects`)}>
              Back to projects
            </Button>
          }
        />
      </div>
    );
  }

  if (!canViewDetails) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <EmptyState
          icon={<ShieldAlert className="h-8 w-8" />}
          title="You don't have access to this project"
          description="Ask a project owner or manager to grant you view access."
          action={
            <Button variant="outline" onClick={() => router.push(`${base}/projects`)}>
              Back to projects
            </Button>
          }
        />
      </div>
    );
  }

  const milestones = (project.milestones || []).sort((a, b) => new Date(a.startDate) - new Date(b.startDate));
  const pendingCount = milestones.filter((m) => m.status === 'pending').length;
  const inProgressCount = milestones.filter((m) => m.status === 'in-progress').length;
  const completedCount = milestones.filter((m) => m.status === 'completed').length;
  const isOverdue = !!stats?.isOverdue;

  const handleFullScreen = () => router.push(`${projectBase}/gantt`);

  return (
    <div className="max-w-full mx-auto">
      <PageHeader
        showBack
        title={project.name}
        eyebrow={project.projectCode}
        badges={[
          <ProjectStatusBadge key="status" status={project.status} />,
          <PriorityBadge key="priority" priority={project.priority} />,
          <HealthBadge key="health" health={project.health} />,
          isOverdue && (
            <Badge key="overdue" variant="outline" className="gap-1 border-red-200 bg-red-50 text-red-700">
              <AlertTriangle className="h-3 w-3" />
              Overdue
            </Badge>
          ),
          <Badge key="vis" variant="outline" className="capitalize gap-1">
            {project.visibility === 'private' ? <Lock className="h-3 w-3" /> : <Globe className="h-3 w-3" />}
            {project.visibility}
          </Badge>,
        ].filter(Boolean)}
        actions={
          <>
            {canEditProject && (
              <Button variant="outline" onClick={() => router.push(`${projectBase}/edit`)}>
                <Pencil className="h-4 w-4 mr-2" />
                Edit
              </Button>
            )}
            {canDeleteProject && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    className="text-red-600 focus:text-red-600"
                    onClick={() => setDeleteProjectOpen(true)}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete project
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </>
        }
      />

      <StatCardGrid columns={4}>
        <StatCard
          title="Progress"
          value={`${stats?.progress ?? project.progress ?? 0}%`}
          sub={stats ? `${stats.completedTasks}/${stats.totalTasks} tasks done` : undefined}
          icon={CheckCircle2}
          color="text-emerald-600"
          index={0}
        />
        <StatCard
          title="Overdue tasks"
          value={stats?.overdueTasks ?? 0}
          icon={AlertTriangle}
          color="text-red-600"
          highlight={(stats?.overdueTasks ?? 0) > 0}
          index={1}
        />
        <StatCard
          title="Hours logged"
          value={`${project.loggedHours ?? 0}`}
          sub={`of ${project.estimatedHours ?? 0} estimated`}
          icon={Clock}
          color="text-blue-600"
          index={2}
        />
        <StatCard
          title="Team"
          value={project.team?.length ?? 0}
          icon={Users}
          color="text-violet-600"
          index={3}
        />
      </StatCardGrid>

      <Tabs defaultValue="overview" className="mt-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          {canViewMilestones && <TabsTrigger value="milestones">Milestones</TabsTrigger>}
          {canViewTasks && (
            <TabsTrigger value="tasks">Tasks{tasks.length > 0 && ` (${tasks.length})`}</TabsTrigger>
          )}
          {canViewTeam && <TabsTrigger value="team">Team ({project.team?.length ?? 0})</TabsTrigger>}
          {canViewChat && (
            <TabsTrigger value="chat" className="gap-1.5 relative">
              <MessageSquare className="h-3.5 w-3.5" />
              Chat
              {chatUnread > 0 && (
                <span className="absolute -top-1.5 -right-2 h-4 min-w-4 px-1 rounded-full bg-red-500 text-white text-[10px] leading-4 text-center">
                  {chatUnread > 9 ? '9+' : chatUnread}
                </span>
              )}
            </TabsTrigger>
          )}
          {canViewResources && <TabsTrigger value="resources">Resources</TabsTrigger>}
          <TabsTrigger value="reports" className="gap-1.5">
            <GanttChartSquare className="h-3.5 w-3.5" />
            Reports
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-4">
          {project.description?.trim() && (
            <Card>
              <CardHeader>
                <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className="prose prose-sm dark:prose-invert max-w-none"
                  dangerouslySetInnerHTML={{ __html: project.description }}
                />
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <CalendarIcon className="h-4.5 w-4.5 text-primary" />
                Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Start date</span>
                <span className="font-medium">{project.startDate ? formatDate(project.startDate) : '—'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">End date</span>
                <span className="font-medium flex items-center gap-1.5">
                  {project.endDate ? formatDate(project.endDate) : '—'}
                  {isOverdue && <AlertTriangle className="h-3.5 w-3.5 text-red-500" />}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Type</span>
                <span className="font-medium capitalize">{project.projectType}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Owner</span>
                <span className="font-medium">{project.owner?.name}</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {canViewMilestones && (
          <TabsContent value="milestones" className="space-y-5 mt-4">
            <StatCardGrid columns={3}>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Pending</p>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-2xl font-bold">{pendingCount}</span>
                    <MilestoneStatusBadge status="pending" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">In progress</p>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-2xl font-bold">{inProgressCount}</span>
                    <MilestoneStatusBadge status="in-progress" />
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground">Completed</p>
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-2xl font-bold">{completedCount}</span>
                    <MilestoneStatusBadge status="completed" />
                  </div>
                </CardContent>
              </Card>
            </StatCardGrid>

            {milestones.length === 0 ? (
              <EmptyState compact title="No milestones yet" description="Milestones you add to this project will show up here." />
            ) : (
              <div className="space-y-3">
                {milestones.map((milestone, index) => (
                  <Card key={milestone._id} className="transition-all duration-200 hover:shadow-md hover:border-primary/40">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold">
                          {index + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-semibold truncate">{milestone.name}</h3>
                            <MilestoneStatusBadge status={milestone.status} />
                          </div>
                          {milestone.description?.trim() && (
                            <div
                              className="mt-2 prose prose-sm dark:prose-invert max-w-none prose-p:my-1 prose-ul:my-2 prose-ol:my-2"
                              dangerouslySetInnerHTML={{ __html: milestone.description }}
                            />
                          )}
                          <div className="mt-3 flex flex-wrap items-center gap-5 text-xs text-muted-foreground">
                            <span>
                              <strong className="text-foreground">Start:</strong> {formatDate(milestone.startDate)}
                            </span>
                            <span>
                              <strong className="text-foreground">Due:</strong> {formatDate(milestone.dueDate)}
                            </span>
                          </div>
                        </div>
                        <div className="w-52 shrink-0">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-muted-foreground">Progress</span>
                            <span className="font-semibold">{milestone.progress}%</span>
                          </div>
                          <Progress value={milestone.progress} className="h-2" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        )}

        {canViewTasks && (
          <TabsContent value="tasks" className="space-y-4 mt-4">
            <div className="flex justify-end">
              {canCreateTask && (
                <Button onClick={() => setShowTaskDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Task
                </Button>
              )}
            </div>

            {isTasksLoading ? (
              <TableSkeleton rows={4} columns={8} />
            ) : tasks.length === 0 ? (
              <EmptyState compact title="No tasks yet" description="Add tasks to this project to get started." />
            ) : (
              <TasksTable
                tasks={tasks}
                isLoading={false}
                projectId={projectId}
                onEdit={() => {}}
                onTaskDeleted={invalidateProject}
              />
            )}
          </TabsContent>
        )}

        {canViewTeam && (
          <TabsContent value="team" className="mt-4">
            <ProjectTeamPanel project={project} isLoading={false} onChanged={invalidateProject} />
          </TabsContent>
        )}

        {canViewChat && (
          <TabsContent value="chat" className="mt-4">
            <ProjectChatTab project={project} canSend={canSendChat} />
          </TabsContent>
        )}

        {canViewResources && (
          <TabsContent value="resources" className="mt-4">
            <ProjectResourcesTab projectId={projectId} />
          </TabsContent>
        )}

        <TabsContent value="reports" className="space-y-4 mt-4 bg-white px-4 py-4 rounded-lg border">
          <Tabs defaultValue="gantt" className="w-full">
            <div className="flex items-center justify-between mb-6 flex-wrap gap-2">
              <TabsList>
                <TabsTrigger value="gantt" className="gap-1.5">
                  <GanttChartSquare className="h-4 w-4" />
                  Gantt Chart
                </TabsTrigger>
                <TabsTrigger value="kanban" className="gap-1.5">
                  <KanbanSquare className="h-4 w-4" />
                  Kanban Board
                </TabsTrigger>
                <button
                  type="button"
                  onClick={() => router.push(`${projectBase}/reports`)}
                  className="inline-flex h-9 items-center justify-center rounded-md px-3 text-sm font-medium transition-all hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <BarChart3 className="h-4 w-4 mr-1.5" />
                  Reports
                </button>
              </TabsList>

              <Button variant="outline" onClick={handleFullScreen}>
                <Maximize2 className="h-4 w-4 mr-2" />
                Full Screen Gantt
              </Button>
            </div>

            <TabsContent value="gantt">
              <ProjectGanttChart projectId={projectId} />
            </TabsContent>

            <TabsContent value="kanban">
              <KanbanBoard projectId={projectId} />
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>

      <TaskFormDialog
        open={showTaskDialog}
        onOpenChange={setShowTaskDialog}
        projectId={projectId}
        teamMembers={project.team || []}
        onCreated={invalidateProject}
      />

      <ConfirmDialog
        open={deleteProjectOpen}
        onOpenChange={setDeleteProjectOpen}
        title="Delete project?"
        description={`"${project.name}" will be moved to trash. Tasks and milestones go with it, and it can be restored later.`}
        confirmLabel="Delete"
        loading={isDeletingProject}
        onConfirm={handleConfirmDeleteProject}
      />

      <SuccessDialog {...feedback.successProps} />
      <ErrorDialog {...feedback.errorProps} />
    </div>
  );
}