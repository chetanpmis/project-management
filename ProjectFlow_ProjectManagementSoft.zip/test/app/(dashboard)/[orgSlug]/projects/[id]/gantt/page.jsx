// app/(dashboard)/[orgSlug]/projects/[projectId]/gantt/page.jsx
'use client';

import { useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { Maximize2 } from 'lucide-react';

import projectService from '@/services/project.service';
import useSidebarStore from '@/store/sidebar.store';

import PageHeader from '@/components/common/PageHeader';
import ProjectGanttChart from '@/components/projects/ProjectGanttChart';
import { Suspense } from 'react';
import GanttChartSkeleton from '@/components/common/GanttChartSkeleton';

import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

import EmptyState from '@/components/feedback/EmptyState';
import { CardListSkeleton } from '@/components/common/Skeletons';

export default function ProjectGanttPage() {
  const { orgSlug, projectId } = useParams();
  const router = useRouter();

  const base = `/${orgSlug}`;
  const projectBase = `${base}/projects/${projectId}`;

  const { collapsed, setCollapsed } = useSidebarStore();

  useEffect(() => {
    const previousState = collapsed;
    setCollapsed(true);
    return () => {
      setCollapsed(previousState);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const { data, isLoading } = useQuery({
    queryKey: ['project', projectId],
    queryFn: () => projectService.getProjectById(projectId),
    enabled: !!projectId,
  });

  const project = data?.data;

  if (isLoading) {
    return (
      <div className="max-w-full mx-auto">
        <PageHeader loading />
        <CardListSkeleton count={1} height="h-[700px]" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="max-w-3xl mx-auto p-8">
        <EmptyState
          title="Project not found"
          description="This project may have been deleted or you don't have access to it."
          action={
            <Button variant="outline" onClick={() => router.push(`${base}/projects`)}>
              Back to Projects
            </Button>
          }
        />
      </div>
    );
  }

  return (
    <div className="max-w-full mx-auto space-y-6">
      <PageHeader
        showBack
        title={`${project.name} - Gantt Chart`}
        description="View the complete project timeline, milestones, and task schedule."
        actions={
          <Button variant="outline" onClick={() => router.push(projectBase)}>
            <Maximize2 className="h-4 w-4 mr-2" />
            Exit Full Screen
          </Button>
        }
      />

      <Card className="overflow-hidden p-0">
        <Suspense fallback={<GanttChartSkeleton />}>
          <ProjectGanttChart projectId={projectId} />
        </Suspense>
      </Card>
    </div>
  );
}