// app/(dashboard)/[orgSlug]/projects/[projectId]/reports/page.jsx
'use client';

import { useEffect, useMemo, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  AreaChart,
  Area,
  Legend,
} from 'recharts';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  ListTodo,
  Users,
  TrendingUp,
  Flag,
  ExternalLink,
  Timer,
  ArrowLeft,
  FileDown,
  FileSpreadsheet,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import reportsService from '@/services/report.service';
import { exportReportsPDF, exportReportsExcel } from '@/lib/reportExport';

const STATUS_COLORS = {
  todo: '#94a3b8',
  inProgress: '#3b82f6',
  review: '#f59e0b',
  completed: '#10b981',
  overdue: '#ef4444',
};

const PRIORITY_COLORS = {
  low: '#94a3b8',
  medium: '#3b82f6',
  high: '#f59e0b',
  critical: '#ef4444',
};

const HEALTH_STYLES = {
  healthy: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  'at-risk': 'bg-amber-50 text-amber-700 border-amber-200',
  critical: 'bg-red-50 text-red-700 border-red-200',
};

const PRIORITY_BADGE = {
  low: 'bg-slate-50 text-slate-600 border-slate-200',
  medium: 'bg-blue-50 text-blue-700 border-blue-200',
  high: 'bg-amber-50 text-amber-700 border-amber-200',
  critical: 'bg-red-50 text-red-700 border-red-200',
};

const STATUS_BADGE = {
  todo: 'bg-slate-50 text-slate-600 border-slate-200',
  'in-progress': 'bg-blue-50 text-blue-700 border-blue-200',
  review: 'bg-amber-50 text-amber-700 border-amber-200',
  completed: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  pending: 'bg-slate-50 text-slate-600 border-slate-200',
};

const TREND_PERIODS = [
  { value: '7d', label: '7D' },
  { value: '30d', label: '30D' },
  { value: '90d', label: '90D' },
  { value: '6m', label: '6M' },
  { value: '1y', label: '1Y' },
];

const DEFAULT_TREND_PERIOD = '30d';

const LOADING_MESSAGES = [
  'Gathering project data…',
  'Crunching task numbers…',
  'Analyzing team performance…',
  'Calculating time logs…',
  'Building your charts…',
  'Almost ready…',
];

function fmtDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

function CircularProgress({ progress }) {
  const radius = 40;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;
  return (
    <div className="relative h-24 w-24">
      <svg width="96" height="96" className="-rotate-90">
        <circle cx="48" cy="48" r={radius} strokeWidth="8" fill="none" className="stroke-muted" />
        <circle
          cx="48"
          cy="48"
          r={radius}
          strokeWidth="8"
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="stroke-indigo-600 transition-[stroke-dashoffset] duration-300 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center text-lg font-semibold tabular-nums">
        {Math.round(progress)}%
      </div>
    </div>
  );
}

function ReportsLoadingScreen({ progress, messageIndex, stageIndex }) {
  const stage = LOADING_MESSAGES[stageIndex];
  const isComplete = stageIndex >= LOADING_MESSAGES.length - 1;

  return (
    <div className="space-y-8">
      <div className="flex flex-col items-center justify-center gap-4 py-10">
        <CircularProgress progress={progress} />
        <AnimatePresence mode="wait">
          <motion.p
            key={stageIndex}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.25 }}
            className="text-sm text-muted-foreground"
          >
            {stage}
          </motion.p>
        </AnimatePresence>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="h-28 rounded-xl" />
        ))}
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <Skeleton className="h-56 rounded-xl" />
        <Skeleton className="h-56 rounded-xl" />
      </div>
      <Skeleton className="h-64 rounded-xl" />
      <Skeleton className="h-48 rounded-xl" />
      <div className="grid lg:grid-cols-2 gap-4">
        <Skeleton className="h-64 rounded-xl" />
        <Skeleton className="h-64 rounded-xl" />
      </div>

      {isComplete && (
        <div className="text-center">
          <p className="text-xs text-emerald-600 font-medium flex items-center justify-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            Data is ready — charts will appear shortly
          </p>
        </div>
      )}
    </div>
  );
}

const KpiCard = ({ title, value, sub, icon: Icon, color, index = 0 }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.2, delay: index * 0.03 }}
    whileHover={{ y: -8 }}
  >
    <Card className="h-full overflow-hidden relative">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className={cn('p-2.5 rounded-xl bg-white shadow-sm', color)}>
          <Icon className="h-5 w-5" />
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="flex items-baseline gap-2">
          <span className="text-4xl font-bold tracking-tight">{value}</span>
        </div>
        {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
      </CardContent>

      <div className={cn('absolute -right-6 -bottom-6 opacity-5', color)}>
        <Icon className="h-20 w-20" />
      </div>
    </Card>
  </motion.div>
);

function SectionCard({ title, action, children, className, delay = 0 }) {
  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.25, delay }}>
      <Card className={className}>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          {action}
        </CardHeader>
        <CardContent>{children}</CardContent>
      </Card>
    </motion.div>
  );
}

export default function ProjectReportsPage() {
  const { orgSlug, projectId } = useParams();
  const router = useRouter();

  const base = `/${orgSlug}`;
  const projectBase = `${base}/projects/${projectId}`;

  const [trendPeriod, setTrendPeriod] = useState(DEFAULT_TREND_PERIOD);
  const [isExporting, setIsExporting] = useState(null);

  const [progress, setProgress] = useState(0);
  const [messageIndex, setMessageIndex] = useState(0);
  const [stageIndex, setStageIndex] = useState(0);
  const [showLoader, setShowLoader] = useState(true);

  const {
    data: dashboardRes,
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ['project-reports-dashboard', projectId],
    queryFn: () => reportsService.getProjectDashboard(projectId),
    enabled: !!projectId,
    staleTime: 60_000,
  });

  useEffect(() => {
    if (!isLoading) return undefined;

    setProgress(0);
    setShowLoader(true);
    setStageIndex(0);
    setMessageIndex(0);

    const progressTimer = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) return p;
        const step = p < 50 ? 6 : p < 75 ? 3 : 1.5;
        return Math.min(100, p + step);
      });
    }, 280);

    const stageTimer = setInterval(() => {
      setStageIndex((prev) => {
        const next = Math.min(prev + 1, LOADING_MESSAGES.length - 1);
        setMessageIndex(next);
        return next;
      });
    }, 1400);

    return () => {
      clearInterval(progressTimer);
      clearInterval(stageTimer);
    };
  }, [isLoading, projectId]);

  useEffect(() => {
    if (isLoading) return undefined;

    setProgress(100);
    const t = setTimeout(() => setShowLoader(false), 480);
    return () => clearTimeout(t);
  }, [isLoading]);

  const usingDefaultTrend = trendPeriod === DEFAULT_TREND_PERIOD;

  const { data: trendRes, isFetching: trendFetching } = useQuery({
    queryKey: ['project-completion-trend', projectId, trendPeriod],
    queryFn: () => reportsService.getProjectCompletionTrend(projectId, trendPeriod),
    enabled: !!projectId && !usingDefaultTrend,
    staleTime: 60_000,
  });

  const d = dashboardRes?.data;
  const overview = d?.overview;
  const taskStatus = d?.taskStatus;
  const milestones = useMemo(
    () => [...(d?.milestones || [])].sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate)),
    [d?.milestones]
  );
  const team = useMemo(
    () => [...(d?.teamPerformance || [])].sort((a, b) => b.assignedTasks - a.assignedTasks),
    [d?.teamPerformance]
  );
  const estVsActual = d?.estimatedVsActual;
  const overdue = d?.overdue;
  const trend = usingDefaultTrend ? d?.completionTrend : trendRes?.data;

  const statusPieData = taskStatus
    ? [
        { key: 'todo', name: 'Todo', value: taskStatus.todo },
        { key: 'inProgress', name: 'In progress', value: taskStatus.inProgress },
        { key: 'review', name: 'Review', value: taskStatus.review },
        { key: 'completed', name: 'Completed', value: taskStatus.completed },
      ].filter((s) => s.value > 0)
    : [];

  const priorityBarData = taskStatus
    ? [
        { name: 'Low', value: taskStatus.low, key: 'low' },
        { name: 'Medium', value: taskStatus.medium, key: 'medium' },
        { name: 'High', value: taskStatus.high, key: 'high' },
        { name: 'Critical', value: taskStatus.critical, key: 'critical' },
      ]
    : [];

  const varianceData = useMemo(
    () =>
      (estVsActual?.breakdown || [])
        .slice()
        .sort((a, b) => Math.abs(b.variance) - Math.abs(a.variance))
        .slice(0, 8)
        .map((t) => ({ name: t.title.length > 18 ? t.title.slice(0, 16) + '…' : t.title, ...t })),
    [estVsActual]
  );

  const handleExportPDF = async () => {
    if (!d) return;
    setIsExporting('pdf');
    try {
      exportReportsPDF(d, overview?.project?.name);
    } finally {
      setIsExporting(null);
    }
  };

  const handleExportExcel = async () => {
    if (!d) return;
    setIsExporting('excel');
    try {
      exportReportsExcel(d, overview?.project?.name);
    } finally {
      setIsExporting(null);
    }
  };

  const BackButton = (
    <Button variant="ghost" size="sm" className="gap-1.5 -ml-2 text-muted-foreground" onClick={() => router.back()}>
      <ArrowLeft className="h-4 w-4" />
      Back
    </Button>
  );

  const ExportButtons = (
    <div className="flex items-center gap-2">
      <Button
        variant="outline"
        size="sm"
        className="gap-1.5"
        disabled={!d || isExporting === 'pdf'}
        onClick={handleExportPDF}
      >
        <FileDown className="h-4 w-4" />
        {isExporting === 'pdf' ? 'Exporting…' : 'Export PDF'}
      </Button>
      <Button
        variant="outline"
        size="sm"
        className="gap-1.5"
        disabled={!d || isExporting === 'excel'}
        onClick={handleExportExcel}
      >
        <FileSpreadsheet className="h-4 w-4" />
        {isExporting === 'excel' ? 'Exporting…' : 'Export Excel'}
      </Button>
    </div>
  );

  if (isError) {
    return (
      <div className="p-6 max-w-7xl mx-auto space-y-4">
        {BackButton}
        <Card className="border-red-200">
          <CardContent className="p-6 flex items-center gap-3 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            <span>{error?.message || 'Failed to load project reports.'}</span>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showLoader) {
    return (
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {BackButton}
        <ReportsLoadingScreen progress={progress} messageIndex={messageIndex} stageIndex={stageIndex} />
      </div>
    );
  }

  const proj = overview?.project;
  const s = overview?.summary;

  const kpis = [
    { title: 'Total tasks', value: s?.totalTasks ?? 0, icon: ListTodo, color: 'text-blue-600' },
    {
      title: 'Completed',
      value: s?.completedTasks ?? 0,
      sub: s?.totalTasks ? `${Math.round((s.completedTasks / s.totalTasks) * 100)}% done` : undefined,
      icon: CheckCircle2,
      color: 'text-emerald-600',
    },
    { title: 'Overdue', value: s?.overdueTasks ?? 0, icon: AlertTriangle, color: 'text-red-600' },
    {
      title: 'Milestones',
      value: `${s?.completedMilestones ?? 0}/${s?.totalMilestones ?? 0}`,
      sub: 'completed',
      icon: Flag,
      color: 'text-purple-600',
    },
    { title: 'Team members', value: s?.teamMembers ?? 0, icon: Users, color: 'text-indigo-600' },
    { title: 'Estimated hrs', value: s?.estimatedHours ?? 0, icon: Clock, color: 'text-amber-600' },
    { title: 'Actual hrs', value: s?.actualHours ?? 0, icon: Timer, color: 'text-indigo-600' },
    { title: 'Remaining hrs', value: Math.round(s?.remainingHours ?? 0), icon: TrendingUp, color: 'text-purple-600' },
  ];

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {BackButton}
        {ExportButtons}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-wrap items-start justify-between gap-4"
      >
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-semibold">{proj?.name}</h1>
            {proj?.status && (
              <Badge variant="outline" className={cn('capitalize', STATUS_BADGE[proj.status] || '')}>
                {proj.status.replace('_', ' ')}
              </Badge>
            )}
            {proj?.priority && (
              <Badge variant="outline" className={cn('capitalize', PRIORITY_BADGE[proj.priority])}>
                <Flag className="h-3 w-3 mr-1" />
                {proj.priority}
              </Badge>
            )}
            {proj?.health && (
              <Badge variant="outline" className={cn('capitalize', HEALTH_STYLES[proj.health])}>
                {proj.health.replace('-', ' ')}
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            {fmtDate(proj?.startDate)} → {fmtDate(proj?.endDate)}
          </p>
        </div>

        <div className="flex items-center gap-3 min-w-[220px]">
          <div className="flex-1">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-muted-foreground">Overall progress</span>
              <span className="font-medium">{s?.progress ?? 0}%</span>
            </div>
            <Progress value={s?.progress ?? 0} className="h-2" />
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {kpis.map((card, i) => (
          <KpiCard key={card.title} {...card} index={i} />
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <SectionCard title="Tasks by status" delay={0.05}>
          {statusPieData.length === 0 ? (
            <p className="text-sm text-muted-foreground py-10 text-center">No tasks yet.</p>
          ) : (
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={statusPieData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2}>
                    {statusPieData.map((entry) => (
                      <Cell key={entry.key} fill={STATUS_COLORS[entry.key]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={24} iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </SectionCard>

        <SectionCard title="Tasks by priority" delay={0.08}>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={priorityBarData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} width={28} />
                <Tooltip />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {priorityBarData.map((entry) => (
                    <Cell key={entry.key} fill={PRIORITY_COLORS[entry.key]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </SectionCard>
      </div>

      <SectionCard
        title="Completion trend"
        delay={0.1}
        action={
          <div className="flex items-center rounded-md border p-0.5">
            {TREND_PERIODS.map((p) => (
              <Button
                key={p.value}
                size="sm"
                variant={trendPeriod === p.value ? 'default' : 'ghost'}
                className="h-7 px-2 text-xs"
                onClick={() => setTrendPeriod(p.value)}
              >
                {p.label}
              </Button>
            ))}
          </div>
        }
      >
        <div className={cn('h-64 transition-opacity', trendFetching && 'opacity-50')}>
          {!trend?.length ? (
            <p className="text-sm text-muted-foreground py-10 text-center">No trend data for this period.</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trend}>
                <defs>
                  <linearGradient id="cumulative" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 11 }}
                  tickFormatter={(v) => new Date(v).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                  minTickGap={30}
                />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} width={28} />
                <Tooltip labelFormatter={(v) => fmtDate(v)} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Area type="monotone" dataKey="cumulativeCompleted" name="Cumulative completed" stroke="#6366f1" fill="url(#cumulative)" strokeWidth={2} />
                <Area type="monotone" dataKey="completed" name="Completed / day" stroke="#10b981" fillOpacity={0} strokeWidth={1.5} />
                <Area type="monotone" dataKey="created" name="Created / day" stroke="#94a3b8" fillOpacity={0} strokeWidth={1.5} strokeDasharray="4 3" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </SectionCard>

      <SectionCard title="Milestones" delay={0.12}>
        {milestones.length === 0 ? (
          <p className="text-sm text-muted-foreground py-6 text-center">No milestones yet.</p>
        ) : (
          <div className="space-y-4">
            {milestones.map((m) => (
              <div key={m._id} className="border rounded-lg p-3">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-medium truncate">{m.name}</span>
                    <Badge variant="outline" className={cn('capitalize text-[10px]', STATUS_BADGE[m.status])}>
                      {m.status.replace('-', ' ')}
                    </Badge>
                    <Badge variant="outline" className={cn('capitalize text-[10px]', PRIORITY_BADGE[m.priority])}>
                      {m.priority}
                    </Badge>
                    {m.overdueTasks > 0 && (
                      <Badge variant="outline" className="text-[10px] bg-red-50 text-red-700 border-red-200">
                        {m.overdueTasks} overdue
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground shrink-0">{fmtDate(m.startDate)} → {fmtDate(m.dueDate)}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Progress value={m.progress} className="h-2 flex-1" />
                  <span className="text-xs font-medium w-10 text-right">{m.progress}%</span>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-[11px] text-muted-foreground">
                  <span>{m.totalTasks} tasks</span>
                  <span>{m.completedTasks} completed</span>
                  <span>{m.inProgressTasks} in progress</span>
                  <span>{m.todoTasks} todo</span>
                  <span>{m.estimatedHours}h estimated</span>
                  <span>{m.actualHours}h logged</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <div className="grid lg:grid-cols-2 gap-4">
        <SectionCard title="Team performance" delay={0.14}>
          {team.length === 0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">No team activity yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Member</TableHead>
                  <TableHead className="text-right">Assigned</TableHead>
                  <TableHead className="text-right">Done</TableHead>
                  <TableHead className="text-right">Overdue</TableHead>
                  <TableHead className="text-right">Logged</TableHead>
                  <TableHead className="text-right">Completion</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {team.map((m) => (
                  <TableRow key={m._id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <span className="h-6 w-6 rounded-full bg-muted flex items-center justify-center text-[10px] font-medium shrink-0">
                          {(m.name || '?').slice(0, 2).toUpperCase()}
                        </span>
                        <span className="truncate max-w-[120px]">{m.name || 'Unknown'}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">{m.assignedTasks}</TableCell>
                    <TableCell className="text-right">{m.completedTasks}</TableCell>
                    <TableCell className={cn('text-right', m.overdueTasks > 0 && 'text-red-600 font-medium')}>
                      {m.overdueTasks}
                    </TableCell>
                    <TableCell className="text-right">{m.loggedHours}h</TableCell>
                    <TableCell className="text-right">
                      <span
                        className={cn(
                          'inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium',
                          m.completionRate >= 70
                            ? 'bg-emerald-50 text-emerald-700'
                            : m.completionRate >= 40
                            ? 'bg-amber-50 text-amber-700'
                            : 'bg-slate-50 text-slate-600'
                        )}
                      >
                        {m.completionRate}%
                      </span>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </SectionCard>

        <SectionCard title="Estimated vs actual (top variance)" delay={0.16}>
          {!estVsActual?.summary ? (
            <p className="text-sm text-muted-foreground py-6 text-center">No time-tracking data yet.</p>
          ) : (
            <>
              <div className="grid grid-cols-4 gap-2 mb-3 text-center">
                <div>
                  <p className="text-sm font-semibold">{estVsActual.summary.estimatedHours}h</p>
                  <p className="text-[10px] text-muted-foreground">Estimated</p>
                </div>
                <div>
                  <p className="text-sm font-semibold">{estVsActual.summary.actualHours}h</p>
                  <p className="text-[10px] text-muted-foreground">Actual</p>
                </div>
                <div>
                  <p className={cn('text-sm font-semibold', estVsActual.summary.variance > 0 ? 'text-red-600' : 'text-emerald-600')}>
                    {estVsActual.summary.variance > 0 ? '+' : ''}
                    {estVsActual.summary.variance}h
                  </p>
                  <p className="text-[10px] text-muted-foreground">Variance</p>
                </div>
                <div>
                  <p className="text-sm font-semibold">{estVsActual.summary.utilization}%</p>
                  <p className="text-[10px] text-muted-foreground">Utilization</p>
                </div>
              </div>
              {varianceData.length === 0 ? (
                <p className="text-sm text-muted-foreground py-6 text-center">No tasks with estimates yet.</p>
              ) : (
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={varianceData} layout="vertical" margin={{ left: 8, right: 12 }}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" tick={{ fontSize: 11 }} />
                      <YAxis type="category" dataKey="name" width={100} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Bar dataKey="estimatedHours" name="Estimated" fill="#94a3b8" radius={[0, 3, 3, 0]} />
                      <Bar dataKey="actualHours" name="Actual" fill="#6366f1" radius={[0, 3, 3, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </>
          )}
        </SectionCard>
      </div>

      <SectionCard
        title="Overdue tasks"
        delay={0.18}
        action={
          overdue?.summary?.totalOverdue > 0 && (
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              {overdue.summary.totalOverdue} overdue
            </Badge>
          )
        }
      >
        {!overdue?.tasks?.length ? (
          <p className="text-sm text-muted-foreground py-6 text-center">Nothing overdue — you're on track.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Task</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead className="text-right">Progress</TableHead>
                <TableHead>Due</TableHead>
                <TableHead className="text-right">Days overdue</TableHead>
                <TableHead className="w-8" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {overdue.tasks.map((t) => (
                <TableRow key={t._id}>
                  <TableCell className="font-medium max-w-[200px] truncate">{t.title}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={cn('capitalize text-[10px]', PRIORITY_BADGE[t.priority])}>
                      {t.priority}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">{t.progress}%</TableCell>
                  <TableCell className="text-muted-foreground">{fmtDate(t.dueDate)}</TableCell>
                  <TableCell className="text-right font-medium text-red-600">{t.daysOverdue}d</TableCell>
                  <TableCell>
                    {/* ⭐ was /tasks/${t._id} — now scoped inside the current project */}
                    <button
                      title="Open task"
                      className="text-muted-foreground hover:text-foreground"
                      onClick={() => router.push(`${projectBase}/tasks/${t._id}`)}
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                    </button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>
    </div>
  );
}