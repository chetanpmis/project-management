// app/(dashboard)/[orgSlug]/projects/create/page.jsx
'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Loader2,
  Check,
  ClipboardList,
  CalendarDays,
  Eye,
  AlertCircle,
  Pencil,
  X,
} from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import projectService from '@/services/project.service';
import useOrganizationStore from '@/store/organization-store';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import PageHeader from '@/components/common/PageHeader';
import { SuccessDialog, ErrorDialog } from '@/components/common/AppDialogs';
import { validateDateRange } from '@/lib/dateValidation';
import { cn } from '@/lib/utils';
import RichTextEditor from '@/components/common/RichTextEditor';
import { formatDate } from '@/lib/date';
import {
  PROJECT_STATUS_CONFIG,
  PRIORITY_CONFIG,
  MILESTONE_STATUS_CONFIG,
} from '@/lib/statusConfig';

const typeOptions = ['internal', 'client', 'product'];
const priorityOptions = Object.keys(PRIORITY_CONFIG);

const steps = [
  { id: 1, label: 'Project info' },
  { id: 2, label: 'Schedule' },
  { id: 3, label: 'Milestones' },
  { id: 4, label: 'Preview' },
];

const stepFields = {
  1: ['name'],
  2: ['startDate', 'endDate', 'estimatedHours'],
};

const schema = z
  .object({
    name: z.string().min(1, 'Project name is required'),
    description: z.string().optional(),
    projectType: z.enum(typeOptions),
    status: z.enum(Object.keys(PROJECT_STATUS_CONFIG)),
    priority: z.enum(priorityOptions),
    startDate: z.string().min(1, 'Start date is required'),
    endDate: z.string().min(1, 'End date is required'),
    estimatedHours: z.coerce.number().min(0),
  })
  .refine((data) => new Date(data.endDate) >= new Date(data.startDate), {
    message: 'End date must be after the start date',
    path: ['endDate'],
  });

const milestoneSchema = z
  .object({
    name: z.string().min(1, 'Milestone name is required'),
    description: z.string().optional(),
    startDate: z.string().min(1, 'Start date is required'),
    dueDate: z.string().min(1, 'Due date is required'),
  })
  .refine((data) => new Date(data.dueDate) >= new Date(data.startDate), {
    message: 'Due date must be after the start date',
    path: ['dueDate'],
  });

const emptyMilestoneValues = { name: '', description: '', startDate: '', dueDate: '' };

function FieldLabel({ children, required }) {
  return (
    <Label className="text-base font-medium text-foreground">
      {children}
      {required && <span className="text-red-500 ml-0.5">*</span>}
    </Label>
  );
}

function FieldError({ message }) {
  if (!message) return null;
  return (
    <p className="text-red-500 text-sm flex items-center gap-1 mt-1.5">
      <AlertCircle className="h-3.5 w-3.5" /> {message}
    </p>
  );
}

function SectionCard({ icon: Icon, title, description, children }) {
  return (
    <Card>
      <CardHeader className="pb-5">
        <div className="flex items-center gap-2.5">
          {Icon && (
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary shrink-0">
              <Icon className="h-4.5 w-4.5" />
            </span>
          )}
          <div>
            <CardTitle className="text-xl font-semibold">{title}</CardTitle>
            {description && <CardDescription className="text-base">{description}</CardDescription>}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-7">{children}</CardContent>
    </Card>
  );
}

function StepIndicator({ currentStep }) {
  return (
    <div className="flex items-start w-full">
      {steps.map((step, idx) => {
        const isComplete = currentStep > step.id;
        const isActive = currentStep === step.id;
        return (
          <div key={step.id} className="flex items-center flex-1 last:flex-none">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 text-sm font-semibold transition-colors',
                  isComplete && 'border-primary bg-primary text-primary-foreground',
                  isActive && 'border-primary text-primary',
                  !isComplete && !isActive && 'border-muted text-muted-foreground'
                )}
              >
                {isComplete ? <Check className="h-4.5 w-4.5" /> : step.id}
              </div>
              <span className={cn('mt-2 text-sm font-medium whitespace-nowrap', isActive || isComplete ? 'text-foreground' : 'text-muted-foreground')}>
                {step.label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <div className={cn('h-px flex-1 mx-4 mt-[18px]', isComplete ? 'bg-primary' : 'bg-border')} />
            )}
          </div>
        );
      })}
    </div>
  );
}

function isEmptyHtml(html) {
  if (!html) return true;
  const stripped = html.replace(/<p><\/p>|<p><br\s*\/?><\/p>/g, '').trim();
  return stripped.length === 0;
}

function deepTrim(value) {
  if (typeof value === 'string') return value.trim();
  if (Array.isArray(value)) return value.map(deepTrim);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, deepTrim(v)]));
  }
  return value;
}

export default function CreateProjectPage() {
  const { orgSlug } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();

  // The active org (with its real Mongo _id) lives in the store, kept in
  // sync by the [orgSlug] layout. This is what was missing before — the
  // page was calling createProject() with only the payload and no
  // organization id at all.
  const organization = useOrganizationStore((s) => s.organization);

  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [currentStep, setCurrentStep] = useState(1);

  const [milestones, setMilestones] = useState([]);
  const [editingMilestoneId, setEditingMilestoneId] = useState(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    watch,
    setValue,
    trigger,
    reset,
  } = useForm({
    resolver: zodResolver(schema),
    mode: 'onChange',
  });

  const milestoneForm = useForm({
    resolver: zodResolver(milestoneSchema),
    defaultValues: emptyMilestoneValues,
  });

  const projectStart = watch('startDate');
  const projectEnd = watch('endDate');

  const createMutation = useMutation({
    mutationFn: (payload) => projectService.createProject(organization._id, payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setShowSuccess(true);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to create project');
      setShowError(true);
    },
  });

  const onSubmit = (data) => {
    const trimmedData = deepTrim(data);
    const trimmedMilestones = deepTrim(milestones);

    const payload = {
      ...trimmedData,
      milestones: trimmedMilestones.length > 0 ? trimmedMilestones : undefined,
    };
    createMutation.mutate(payload);
  };

  const getMilestoneId = (m) => m._id ?? m.name;

  const startEditMilestone = (milestone) => {
    setEditingMilestoneId(getMilestoneId(milestone));
    milestoneForm.reset({
      name: milestone.name,
      description: milestone.description || '',
      startDate: milestone.startDate,
      dueDate: milestone.dueDate,
    });
  };

  const cancelEditMilestone = () => {
    setEditingMilestoneId(null);
    milestoneForm.reset(emptyMilestoneValues);
  };

  const saveMilestone = () => {
    milestoneForm.handleSubmit((data) => {
      const trimmed = deepTrim(data);
      trimmed.description = isEmptyHtml(trimmed.description) ? '' : trimmed.description;
      const { startError, endError } = validateDateRange({
        start: trimmed.startDate,
        end: trimmed.dueDate,
        bounds: { min: projectStart, max: projectEnd },
        startLabel: 'Milestone start',
        endLabel: 'Milestone due date',
      });
      if (startError) {
        milestoneForm.setError('startDate', { type: 'manual', message: startError });
        return;
      }
      if (endError) {
        milestoneForm.setError('dueDate', { type: 'manual', message: endError });
        return;
      }

      if (editingMilestoneId) {
        setMilestones((prev) =>
          prev.map((m) => (getMilestoneId(m) === editingMilestoneId ? { ...m, ...trimmed } : m))
        );
      } else {
        setMilestones((prev) => [...prev, trimmed]);
      }

      setEditingMilestoneId(null);
      milestoneForm.reset(emptyMilestoneValues);
    })();
  };

  const removeMilestone = (id) => {
    setMilestones((prev) => prev.filter((m) => getMilestoneId(m) !== id));
    if (editingMilestoneId === id) cancelEditMilestone();
  };

  const msStart = milestoneForm.watch('startDate');
  const msDescription = milestoneForm.watch('description');

  const sortedMilestones = [...milestones].sort(
    (a, b) => new Date(a.startDate) - new Date(b.startDate)
  );

  useEffect(() => {
    reset({
      name: '',
      description: '',
      projectType: 'internal',
      status: 'planning',
      priority: 'medium',
      startDate: '',
      endDate: '',
      estimatedHours: 0,
    });
  }, [reset]);

  const nextStep = async () => {
    if (currentStep === 3) {
      setCurrentStep(currentStep + 1);
      return;
    }
    const fieldsToValidate = stepFields[currentStep];
    const valid = fieldsToValidate ? await trigger(fieldsToValidate) : true;
    if (valid && currentStep < steps.length) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleSuccessClose = () => {
    setShowSuccess(false);
    router.push(`/${orgSlug}/projects`);
  };

  return (
    <div className="min-h-screen max-w-full">
      <form onSubmit={handleSubmit(onSubmit)} className="w-full">
        <PageHeader showBack size="form" title="New project" description="Set up a project, its schedule, and milestones." />

        <div className="rounded-2xl border border-border p-6 lg:p-10 space-y-8">
          <StepIndicator currentStep={currentStep} />

          {/* Step 1 — Project info */}
          <div className={cn('transition-opacity duration-300', currentStep === 1 ? 'block' : 'hidden')}>
            <SectionCard icon={ClipboardList} title="Project information" description="What this project is and who it's for.">
              <div className="space-y-2">
                <FieldLabel required>Project name</FieldLabel>
                <Input placeholder="e.g. Q4 Marketing Campaign" {...register('name')} className={cn('h-12 text-base w-full', errors.name && 'border-red-500 focus-visible:ring-red-500')} />
                <FieldError message={errors.name?.message} />
              </div>

              <div className="space-y-2">
                <FieldLabel>Description</FieldLabel>
                <RichTextEditor
                  value={watch('description')}
                  onChange={(html) => setValue('description', html, { shouldValidate: true, shouldDirty: true })}
                  placeholder="A couple of sentences on scope and goals…"
                  error={errors.description}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <FieldLabel>Type</FieldLabel>
                  <Select defaultValue={typeOptions[0]} onValueChange={(v) => setValue('projectType', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {typeOptions.map((t) => (
                        <SelectItem key={t} value={t} className="capitalize text-base">{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                

                <div className="space-y-2">
                  <FieldLabel>Priority</FieldLabel>
                  <Select defaultValue="medium" onValueChange={(v) => setValue('priority', v)}>
                    <SelectTrigger className="h-12 text-base w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorityOptions.map((p) => (
                        <SelectItem key={p} value={p} className="capitalize text-base">
                          {PRIORITY_CONFIG[p]?.label || p}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Step 2 — Schedule */}
          <div className={cn('transition-opacity duration-300 space-y-8', currentStep === 2 ? 'block' : 'hidden')}>
            <SectionCard icon={CalendarDays} title="Schedule" description="When the project runs.">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel required>Start date</FieldLabel>
                  <Input type="date" className="h-12 text-base w-full" {...register('startDate')} />
                  <FieldError message={errors.startDate?.message} />
                </div>

                <div className="space-y-2">
                  <FieldLabel required>End date</FieldLabel>
                  <Input type="date" className="h-12 text-base w-full" min={projectStart || undefined} {...register('endDate')} />
                  <FieldError message={errors.endDate?.message} />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <FieldLabel>Estimated hours</FieldLabel>
                  <Input type="number" placeholder="120" {...register('estimatedHours', { valueAsNumber: true })} className={cn('h-12 text-base w-full', errors.estimatedHours && 'border-red-500 focus-visible:ring-red-500')} />
                  <FieldError message={errors.estimatedHours?.message} />
                </div>
              </div>
            </SectionCard>
          </div>

          {/* Step 3 — Milestones */}
          <div className={cn('transition-opacity duration-300', currentStep === 3 ? 'block' : 'hidden')}>
            <SectionCard
              icon={ClipboardList}
              title="Milestones"
              description={
                editingMilestoneId
                  ? 'Editing an existing milestone — update the fields below and save.'
                  : 'Add, review, edit, or remove milestones for the project.'
              }
            >
              {editingMilestoneId && (
                <div className="flex items-center gap-2 rounded-lg border border-primary/30 bg-primary/5 px-4 py-3 text-sm text-primary">
                  <Pencil className="h-4 w-4 shrink-0" />
                  Editing milestone — changes will replace the original entry when you save.
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <FieldLabel required>Milestone name</FieldLabel>
                  <Input placeholder="e.g. MVP Foundation" {...milestoneForm.register('name')} />
                  <FieldError message={milestoneForm.formState.errors.name?.message} />
                </div>

                <div className="space-y-2">
                  <FieldLabel required>Start date</FieldLabel>
                  <Input
                    type="date"
                    className="h-12 text-base w-full"
                    min={projectStart || undefined}
                    max={projectEnd || undefined}
                    {...milestoneForm.register('startDate')}
                  />
                  <FieldError message={milestoneForm.formState.errors.startDate?.message} />
                </div>

                <div className="space-y-2">
                  <FieldLabel required>Due date</FieldLabel>
                  <Input
                    type="date"
                    className="h-12 text-base w-full"
                    min={msStart || projectStart || undefined}
                    max={projectEnd || undefined}
                    {...milestoneForm.register('dueDate')}
                  />
                  <FieldError message={milestoneForm.formState.errors.dueDate?.message} />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <FieldLabel>Description</FieldLabel>
                  <RichTextEditor
                    value={msDescription}
                    onChange={(html) =>
                      milestoneForm.setValue('description', html, {
                        shouldValidate: true,
                        shouldDirty: true,
                      })
                    }
                    placeholder="Optional description"
                    error={milestoneForm.formState.errors.description}
                    minHeight={120}
                  />
                  <FieldError message={milestoneForm.formState.errors.description?.message} />
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 mt-6">
                <Button type="button" onClick={saveMilestone} className="w-full">
                  {editingMilestoneId ? 'Update milestone' : '+ Add milestone'}
                </Button>
                {editingMilestoneId && (
                  <Button type="button" variant="outline" onClick={cancelEditMilestone} className="w-full sm:w-auto">
                    Cancel edit
                  </Button>
                )}
              </div>

              {sortedMilestones.length > 0 && (
                <div className="mt-8">
                  <h4 className="font-medium mb-3">Milestones ({sortedMilestones.length})</h4>
                  <div className="space-y-3">
                    {sortedMilestones.map((milestone, index) => {
                      const id = getMilestoneId(milestone);
                      const isBeingEdited = id === editingMilestoneId;
                      return (
                        <div
                          key={id ?? index}
                          className={cn(
                            'flex items-center justify-between gap-3 rounded-lg border p-4 transition-colors',
                            isBeingEdited ? 'border-primary bg-primary/5' : 'border-border'
                          )}
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <p className="font-medium">{milestone.name}</p>
                              {milestone.status && MILESTONE_STATUS_CONFIG[milestone.status] && (
                                <Badge variant="outline" className={cn('text-xs', MILESTONE_STATUS_CONFIG[milestone.status].badge)}>
                                  {MILESTONE_STATUS_CONFIG[milestone.status].label}
                                </Badge>
                              )}
                              {isBeingEdited && (
                                <Badge variant="secondary" className="text-xs">Editing</Badge>
                              )}
                            </div>
                            {!isEmptyHtml(milestone.description) && (
                              <div
                                className="prose prose-sm dark:prose-invert max-w-none text-sm text-muted-foreground mt-1"
                                dangerouslySetInnerHTML={{ __html: milestone.description }}
                              />
                            )}
                            <p className="text-sm text-muted-foreground mt-2">
                              Start: {formatDate(milestone.startDate)} • Due: {formatDate(milestone.dueDate)}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="text-muted-foreground hover:text-primary"
                              onClick={() => startEditMilestone(milestone)}
                              title="Edit milestone"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="text-muted-foreground hover:text-red-600"
                              onClick={() => removeMilestone(id)}
                              title="Remove milestone"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </SectionCard>
          </div>

          {/* Step 4 — Preview */}
          <div className={cn('transition-opacity duration-300', currentStep === 4 ? 'block' : 'hidden')}>
            <SectionCard icon={Eye} title="Preview" description="All your project details — ready to create!">
              <div className="space-y-6">
                <div className="space-y-2">
                  <FieldLabel>Project name</FieldLabel>
                  <div className="bg-muted/30 rounded-md px-4 py-3 text-base font-medium">{watch('name') || '—'}</div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Description</FieldLabel>
                  <div
                    className="prose prose-sm dark:prose-invert bg-muted/30 rounded-md px-4 py-3 min-h-[88px] text-base max-w-none"
                    dangerouslySetInnerHTML={{ __html: isEmptyHtml(watch('description')) ? '—' : watch('description') }}
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
                  
                  <div className="space-y-2">
                    <FieldLabel>Priority</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">
                      {PRIORITY_CONFIG[watch('priority')]?.label ?? '—'}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Start</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{formatDate(projectStart)}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>End</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{formatDate(projectEnd)}</div>
                  </div>
                  <div className="space-y-2">
                    <FieldLabel>Estimated hours</FieldLabel>
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base">{watch('estimatedHours')}</div>
                  </div>
                </div>

                <div className="space-y-2">
                  <FieldLabel>Milestones ({sortedMilestones.length})</FieldLabel>
                  {sortedMilestones.length === 0 ? (
                    <div className="bg-muted/30 rounded-md px-4 py-3 text-base text-muted-foreground">No milestones added yet (optional).</div>
                  ) : (
                    <div className="space-y-3">
                      {sortedMilestones.map((milestone, index) => (
                        <div key={milestone._id ?? `${milestone.name}-${index}`} className="bg-muted/30 rounded-md px-4 py-3 text-sm">
                          <p className="font-medium">{milestone.name}</p>
                          {!isEmptyHtml(milestone.description) && (
                            <div
                              className="prose prose-sm dark:prose-invert max-w-none text-muted-foreground mt-1"
                              dangerouslySetInnerHTML={{ __html: milestone.description }}
                            />
                          )}
                          <p className="text-xs text-muted-foreground mt-3">
                            Start: {formatDate(milestone.startDate)} • Due: {formatDate(milestone.dueDate)}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

               
              </div>
            </SectionCard>
          </div>

          {/* Bottom navigation */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div>
              {currentStep > 1 && (
                <Button type="button" variant="outline" onClick={prevStep} className="h-12 px-6 text-base">
                  Previous
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3">
              {currentStep === steps.length && (
                <Button type="button" variant="outline" onClick={() => router.back()} className="h-12 px-6 text-base">
                  Cancel
                </Button>
              )}

              {currentStep < steps.length && (
                <Button type="button" onClick={nextStep} className="h-12 px-8 text-base">
                  Next
                </Button>
              )}

              {currentStep === steps.length && (
                <Button type="submit" disabled={isSubmitting || createMutation.isPending || !organization} className="h-12 px-8 text-base min-w-[180px]">
                  {isSubmitting || createMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Creating project…
                    </>
                  ) : (
                    'Create project'
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      </form>

      <SuccessDialog
        open={showSuccess}
        onOpenChange={setShowSuccess}
        title="Project created"
        description="Your project has been created successfully."
        actionLabel="Go to projects"
        onAction={handleSuccessClose}
      />
      <ErrorDialog
        open={showError}
        onOpenChange={setShowError}
        title="Creation failed"
        description={errorMessage}
      />
    </div>
  );
}