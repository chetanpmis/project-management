"use client";

import { useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Building2, Users, UserPlus, Trash2, Shield, Crown, MoreVertical, Mail } from "lucide-react";
import { toast } from "sonner";

import organizationService from "@/services/organization.service";
import { ORG_ROLE_OPTIONS, ORG_ROLE_META } from "@/constants/organizationPermissions";
import { useOrgPermission, useIsOrgOwner, useOrgMembership } from "@/hooks/useOrgPermission";
import OrgPermissionGate from "@/components/organizations/OrgPermissionGate";
import InviteMemberDialog from "@/components/organizations/InviteMemberDialog";
import PermissionsDialog from "@/components/organizations/PermissionsDialog";
import InvitationsTable from "@/components/organizations/InvitationsTable";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import PageHeader from "@/components/common/PageHeader";
import EmptyState from "@/components/feedback/EmptyState";
import NoPermissionState from "@/components/feedback/NoPermissionState";
import StatCard, { StatCardGrid } from "@/components/common/StatCard";
import { CardListSkeleton } from "@/components/common/Skeletons";
import { ConfirmDialog } from "@/components/common/AppDialogs";

export default function OrganizationDetailPage() {
  const { orgSlug } = useParams();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [inviteOpen, setInviteOpen] = useState(false);
  const [permissionsMember, setPermissionsMember] = useState(null);
  const [removeTarget, setRemoveTarget] = useState(null);
  const [isRemoving, setIsRemoving] = useState(false);

  const { data: orgRes, isLoading, error } = useQuery({
    queryKey: ["organization", orgSlug],
    queryFn: () => organizationService.getOrganization(orgSlug),
    enabled: !!orgSlug,
    retry: (failureCount, err) => err?.status !== 403 && err?.status !== 404 && failureCount < 2,
  });

  const org = orgRes?.data;

  const isOwner = useIsOrgOwner(org);
  const myMembership = useOrgMembership(org);
  const canInvite = useOrgPermission(org, "team.invite");
  const canManageInvitations = useOrgPermission(org, "team.invite.manage");
  const canChangeRoles = useOrgPermission(org, "team.role.edit");
  const canRemove = useOrgPermission(org, "team.remove");
  const canEditPermissions = useOrgPermission(org, "team.permissions.edit");

  const acceptedMembers = org?.members?.filter((m) => m.status === "accepted") || [];

  const roleMutation = useMutation({
    mutationFn: ({ userId, role }) => organizationService.updateMemberRole(orgSlug, userId, role),
    onSuccess: () => {
      toast.success("Role updated.");
      queryClient.invalidateQueries({ queryKey: ["organization", orgSlug] });
    },
    onError: (err) => toast.error(err.message || "Failed to update role."),
  });

  const removeMutation = useMutation({
    mutationFn: (userId) => organizationService.removeMember(orgSlug, userId),
    onSuccess: () => {
      toast.success("Member removed.");
      queryClient.invalidateQueries({ queryKey: ["organization", orgSlug] });
      setRemoveTarget(null);
      setIsRemoving(false);
    },
    onError: (err) => {
      toast.error(err.message || "Failed to remove member.");
      setIsRemoving(false);
    },
  });

  const handleConfirmRemove = () => {
    setIsRemoving(true);
    removeMutation.mutate(removeTarget.user._id);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6 lg:p-8">
        <div className="max-w-6xl mx-auto space-y-6">
          <PageHeader loading />
          <CardListSkeleton count={3} height="h-16" />
        </div>
      </div>
    );
  }

  if (error?.status === 403) {
    return (
      <div className="min-h-screen bg-background p-6 lg:p-8">
        <div className="max-w-3xl mx-auto">
          <NoPermissionState
            title="You don't have access to this organization"
            description="You may have a pending invitation, or you may need to ask an admin to add you."
          />
          <div className="flex justify-center mt-4">
            <Button variant="outline" onClick={() => router.push("/organizations")}>
              Back to organizations
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!org) {
    return (
      <div className="min-h-screen bg-background p-6 lg:p-8">
        <div className="max-w-3xl mx-auto">
          <EmptyState
            title="Organization not found"
            description="This organization may have been deleted, or you may not have access to it."
            action={
              <Button variant="outline" onClick={() => router.push("/organizations")}>
                Back to organizations
              </Button>
            }
          />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-background rounded-md p-4 lg:p-4">
      <div className="max-w-full mx-auto">
        <PageHeader
          showBack
          title={org.name}
          eyebrow={`/${org.slug}`}
          badges={[
            isOwner && (
              <Badge key="owner" variant="outline" className="gap-1">
                <Crown className="h-3 w-3" /> Owner
              </Badge>
            ),
          ].filter(Boolean)}
          actions={
            <OrgPermissionGate org={org} permission="team.invite" inline>
              <Button onClick={() => setInviteOpen(true)} className="inline-flex items-center gap-2 whitespace-nowrap">
                <UserPlus className="h-4 w-4" />
                Invite Member
              </Button>
            </OrgPermissionGate>
          }
        />

        <StatCardGrid columns={3}>
          <StatCard title="Members" value={acceptedMembers.length} icon={Users} color="text-blue-600" index={0} />
          <StatCard
            title="Your role"
            value={isOwner ? "Owner" : ORG_ROLE_META[myMembership?.role]?.label || "—"}
            icon={Shield}
            color="text-violet-600"
            index={1}
          />
          <StatCard title="Organization slug" value={`/${org.slug}`} icon={Building2} color="text-zinc-600" index={2} />
        </StatCardGrid>

        <Tabs defaultValue="members" className="mt-6">
          <TabsList>
            <TabsTrigger value="members">Members ({acceptedMembers.length})</TabsTrigger>
            <TabsTrigger value="invitations" className="gap-1.5">
              <Mail className="h-3.5 w-3.5" />
              Invitations
            </TabsTrigger>
            <TabsTrigger value="overview">Overview</TabsTrigger>
          </TabsList>

          {/* Members tab — invite action lives here now instead of a separate Pending tab */}
          <TabsContent value="members" className="mt-4 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <p className="text-sm text-muted-foreground">Accepted members of this organization.</p>
              <OrgPermissionGate org={org} permission="team.invite" inline>
                <Button variant="outline" size="sm" onClick={() => setInviteOpen(true)} className="inline-flex items-center gap-1.5">
                  <UserPlus className="h-3.5 w-3.5" />
                  Invite Member
                </Button>
              </OrgPermissionGate>
            </div>

            {acceptedMembers.length === 0 ? (
              <EmptyState compact title="No members yet" description="Invite your team to get started." />
            ) : (
              acceptedMembers.map((member) => {
                const isMemberOwner = member.role === "owner";
                const meta = ORG_ROLE_META[member.role] || ORG_ROLE_META.member;
                return (
                  <Card key={member.user?._id}>
                    <CardContent className="p-4 flex items-center justify-between gap-4 flex-wrap">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>{member.user?.name?.slice(0, 2)?.toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium truncate">{member.user?.name}</p>
                            {isMemberOwner && <Crown className="h-3.5 w-3.5 text-amber-500 shrink-0" />}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{member.user?.email}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {isMemberOwner ? (
                          <Badge variant="outline" className={meta.badgeClass}>{meta.label}</Badge>
                        ) : canChangeRoles ? (
                          <Select
                            value={member.role}
                            onValueChange={(role) => roleMutation.mutate({ userId: member.user._id, role })}
                            // Only lock the dropdown for an ADMIN target when the viewer isn't the
                            // true owner — this matches the backend's updateMemberRole guard
                            // exactly. Member targets are never locked by this condition.
                            disabled={member.role === "admin" && !isOwner}
                          >
                            <SelectTrigger className="h-9 w-[120px] text-sm capitalize">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {ORG_ROLE_OPTIONS.filter((r) => r !== "admin" || isOwner).map((r) => (
                                <SelectItem key={r} value={r} className="capitalize text-sm">{r}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        ) : (
                          // canChangeRoles is false — this person's persisted permissions don't
                          // include team.role.edit. Showing the badge (not a disabled dropdown)
                          // makes it clear this is a permission gap, not a UI bug.
                          <Badge variant="outline" className={meta.badgeClass}>{meta.label}</Badge>
                        )}

                        {!isMemberOwner && (canEditPermissions || canRemove) && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-9 w-9">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {canEditPermissions && (
                                <DropdownMenuItem onClick={() => setPermissionsMember(member)}>
                                  <Shield className="h-4 w-4 mr-2" />
                                  Edit permissions
                                </DropdownMenuItem>
                              )}
                              {canRemove && (
                                <DropdownMenuItem
                                  className="text-red-600 focus:text-red-600"
                                  onClick={() => setRemoveTarget(member)}
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Remove member
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </TabsContent>

          {/* Invitations tab — all pending/accepted/declined/expired/revoked invites live here,
              replacing the old separate "Pending" tab entirely */}
          <TabsContent value="invitations" className="mt-4">
            <InvitationsTable org={org} orgId={orgSlug} />
          </TabsContent>

          <TabsContent value="overview" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Building2 className="h-4.5 w-4.5 text-primary" />
                  About
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between gap-4">
                  <span className="text-muted-foreground shrink-0">Description</span>
                  <span className="font-medium text-right">{org.description || "—"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Owner</span>
                  <span className="font-medium">{org.owner?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Slug</span>
                  <span className="font-medium">/{org.slug}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Created</span>
                  <span className="font-medium">{new Date(org.createdAt).toLocaleDateString()}</span>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <InviteMemberDialog open={inviteOpen} onOpenChange={setInviteOpen} orgId={orgSlug} isOwner={isOwner} />
        <PermissionsDialog
          open={!!permissionsMember}
          onOpenChange={(v) => !v && setPermissionsMember(null)}
          orgId={orgSlug}
          org={org}
          member={permissionsMember}
        />
        <ConfirmDialog
          open={!!removeTarget}
          onOpenChange={(v) => !v && setRemoveTarget(null)}
          title="Remove member?"
          description={`"${removeTarget?.user?.name}" will lose access to "${org.name}" and its projects.`}
          confirmLabel="Remove"
          loading={isRemoving}
          onConfirm={handleConfirmRemove}
        />
      </div>
    </div>
  );
}