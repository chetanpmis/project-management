// store/organizationStore.js
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useOrganizationStore = create(
  persist(
    (set, get) => ({
      activeOrganizationId: null,
      activeOrganizationSlug: null,
      organization: null,
      organizations: [],

      setOrganizations: (orgs) => set({ organizations: orgs }),

      // Called every time ["organization", slug] refetches — this is how
      // permission changes (role edit, permissions edit, removal) propagate
      // to every consumer of useOrgPermission / the sidebar without a
      // separate "refresh permissions" action.
      setActiveOrganization: (org) =>
        set({
          organization: org,
          activeOrganizationId: org?._id ?? null,
          activeOrganizationSlug: org?.slug ?? null,
        }),

      clearActiveOrganization: () =>
        set({ organization: null, activeOrganizationId: null, activeOrganizationSlug: null }),

      can: (permission) => !!get().organization?.currentUserPermissions?.can?.[permission],
      isOwner: () => !!get().organization?.currentUserPermissions?.isOwner,
      role: () => get().organization?.currentUserPermissions?.role ?? null,
    }),
    {
      name: 'active-organization',
      partialize: (state) => ({
        activeOrganizationId: state.activeOrganizationId,
        activeOrganizationSlug: state.activeOrganizationSlug,
      }),
    }
  )
);

export default useOrganizationStore;